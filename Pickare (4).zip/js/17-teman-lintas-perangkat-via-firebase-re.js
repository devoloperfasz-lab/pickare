/* ===== TEMAN LINTAS PERANGKAT via Firebase Realtime Database (tanpa kode room) ===== */
(function(){
const h=t=>{let x=2166136261;for(let i=0;i<t.length;i++)x=Math.imul(x^t.charCodeAt(i),16777619);return(x>>>0).toString(36)};
const myRoom=()=>('f-'+h(me.name)).slice(0,14);
let lob=null,RG={},creating=0;
const clean=g=>{const d=JSON.parse(JSON.stringify(g));delete d.thumb;delete d.icon;delete d.by;delete d.mb;d.pub=true;d.name=String(d.name||'Game').slice(0,22);d.emoji=String(d.emoji||'').slice(0,4);if(!Array.isArray(d.objs))d.objs=[];if(d.objs.length>800)d.objs.length=800;return d};
const card=()=>{const p=me.pres&&me.pres.g?me.pres:null;let game=null;if(p){const g=allGames().find(x=>x.id==p.g)||RG[p.g];if(g){try{game=clean(g)}catch(e){}}}return{n:me.name,av:me.av,pres:p,game,t:Date.now()}};
const track=()=>{if(lob&&lob.ready&&me){try{lob.ch.track(card())}catch(e){}}};
function syncUsers(st){if(!me)return;const on={};
 for(const k in st){const e=st[k][st[k].length-1];if(!e||!e.n||e.n===me.name)continue;on[e.n]=1;
  let u=users[e.n];if(!u)u=users[e.n]={rm:1,bux:0,av:e.av,games:[],notes:[]};
  if(!u.rm)continue;u.av=e.av||u.av;u.pres=e.pres&&e.pres.g?{g:String(e.pres.g),room:String(e.pres.room||'').toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,16),t:Date.now()}:null;
  if(e.game&&e.game.id&&u.pres&&rel(e.n)=='friend'){try{const g=clean(e.game);RG[g.id]=g;u.games=[g]}catch(x){u.games=[]}}else u.games=[]}
 for(const k in users){const u=users[k];if(u.rm&&!on[k]){u.pres=null;u.games=[]}}
 save();flush();try{refreshUI()}catch(e){}}
function send(to,t,x){const ev={id:Math.random().toString(36).slice(2,10),to,from:me.name,t,x:x||'',av:me.av,ts:Date.now()};(me.ob=me.ob||[]).push(ev);try{window.spInboxPut&&spInboxPut(ev)}catch(e){}save();flush()}
function flush(){if(!lob||!lob.ready||!me||!me.ob)return;me.ob=me.ob.filter(e=>Date.now()-e.ts<6048e5);me.ob.forEach(ev=>{try{lob.ch.send({type:'broadcast',event:'ev',payload:ev})}catch(e){}})}
function onEv(p){if(!p||!me)return;
 if(p.t==='ack'){if(p.to===me.name&&me.ob){me.ob=me.ob.filter(e=>e.id!==p.id);save()}return}
 if(p.to!==me.name||!p.from)return;
 try{lob.ch.send({type:'broadcast',event:'ev',payload:{t:'ack',to:p.from,id:p.id}})}catch(e){}
 me.seen=me.seen||[];if(me.seen.includes(p.id))return;me.seen.push(p.id);if(me.seen.length>200)me.seen.shift();
 const n=String(p.from).slice(0,20);if(!users[n])users[n]={rm:1,bux:0,av:p.av,games:[],notes:[]};
 const f=FRD(me),x=p.t;
 if(x==='freq'){if(!f.f.includes(n)){if(f.o.includes(n)){f.o=f.o.filter(y=>y!=n);f.f.push(n);pushNote(me,n+' menerima permintaan pertemananmu')}else if(!f.i.includes(n)){f.i.push(n);pushNote(me,n+' mengirim permintaan pertemanan')}}}
 else if(x==='facc'){f.o=f.o.filter(y=>y!=n);if(!f.f.includes(n))f.f.push(n);pushNote(me,n+' menerima permintaan pertemananmu')}
 else if(x==='fdec'){f.o=f.o.filter(y=>y!=n)}
 else if(x==='fcan'){f.i=f.i.filter(y=>y!=n)}
 else if(x==='funf'){f.f=f.f.filter(y=>y!=n);f.i=f.i.filter(y=>y!=n)}
 else if(x==='msg'&&f.f.includes(n)){const t=String(p.x||'').slice(0,200);if(t){(me.chat=me.chat||{})[n]=(me.chat[n]||[]).concat({me:0,t,ts:Date.now()}).slice(-80);(me.unr=me.unr||{})[n]=((me.unr||{})[n]||0)+1;pushNote(me,n+': '+t.slice(0,40))}}
 save();try{refreshUI()}catch(e){}}
window.__spOnEv=p=>onEv(p);
async function lobby(){if(!me||creating||(lob&&lob.nm===me.name))return;creating=1;
 try{const sb=await spSB();if(lob){try{sb.removeChannel(lob.ch)}catch(e){}lob=null}
  const ch=sb.channel('sp-lobby-v1',{config:{presence:{key:me.name},broadcast:{self:false,ack:false}}}),L={ch,nm:me.name,ready:0};lob=L;
  ch.on('presence',{event:'sync'},()=>syncUsers(ch.presenceState()));
  ch.on('broadcast',{event:'ev'},({payload})=>onEv(payload));
  ch.subscribe(st=>{if(st==='SUBSCRIBED'){L.ready=1;track();flush()}})}catch(e){}creating=0}
window.addEventListener('load',()=>{
 const _sg=startGame;startGame=function(g,test){const r=_sg.apply(this,arguments);setTimeout(track,400);return r};
 const _st=stopGame;stopGame=function(){const r=_st.apply(this,arguments);setTimeout(track,400);return r};
 const _out=act.out;act.out=function(){try{if(lob&&window.__sb){window.__sb.removeChannel(lob.ch)}}catch(e){}lob=null;return _out.apply(this,arguments)};
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(lobby,400);return r};
 [['freq','none'],['facc','recv'],['fdec','recv'],['fcan','sent'],['funf','friend']].forEach(([k,need])=>{const o=act[k];act[k]=function(n){const b=rel(n),r=o.apply(this,arguments);if(b===need&&users[n]&&users[n].rm)send(n,k,'');return r}});
 const os=act.say;act.say=function(){const i=$('#mi'),t=i?i.value.trim():'',n=thread;const r=os.apply(this,arguments);if(t&&n&&users[n]&&users[n].rm&&rel(n)=='friend')send(n,'msg',t);return r};
 const R=render;window.render=render=function(){R.apply(this,arguments);try{
  if(page!=='home')return;const rc=document.getElementById('rc');if(rc){const c=rc.closest('.card'),hh=c&&c.previousElementSibling;if(hh&&hh.classList.contains('sec'))hh.style.display='none';if(c)c.style.display='none'}
  const k=document.getElementById('rkc');if(k)k.style.display='none';
  if(document.getElementById('frh'))return;const fl=friends(),m=document.querySelector('#main .page')||$('#main');
  const html='<h3 class="sec">Teman</h3><div class="card" id="frh"><div style="margin-bottom:10px">'+(fl.length?fl.map(x=>'<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><b style="flex:1">'+esc(x.n)+'<small style="display:block;font-weight:400">'+(x.pl?'Bermain: '+esc(x.g):'Offline')+'</small></b>'+(x.pl?'<button class="btn sm g" data-a="join" data-v="'+esc(x.n)+'">Gabung</button>':'')+'</div>').join(''):'<small>Belum ada teman. Tambah teman, lalu bergabung ke game mereka.</small>')+'</div><button class="btn w" data-a="ppl">+ Cari / Tambah Teman</button></div>';
  if(rc&&rc.closest('.card'))rc.closest('.card').insertAdjacentHTML('afterend',html);else m.insertAdjacentHTML('beforeend',html)}catch(e){}};
 setInterval(()=>{if(me&&$('#app').classList.contains('on')){lobby();track()}},6000);
 if(me&&$('#app').classList.contains('on'))setTimeout(lobby,800)});
})();
