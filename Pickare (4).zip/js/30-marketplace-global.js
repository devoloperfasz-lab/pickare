/* ===== MARKETPLACE GLOBAL: aksesori & model tampil di semua pemain, bisa dibeli, dipakai, dan terlihat pemain lain =====
   - Aksesori yang dipublish (Studio) dan Model/Suara yang dipublish (Toko Model) dikirim sebagai pesan "retained"
     ke broker MQTT publik (topik pickare/v9/acc/<id> dan pickare/v9/mdl/<id>), sama seperti katalog map.
   - HP lain subscribe ke topik itu -> item langsung muncul di Marketplace / Toko Model mereka.
   - Beli: PickBux pembeli berkurang, kreator di HP lain menerima PickBux lewat kotak masuk (event "sale").
   - Aksesori yang sedang dipakai ikut dikirim di presence room (Firebase) sehingga pemain lain melihatnya di avatar. */
(function(){
const BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const PA='pickare/v9/acc/',PM='pickare/v9/mdl/',MAXB=700000;
const mq=()=>window.__spMq;
const lib=()=>mq()?mq().lib():Promise.resolve(0);
const hsh=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)+t.length};
const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const unb64=t=>{const s=atob(t),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u};
const pipe=async(data,S)=>{const st=new S('gzip'),w=st.writable.getWriter();w.write(data);w.close();return new Uint8Array(await new Response(st.readable).arrayBuffer())};
const enc=async o=>{const j=JSON.stringify(o);if(window.CompressionStream){try{return 'z1:'+b64(await pipe(new TextEncoder().encode(j),CompressionStream))}catch(e){}}return 'j1:'+j};
const dec=async s=>{try{if(s.startsWith('x1:'))return{dead:1,ts:+s.slice(3)||0};if(s.startsWith('j1:'))return JSON.parse(s.slice(3));if(s.startsWith('z1:'))return JSON.parse(new TextDecoder().decode(await pipe(unb64(s.slice(3)),DecompressionStream)))}catch(e){}return null};
const shrink=(src,w,h,q)=>new Promise(res=>{if(!src)return res('');const im=new Image();im.onload=()=>{try{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d'),r=Math.max(w/im.width,h/im.height),dw=im.width*r,dh=im.height*r;x.drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);res(c.toDataURL('image/jpeg',q))}catch(e){res('')}};im.onerror=()=>res('');im.src=src});
const hx=(c,f)=>/^#[0-9a-f]{6}$/i.test(c||'')?c:f;
const okI=u=>/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(u||'')?u:'';
const num=(v,d,lo,hi)=>{v=+v;return isFinite(v)?Math.max(lo,Math.min(hi,v)):d};
const price=v=>Math.max(0,Math.min(9999,Math.floor(+v||0)));
const nm=(s,n)=>String(s==null?'':s).replace(/[\u0000-\u001f<>"&]/g,'').slice(0,n);
const BAD=/^(pickare|owner|admin|coowner|co-owner)$/i;
const arr=v=>Array.isArray(v)?v:(v&&typeof v==='object'?Object.values(v):[]);
const toast_=m=>{try{toast(m)}catch(e){}};

/* ---- pembersih objek 3D (data dari HP lain tidak dipercaya) ---- */
const TY=['cyl','ball','part','box'];
function cleanObjs(a,max,noId){const out=[];for(const o of arr(a)){if(out.length>=max)break;if(!o||typeof o!=='object'||o.t==='coin')continue;
 const r={t:(TY.includes(o.t)||o.t==='grass'||o.t==='video')?o.t:'part',x:num(o.x,0,-60,60),y:num(o.y,0,-60,60),z:num(o.z,0,-60,60),sx:num(o.sx,1,.05,30),sy:num(o.sy,1,.05,30),sz:num(o.sz,1,.05,30),ry:num(o.ry,0,-720,720),rx:num(o.rx,0,-720,720),rz:num(o.rz,0,-720,720),c:hx(o.c,'#ffffff')};
 if(!noId)r.id='r'+Math.random().toString(36).slice(2,9);
 if(typeof o.tex==='string'&&/^[a-z0-9_-]{1,24}$/i.test(o.tex))r.tex=o.tex;if(r.t==='grass'||r.t==='video')r.cc=false;if(o.t==='video'){if(typeof o.vurl==='string'&&/^https:\/\/[^\s]{4,300}$/i.test(o.vurl))r.vurl=o.vurl;if(typeof o.vid==='string'&&/^v_[a-z0-9]{1,24}$/i.test(o.vid))r.vid=o.vid;if(o.vmode==='efek')r.vmode='efek';r.vop=num(o.vop,1,.05,1)}out.push(r)}return out}

/* ---- pembersih item dari katalog ---- */
const FXT=['Fire','Smoke','Sparkles','ParticleEmitter','Explosion','PointLight'];
function cleanFx(l){const n=(v,a,b,d)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):d};return arr(l).slice(0,6).map(d=>{if(!d||FXT.indexOf(d.c)<0)return null;return{q:(Array.isArray(d.q)&&d.q.length===4)?d.q.map(v=>n(v,-30,30,0)):undefined,c:d.c,e:d.e===0?0:1,r:n(d.r,0,60,20),l:n(d.l,.05,6,1.5),s:n(d.s,0,30,3),z:n(d.z,.02,4,.5),a:n(d.a,0,180,30),g:n(d.g,-30,30,0),k:hx(d.k,'#ffffff'),b:n(d.b,0,20,1),n:n(d.n,1,40,16)}}).filter(Boolean)}
function cleanAcc(a){if(!a||typeof a!=='object')return null;const by=nm(a.by,20),id=String(a.id||'').replace(/[^\w-]/g,'').slice(0,24);if(!by||!id||BAD.test(by))return null;
 const objs=cleanObjs(a.objs,80);if(!objs.length)return null;
 return{key:'u_'+by+'_'+id,name:nm(a.name,22)||'Aksesoris',e:'',icon:okI(a.icon),price:price(a.price),by,objs,desc:nm(a.desc,140),slot:nm(a.slot,14)||'Kepala',rp:1,fx:cleanFx(a.fx)}}
function cleanMdl(m,id){if(!m||typeof m!=='object')return null;const kind=m.kind==='sound'?'sound':'model';
 const r={id:String(m.id||id).replace(/[^\w-]/g,'').slice(0,24),kind,name:nm(m.name,40)||'Model',desc:nm(m.desc,160),by:nm(m.by,20),t:num(m.t,Date.now(),0,4e12),thumb:okI(m.thumb)||null,price:price(m.price),rp:1};
 if(!r.id||!r.by||BAD.test(r.by))return null;
 if(kind==='sound'){if(!/^data:audio\/[\w.+-]+;base64,[A-Za-z0-9+\/=]+$/.test(m.snd||''))return null;r.snd=m.snd}
 else{const d=m.data;if(!d||typeof d!=='object')return null;if(!Array.isArray(d.objs))d.objs=[];if(!d.svc||typeof d.svc!=='object')d.svc={};r.data=d}
 return r}

/* ---- state katalog ---- */
let RACC=[];window.spRMD=[];
try{const c=ls.get('sp_acccache',[]);if(Array.isArray(c))RACC=c.filter(x=>x&&x.key&&x.by&&Array.isArray(x.objs)).slice(0,150)}catch(e){}
const MDL=()=>{const a=ls.get('sp_models',[]);return Array.isArray(a)?a:[]};
const remoteItems=()=>RACC.filter(x=>x.by!==(me&&me.name)&&!banOf(users[x.by])).map(x=>Object.assign({},x,{v:!!(users[x.by]&&users[x.by].verified)}));

/* ---- Marketplace: gabungkan item online ---- */
const _mk=mkItems;
mkItems=function(){const a=_mk.apply(this,arguments),k=new Set(a.map(x=>x.key));return a.concat(remoteItems().filter(x=>!k.has(x.key))).filter(x=>{if(!x.by||!String(x.key).startsWith('u_'+x.by+'_'))return true;return !window.tkBlk('acc',x.by,x.key.slice(('u_'+x.by+'_').length))})};

/* ---- kirim (publish / unpublish) ---- */
let syncing=0;
async function sync(){if(syncing||typeof users==='undefined'||typeof me==='undefined'||!me)return;syncing=1;
 try{const sigs=ls.get('sp_mktsig',{}),cur={};
  Object.keys(users).forEach(un=>{const u=users[un];if(!u||u.rm||banOf(u))return;(u.items||[]).forEach(i=>{if(i&&i.pub===true&&!(i.rv&&i.rv.s&&i.rv.s!=='approved')&&!i.src&&i.id&&Array.isArray(i.objs)&&i.objs.length)cur[PA+(hsh(un)+'_'+String(i.id).replace(/[^\w-]/g,''))]={k:'a',un,i}})});
  MDL().forEach(m=>{if(m&&m.id&&m.by&&(!m.rv||m.rv.s==='approved')&&!BAD.test(m.by)&&!banOf(users[m.by]))cur[PM+String(m.id).replace(/[^\w-]/g,'')]={k:'m',m}});
  const msgs=[],upd={};let nA=0,nM=0;
  for(const t in cur){const x=cur[t];let sg,build;
   if(x.k==='a'){const i=x.i,objs=cleanObjs(i.objs,80,1);sg=hsh(JSON.stringify([i.name,i.desc,i.price,i.icon,i.slot,objs,x.un,window.__fxOf?window.__fxOf(i):0]));
    build=async()=>{const ic=i.icon?await shrink(i.icon,96,96,.75):'';return{ts:Date.now(),a:{id:i.id,name:i.name,desc:i.desc||'',icon:ic,by:x.un,price:price(i.price),slot:i.slot||'Kepala',objs,fx:(window.__fxOf?window.__fxOf(i):[])}}}}
   else{const m=x.m;sg=hsh(JSON.stringify([m.name,m.desc,m.price,m.by,m.kind,m.thumb,m.kind==='sound'?m.snd:m.data]));
    build=async()=>{const d=Object.assign({},m);d.price=price(m.price);return{ts:Date.now(),m:d}}}
   const e=sigs[t];if(e&&e.s===sg&&Date.now()-e.t<216e5)continue;
   const body=await build();if(!body)continue;const p=await enc(body);
   if(p.length>MAXB){toast_('"'+(x.k==='a'?x.i.name:x.m.name)+'" terlalu besar untuk dibagikan online');upd[t]={s:sg,t:Date.now()};continue}
   msgs.push({t,p});upd[t]={s:sg,t:Date.now()};x.k==='a'?nA++:nM++}
  const gone=[];for(const t in sigs)if(!cur[t]){msgs.push({t,p:'x1:'+Date.now()});gone.push(t)}
  if(!msgs.length){if(Object.keys(upd).length){for(const t in upd)sigs[t]=upd[t];ls.set('sp_mktsig',sigs)}return}
  if(!(window.mqtt||await lib()))return;
  const ok=await mq().pushAll(msgs);
  if(ok){for(const t in upd)sigs[t]=upd[t];gone.forEach(t=>delete sigs[t]);ls.set('sp_mktsig',sigs);
   if(nA||nM)toast_('Dibagikan ke semua pemain ✓')}
  else if(nA||nM)toast_('Gagal membagikan item, akan dicoba lagi')
 }catch(e){}finally{syncing=0}}

/* ---- terima ---- */
function fetchAll(){return new Promise(async res=>{if(!(window.mqtt||await lib()))return res(null);const got={a:{},m:{}};let pend=BR.length,fin=0;
 const out=()=>{if(fin)return;fin=1;res(got)};
 BR.forEach(url=>{let done=0,m;const ps=[];const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}Promise.all(ps).then(()=>{if(--pend===0)out()})};
  try{m=mqtt.connect(url,{clientId:'spm_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)out();return}
  m.on('error',end);m.on('close',end);
  m.on('connect',()=>{m.subscribe([PA+'+',PM+'+'],{qos:0});setTimeout(end,4500)});
  m.on('message',(t,b)=>{const isA=t.startsWith(PA),id=t.slice((isA?PA:PM).length).replace(/[^\w-]/g,'');if(!id)return;
   ps.push(dec(b.toString()).then(d=>{const B=isA?got.a:got.m;if(d&&d.ts&&(!B[id]||d.ts>B[id].ts))B[id]=d}))});
  setTimeout(end,9000)});
 setTimeout(out,11000)})}
let fetching=0,lastPull=0,lastSig='';
async function pull(force){if(fetching||typeof me==='undefined'||!me)return;if(!force&&Date.now()-lastPull<8000)return;fetching=1;lastPull=Date.now();window.spMLoading=1;try{window.spStoreRefresh&&spStoreRefresh()}catch(e){}
 try{const got=await fetchAll();if(!got||(!Object.keys(got.a).length&&!Object.keys(got.m).length))return;
  const A=[],Mo=[];
  for(const id in got.a){const d=got.a[id];if(!d||d.dead||!d.a)continue;const x=cleanAcc(d.a);if(x){x._ts=d.ts;A.push(x)}}
  for(const id in got.m){const d=got.m[id];if(!d||d.dead||!d.m)continue;const x=cleanMdl(d.m,id);if(x){x._ts=d.ts;Mo.push(x)}}
  A.sort((a,b)=>b._ts-a._ts);Mo.sort((a,b)=>b.t-a.t);
  const sg=A.map(x=>x.key+':'+x._ts).join(',')+'|'+Mo.map(x=>x.id+':'+x._ts).join(',');if(sg===lastSig)return;lastSig=sg;
  RACC=A;window.spRMD=Mo;try{ls.set('sp_acccache',A.slice(0,150))}catch(e){}
  refresh()}catch(e){}finally{fetching=0;window.spMLoading=0;try{window.spStoreRefresh&&spStoreRefresh()}catch(e){}}}
function marketOpen(){try{return page==='avatar'&&typeof avt!=='undefined'&&avt==='mkt'}catch(e){return false}}
function storeOpen(){const s=document.getElementById('sto');return !!(s&&s.classList.contains('on'))}
function refresh(){try{if(window.spStoreRefresh)spStoreRefresh();
 const a=document.getElementById('app'),sh=document.getElementById('sh');
 if(!(a&&a.classList.contains('on')&&marketOpen()&&!(sh&&sh.classList.contains('on'))))return;
 /* update di tempat: hanya daftar item yang diganti, tanpa render ulang halaman (tidak ada getaran / scroll lompat) */
 const tmp=document.createElement('div');tmp.innerHTML=avP();const nw=tmp.querySelector('.ig'),cur=document.querySelector('#main .ig');
 if(!nw)return;
 if(cur){if(cur.innerHTML===nw.innerHTML)return;cur.innerHTML=nw.innerHTML}
 else{const sheet=document.querySelector('#main .sheet');if(!sheet)return;const em=[...sheet.children].find(c=>/Belum ada item/.test(c.textContent||'')&&!c.classList.contains('ban')&&!c.classList.contains('chips'));if(em)em.remove();sheet.appendChild(nw)}
 document.querySelectorAll('#main .ig .it').forEach(e=>{e.style.animation='none'})}catch(e){}}

/* ---- bayar kreator yang ada di HP lain (kotak masuk MQTT) ---- */
function payCreator(by,name,p){if(!p||!by||by===(me&&me.name))return;const cr=users[by];
 if(cr&&!cr.rm){cr.bux=(cr.bux||0)+p;try{nt(cr,me.name+' membeli "'+name+'" +'+p+' PickBux')}catch(e){}save();return}
 const ev={id:Math.random().toString(36).slice(2,10),to:by,from:me.name,t:'sale',x:JSON.stringify({n:name,p}),ts:Date.now()};
 try{window.spInboxPut&&spInboxPut(ev)}catch(e){}}
const _oe=window.__spOnEv;
window.__spOnEv=function(p){
 if(p&&p.t==='sale'&&typeof me!=='undefined'&&me&&p.to===me.name){
  me.seen=me.seen||[];if(me.seen.includes(p.id))return;me.seen.push(p.id);if(me.seen.length>200)me.seen.shift();
  let d={};try{d=JSON.parse(p.x||'{}')}catch(e){}const a=price(d&&d.p);
  if(a>0){me.bux=(me.bux||0)+a;try{notify(nm(p.from,20)+' membeli "'+nm(d.n,40)+'" +'+a+' PickBux')}catch(e){}}
  save();try{navRender()}catch(e){}return}
 return _oe?_oe.apply(this,arguments):undefined};

/* ---- beli aksesori online: bayar kreator + simpan ikon ---- */
const _b2=act.buy2;
act.buy2=function(k){const it=mkItems().find(x=>x.key===k),had=(me.items||[]).length;const r=_b2?_b2.apply(this,arguments):undefined;
 try{if(it&&(me.items||[]).length>had){const n=(me.items||[]).find(x=>x.src===k);if(n&&it.icon&&!n.icon)n.icon=it.icon;if(it.rp)payCreator(it.by,it.name,price(it.price));save()}}catch(e){}
 return r};

/* ---- beli model / suara (dipanggil dari Toko Model) ---- */
window.spPayModel=function(m){const p=price(m.price);if(!p||m.by===me.name)return true;
 me.mbought=me.mbought||[];const id=String(m.id);if(me.mbought.includes(id))return true;
 if(me.bux<p){toast_('PickBux tidak cukup · butuh '+p);return false}
 addBux(-p);me.mbought.push(id);if(me.mbought.length>500)me.mbought.shift();
 payCreator(m.by,m.name,p);save();try{notify('Membeli '+(m.kind==='sound'?'suara':'model')+' "'+m.name+'" -'+p+' PickBux')}catch(e){}return true};

/* ---- aksesori yang sedang dipakai ikut terkirim ke pemain lain ---- */
const r2=v=>Math.round((+v||0)*100)/100,CODE={cyl:'c',ball:'s'};
let _k='',_v=[];
window.spAcc=function(){try{const ids=((typeof forceAcc!=='undefined'&&forceAcc)||me.av.acc||[]).slice(0,4),items=me.items||[];
 const key=ids.map(id=>{const it=items.find(i=>i.id==id);return id+':'+(it&&it.objs?it.objs.length:0)+(it&&it.slot||'')}).join('|');if(key===_k)return _v;
 const out=[];let tot=0;ids.forEach(id=>{const it=items.find(i=>i.id==id);if(!it||!Array.isArray(it.objs))return;
  const rows=[];for(const o of cleanObjs(it.objs,60,1)){if(tot>=100)break;const r=[CODE[o.t]||'p',r2(o.x),r2(o.y),r2(o.z),r2(o.sx),r2(o.sy),r2(o.sz),Math.round(o.ry),o.c];const bd=it.slot==='Tubuh'||it.slot==='Avatar';if(bd){r.push(o.tex||'',String(o.n||'').slice(0,20))}else if(o.tex)r.push(o.tex);rows.push(r);tot++}
  if(rows.length){const e={i:String(id).slice(0,24),o:rows};if(it.slot==='Tubuh'||it.slot==='Avatar')e.b=1;else if(/^(Alat|Perlengkapan)$/.test(it.slot||''))e.h=1;out.push(e)}});
 _k=key;_v=out;return out}catch(e){return []}};
window.spApplyAcc=function(o,ac){const list=arr(ac).slice(0,4);const sig=list.length?JSON.stringify(list):'';if(o.acs===sig)return;o.acs=sig;
 if(o.ag){o.ag.parent&&o.ag.parent.remove(o.ag);o.ag=null}
 if(o.bl){o.bl.forEach(m=>m.parent&&m.parent.remove(m));o.bl=null}
 if(o.hid){o.hid.forEach(m=>m.visible=true);o.hid=null}
 if(!list.length)return;
 const grp=new THREE.Group();let n=0;const T={c:'cyl',s:'ball',p:'part'};
 if(list.some(a=>a&&a.b)){o.hid=[];o.g.traverse(m=>{if(m.isMesh&&m.visible){m.visible=false;o.hid.push(m)}});o.bl=[]}if(!o.bl)o.bl=[];
 const named=list.some(a=>a&&a.b&&arr(a.o).some(r=>window.__limbName&&window.__limbName(arr(r)[10])));
 list.forEach(a=>{const isB=!!(a&&a.b);arr(a&&a.o).forEach(r=>{const v=arr(r);if(n>=100||v.length<9)return;n++;
  const ob={t:T[v[0]]||'part',x:num(v[1],0,-60,60),y:num(v[2],0,-60,60),z:num(v[3],0,-60,60),sx:num(v[4],1,.05,30),sy:num(v[5],1,.05,30),sz:num(v[6],1,.05,30),ry:num(v[7],0,-720,720),c:hx(v[8],'#ffffff')};
  if(typeof v[9]==='string'&&/^[a-z0-9_-]{1,24}$/i.test(v[9]))ob.tex=v[9];
  try{const m=mkObj(ob);let p=null;
   if(isB){const nm=String(v[10]||'').toLowerCase(),L=o.g.l||[],A=o.g.a||[];
    p=window.__limbPick?window.__limbPick(nm,ob,A,L,named):null}else if(a&&a.h&&o.g.a)p=o.g.a[1];
   if(p){m.position.x-=p.position.x;m.position.y-=p.position.y;m.position.z-=p.position.z;p.add(m);o.bl.push(m)}else grp.add(m)}catch(e){}})});
 o.ag=grp;o.g.add(grp)};

/* ---- jadwal ---- */
setInterval(()=>{if(typeof me!=='undefined'&&me)sync()},10000);
setInterval(()=>{if(typeof me==='undefined'||!me||document.hidden)return;if(marketOpen()||storeOpen())pull()},3000);
setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)pull()},40000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&typeof me!=='undefined'&&me){pull();sync()}});
const wrap=(k,f)=>{const o=act[k];act[k]=function(){const r=o?o.apply(this,arguments):undefined;try{f.apply(this,arguments)}catch(e){}return r}};
['pmgo','hpub','edpub','pdgo','stdel'].forEach(k=>wrap(k,()=>setTimeout(sync,500)));
wrap('stoopen',()=>pull(1));
/* Insert by ID: kalau model dibuat pemain lain & belum ada di HP ini, ambil dulu dari jaringan */
{const midOf=v=>{const m=String(v||'').match(/\d{6,}/);return m?m[0]:String(v||'').trim()},
 hasM=id=>MDL().some(m=>String(m.id)===id)||(window.spRMD||[]).some(m=>String(m.id)===id);
 async function ensureM(id){if(!id||hasM(id))return;toast_('Mencari model '+id+'…');
  for(let t=0;t<2&&!hasM(id);t++){let w=0;while(fetching&&w++<60)await new Promise(r=>setTimeout(r,250));await pull(1)}}
 const _mg=act.midget;act.midget=async function(){const i=document.getElementById('mid');if(!i)return;const id=midOf(i.value);i.value=id;await ensureM(id);return _mg.apply(this,arguments)};
 document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='mid'){e.preventDefault();act.midget()}})}
const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{pull(1);sync()},900);return r};
window.spMarketSync=()=>{sync();pull(1)};
if(typeof me!=='undefined'&&me)setTimeout(()=>{pull(1);sync()},1200);
})();
