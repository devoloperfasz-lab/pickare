/* ===== v13: centang biru & akses panel cepat terlihat ===== */
(function(){
const BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
async function ensurePin(){try{if(ls.get('sp_ownpk',null))return true;const mq=window.__spMq;if(!mq||!(window.mqtt||await mq.lib()))return false;let best=null;
 await Promise.all(BR.map(url=>new Promise(res=>{let m,d=0;const end=()=>{if(d)return;d=1;try{m.end(true)}catch(e){}res()};
  try{m=mqtt.connect(url,{clientId:'spv_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){return res()}
  m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe('pickare/v9/own/pk',{qos:0});setTimeout(end,2500)});
  m.on('message',(t,b)=>{try{const x=JSON.parse(b.toString());if(x&&x.pub&&(!best||x.ts>best.ts))best=x}catch(e){}});setTimeout(end,7000)})));
 if(best){ls.set('sp_ownpk',best.pub);return true}return false}catch(e){return false}}
const run=async()=>{try{if(typeof me==='undefined'||!me||document.hidden)return;await ensurePin();
 if(me.role!=='owner'){if(!staff()&&window.spPullGrant)await window.spPullGrant()}
 if(window.spVfSync)await window.spVfSync()}catch(e){}};
window.addEventListener('load',()=>setTimeout(()=>{
 const _e=enter;enter=function(){const r=_e.apply(this,arguments);setTimeout(run,3500);setTimeout(run,10000);return r};
 setInterval(run,20000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)run()});
},0));
})();
