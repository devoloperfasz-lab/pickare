/* ===== v17: Luau Pro: Material/Neon, BrickColor, CFrame, Humanoid (WalkSpeed, JumpPower, fly, noclip), UserInputService, Light, Body movers, Model, Value, Debris, dll ===== */
(function(){
const L=window.SPL={};
const defs=()=>({noclip:false,fly:false,ph:false,ws:16,jp:50,grav:196.2,vel:null,bvs:[],anch:false,tr:0,mv:null,jump:false,dn:false,mh:100,st:'Running',sit:false,tint:{},keys:L.keys||{},cas:{},tags:{}});
const rs=()=>{const k=L.keys;Object.keys(L).forEach(x=>delete L[x]);Object.assign(L,defs());L.keys=k||{}};
rs();
const nn=(v,a,b,d)=>{v=+v;return isFinite(v)?Math.min(b,Math.max(a,v)):d};
const clsOf=x=>{try{return x&&x.$g?x.$g('ClassName'):typeof x}catch(e){return'?'}};
const addV=(a,b)=>new LV(a.x+b.x,a.y+b.y,a.z+b.z);

/* ===== Enum ===== */
const E=G.get('Enum'),mkE=a=>mkT(Object.fromEntries(a.map(x=>[x,x]))),setE=(n,a)=>{if(!E.get(n))E.set(n,mkE(a))};
setE('Material',['Plastic','SmoothPlastic','Neon','Glass','ForceField','Metal','DiamondPlate','CorrodedMetal','Foil','Wood','WoodPlanks','Brick','Concrete','Granite','Marble','Slate','Sand','Grass','LeafyGrass','Ice','Fabric','Cobblestone','Pebble','Rock','Basalt','Salt','Snow','Mud','Ground','Limestone','Pavement','Asphalt']);
setE('KeyCode',[...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'].concat(['Zero','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Space','LeftShift','RightShift','LeftControl','RightControl','LeftAlt','Return','Escape','Tab','Backspace','Up','Down','Left','Right','Unknown'],Array.from({length:12},(_,i)=>'F'+(i+1))));
setE('UserInputType',['Keyboard','MouseButton1','MouseButton2','MouseMovement','Touch','Focus']);
setE('UserInputState',['Begin','Change','End']);
const HST=['FallingDown','Ragdoll','GettingUp','Jumping','Swimming','Freefall','Flying','Landed','Running','Unused','RunningNoPhysics','StrafingNoPhysics','Climbing','Seated','PlatformStanding','Dead','Physics'];
setE('HumanoidStateType',HST.filter(x=>x!='Unused'));
setE('PartType',['Block','Ball','Cylinder']);setE('CameraType',['Custom','Scriptable','Fixed','Follow']);setE('RaycastFilterType',['Exclude','Include','Blacklist','Whitelist']);
setE('RenderPriority',['First','Input','Camera','Character','Last']);setE('SurfaceType',['Smooth','Studs','Inlet','Weld']);setE('Technology',['Compatibility','Voxel','ShadowMap','Future']);
if(!E.get('EasingStyle'))setE('EasingStyle',['Linear','Sine','Quad','Cubic','Quart','Quint','Exponential','Circular','Back','Bounce','Elastic']);

/* ===== BrickColor ===== */
const BCN={'Really red':'#ff0000','Bright red':'#c4281c','Bright blue':'#0d69ac','Really blue':'#0000ff','Bright green':'#4b974b','Lime green':'#00ff00','Bright yellow':'#f5cd30','Bright orange':'#da8541','Hot pink':'#ff66cc','Pink':'#ff98dc','Magenta':'#aa00aa','Royal purple':'#6b327c','Black':'#1b2a35','Really black':'#000000','White':'#f2f3f3','Institutional white':'#f8f8f8','Medium stone grey':'#a3a2a5','Dark stone grey':'#635f62','Light stone grey':'#e5e4df','Cyan':'#049f9a','Teal':'#12eed4','Toothpaste':'#7df9ff','Navy blue':'#203a56','Brown':'#7c5c46','Dark orange':'#a05f35','Gold':'#efb838','Camo':'#3a7d15','Light blue':'#9fc3e9','Persimmon':'#ff6600','Neon orange':'#d5733d'};
class BCW{constructor(n,h){this.nm=n;this.hx=h}$g(k){switch(k){case'Name':return this.nm;case'Color':return hexC(this.hx);case'Number':return 1;case'r':return parseInt(this.hx.slice(1,3),16)/255;case'g':return parseInt(this.hx.slice(3,5),16)/255;case'b':return parseInt(this.hx.slice(5,7),16)/255}}$str(){return this.nm}}
const bcNew=(v,g,b)=>{if(v instanceof LC)return new BCW('Custom',cHex(v));if(typeof v==='number'&&g!==undefined)return new BCW('Custom',cHex(new LC(v,g,b)));if(typeof v==='number'){const k=Object.keys(BCN)[Math.abs(v|0)%Object.keys(BCN).length];return new BCW(k,BCN[k])}
 const k=Object.keys(BCN).find(n=>n.toLowerCase()==String(v).toLowerCase());return new BCW(k||'Medium stone grey',k?BCN[k]:BCN['Medium stone grey'])};
{const o={new:bcNew,Random:()=>bcNew(Math.floor(Math.random()*30)),palette:i=>bcNew(i)};['Red:Bright red','Blue:Bright blue','Green:Bright green','Yellow:Bright yellow','Orange:Bright orange','White:White','Black:Black','Gray:Medium stone grey','Pink:Hot pink','Purple:Royal purple'].forEach(x=>{const[a,b]=x.split(':');o[a]=()=>bcNew(b)});G.set('BrickColor',mkT(o))}
const cOf=v=>v instanceof BCW?v.hx:cHex(v);

/* ===== Vector3 / Color3 tambahan ===== */
{const g0=LV.prototype.$g;LV.prototype.$g=function(k){const r=g0.call(this,k);if(r!==undefined)return r;const t=this;switch(k){case'Dot':return(_,o)=>t.x*o.x+t.y*o.y+t.z*o.z;case'Cross':return(_,o)=>new LV(t.y*o.z-t.z*o.y,t.z*o.x-t.x*o.z,t.x*o.y-t.y*o.x);case'Lerp':return(_,o,a)=>new LV(t.x+(o.x-t.x)*a,t.y+(o.y-t.y)*a,t.z+(o.z-t.z)*a);case'Abs':return()=>new LV(Math.abs(t.x),Math.abs(t.y),Math.abs(t.z));case'Floor':return()=>new LV(Math.floor(t.x),Math.floor(t.y),Math.floor(t.z));case'FuzzyEq':return(_,o,e)=>Math.hypot(t.x-o.x,t.y-o.y,t.z-o.z)<=(e||1e-5);case'Min':return(_,o)=>new LV(Math.min(t.x,o.x),Math.min(t.y,o.y),Math.min(t.z,o.z));case'Max':return(_,o)=>new LV(Math.max(t.x,o.x),Math.max(t.y,o.y),Math.max(t.z,o.z))}}
 const V=G.get('Vector3');V.set('xAxis',new LV(1,0,0));V.set('yAxis',new LV(0,1,0));V.set('zAxis',new LV(0,0,1));
 const c0=LC.prototype.$g;LC.prototype.$g=function(k){const r=c0.call(this,k);if(r!==undefined)return r;const t=this;if(k=='Lerp')return(_,o,a)=>new LC(t.r+(o.r-t.r)*a,t.g+(o.g-t.g)*a,t.b+(o.b-t.b)*a);if(k=='ToHex')return()=>cHex(t).slice(1)}}

/* ===== CFrame ===== */
const I3=[1,0,0,0,1,0,0,0,1];
const mm=(a,b)=>{const r=[];for(let i=0;i<3;i++)for(let j=0;j<3;j++)r.push(a[i*3]*b[j]+a[i*3+1]*b[3+j]+a[i*3+2]*b[6+j]);return r};
const mv=(m,v)=>new LV(m[0]*v.x+m[1]*v.y+m[2]*v.z,m[3]*v.x+m[4]*v.y+m[5]*v.z,m[6]*v.x+m[7]*v.y+m[8]*v.z);
const tr3=m=>[m[0],m[3],m[6],m[1],m[4],m[7],m[2],m[5],m[8]];
const Rx=a=>{const c=Math.cos(a),s=Math.sin(a);return[1,0,0,0,c,-s,0,s,c]},Ry=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,0,s,0,1,0,-s,0,c]},Rz=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,-s,0,s,c,0,0,0,1]};
const ang=(x,y,z)=>mm(Rx(x),mm(Ry(y),Rz(z)));
const eul=m=>[Math.atan2(-m[5],m[8]),Math.asin(Math.max(-1,Math.min(1,m[2]))),Math.atan2(-m[1],m[0])];
class CF{constructor(p,m){this.p=p;this.m=m||I3}
 $g(k){const t=this,m=this.m;switch(k){case'Position':return t.p;case'X':return t.p.x;case'Y':return t.p.y;case'Z':return t.p.z;
  case'LookVector':return new LV(-m[2],-m[5],-m[8]);case'RightVector':return new LV(m[0],m[3],m[6]);case'UpVector':return new LV(m[1],m[4],m[7]);
  case'Inverse':return()=>{const q=tr3(m),np=mv(q,t.p);return new CF(new LV(-np.x,-np.y,-np.z),q)};
  case'ToWorldSpace':return(_,c)=>cfMul(t,c);case'ToObjectSpace':return(_,c)=>cfMul(t.$g('Inverse')(),c);
  case'PointToWorldSpace':return(_,v)=>addV(t.p,mv(m,v));case'PointToObjectSpace':return(_,v)=>mv(tr3(m),new LV(v.x-t.p.x,v.y-t.p.y,v.z-t.p.z));case'VectorToWorldSpace':return(_,v)=>mv(m,v);case'VectorToObjectSpace':return(_,v)=>mv(tr3(m),v);
  case'Lerp':return(_,c,a)=>new CF(new LV(t.p.x+(c.p.x-t.p.x)*a,t.p.y+(c.p.y-t.p.y)*a,t.p.z+(c.p.z-t.p.z)*a),a<.5?m:c.m);
  case'ToEulerAnglesXYZ':case'ToOrientation':return()=>eul(m)}}
 $str(){return this.p.x+', '+this.p.y+', '+this.p.z+', '+this.m.join(', ')}}
const cfMul=(a,b)=>new CF(addV(a.p,mv(a.m,b.p)),mm(a.m,b.m));
const lookM=(at,tg,up)=>{let z=new LV(at.x-tg.x,at.y-tg.y,at.z-tg.z);const zl=Math.hypot(z.x,z.y,z.z)||1;z=new LV(z.x/zl,z.y/zl,z.z/zl);up=up||new LV(0,1,0);let x=new LV(up.y*z.z-up.z*z.y,up.z*z.x-up.x*z.z,up.x*z.y-up.y*z.x);let xl=Math.hypot(x.x,x.y,x.z);if(xl<1e-6){x=new LV(1,0,0);xl=1}x=new LV(x.x/xl,x.y/xl,x.z/xl);const y=new LV(z.y*x.z-z.z*x.y,z.z*x.x-z.x*x.z,z.x*x.y-z.y*x.x);return[x.x,y.x,z.x,x.y,y.y,z.y,x.z,y.z,z.z]};
G.set('CFrame',mkT({new:(a,b,c)=>{if(a===undefined)return new CF(new LV(0,0,0));if(a instanceof LV&&b instanceof LV)return new CF(a,lookM(a,b));if(a instanceof LV)return new CF(a);return new CF(new LV(+a||0,+b||0,+c||0))},
 Angles:(x,y,z)=>new CF(new LV(0,0,0),ang(+x||0,+y||0,+z||0)),fromEulerAnglesXYZ:(x,y,z)=>new CF(new LV(0,0,0),ang(+x||0,+y||0,+z||0)),fromOrientation:(x,y,z)=>new CF(new LV(0,0,0),ang(+x||0,+y||0,+z||0)),
 lookAt:(a,b,u)=>new CF(a,lookM(a,b,u)),identity:new CF(new LV(0,0,0))}));
{const _ar=arith;arith=function(op,a,b){if(a instanceof CF||b instanceof CF){
  if(op=='*'){if(a instanceof CF&&b instanceof CF)return cfMul(a,b);if(a instanceof CF&&b instanceof LV)return addV(a.p,mv(a.m,b))}
  if(op=='+'&&a instanceof CF&&b instanceof LV)return new CF(addV(a.p,b),a.m);
  if(op=='-'&&a instanceof CF&&b instanceof LV)return new CF(new LV(a.p.x-b.x,a.p.y-b.y,a.p.z-b.z),a.m);
  throw new Error('operasi CFrame tidak valid')}return _ar(op,a,b)};
 const ty=G.get('typeof');G.set('typeof',v=>v instanceof CF?'CFrame':v instanceof BCW?'BrickColor':ty(v))}
const cfFromObj=(o)=>new CF(new LV(o.position.x,o.position.y,o.position.z),ang(o.rotation.x,o.rotation.y,o.rotation.z));
const cfToObj=(o,cf)=>{o.position.set(cf.p.x,cf.p.y,cf.p.z);const e=eul(cf.m);o.rotation.set(e[0],e[1],e[2])};

/* ===== library tambahan ===== */
G.set('tick',()=>Date.now()/1000);G.set('time',()=>performance.now()/1000);
{const xr=seed=>{let s=(seed>>>0)||1;return()=>{s^=s<<13;s>>>=0;s^=s>>>17;s^=s<<5;s>>>=0;return s/4294967296}};
 G.set('Random',mkT({new:seed=>{const r=seed===undefined?Math.random:xr(+seed);return mkT({NextNumber:(_,a,b)=>a===undefined?r():a+(b-a)*r(),NextInteger:(_,a,b)=>a+Math.floor(r()*(b-a+1))})}}));
 STR.set('split',(s,sep)=>tbl2(s.split(sep===undefined?',':sep)));
 const T=G.get('table');T.set('freeze',t=>t);T.set('isfrozen',()=>false);T.set('create',(n,v)=>{const t=new LT();for(let i=1;i<=n;i++)t.set(i,v);return t});T.set('pack',(...a)=>{const t=tbl2(a);t.set('n',a.length);return t});
 T.set('move',(a,f,e,t,b)=>{b=b||a;const v=[];for(let i=f;i<=e;i++)v.push(a.get(i));v.forEach((x,i)=>b.set(t+i,x));return b});
 MATH.set('lerp',(a,b,t)=>a+(b-a)*t);
 G.set('bit32',mkT({band:(a,b)=>(a&b)>>>0,bor:(a,b)=>(a|b)>>>0,bxor:(a,b)=>(a^b)>>>0,lshift:(a,b)=>(a<<b)>>>0,rshift:(a,b)=>a>>>b,bnot:a=>(~a)>>>0}));
 G.set('NumberRange',mkT({new:(a,b)=>mkT({Min:a,Max:b===undefined?a:b})}));G.set('NumberSequence',mkT({new:(a,b)=>mkT({Value:a,Value2:b})}));
 G.set('RaycastParams',mkT({new:()=>mkT({FilterDescendantsInstances:new LT(),FilterType:'Exclude',IgnoreWater:true})}));G.set('OverlapParams',G.get('RaycastParams'))}

/* ===== Part: Material (Neon!), BrickColor, CFrame, collision, dll ===== */
let NL=0;
const findBox=w=>{const o=w.o;if(!o||typeof boxes==='undefined'||!boxes)return null;const tp=o.y+o.sy/2;return boxes.find(b=>!b.sh&&Math.abs(b.x-o.x)<.01&&Math.abs(b.z-o.z)<.01&&Math.abs(b.top-tp)<.01)||null};
const syncBox=w=>{const b=w.bx,m=w.m;if(!b||!m)return;const a=m.rotation.y,c=Math.abs(Math.cos(a)),s=Math.abs(Math.sin(a));b.x=m.position.x;b.z=m.position.z;b.hw=(c*m.scale.x+s*m.scale.z)/2;b.hd=(s*m.scale.x+c*m.scale.z)/2;b.top=m.position.y+m.scale.y/2;b.bot=m.position.y-m.scale.y/2};
const addBox=w=>{if(!w.bx){w.bx={x:0,z:0,hw:1,hd:1,top:0,bot:0};syncBox(w)}if(typeof boxes!=='undefined'&&boxes&&!boxes.includes(w.bx))boxes.push(w.bx)};
const delBox=w=>{if(w.bx&&typeof boxes!=='undefined'&&boxes){const i=boxes.indexOf(w.bx);if(i>=0)boxes.splice(i,1)}};
function applyMat(w){const mt=w.m.material;if(!mt)return;const k=w.mat||'Plastic',c=w.col||(w.o&&w.o.c)||'#ffffff';
 if(mt.emissive){if(k=='Neon'){mt.emissive.set(c);mt.emissiveIntensity=1;mt.color.set(c)}else if(k=='ForceField'){mt.emissive.set(c);mt.emissiveIntensity=.6}else{mt.emissive.set('#000000');mt.emissiveIntensity=0}}
 if(w.trs===undefined){if(k=='Glass'||k=='ForceField'||k=='Ice'){mt.transparent=true;mt.opacity=k=='Glass'?.45:k=='Ice'?.8:.55}else mt.opacity=1}
 if(k=='Neon'&&!w.glow&&NL<4&&typeof THREE!=='undefined'&&THREE.PointLight){NL++;w.glow=new THREE.PointLight(c,.7,10);w.m.add(w.glow)}else if(k!='Neon'&&w.glow){w.m.remove(w.glow);w.glow=null;NL--}
 if(w.glow)w.glow.color.set(c);mt.needsUpdate=true}
const attachWs=w=>{PS0.call(w,'Parent',RT.ws);if(w.o.cc!==false&&w.cc!==false)addBox(w)};
const detachWs=w=>{PS0.call(w,'Parent',undefined);delBox(w)};
const PG0=PtW.prototype.$g,PS0=PtW.prototype.$s;
PtW.prototype.$g=function(k){const w=this,m=this.m;switch(k){
 case'Material':return w.mat||'Plastic';case'BrickColor':return new BCW('Custom',w.col||(w.o&&w.o.c)||'#ffffff');case'Reflectance':return w.rf||0;
 case'Anchored':return w.anch!==false;case'CanCollide':return w.cc!==false&&w.o.cc!==false;case'CanTouch':case'CanQuery':return true;case'Massless':case'Locked':case'CastShadow':return false;
 case'Shape':return w.o.t=='ball'?'Ball':w.o.t=='cyl'?'Cylinder':'Block';
 case'CFrame':return cfFromObj(m);case'Orientation':case'Rotation':{const e=eul(ang(m.rotation.x,m.rotation.y,m.rotation.z));return new LV(e[0]*180/Math.PI,e[1]*180/Math.PI,e[2]*180/Math.PI)}
 case'Velocity':case'AssemblyLinearVelocity':case'RotVelocity':return new LV(0,0,0);
 case'Parent':return w.par2||(m.parent?RT.ws:undefined);
 case'IsA':return(_,c)=>/^(Part|BasePart|PVInstance|Instance|FormFactorPart)$/.test(c);
 case'GetChildren':return()=>tbl2(w.kids||[]);case'GetDescendants':return()=>tbl2(w.kids||[]);
 case'FindFirstChild':case'WaitForChild':return(_,n)=>(w.kids||[]).find(c=>c.n==n);case'FindFirstChildOfClass':case'FindFirstChildWhichIsA':return(_,c)=>(w.kids||[]).find(x=>clsOf(x)==c);
 case'SetAttribute':return(_,a,v)=>{(w.at=w.at||{})[a]=v};case'GetAttribute':return(_,a)=>(w.at||{})[a];case'GetTouchingParts':return()=>tbl2([]);case'GetFullName':return()=>'Workspace.'+w.nm;
 case'TouchEnded':return w.te||(w.te=new Sig());
 case'Clone':return()=>{const o2=Object.assign({},w.o,{id:nid()}),m2=mkObj(o2);m2.position.copy?m2.position.copy(m.position):m2.position.set(m.position.x,m.position.y,m.position.z);m2.scale.set(m.scale.x,m.scale.y,m.scale.z);m2.rotation.set(m.rotation.x,m.rotation.y,m.rotation.z);const c=new PtW(o2,m2);['mat','col','rf','anch','cc','trs'].forEach(q=>{if(w[q]!==undefined)c[q]=w[q]});if(w.col)m2.material.color.set(w.col);if(w.trs!==undefined)PS0.call(c,'Transparency',1-(m.material.opacity));applyMat(c);return c};
 case'Destroy':return()=>{delBox(w);if(w.glow){NL--;w.glow=null}if(w.par2&&w.par2.ch)w.par2.ch=w.par2.ch.filter(x=>x!==w);if(m.parent)m.parent.remove(m);RT.parts=RT.parts.filter(x=>x!==w)};
 case'Transparency':return w.trs!==undefined?w.trs:(m.material&&m.material.transparent?1-m.material.opacity:0)}
 return PG0.call(this,k)};
PtW.prototype.$s=function(k,v){const w=this,m=this.m;switch(k){
 case'Material':w.mat=String(v);applyMat(w);return;case'BrickColor':case'Color':if(!w.bxd)w.bxd=0;PS0.call(w,'Color',k=='BrickColor'?(v instanceof BCW?hexC(v.hx):v):v);w.col=cOf(k=='BrickColor'?v:v);applyMat(w);return;
 case'Reflectance':w.rf=+v||0;return;case'Anchored':w.anch=truthy(v);return;
 case'CanCollide':{const on=truthy(v);w.cc=on;if(!on)delBox(w);else if(m.parent){if(!w.bx)w.bx=findBox(w);addBox(w)}return}
 case'Transparency':w.trs=nn(v,0,1,0);PS0.call(w,'Transparency',w.trs);return;
 case'Position':case'Size':case'CFrame':case'Orientation':case'Rotation':if(!w.bxd){w.bxd=1;if(!w.bx)w.bx=findBox(w)}
  if(k=='CFrame'&&v instanceof CF)cfToObj(m,v);else if(k=='Orientation'||k=='Rotation'){if(v instanceof LV)m.rotation.set(v.x*Math.PI/180,v.y*Math.PI/180,v.z*Math.PI/180)}else PS0.call(w,k,v);
  w.dirty=1;return;
 case'Shape':{const s=String(v);if(typeof THREE!=='undefined'&&m.geometry){m.geometry=s=='Ball'?new THREE.SphereGeometry(.5,16,12):s=='Cylinder'?new THREE.CylinderGeometry(.5,.5,1,20):new THREE.BoxGeometry(1,1,1)}w.o.t=s=='Ball'?'ball':s=='Cylinder'?'cyl':'part';return}
 case'Parent':{if(w.par2&&w.par2.ch)w.par2.ch=w.par2.ch.filter(x=>x!==w);w.par2=null;
  if(v instanceof MD){w.par2=v;v.ch.push(w);if(v.ws)attachWs(w);else if(m.parent)detachWs(w)}
  else if(v===RT.ws){attachWs(w)}else if(v==null){detachWs(w)}else PS0.call(w,k,v);return}
 case'Velocity':case'AssemblyLinearVelocity':case'RotVelocity':case'Massless':case'Locked':case'CastShadow':case'CanTouch':case'CanQuery':case'TopSurface':case'BottomSurface':case'Archivable':return}
 return PS0.call(this,k,v)};

/* ===== Model/Folder, Light, Body mover, Value, stub ===== */
class MD{constructor(c,n){this.cls=c;this.nm=n||c;this.ch=[];this.par=null;this.ws=false;this.at={}}get n(){return this.nm}
 desc(){const o=[];this.ch.forEach(c=>{o.push(c);if(c instanceof MD)o.push(...c.desc())});return o}
 parts(){return this.desc().filter(x=>x instanceof PtW)}
 setWs(on){this.ws=on;this.ch.forEach(c=>{if(c instanceof MD)c.setWs(on);else if(c instanceof PtW){on?attachWs(c):detachWs(c)}});if(on){if(!RT.models.includes(this)&&this.par===RT.ws)RT.models.push(this)}else RT.models=RT.models.filter(x=>x!==this)}
 mid(){const p=this.parts();if(!p.length)return new LV(0,0,0);let x=0,y=0,z=0;p.forEach(w=>{x+=w.m.position.x;y+=w.m.position.y;z+=w.m.position.z});return new LV(x/p.length,y/p.length,z/p.length)}
 shift(d){this.parts().forEach(w=>{if(!w.bxd){w.bxd=1;if(!w.bx)w.bx=findBox(w)}w.m.position.set(w.m.position.x+d.x,w.m.position.y+d.y,w.m.position.z+d.z);w.dirty=1})}
 $g(k){const t=this;switch(k){case'Name':return t.nm;case'ClassName':return t.cls;case'Parent':return t.par;case'GetChildren':return()=>tbl2(t.ch);case'GetDescendants':return()=>tbl2(t.desc());
  case'FindFirstChild':case'WaitForChild':return(_,n,r)=>(r?t.desc():t.ch).find(c=>c.n==n);case'FindFirstChildOfClass':case'FindFirstChildWhichIsA':return(_,c)=>t.ch.find(x=>clsOf(x)==c);
  case'IsA':return(_,c)=>c==t.cls||c=='Instance'||(c=='PVInstance'&&t.cls=='Model');case'SetAttribute':return(_,a,v)=>{t.at[a]=v};case'GetAttribute':return(_,a)=>t.at[a];
  case'Destroy':return()=>{t.$s('Parent',undefined);t.parts().forEach(w=>w.$g('Destroy')())};case'ClearAllChildren':return()=>{t.ch.slice().forEach(c=>c.$g('Destroy')&&c.$g('Destroy')())};
  case'MoveTo':return(_,v)=>{const c=t.mid();t.shift(new LV(v.x-c.x,v.y-c.y,v.z-c.z))};case'PivotTo':case'SetPrimaryPartCFrame':return(_,cf)=>{const c=t.mid();t.shift(new LV(cf.p.x-c.x,cf.p.y-c.y,cf.p.z-c.z))};case'GetPivot':return()=>new CF(t.mid());
  case'Clone':return()=>{const n=new MD(t.cls,t.nm);t.ch.forEach(c=>{const cc=c.$g('Clone');if(cc){const x=cc();x.$s('Parent',n)}});return n};
  case'GetFullName':return()=>t.nm}return t.ch.find(c=>c.n==k)}
 $s(k,v){if(k=='Name'){this.nm=tostr(v);return}if(k=='Parent'){if(this.par instanceof MD)this.par.ch=this.par.ch.filter(x=>x!==this);
  if(this.par===RT.pl&&RT.plk)RT.plk=RT.plk.filter(x=>x!==this);this.par=v==null?null:v;
  if(v instanceof MD){v.ch.push(this);this.setWs(v.ws)}else if(v===RT.ws)this.setWs(true);else{if(v===RT.pl){RT.plk=RT.plk||[];RT.plk.push(this)}this.setWs(false)}return}this.at[k]=v}}
class LiW{constructor(c){this.cls=c;this.nm=c;this.p={Brightness:1,Range:12,Color:hexC('#ffffff'),Enabled:true,Angle:90,Shadows:false};this.par=null;this.l=null}get n(){return this.nm}
 rm(){if(this.l&&this.l.parent){this.l.parent.remove(this.l);NL--}this.l=null}
 mk(host){if(NL>=5||typeof THREE==='undefined')return;NL++;this.l=new THREE.PointLight(cHex(this.p.Color),nn(this.p.Brightness,0,10,1),nn(this.p.Range,1,80,12));this.l.visible=truthy(this.p.Enabled);host.add(this.l)}
 $g(k){const t=this;switch(k){case'Name':return t.nm;case'ClassName':return t.cls;case'Parent':return t.par;case'Destroy':return()=>{t.rm();t.par=null};case'IsA':return(_,c)=>c==t.cls||c=='Light'||c=='Instance'}return t.p[k]}
 $s(k,v){if(k=='Name'){this.nm=tostr(v);return}if(k=='Parent'){this.rm();this.par=v;const h=v instanceof PtW?v.m:(v instanceof RootW||v instanceof CPW)?plr:null;if(h)this.mk(h);return}this.p[k]=v;if(this.l){if(k=='Brightness')this.l.intensity=nn(v,0,10,1);else if(k=='Range')this.l.distance=nn(v,1,80,12);else if(k=='Color')this.l.color.set(cHex(v));else if(k=='Enabled')this.l.visible=truthy(v)}}}
class BVW{constructor(c){this.cls=c;this.nm=c;this.p={Velocity:new LV(0,0,0),VectorVelocity:new LV(0,0,0),MaxForce:new LV(4e4,4e4,4e4),P:1250,D:100,Force:new LV(0,0,0),Position:new LV(0,0,0),CFrame:new CF(new LV(0,0,0)),Enabled:true};this.par=null}get n(){return this.nm}
 reg(on){L.bvs=(L.bvs||[]).filter(x=>x!==this);if(on)L.bvs.push(this)}
 $g(k){const t=this;switch(k){case'Name':return t.nm;case'ClassName':return t.cls;case'Parent':return t.par;case'Destroy':return()=>{t.reg(false);t.par=null};case'IsA':return(_,c)=>c==t.cls||c=='Instance'}return t.p[k]}
 $s(k,v){if(k=='Name'){this.nm=tostr(v);return}if(k=='Parent'){this.par=v;this.reg(v instanceof RootW||v instanceof CPW);return}this.p[k]=v}}
class SB{constructor(c){this.cls=c;this.nm=c;this.p={};this.sg={};this.par=null;this.ch=[];if(/Value$/.test(c))this.p.Value=/^(Int|Number)Value$/.test(c)?0:c=='StringValue'?'':c=='BoolValue'?false:undefined}get n(){return this.nm}
 sig(k){return this.sg[k]||(this.sg[k]=new Sig())}
 $g(k){const t=this;switch(k){case'Name':return t.nm;case'ClassName':return t.cls;case'Parent':return t.par;case'IsA':return(_,c)=>c==t.cls||c=='Instance'||(c=='ValueBase'&&/Value$/.test(t.cls));
  case'Destroy':return()=>{t.$s('Parent',undefined)};case'GetChildren':return()=>tbl2(t.ch);case'FindFirstChild':case'WaitForChild':return(_,n)=>t.ch.find(c=>c.n==n);
  case'Clone':return()=>{const c=new SB(t.cls);c.nm=t.nm;Object.assign(c.p,t.p);return c};case'SetAttribute':return(_,a,v)=>{t.p['@'+a]=v};case'GetAttribute':return(_,a)=>t.p['@'+a];
  case'Play':case'Stop':case'Pause':case'Resume':case'Emit':case'Fire':return()=>[];case'GetPropertyChangedSignal':return(_,p)=>t.sig('pc_'+p)}
  if(/^(Changed|Touched|MouseClick|MouseHover|Triggered|Activated|Equipped|Unequipped|Died|ChildAdded|MouseButton1Click|Event|OnServerEvent)$/.test(k))return t.sig(k);return t.p[k]}
 $s(k,v){if(k=='Name'){this.nm=tostr(v);return}if(k=='Parent'){const o=this.par;if(o&&o.ch)o.ch=o.ch.filter(x=>x!==this);if(o instanceof PtW&&o.kids)o.kids=o.kids.filter(x=>x!==this);this.par=v==null?null:v;
  if(v instanceof MD||v instanceof SB)v.ch.push(this);else if(v instanceof PtW){(v.kids=v.kids||[]).push(this)}
  if(this.cls=='Sound'&&v&&this.p.Playing)this.p.Playing=true;return}const o=this.p[k];this.p[k]=v;if(o!==v){this.sig('Changed').fire(v);this.sig('pc_'+k).fire()}}}
{const I=G.get('Instance'),old=I.get('new');
 const STUB=/^(Sound|ClickDetector|ProximityPrompt|ParticleEmitter|Fire|Smoke|Sparkles|Highlight|Decal|Texture|Beam|Trail|Attachment|Weld|WeldConstraint|Motor6D|Tool|Humanoid|Animation|StringValue|IntValue|NumberValue|BoolValue|ObjectValue|Color3Value|Vector3Value|CFrameValue|SelectionBox|BillboardGui|SurfaceGui|Camera|Configuration|Accessory|Shirt|Pants|ForceField|Explosion|Seat|VehicleSeat|Script|LocalScript|ModuleScript)$/;
 I.set('new',(cls,par)=>{cls=String(cls);
  if(GN[cls]||cls=='Part'&&false)return old(cls,par);
  let w;if(/^(Part|WedgePart|CornerWedgePart|SpawnLocation|MeshPart|TrussPart)$/.test(cls)){w=old('Part');if(cls=='SpawnLocation')w.nm=cls}
  else if(cls=='Model'||cls=='Folder')w=new MD(cls);
  else if(/^(PointLight|SpotLight|SurfaceLight)$/.test(cls))w=new LiW(cls);
  else if(/^(BodyVelocity|BodyGyro|BodyPosition|BodyForce|BodyAngularVelocity|LinearVelocity|VectorForce|AlignPosition|AlignOrientation)$/.test(cls))w=new BVW(cls);
  else if(cls=='BindableEvent'||cls=='RemoteEvent'||cls=='RemoteFunction'||cls=='BindableFunction'){w=new REW({cls,n:cls})}
  else if(STUB.test(cls))w=new SB(cls);else throw new Error('Instance.new("'+cls+'") belum didukung');
  if(par!==undefined)w.$s('Parent',par);return w})}

/* ===== bagian karakter ===== */
function tintMeshes(name,fn){if(typeof plr==='undefined'||!plr)return;const arm=[plr.a&&plr.a[0],plr.a&&plr.a[1]],leg=[plr.l&&plr.l[0],plr.l&&plr.l[1]];
 const inside=(o,g)=>{for(let p=o;p;p=p.parent)if(p===g)return true;return false};
 const apply=g=>g&&g.traverse&&g.traverse(o=>{if(o.material&&o.material.color)fn(o.material)});
 if(name=='Left Arm')apply(arm[0]);else if(name=='Right Arm')apply(arm[1]);else if(name=='Left Leg')apply(leg[0]);else if(name=='Right Leg')apply(leg[1]);
 else plr.traverse(o=>{if(o.material&&o.material.color&&!arm.some(g=>inside(o,g))&&!leg.some(g=>inside(o,g)))fn(o.material)})}
class CPW{constructor(n,dx,dy,sx,sy,sz){this.nm=n;this.dx=dx;this.dy=dy;this.sz=new LV(sx,sy,sz);this.t=new Sig();this.kids=[]}get n(){return this.nm}
 $g(k){const t=this;switch(k){case'Name':return t.nm;case'ClassName':return'Part';case'Position':return new LV(P.x+t.dx,P.y+t.dy,P.z);case'CFrame':return new CF(new LV(P.x+t.dx,P.y+t.dy,P.z),Ry(P.ry+Math.PI));case'Size':return t.sz;case'Parent':return RT.ch;
  case'CanCollide':return!L.noclip;case'Transparency':return L.tr;case'Anchored':return L.anch;case'Material':return(L.tint[t.nm]||{}).mat||'Plastic';case'Color':return hexC((L.tint[t.nm]||{}).col||(me.av&&me.av.skin)||'#ffd7b5');case'BrickColor':return new BCW('Custom',(L.tint[t.nm]||{}).col||'#ffd7b5');
  case'Velocity':case'AssemblyLinearVelocity':return L.vel||new LV(0,0,0);case'Touched':return t.t;case'IsA':return(_,c)=>/^(Part|BasePart|PVInstance|Instance)$/.test(c);
  case'GetChildren':case'GetDescendants':return()=>tbl2(t.kids);case'FindFirstChild':case'FindFirstChildOfClass':return(_,n)=>t.kids.find(c=>c.n==n);case'Destroy':return()=>[];case'GetFullName':return()=>'Workspace.'+me.name+'.'+t.nm}}
 $s(k,v){const t=this;switch(k){case'CanCollide':L.noclip=!truthy(v);return;case'Transparency':L.tr=nn(v,0,1,0);if(plr)plr.traverse(o=>{if(o.material&&o.type!=='Sprite'){o.material.transparent=true;o.material.opacity=1-L.tr}});return;case'Anchored':L.anch=truthy(v);return;
  case'Velocity':case'AssemblyLinearVelocity':if(v instanceof LV)L.vel=v;return;
  case'Color':case'BrickColor':{const c=cOf(v),T=L.tint[t.nm]=L.tint[t.nm]||{};T.col=c;tintMeshes(t.nm,m=>{m.color.set(c);if(T.mat=='Neon'&&m.emissive){m.emissive.set(c);m.emissiveIntensity=1}});return}
  case'Material':{const T=L.tint[t.nm]=L.tint[t.nm]||{};T.mat=String(v);const c=T.col||(me.av&&me.av.skin)||'#ffd7b5';tintMeshes(t.nm,m=>{if(m.emissive){if(T.mat=='Neon'){m.emissive.set(c);m.emissiveIntensity=1}else{m.emissive.set('#000000');m.emissiveIntensity=0}}});return}
  case'CFrame':if(v instanceof CF)setRootCF(v);return}}}
const rootCF=()=>new CF(new LV(P.x,P.y+1.5,P.z),Ry(P.ry+Math.PI));
const setRootCF=cf=>{P.x=cf.p.x;P.y=cf.p.y-1.5;P.z=cf.p.z;P.vy=0;const lv=new LV(-cf.m[2],0,-cf.m[8]);if(Math.hypot(lv.x,lv.z)>1e-4)P.ry=Math.atan2(lv.x,lv.z)};
{const g0=RootW.prototype.$g,s0=RootW.prototype.$s;
 RootW.prototype.$g=function(k){switch(k){case'CFrame':return rootCF();case'Orientation':case'Rotation':return new LV(0,(P.ry+Math.PI)*180/Math.PI,0);case'Velocity':case'AssemblyLinearVelocity':return L.vel||new LV(0,P.vy||0,0);case'Anchored':return L.anch;case'CanCollide':return!L.noclip;case'Size':return new LV(2,2,1);case'Transparency':return L.tr;case'Material':return'Plastic';case'IsA':return(_,c)=>/^(Part|BasePart|PVInstance|Instance)$/.test(c);case'GetChildren':case'GetDescendants':return()=>tbl2([]);case'FindFirstChild':return()=>undefined;case'Touched':return this.t||(this.t=new Sig());case'GetFullName':return()=>'Workspace.'+me.name+'.HumanoidRootPart'}return g0.call(this,k)};
 RootW.prototype.$s=function(k,v){switch(k){case'CFrame':if(v instanceof CF)setRootCF(v);return;case'Velocity':case'AssemblyLinearVelocity':if(v instanceof LV)L.vel=v;return;case'Anchored':L.anch=truthy(v);return;case'CanCollide':L.noclip=!truthy(v);return;case'Orientation':case'Rotation':if(v instanceof LV)P.ry=v.y*Math.PI/180-Math.PI;return;case'Transparency':case'Material':case'Color':case'Size':case'Massless':return}return s0.call(this,k,v)}}

/* ===== Humanoid ===== */
const chState=s=>{if(typeof s==='number')s=HST[s]||'Running';s=String(s);L.st=s;
 if(s=='Flying'||s=='Physics'||s=='PlatformStanding')L.fly=true;else if(/^(Running|Freefall|GettingUp|Landed|Jumping|Climbing|Seated)$/.test(s))L.fly=false;
 if(s=='Jumping')L.jump=true;if(s=='Dead')RT.hum.$s('Health',0);try{L.sig.sc.fire(s)}catch(e){}};
{const g0=HumW.prototype.$g,s0=HumW.prototype.$s;
 HumW.prototype.$g=function(k){switch(k){case'WalkSpeed':return L.ws;case'JumpPower':return L.jp;case'JumpHeight':return L.jp/50*7.2;case'UseJumpPower':return true;case'PlatformStand':return L.ph;case'Sit':return L.sit;case'MaxHealth':return L.mh;case'DisplayName':return me.name;case'RigType':return'R6';case'HipHeight':return 0;case'AutoRotate':return true;case'Jump':return false;case'FloorMaterial':return'Plastic';
  case'MoveDirection':return moveDir();case'HealthChanged':return L.sig.hc;case'Running':return L.sig.run;case'Jumping':return L.sig.jump;case'StateChanged':return L.sig.sc;case'MoveToFinished':return L.sig.mtf;
  case'ChangeState':case'SetStateEnabled':return(_,s)=>{if(k=='ChangeState')chState(s);return[]};case'GetState':return()=>L.st;case'MoveTo':return(_,v)=>{if(v instanceof LV)L.mv={x:v.x,z:v.z};return[]};case'Move':case'EquipTool':case'UnequipTools':case'RemoveAccessories':return()=>[];
  case'LoadAnimation':return()=>mkT({Play:()=>[],Stop:()=>[],AdjustSpeed:()=>[],Looped:false,IsPlaying:false,Length:1});case'GetPlayingAnimationTracks':return()=>tbl2([]);case'IsA':return(_,c)=>/^(Humanoid|Instance)$/.test(c);case'GetFullName':return()=>'Workspace.'+me.name+'.Humanoid'}
  return g0.call(this,k)};
 HumW.prototype.$s=function(k,v){switch(k){case'WalkSpeed':L.ws=nn(v,0,500,16);return;case'JumpPower':L.jp=nn(v,0,1000,50);return;case'JumpHeight':L.jp=nn(v,0,200,7.2)/7.2*50;return;case'PlatformStand':L.ph=truthy(v);return;case'Sit':L.sit=truthy(v);return;case'MaxHealth':L.mh=nn(v,1,1e9,100);return;case'Jump':if(truthy(v))L.jump=true;return;case'UseJumpPower':case'HipHeight':case'AutoRotate':case'DisplayName':case'CameraOffset':case'DisplayDistanceType':case'NameDisplayDistance':case'HealthDisplayType':return}
  return s0.call(this,k,v)}}
function moveDir(){let ix=joy.x+(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),iy=joy.y+(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0);const l=Math.hypot(ix,iy);if(l>1){ix/=l;iy/=l}
 return new LV(Math.cos(yaw)*ix-Math.sin(yaw)*iy,0,-Math.sin(yaw)*ix-Math.cos(yaw)*iy)}

/* ===== service tambahan ===== */
class NW extends FW{$g(k){const v=super.$g(k);if(v!==undefined)return v;return(typeof k==='string'&&/^[A-Z]/.test(k))?(()=>[]):undefined}}
class LS{constructor(){this.p={Brightness:1,ClockTime:12,FogEnd:140,FogStart:40,FogColor:hexC('#7df9ff'),Ambient:hexC('#7f7f7f'),OutdoorAmbient:hexC('#7f7f7f'),GlobalShadows:true,TimeOfDay:'12:00:00'}}get n(){return'Lighting'}
 $g(k){if(k=='Name'||k=='ClassName')return'Lighting';if(k=='GetChildren')return()=>tbl2([]);if(k=='FindFirstChild')return()=>undefined;if(k=='GetMinutesAfterMidnight')return()=>this.p.ClockTime*60;if(k=='SetMinutesAfterMidnight')return(_,m)=>this.$s('ClockTime',m/60);return this.p[k]}
 $s(k,v){this.p[k]=v;try{this.ap(k)}catch(e){}}
 ap(k){if(typeof scene==='undefined'||!scene)return;const p=this.p;
  if(!this.sky0&&scene.background&&scene.background.clone){this.sky0=scene.background.clone()}
  const f=.5+.5*Math.cos((nn(p.ClockTime,0,24,12)-12)/12*Math.PI),dim=.2+.8*f;
  scene.children.forEach(c=>{if(c.isHemisphereLight)c.intensity=nn(p.Brightness,0,10,1)*(.3+.7*f);if(c.isDirectionalLight)c.intensity=nn(p.Brightness,0,10,1)*.5*dim});
  if(k=='FogEnd'&&scene.fog)scene.fog.far=nn(p.FogEnd,1,5000,140);if(k=='FogStart'&&scene.fog)scene.fog.near=nn(p.FogStart,0,5000,40);
  if(k=='FogColor'&&scene.fog){scene.fog.color.set(cHex(p.FogColor));scene.background&&scene.background.set&&scene.background.set(cHex(p.FogColor));this.sky0=scene.background.clone()}
  if(k=='ClockTime'&&this.sky0&&scene.background){scene.background.copy(this.sky0).multiplyScalar(dim);if(scene.fog)scene.fog.color.copy(scene.background)}}}
class CAMW{get n(){return'Camera'}$g(k){switch(k){case'Name':return'Camera';case'ClassName':return'Camera';case'FieldOfView':return cam3.fov;case'CFrame':return cfFromObj(cam3);case'CameraType':return L.camType||'Custom';case'CameraSubject':return RT.hum;case'ViewportSize':return new LV(innerWidth,innerHeight,0);
  case'WorldToViewportPoint':case'WorldToScreenPoint':return(_,v)=>{const p=new THREE.Vector3(v.x,v.y,v.z).project(cam3);return[new LV((p.x*.5+.5)*innerWidth,(-p.y*.5+.5)*innerHeight,p.z),Math.abs(p.x)<=1&&Math.abs(p.y)<=1&&p.z<1]};case'Focus':return rootCF()}}
 $s(k,v){if(k=='FieldOfView'){cam3.fov=nn(v,1,120,70);cam3.updateProjectionMatrix()}else if(k=='CameraType')L.camType=String(v)}}
function raycast(o,d){const len=Math.hypot(d.x,d.y,d.z);if(!len)return;const ux=d.x/len,uy=d.y/len,uz=d.z/len;let prev=0;
 for(let s=.25;s<=Math.min(len,600);s+=.25){const x=o.x+ux*s,y=o.y+uy*s,z=o.z+uz*s;let hitB=null;
  if(baseOn&&y<=0&&o.y>0||baseOn&&y<=0&&uy<0)hitB={g:1};else for(const b of boxes||[])if(!b.sh&&inF(b,x,z,0)&&y<=b.top&&y>=b.bot){hitB=b;break}
  if(hitB){const r=new LT();r.set('Position',new LV(x,hitB.g?0:y,z));r.set('Distance',s);r.set('Normal',new LV(0,1,0));r.set('Material','Plastic');const w=hitB.g?undefined:RT.parts.find(q=>q.bx===hitB||(q.o&&Math.abs(q.o.x-hitB.x)<.01&&Math.abs(q.o.z-hitB.z)<.01&&Math.abs(q.o.y+q.o.sy/2-hitB.top)<.01));r.set('Instance',w||RT.ws);return r}}}
const jsonOf=v=>v instanceof LT?(v.len()>0&&[...v.h.keys()].every(k=>typeof k==='number')?arr(v).map(jsonOf):Object.fromEntries([...v.h].map(([k,x])=>[String(k),jsonOf(x)]))):(v instanceof LV?{x:v.x,y:v.y,z:v.z}:v instanceof LC?{r:v.r,g:v.g,b:v.b}:(typeof v=='object'||typeof v=='function')&&v!==null?undefined:v);
const ofJson=j=>Array.isArray(j)?tbl2(j.map(ofJson)):j&&typeof j=='object'?mkT(Object.fromEntries(Object.entries(j).map(([k,v])=>[k,ofJson(v)]))):j===null?undefined:j;

function setup(){
 L.sig={hc:new Sig(),run:new Sig(),jump:new Sig(),sc:new Sig(),mtf:new Sig()};RT.models=[];RT.plk=[];
 const bp=(n,dx,dy,sx,sy,sz)=>new CPW(n,dx,dy,sx,sy,sz);
 RT.body=[bp('Head',0,2.55,1,1,1),bp('Torso',0,1.6,2,2,1),bp('Left Arm',-1.5,1.6,1,2,1),bp('Right Arm',1.5,1.6,1,2,1),bp('Left Leg',-.5,.5,1,2,1),bp('Right Leg',.5,.5,1,2,1)];
 const ch=RT.ch,fg=FW.prototype.$g;ch.kf=()=>[RT.root,RT.hum].concat(RT.body);RT.body.forEach(b=>ch.x[b.nm]=b);ch.x.PrimaryPart=RT.root;
 ch.$g=function(k){switch(k){case'ClassName':return'Model';case'GetDescendants':return()=>tbl2(this.kf());case'IsA':return(_,c)=>/^(Model|PVInstance|Instance)$/.test(c);
  case'FindFirstChildOfClass':case'FindFirstChildWhichIsA':return(_,c)=>c=='Humanoid'?RT.hum:this.kf().find(x=>clsOf(x)==c||(c=='BasePart'&&clsOf(x)=='Part'));case'GetPivot':return()=>rootCF();case'PivotTo':case'SetPrimaryPartCFrame':return(_,cf)=>{if(cf instanceof CF)setRootCF(cf);return[]};
  case'MoveTo':return(_,v)=>{if(v instanceof LV){P.x=v.x;P.y=v.y;P.z=v.z;P.vy=0}return[]};case'BreakJoints':case'Destroy':return()=>{RT.hum.$s('Health',0);return[]};case'GetFullName':return()=>'Workspace.'+me.name}return fg.call(this,k)};
 const pl=RT.pl;pl.kf=()=>[RT.pg].concat(RT.plk);const mo=new FW('Mouse',()=>[],{Button1Down:new Sig(),Button1Up:new Sig(),Button2Down:new Sig(),KeyDown:new Sig(),KeyUp:new Sig(),Move:new Sig(),X:0,Y:0,Icon:''});
 mo.$g=function(k){if(k=='Hit'){const d=new LV(-Math.sin(yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch));return new CF(new LV(cam3.position.x+d.x*14,cam3.position.y+d.y*14,cam3.position.z+d.z*14))}return FW.prototype.$g.call(this,k)};RT.mouse=mo;
 Object.assign(pl.x,{GetMouse:()=>mo,LoadCharacter:()=>{act.respawn();return[]},Kick:(_,m)=>{toast(String(m||'Dikeluarkan'));return[]},Neutral:true,CharacterRemoving:new Sig(),Chatted:new Sig(),MembershipType:'None',RespawnTime:3});
 /* services */
 const svc=RT.svc,uis=new FW('UserInputService',()=>[],{InputBegan:new Sig(),InputEnded:new Sig(),InputChanged:new Sig(),JumpRequest:new Sig(),
  IsKeyDown:(_,k)=>!!L.keys[k],GetMouseLocation:()=>new LV(innerWidth/2,innerHeight/2,0),TouchEnabled:'ontouchstart' in window,KeyboardEnabled:!('ontouchstart' in window),MouseEnabled:!('ontouchstart' in window),GamepadEnabled:false,MouseBehavior:'Default',MouseIconEnabled:true,GetFocusedTextBox:()=>undefined,
  GetKeysPressed:()=>tbl2(Object.keys(L.keys).filter(k=>L.keys[k]))});RT.uis=uis;svc.UserInputService=uis;
 svc.ContextActionService=new FW('ContextActionService',()=>[],{BindAction:(_,n,f,b,...ks)=>{L.cas[n]={f,ks};return[]},UnbindAction:(_,n)=>{delete L.cas[n];return[]},BindActionAtPriority:(_,n,f,b,p,...ks)=>{L.cas[n]={f,ks};return[]}});
 svc.Debris=new FW('Debris',()=>[],{AddItem:(_,it,t)=>{setTimeout(()=>{try{call(it.$g('Destroy'),[it])}catch(e){}},(+t||10)*1000);return[]}});
 svc.HttpService=new FW('HttpService',()=>[],{JSONEncode:(_,v)=>JSON.stringify(jsonOf(v)),JSONDecode:(_,s)=>{try{return ofJson(JSON.parse(s))}catch(e){throw new Error('JSON tidak valid')}},GenerateGUID:(_,w)=>{const u=(crypto.randomUUID?crypto.randomUUID():String(Math.random())).toUpperCase();return w===false?u.replace(/-/g,''):'{'+u+'}'},UrlEncode:(_,s)=>encodeURIComponent(s),
  GetAsync:()=>{throw new Error('HTTP request diblokir di Pickare')},PostAsync:()=>{throw new Error('HTTP request diblokir di Pickare')},RequestAsync:()=>{throw new Error('HTTP request diblokir di Pickare')},HttpEnabled:false});
 const tagSet=t=>L.tags[t]||(L.tags[t]=new Set());
 svc.CollectionService=new FW('CollectionService',()=>[],{AddTag:(_,i,t)=>{tagSet(String(t)).add(i);return[]},RemoveTag:(_,i,t)=>{tagSet(String(t)).delete(i);return[]},HasTag:(_,i,t)=>tagSet(String(t)).has(i),GetTagged:(_,t)=>tbl2([...tagSet(String(t))]),GetTags:(_,i)=>tbl2(Object.keys(L.tags).filter(t=>L.tags[t].has(i)))});
 ['MarketplaceService','SoundService','StarterPlayer','Chat','TextChatService','PhysicsService','ContentProvider','GuiService','TeleportService','BadgeService','LocalizationService','Stats','NetworkClient','VRService','Selection','MaterialService','TestService','StarterPack','Players_'].forEach(n=>{if(!svc[n])svc[n]=new NW(n,()=>[],{})});
 svc.MarketplaceService.x.UserOwnsGamePassAsync=()=>false;svc.MarketplaceService.x.PromptPurchase=()=>[];
 const rs0=svc.RunService;rs0.x.IsStudio=()=>false;rs0.x.IsRunning=()=>true;rs0.x.BindToRenderStep=(_,n,p,f)=>{rs0.x['_b'+n]=f;RT.hb.h.push(f);return[]};rs0.x.UnbindFromRenderStep=(_,n)=>{const f=rs0.x['_b'+n];if(f)RT.hb.h=RT.hb.h.filter(x=>x!==f);return[]};
 svc.Lighting=new LS();
 const ws=RT.ws,k0=ws.kf;ws.kf=()=>k0().filter(c=>!(c instanceof PtW&&c.par2)).concat(RT.models);
 const wg=FW.prototype.$g,wsx=FW.prototype.$s,cam=new CAMW();
 ws.$g=function(k){switch(k){case'Gravity':return L.grav;case'CurrentCamera':case'Camera':return cam;case'ClassName':return'Workspace';case'Raycast':return(_,o,d)=>raycast(o,d);case'GetServerTimeNow':return()=>Date.now()/1000;case'GetDescendants':return()=>tbl2(k0().concat(RT.models.flatMap(m=>m.desc())));case'IsA':return(_,c)=>/^(Workspace|Instance|Model)$/.test(c);case'FindPartsInRegion3':case'GetPartBoundsInBox':case'GetPartBoundsInRadius':return()=>tbl2([]);case'Terrain':return undefined}return wg.call(this,k)};
 ws.$s=function(k,v){if(k=='Gravity'){L.grav=nn(v,0,1000,196.2);return}return wsx.call(this,k,v)};
 /* leaderstats */
 const hud=document.createElement('div');hud.id='sp-ls';hud.style.cssText='position:absolute;top:56px;right:8px;z-index:6;background:rgba(0,0,0,.55);color:#fff;border-radius:10px;padding:6px 10px;font:600 13px system-ui;display:none;pointer-events:none;max-width:44vw';const gm=document.getElementById('game');if(gm)gm.appendChild(hud);RT.lsHud=hud;
 RT.lsT=setInterval(()=>{if(!RT||!RT.alive){clearInterval(RT&&RT.lsT);return}const f=(RT.plk||[]).find(x=>x.n=='leaderstats');if(!f){hud.style.display='none';return}
  const rows=f.ch.filter(c=>c.p&&c.p.Value!==undefined).map(c=>'<div style="display:flex;justify-content:space-between;gap:14px"><span>'+esc(c.nm)+'</span><b>'+esc(tostr(c.p.Value))+'</b></div>');hud.innerHTML=rows.join('');hud.style.display=rows.length?'block':'none'},500);
 /* respawn -> CharacterAdded */
 L.respawnFlag=0}
const _rt=rtStart;rtStart=function(g){rs();_rt.apply(this,arguments);if(RT)try{setup()}catch(e){OUT('err','Luau Pro: '+(e.message||e))}};
const _rp=rtStop;rtStop=function(){try{if(RT&&RT.lsT)clearInterval(RT.lsT);if(RT&&RT.lsHud)RT.lsHud.remove()}catch(e){}try{const dn=document.getElementById('sp-dn');if(dn)dn.style.display='none'}catch(e){}rs();return _rp.apply(this,arguments)};

/* ===== input ke Luau ===== */
const KN=e=>{const k=e.key;if(k.length==1){const u=k.toUpperCase();if(/[A-Z]/.test(u))return u;if(/[0-9]/.test(u))return['Zero','One','Two','Three','Four','Five','Six','Seven','Eight','Nine'][+u];return u==' '?'Space':null}return({Shift:'LeftShift',Control:'LeftControl',Alt:'LeftAlt',Enter:'Return',Escape:'Escape',Tab:'Tab',Backspace:'Backspace',ArrowUp:'Up',ArrowDown:'Down',ArrowLeft:'Left',ArrowRight:'Right'})[k]||(/^F\d+$/.test(k)?k:null)};
const inp=(kc,ty,st)=>{const t=new LT();t.set('KeyCode',kc||'Unknown');t.set('UserInputType',ty);t.set('UserInputState',st);return t};
const kfire=(down,e)=>{if(!RT||!RT.alive||!RT.uis)return;if(document.activeElement&&document.activeElement.tagName=='INPUT')return;const k=KN(e);if(!k)return;
 if(down){if(e.repeat)return;L.keys[k]=1}else L.keys[k]=0;
 const i=inp(k,'Keyboard',down?'Begin':'End');RT.uis.x[down?'InputBegan':'InputEnded'].fire(i,false);if(RT.mouse)RT.mouse.x[down?'KeyDown':'KeyUp'].fire(String(e.key).toLowerCase());
 if(down&&k=='Space')RT.uis.x.JumpRequest.fire();
 if(down)Object.keys(L.cas).forEach(n=>{const c=L.cas[n];if(c.ks.some(x=>x===k||x===k.toLowerCase())){call(c.f,[n,'Begin',i]).catch(rerr)}})};
window.addEventListener('keydown',e=>kfire(true,e),true);window.addEventListener('keyup',e=>kfire(false,e),true);
window.addEventListener('blur',()=>{L.keys={}});
{const cvs=document.getElementById('c')||document.querySelector('#game canvas');const cv0=typeof cv!=='undefined'?cv:cvs;
 if(cv0){cv0.addEventListener('pointerdown',e=>{if(!RT||!RT.alive||!RT.uis)return;const t=e.pointerType=='mouse'?'MouseButton1':'Touch';RT.uis.x.InputBegan.fire(inp('Unknown',t,'Begin'),false);if(RT.mouse)RT.mouse.x.Button1Down.fire()});
  cv0.addEventListener('pointerup',e=>{if(!RT||!RT.alive||!RT.uis)return;RT.uis.x.InputEnded.fire(inp('Unknown',e.pointerType=='mouse'?'MouseButton1':'Touch','End'),false);if(RT.mouse)RT.mouse.x.Button1Up.fire()})}}

/* ===== tombol turun (HP) ===== */
let dn=null;const mkDn=()=>{if(dn)return dn;const g=document.getElementById('game');if(!g)return null;dn=document.createElement('button');dn.id='sp-dn';dn.textContent='▼';dn.style.cssText='position:absolute;right:22px;bottom:200px;width:54px;height:54px;border-radius:50%;border:3px solid #000;background:#ffde59;font:700 22px system-ui;z-index:7;display:none;touch-action:none';
 dn.addEventListener('pointerdown',e=>{e.preventDefault();L.dn=true});['pointerup','pointercancel','pointerleave'].forEach(v=>dn.addEventListener(v,()=>L.dn=false));g.appendChild(dn);return dn};

/* ===== fisika: WalkSpeed, JumpPower, Gravity, fly, noclip, velocity, BodyVelocity ===== */
const _loop=loop;
loop=function(t){
 if(!run||!RT||!RT.alive||typeof P==='undefined'||!P)return _loop(t);
 const dt=Math.min(.05,(t-last)/1000)||.016;
 /* sinkronkan kotak tabrak part yang dipindah script */
 try{RT.parts.forEach(w=>{if(w.dirty){w.dirty=0;if(w.bx&&w.cc!==false&&w.o.cc!==false)syncBox(w)}});(RT.models||[]).forEach(m=>m.parts().forEach(w=>{if(w.dirty){w.dirty=0;if(w.bx)syncBox(w)}}))}catch(e){}
 const bv=(L.bvs||[]).filter(b=>truthy(b.p.Enabled));
 const on=L.noclip||L.fly||L.ph||L.ws!==16||L.jp!==50||L.grav!==196.2||L.vel||bv.length||L.anch||L.mv||L.jump;
 const d=mkDn();if(d)d.style.display=(L.fly||L.ph||bv.length)&&!paused?'block':'none';
 if(!on||paused)return _loop(t);
 const x0=P.x,y0=P.y,z0=P.z,g0=P.ground;let sb,sl;
 if(L.noclip){sb=boxes;sl=lavas;boxes=[];lavas=[]}
 try{_loop(t)}finally{if(sb){boxes=sb;lavas=sl}}
 const dx=P.x-x0,dz=P.z-z0,hitf=(x,z,y)=>L.noclip?false:hit(x,z,y);
 if(L.ws!==16&&(dx||dz)){const f=L.ws/16,nx=Math.max(-48,Math.min(48,x0+dx*f)),nz=Math.max(-48,Math.min(48,z0+dz*f));if(!hitf(nx,P.z,P.y))P.x=nx;if(!hitf(P.x,nz,P.y))P.z=nz}
 if(L.mv){const tx=L.mv.x-P.x,tz=L.mv.z-P.z,dd=Math.hypot(tx,tz);if(dd<.6){L.mv=null;L.sig.mtf.fire(true)}else{const sp=Math.max(1,L.ws/2)*dt;P.x+=tx/dd*sp;P.z+=tz/dd*sp;P.ry=Math.atan2(tx,tz)}}
 if(g0&&P.vy>4&&(L.jp!==50||L.jump)){P.vy=12*(L.jp/50)-30*dt;L.sig.jump.fire(true)}
 if(L.jump){if(g0&&P.vy<=4){P.vy=12*(L.jp/50);P.ground=false;L.sig.jump.fire(true)}L.jump=false}
 if(L.grav!==196.2&&!P.ground)P.vy+=(30-30*L.grav/196.2)*dt;
 if(L.fly||L.ph){const up=(jumpHeld||keys[' '])?1:0,dw=(keys.shift||keys.control||keys.q||L.dn)?1:0,fs=Math.max(4,L.ws/16*10);P.y=y0+(up-dw)*fs*dt;P.vy=0;P.ground=false}
 if(bv.length){const b=bv[bv.length-1],v=b.cls=='LinearVelocity'?b.p.VectorVelocity:b.cls=='BodyPosition'?null:b.p.Velocity;
  if(b.cls=='BodyPosition'){const p=b.p.Position,k=Math.min(1,dt*4);P.x+=(p.x-P.x)*k;P.y+=(p.y-1.5-P.y)*k;P.z+=(p.z-P.z)*k}
  else if(v instanceof LV&&(b.cls=='BodyVelocity'||b.cls=='LinearVelocity')){P.x+=v.x*dt;P.y+=v.y*dt;P.z+=v.z*dt;P.vy=0;P.ground=false}}
 if(L.vel instanceof LV){P.x+=L.vel.x*dt;P.y+=L.vel.y*dt;P.z+=L.vel.z*dt;if(L.vel.y)P.vy=0;const k=Math.max(0,1-4*dt);L.vel=new LV(L.vel.x*k,L.vel.y*k,L.vel.z*k);if(Math.hypot(L.vel.x,L.vel.y,L.vel.z)<.05)L.vel=null}
 if(L.anch){P.x=x0;P.y=y0;P.z=z0;P.vy=0}
 if(P.y<-60&&(L.noclip||L.fly))P.y=-60;
 try{plr.position.set(P.x,P.y,P.z)}catch(e){}};

/* ===== toolbox: template siap pakai ===== */
const lsrc=(k,cls)=>ST.d.svc[k]?k:'ReplicatedFirst';
const addT=(n,d,f)=>{if(!TB.some(x=>x.n===n))TB.push({n,ic:'',d,f})};
addT('Neon Part','Balok neon yang berganti warna pelan-pelan',()=>{ST.d.objs.push(pa(0,1,10,4,1,4,'#00ffff','NeonPart'));return sg('ServerScriptService','Script','local part = workspace:FindFirstChild("NeonPart")\npart.Material = Enum.Material.Neon\nwhile true do\n\tpart.Color = Color3.fromHSV((tick() % 5) / 5, 1, 1)\n\twait(0.05)\nend\n','NeonScript')});
addT('Ubah Warna & Material','Balok: ganti warna dengan BrickColor + Material',()=>{ST.d.objs.push(pa(8,1,10,4,1,4,'#ffffff','ColorPart'));return sg('ServerScriptService','Script','local part = workspace:FindFirstChild("ColorPart")\nlocal mats = {Enum.Material.Neon, Enum.Material.Glass, Enum.Material.Metal, Enum.Material.Wood}\nlocal i = 1\nwhile true do\n\tpart.BrickColor = BrickColor.Random()\n\tpart.Material = mats[i]\n\ti = i % #mats + 1\n\twait(1)\nend\n','ColorScript')});
addT('Fly (tekan F)','LocalScript: tekan F untuk terbang. Spasi/lompat = naik, Shift/▼ = turun',()=>{const k=lsrc('StarterPlayerScripts');return sg(k,'LocalScript','local UIS = game:GetService("UserInputService")\nlocal player = game:GetService("Players").LocalPlayer\nlocal hum = player.Character:FindFirstChild("Humanoid")\nlocal flying = false\n\nUIS.InputBegan:Connect(function(input, gp)\n\tif input.KeyCode == Enum.KeyCode.F then\n\t\tflying = not flying\n\t\thum.PlatformStand = flying\n\t\tprint("Fly:", flying)\n\tend\nend)\n','FlyScript')});
addT('Fly BodyVelocity','LocalScript: terbang ke arah kamera (Heartbeat + BodyVelocity), tombol E',()=>{const k=lsrc('StarterPlayerScripts');return sg(k,'LocalScript','local Players = game:GetService("Players")\nlocal UIS = game:GetService("UserInputService")\nlocal RunService = game:GetService("RunService")\nlocal char = Players.LocalPlayer.Character\nlocal root = char:FindFirstChild("HumanoidRootPart")\nlocal hum = char:FindFirstChild("Humanoid")\nlocal cam = workspace.CurrentCamera\nlocal speed = 50\nlocal bv = nil\n\nUIS.InputBegan:Connect(function(input)\n\tif input.KeyCode ~= Enum.KeyCode.E then return end\n\tif bv then\n\t\tbv:Destroy()\n\t\tbv = nil\n\telse\n\t\tbv = Instance.new("BodyVelocity")\n\t\tbv.MaxForce = Vector3.new(1e5, 1e5, 1e5)\n\t\tbv.Parent = root\n\tend\nend)\n\nRunService.Heartbeat:Connect(function()\n\tif bv then\n\t\tif hum.MoveDirection.Magnitude > 0 then\n\t\t\tbv.Velocity = cam.CFrame.LookVector * speed\n\t\telse\n\t\t\tbv.Velocity = Vector3.new(0, 0, 0)\n\t\tend\n\tend\nend)\n','FlyBodyVelocity')});
addT('Noclip (tekan N)','LocalScript: tekan N untuk tembus dinding & lantai',()=>{const k=lsrc('StarterPlayerScripts');return sg(k,'LocalScript','local UIS = game:GetService("UserInputService")\nlocal RunService = game:GetService("RunService")\nlocal char = game:GetService("Players").LocalPlayer.Character\nlocal noclip = false\n\nUIS.InputBegan:Connect(function(input)\n\tif input.KeyCode == Enum.KeyCode.N then\n\t\tnoclip = not noclip\n\t\tprint("Noclip:", noclip)\n\tend\nend)\n\nRunService.Stepped:Connect(function()\n\tfor _, part in pairs(char:GetDescendants()) do\n\t\tif part:IsA("BasePart") then\n\t\t\tpart.CanCollide = not noclip\n\t\tend\n\tend\nend)\n','NoclipScript')});
addT('Speed & Lompat Tinggi','Script: WalkSpeed 32, JumpPower 100',()=>sg('ReplicatedFirst','LocalScript','local hum = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Humanoid")\nhum.WalkSpeed = 32\nhum.JumpPower = 100\nprint("Speed & lompat tinggi aktif")\n','SpeedScript'));
addT('Lampu Neon (PointLight)','Balok neon + PointLight yang menyala',()=>{ST.d.objs.push(pa(-8,1,10,2,2,2,'#ff00ff','GlowPart'));return sg('ServerScriptService','Script','local part = workspace:FindFirstChild("GlowPart")\npart.Material = Enum.Material.Neon\nlocal light = Instance.new("PointLight")\nlight.Brightness = 2\nlight.Range = 16\nlight.Color = part.Color\nlight.Parent = part\n','GlowScript')});

/* ===== referensi Luau: tambahan ===== */
new MutationObserver(()=>{const r=document.getElementById('sref');if(r&&!document.getElementById('sref2'))r.insertAdjacentHTML('beforeend','<div id="sref2" style="margin-top:8px"><b>Tambahan Luau Pro</b><br>Part: <code>.Material = Enum.Material.Neon</code> <code>.BrickColor = BrickColor.new("Bright red")</code> <code>.Anchored</code> <code>.CanCollide</code> <code>.CFrame</code> <code>.Orientation</code> <code>:Clone()</code> <code>:Destroy()</code><br>Humanoid: <code>.WalkSpeed</code> <code>.JumpPower</code> <code>.PlatformStand</code> (terbang) <code>.Health</code> <code>.MoveDirection</code> <code>:ChangeState(...)</code> <code>:MoveTo(pos)</code><br>Noclip: <code>part.CanCollide = false</code> pada bagian karakter · Fly: <code>PlatformStand</code>, <code>BodyVelocity</code>, atau <code>root.Velocity</code><br>Input: <code>UserInputService.InputBegan:Connect(function(input, gp) ... end)</code> <code>input.KeyCode == Enum.KeyCode.F</code> <code>UIS:IsKeyDown(...)</code> <code>ContextActionService:BindAction</code><br>Lainnya: <code>CFrame.new/Angles/lookAt</code> <code>BrickColor</code> <code>Instance.new("Model"/"PointLight"/"BodyVelocity"/"IntValue"...)</code> <code>Debris:AddItem</code> <code>workspace.Gravity</code> <code>workspace:Raycast</code> <code>workspace.CurrentCamera</code> <code>Lighting.ClockTime</code> <code>HttpService:JSONEncode</code> <code>CollectionService</code> <code>tick()</code> <code>Random.new()</code> <code>leaderstats</code></div>')}).observe(document.body,{childList:true,subtree:true});
})();
