/* ===== v12f: Beranda tidak di-refresh kalau datanya sama ===== */
(function(){
let lastSig='';
function sig(){try{const gs=pubGames();
 return JSON.stringify([gs.map(g=>[g.id,g.name,g.pl,g.lk,g._ts,g.n]),me.recent,FRD(me),
  Object.keys(users).filter(k=>users[k]&&users[k].rm).map(k=>[k,users[k].pres&&users[k].pres.g,JSON.stringify(users[k].av)]),
  (me.notes||[]).length,me.unr,me.bux,me.name,JSON.stringify(me.av),(me.games||[]).map(g=>g.id+':'+g.name+':'+(g.pub?1:0))])}catch(e){return String(Math.random())}}
const _ru=refreshUI;
refreshUI=function(){
 try{if(me&&page==='home'&&!(OVS&&OVS.length)){const m=$('#main');
   if(m&&m.firstElementChild&&sig()===lastSig)return;
   const top=m?m.scrollTop:0;const r=_ru.apply(this,arguments);if(m)m.scrollTop=top;lastSig=sig();return r}}catch(e){}
 return _ru.apply(this,arguments)};
const _rd2=render;
render=function(){const r=_rd2.apply(this,arguments);try{if(me&&page==='home')lastSig=sig()}catch(e){}return r};
})();
