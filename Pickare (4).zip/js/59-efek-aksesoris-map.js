/* ===== v19: efek aksesoris (Fire/Smoke/Sparkles/ParticleEmitter/Explosion/PointLight) selalu muncul saat main di map =====
   Penyebab sebelumnya:
   1. rtStart() langsung berhenti untuk map yang belum punya "svc" (map tanpa script/service) -> runtime efek tidak pernah hidup,
      jadi aksesoris ber-efek tidak mengeluarkan efek sama sekali di map itu.
   2. Aksesoris hasil beli yang tidak sempat menyalin efeknya (ch kosong) tidak punya efek untuk dijalankan.
   Perbaikan: map tanpa svc dijalankan dengan svc kosong (data map asli tidak diubah), dan efek aksesoris yang dipakai
   disalin ulang dari katalog bila hilang, sebelum game dimulai. Efek tetap ikut dikirim ke pemain lain lewat presence. */
(function(){
const M={r:'Rate',l:'Lifetime',s:'Speed',z:'Size',a:'SpreadAngle',g:'Acceleration'};
function toNode(d){const n=newI(d.c);for(const k in M)if(d[k]!==undefined&&n[M[k]]!==undefined)n[M[k]]=+d[k];
 if(/^#[0-9a-f]{6}$/i.test(d.k||''))n.Color=d.k;if(d.c==='Explosion')n.BlastRadius=+d.b||6;
 if(d.c==='PointLight'){n.Brightness=+d.b||1;n.Range=+d.n||16}
 if(d.e===0&&n.Enabled!==undefined)n.Enabled=false;if(Array.isArray(d.q)&&d.q.length===4)n.pq=d.q.map(v=>+v||0);return n}
const hasFx=l=>(l||[]).some(n=>n&&(n.fx||(n.ch&&hasFx(n.ch))));
function heal(){try{if(typeof me==='undefined'||!me)return;
 const ids=((typeof forceAcc!=='undefined'&&forceAcc)||(me.av&&me.av.acc)||[]).slice();if(me.av&&me.av.body&&!ids.includes(me.av.body))ids.push(me.av.body);
 let cat=null,ch=0;
 ids.forEach(id=>{const it=(me.items||[]).find(x=>x.id==id);if(!it||!it.src||(it.ch&&it.ch.length)||(it.objs||[]).some(o=>o&&hasFx(o.ch)))return;
  if(!cat)cat=mkItems();const m=cat.find(x=>x.key===it.src);
  if(m&&Array.isArray(m.fx)&&m.fx.length){it.ch=m.fx.slice(0,6).map(toNode);ch=1}});
 if(ch)save()}catch(e){}}
const _rs=rtStart;
rtStart=function(g){heal();
 if(g&&!g.svc)g=Object.assign({},g,{svc:{}});
 return _rs.call(this,g)};
})();
