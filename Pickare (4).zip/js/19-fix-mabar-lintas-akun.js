/* ===== FIX MABAR LINTAS AKUN: room teman (f-...) & server privat (ps-...) tidak boleh bergantung pada API key lokal tiap HP,
   kalau tidak HP A dan HP B masuk dunia berbeda walau gabung dari daftar teman ===== */
(function(){const g=Storage.prototype.getItem;
Storage.prototype.getItem=function(k){if(k==='sp_rkey'&&this===window.localStorage){try{if(typeof roomCode==='string'&&/^(f-|ps-)/.test(roomCode)||roomCode==='publik')return ''}catch(e){}}return g.apply(this,arguments)}})();
