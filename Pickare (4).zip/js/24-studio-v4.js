/* ===== STUDIO v4: UICorner/UIStroke/UIGradient, ImageButton/Label, RemoteEvent, Sound, Tekstur, Rig, Toolbox lengkap ===== */
(function(){
const MODC=['UICorner','UIStroke','UIGradient','UIListLayout','UIGridLayout','UIPadding'],SERV=['RemoteEvent','RemoteFunction','BindableEvent'];
Object.assign(GN,{ImageButton:1,ImageLabel:1});
Object.assign(CL,{ImageButton:'',ImageLabel:'',UICorner:'◜',UIStroke:'',UIGradient:'',UIListLayout:'',UIGridLayout:'',UIPadding:'',RemoteEvent:'',RemoteFunction:'',BindableEvent:'',Sound:''});
Object.assign(CD,{ImageButton:'Tombol bergambar (upload gambar)',ImageLabel:'Label bergambar',UICorner:'Sudut membulat untuk elemen GUI',UIStroke:'Garis tepi (warna & tebal)',UIGradient:'Warna gradasi',UIListLayout:'Susun anak GUI berurutan (vertikal / horizontal)',UIGridLayout:'Susun anak GUI dalam kotak-kotak (grid)',UIPadding:'Jarak dalam (padding) elemen',RemoteEvent:'Event klien↔server (FireServer/OnServerEvent)',RemoteFunction:'Fungsi klien↔server (InvokeServer)',BindableEvent:'Event antar script',Sound:'Suara (efek / musik)'});
GUIK.push('ImageButton','ImageLabel');
PL.ReplicatedStorage.push('RemoteEvent','RemoteFunction','BindableEvent','Sound');
PL.Workspace.push('Sound','Folder');PL.ServerScriptService.push('RemoteEvent','RemoteFunction','BindableEvent','Sound');PL.ServerStorage.push('RemoteEvent','Sound');PL.StarterGui.push('Sound');
const hx=c=>/^#[0-9a-f]{6}$/i.test(c)?c:null,nn=(v,a,b,d)=>{v=+v;return isFinite(v)?Math.min(b,Math.max(a,v)):d};
/* ---- newI ---- */
const _ni=newI;newI=function(c){const i=_ni(c);
 if(c=='ImageButton'||c=='ImageLabel'){i.img='';i.bg='#ffffff';i.bt=0;i.txt='';i.s=[0,120,0,120]}
 if(c=='UIListLayout'){i.pad=6;i.dir='v';i.ha='l'}if(c=='UIGridLayout'){i.pad=6;i.cw=80;i.chh=80}if(c=='UIPadding'){i.pt=8;i.pb=8;i.pl=8;i.pr=8}
 if(c=='UICorner')i.rad=8;if(c=='UIStroke'){i.col='#000000';i.th=2}if(c=='UIGradient'){i.c0='#ff90e8';i.c1='#7df9ff';i.rot=90}
 if(c=='Sound'){i.preset='coin';i.vol=.6;i.loop=false;i.auto=false}return i};
/* ---- gSty: modifier + gambar ---- */
const _gs=gSty;gSty=function(i,e){_gs(i,e);if(i.cls=='ScreenGui')return;const ch=i.ch||[],c=ch.find(x=>x.cls=='UICorner'),st=ch.find(x=>x.cls=='UIStroke'),gr=ch.find(x=>x.cls=='UIGradient'),s=e.style,im=(i.cls=='ImageButton'||i.cls=='ImageLabel')?okImg(i.img):'';
 if(i.cls=='ImageButton')s.cursor='pointer';
 if(c)s.borderRadius=nn(c.rad,0,999,8)+'px';
 if(st){s.border=nn(st.th,0,30,2)+'px solid '+(hx(st.col)||'#000000')}
 const L=[];if(gr)L.push(`linear-gradient(${nn(gr.rot,-360,360,90)}deg,${hx(gr.c0)||'#fff'},${hx(gr.c1)||'#000'})`);if(im)L.push(`url("${im}")`);
 if(L.length){s.backgroundImage=L.join(',');s.backgroundSize=im?(gr?'auto,cover':'cover'):'auto';s.backgroundPosition='center';s.backgroundRepeat='no-repeat'}
 const ll=ch.find(x=>x.cls=='UIListLayout'),lg=ch.find(x=>x.cls=='UIGridLayout'),pd=ch.find(x=>x.cls=='UIPadding'),cx=e.classList;
 cx.remove('llv','llh','lla','llr','lgd');
 if(i.vis!==false){if(ll){cx.add(ll.dir=='h'?'llh':'llv');if(ll.ha=='c')cx.add('lla');else if(ll.ha=='r')cx.add('llr');s.setProperty('--gap',nn(ll.pad,0,200,6)+'px')}
  else if(lg){cx.add('lgd');s.setProperty('--gap',nn(lg.pad,0,200,6)+'px');s.setProperty('--cw',nn(lg.cw,8,600,80)+'px');s.setProperty('--chh',nn(lg.chh,8,600,80)+'px')}}
 if(pd)s.padding=nn(pd.pt,0,200,8)+'px '+nn(pd.pr,0,200,8)+'px '+nn(pd.pb,0,200,8)+'px '+nn(pd.pl,0,200,8)+'px'};
/* ---- picker ---- */
const _pk=pickL;pickL=function(t){const L=_pk(t),have=new Set(L.map(x=>x.id)),add=c=>{if(!have.has(c)){have.add(c);L.push({id:c,k:'inst',n:c,ic:CL[c],d:CD[c]})}},r=loc(t);
 if(r){const cl=r.i.cls;if(GN[cl]&&cl!='ScreenGui')MODC.forEach(add);if(cl=='Folder'){SERV.concat('Sound').forEach(add)}}return L};
/* ---- properti ---- */
const _ip=iProps;iProps=function(i){let h=_ip(i);const K='<div style="display:flex;gap:6px;margin-top:8px"><button class="btn sm c" data-a="idup">',cv=v=>hx(v)||'#ffffff',
 nf=(l,q,v,a)=>`<label>${l}</label><input type="number" ${a||''} data-q="${q}" value="${v}">`,cf=(l,q,v)=>`<label>${l}</label><input type="color" data-q="${q}" value="${cv(v)}">`;let a='';
 if(i.cls=='UICorner')a=nf('CornerRadius (px, 999 = bulat)','rad',i.rad,'min="0" max="999" step="2"');
 if(i.cls=='UIStroke')a=cf('Color','col',i.col)+nf('Thickness','th',i.th,'min="0" max="30" step="1"');
 if(i.cls=='UIGradient')a=cf('Color 0','c0',i.c0)+cf('Color 1','c1',i.c1)+nf('Rotation','rot',i.rot,'step="15"');
 if(i.cls=='UIListLayout')a=nf('Padding (px)','pad',i.pad,'min="0" max="200"')+`<label>FillDirection</label><select data-q="dir"><option value="v" ${i.dir!='h'?'selected':''}>Vertical</option><option value="h" ${i.dir=='h'?'selected':''}>Horizontal</option></select><label>HorizontalAlignment</label><select data-q="ha">${[['l','Left'],['c','Center'],['r','Right']].map(x=>`<option value="${x[0]}" ${(i.ha||'l')==x[0]?'selected':''}>${x[1]}</option>`).join('')}</select>`;
 if(i.cls=='UIGridLayout')a=nf('CellSize lebar (px)','cw',i.cw,'min="8" max="600"')+nf('CellSize tinggi (px)','chh',i.chh,'min="8" max="600"')+nf('CellPadding (px)','pad',i.pad,'min="0" max="200"');
 if(i.cls=='UIPadding')a=nf('PaddingTop','pt',i.pt,'min="0" max="200"')+nf('PaddingBottom','pb',i.pb,'min="0" max="200"')+nf('PaddingLeft','pl',i.pl,'min="0" max="200"')+nf('PaddingRight','pr',i.pr,'min="0" max="200"');
 if(i.cls=='ImageButton'||i.cls=='ImageLabel'){const im=okImg(i.img);a=`<label>Image</label><div class="pv" style="${im?`background:url('${im}') center/cover`:''}">${im?'':'kosong'}</div><div style="display:flex;gap:6px"><button class="btn sm g" data-a="iimg">Upload</button><button class="btn sm o" data-a="iclr">Hapus</button></div>`}
 if(SERV.includes(i.cls))a='<div style="font-size:11px;line-height:1.5;margin-top:6px"><code>ev.OnServerEvent:Connect(f)</code><br><code>ev:FireServer(...)</code><br><code>ev:FireClient(plr, ...)</code><br><code>ev.OnClientEvent:Connect(f)</code></div>';
 if(i.cls=='Sound')a=`<label>Suara</label><select data-q="preset">${Object.keys(SNDN).map(k=>`<option value="${k}" ${i.preset==k?'selected':''}>${SNDN[k]}</option>`).join('')}</select>`+nf('Volume (0-1)','vol',i.vol,'min="0" max="1" step=".1"')+`<label class="ck"><input type="checkbox" data-q="loop" ${i.loop?'checked':''}> Looped</label><label class="ck"><input type="checkbox" data-q="auto" ${i.auto?'checked':''}> Putar otomatis saat Test</label><button class="btn sm g w" data-a="sndtest">▶ Dengar</button>`;
 return a?h.replace(K,a+K):h};
/* ---- upload gambar GUI ---- */
document.body.insertAdjacentHTML('beforeend','<input type="file" id="fi2" accept="image/*" hidden>');
$('#fi2').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';const r=SI&&loc(SI);if(!f||!r)return;if(!/^image\//.test(f.type))return toast('File harus gambar');
 const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const m=Math.min(1,256/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,im.width*m|0);c.height=Math.max(1,im.height*m|0);c.getContext('2d').drawImage(im,0,0,c.width,c.height);r.i.img=c.toDataURL(f.type=='image/png'?'image/png':'image/jpeg',.85);touch();pRender();guiRefresh();toast('Gambar dipasang')};im.onerror=()=>toast('Gambar tidak valid');im.src=fr.result};fr.readAsDataURL(f)});
/* ---- palet GUI & tambah modifier ---- */
const _tr=tbxRender;tbxRender=function(){_tr();if(ST&&ST.kind=='g'&&guiOn)$('#tbx').insertAdjacentHTML('beforeend','<h4>Gambar</h4><div class="tg">'+['ImageButton','ImageLabel'].map(c=>`<button class="btn sm" data-a="gadd" data-v="${c}">${CL[c]}<br>${c.replace('Image','Img')}</button>`).join('')+'</div><h4>Modifier</h4><div class="tg">'+MODC.map(c=>`<button class="btn sm" data-a="gadd" data-v="${c}">${CL[c]}<br>${c.slice(2)}</button>`).join('')+'</div><div class="hint">Modifier dipasang ke elemen yang dipilih.</div>')};
const _ga=act.gadd;act.gadd=function(cls){if(!MODC.includes(cls))return _ga.apply(this,arguments);
 let r=SI&&loc(SI),p=r&&r.i;if(p&&MODC.includes(p.cls))p=findPar(ST.d.svc.StarterGui,p);if(!p||!GN[p.cls]||p.cls=='ScreenGui')return toast('Pilih elemen GUI dulu (Frame, Tombol, dll)');
 let x=p.ch.find(y=>y.cls==cls);if(!x){x=newI(cls);p.ch.push(x)}SI=x.id;SEL='root';guiOn=true;eRender();pRender();guiRefresh();touch();rtab('props');toast(cls+' dipasang')};
Object.assign(act,{iimg(){$('#fi2').click()},iclr(){const r=SI&&loc(SI);if(r){r.i.img='';touch();pRender();guiRefresh()}},
 sndtest(){const r=SI&&loc(SI);if(r)sndGo(r.i.preset,r.i.vol,false)}});
/* ---- tekstur ---- */
const TXN={brick:'Batu Bata',grass:'Rumput',wood:'Kayu',stone:'Batu',sand:'Pasir',metal:'Logam',checker:'Papan Catur',water:'Air'},TXC={};
function txGet(k){if(TXC[k])return TXC[k];const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');let s=7;const r=()=>(s=(s*16807)%2147483647)/2147483647,fill=q=>{x.fillStyle=q;x.fillRect(0,0,128,128)},sp=(cols,n,z)=>{for(let i=0;i<n;i++){x.fillStyle=cols[i%cols.length];x.fillRect(r()*128,r()*128,z,z)}};
 if(k=='brick'){fill('#d8d0c0');x.fillStyle='#b5523b';for(let j=0;j<4;j++)for(let i=-1;i<3;i++)x.fillRect(i*64+(j%2)*32+2,j*32+2,60,28);sp(['#a2452f','#c26048'],60,4)}
 if(k=='grass'){fill('#4caf50');sp(['#3d9142','#66bb6a','#2f7d35'],400,3)}
 if(k=='wood'){fill('#a1693a');for(let j=0;j<4;j++){x.fillStyle='#6b4423';x.fillRect(0,j*32,128,2);x.fillStyle='#8c5a2e';for(let g=0;g<5;g++)x.fillRect(r()*128,j*32+4+r()*24,30+r()*40,1.5)}}
 if(k=='stone'){fill('#8a8d93');for(let i=0;i<45;i++){x.fillStyle=`rgba(${r()<.5?'40,40,45':'200,200,205'},.25)`;x.beginPath();x.arc(r()*128,r()*128,6+r()*14,0,7);x.fill()}}
 if(k=='sand'){fill('#e6cf8e');sp(['#d4b972','#f1dfa8','#c9ad66'],500,2)}
 if(k=='metal'){fill('#b0b7bf');x.fillStyle='#8d949c';for(let i=0;i<128;i+=32){x.fillRect(i,0,2,128);x.fillRect(0,i,128,2)}x.fillStyle='#6f757c';for(let i=0;i<4;i++)for(let j=0;j<4;j++){x.beginPath();x.arc(i*32+8,j*32+8,2.5,0,7);x.fill()}}
 if(k=='checker'){for(let i=0;i<8;i++)for(let j=0;j<8;j++){x.fillStyle=(i+j)%2?'#111':'#fff';x.fillRect(i*16,j*16,16,16)}}
 if(k=='water'){fill('#2f7de1');x.strokeStyle='rgba(255,255,255,.35)';x.lineWidth=2;for(let j=0;j<6;j++){x.beginPath();for(let i=0;i<=128;i+=8)x.lineTo(i,j*22+8+Math.sin(i/10+j)*4);x.stroke()}}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;return TXC[k]=t}
const _mo=mkObj;mkObj=function(o){const m=_mo(o);if(o&&o.t!='coin'&&typeof o.tex=='string'&&Object.hasOwn(TXN,o.tex)&&m.material){const t=txGet(o.tex).clone(),q=Math.max(1,Math.round(((+o.sx||1)+(+o.sz||1))/8));t.needsUpdate=true;t.repeat.set(q,q);m.material.map=t;m.material.needsUpdate=true}return m};
const _pr=pRender;pRender=function(){_pr();if(!ST||SI)return;const o=cur();if(!o||o.t=='coin')return;const p=$('#props'),K='<div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm c" data-a="edup">';
 p.innerHTML=p.innerHTML.replace(K,'<label>Tekstur</label><select data-p="tex"><option value="">Tanpa</option>'+Object.keys(TXN).map(q=>`<option value="${q}" ${o.tex==q?'selected':''}>${TXN[q]}</option>`).join('')+'</select>'+K)};
/* ---- suara (sintesis WebAudio) ---- */
let AC=null;const SNDS=new Set();
const SP={coin:{w:'square',s:[[988,.07],[1319,.3]]},jump:{w:'square',sw:[260,760,.2]},boom:{n:.7},win:{w:'triangle',s:[[523,.12],[659,.12],[784,.12],[1047,.45]]},alarm:{w:'sawtooth',s:[[880,.22],[660,.22],[880,.22],[660,.22]]},klik:{w:'square',s:[[1400,.04]]},hit:{w:'sawtooth',sw:[400,80,.25]},
 musik:{w:'triangle',s:[[262,.3],[330,.3],[392,.3],[523,.3],[392,.3],[330,.3],[294,.3],[392,.3],[262,.3],[330,.3],[392,.3],[494,.3],[392,.3],[330,.3],[262,.6],[0,.3]]},
 petualangan:{w:'square',g:.5,s:[[330,.15],[392,.15],[440,.15],[494,.3],[440,.15],[392,.15],[330,.3],[294,.15],[330,.15],[392,.3],[330,.15],[294,.15],[262,.45],[0,.15]]},angin:{n:2.5,lp:600}};
const SNDN={coin:'Koin',jump:'Lompat',boom:'Ledakan',win:'Menang',alarm:'Alarm',klik:'Klik',hit:'Pukulan',musik:'Musik Santai',petualangan:'Musik Petualangan',angin:'Angin'};
function sndGo(p,vol,loop,onEnd){let c;try{c=AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(c.state=='suspended')c.resume()}catch(e){return()=>{}}
 const d=SP[p]||SP.coin;vol=nn(vol,0,1,.5);let dead=0,iv=0,to=0;const nodes=[];
 const once=()=>{let t=c.currentTime+.02;const t0=t,env=(g,du)=>{g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol*.3*(d.g||1),t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+du)};
  if(d.n){const len=c.sampleRate*d.n|0,b=c.createBuffer(1,len,c.sampleRate),a=b.getChannelData(0);for(let k=0;k<len;k++)a[k]=Math.random()*2-1;const sr=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();sr.buffer=b;f.type='lowpass';f.frequency.value=d.lp||1200;g.gain.setValueAtTime(vol*.5,t);g.gain.exponentialRampToValueAtTime(.0001,t+d.n);sr.connect(f);f.connect(g);g.connect(c.destination);sr.start(t);nodes.push(sr);return d.n}
  if(d.sw){const o=c.createOscillator(),g=c.createGain();o.type=d.w;o.frequency.setValueAtTime(d.sw[0],t);o.frequency.exponentialRampToValueAtTime(d.sw[1],t+d.sw[2]);env(g,d.sw[2]);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+d.sw[2]+.05);nodes.push(o);return d.sw[2]}
  d.s.forEach(([f,du])=>{if(f){const o=c.createOscillator(),g=c.createGain();o.type=d.w;o.frequency.value=f;env(g,du);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+du+.03);nodes.push(o)}t+=du});return t-t0};
 const dur=once(),stop=()=>{if(dead)return;dead=1;clearInterval(iv);clearTimeout(to);nodes.forEach(n=>{try{n.stop()}catch(e){}});SNDS.delete(stop)};
 if(loop)iv=setInterval(once,Math.max(100,dur*1000));else to=setTimeout(()=>{stop();if(onEnd)onEnd()},dur*1000);SNDS.add(stop);return stop}
window.sndGo=sndGo;
/* ---- runtime Luau: RemoteEvent, Sound, modifier, Image ---- */
class REW{constructor(i){this.i=i;this.s=new Sig();this.c=new Sig();this.fn=null;this.cf=null}get n(){return this.i.n}
 $g(k){const t=this,b=t.i.cls=='BindableEvent';switch(k){case'Name':return t.i.n;case'ClassName':return t.i.cls;case'OnServerEvent':case'Event':return t.s;case'OnClientEvent':return t.c;
  case'FireServer':case'Fire':return(_,...a)=>{t.s.fire(...(b?[]:[RT&&RT.pl]),...a)};case'FireClient':return(_,pl,...a)=>{t.c.fire(...a)};case'FireAllClients':return(_,...a)=>{t.c.fire(...a)};
  case'InvokeServer':return async(_,...a)=>t.fn?call(t.fn,[RT&&RT.pl,...a]):[];case'InvokeClient':return async(_,pl,...a)=>t.cf?call(t.cf,a):[]}}
 $s(k,v){if(k=='OnServerInvoke')this.fn=v;else if(k=='OnClientInvoke')this.cf=v;else if(k=='Name')this.i.n=tostr(v)}};window.REW=REW;
class SOW{constructor(i){this.i=i;this.stop=null;this.pl=false;this.en=new Sig()}get n(){return this.i.n}
 play(){this.halt();this.pl=true;this.stop=sndGo(this.i.preset,this.i.vol,this.i.loop,()=>{this.pl=false;this.en.fire()})}
 halt(){if(this.stop)this.stop();this.stop=null;this.pl=false}
 $g(k){const t=this,i=this.i;switch(k){case'Name':return i.n;case'ClassName':return'Sound';case'Volume':return i.vol;case'Looped':return!!i.loop;case'IsPlaying':case'Playing':return t.pl;case'SoundId':return i.preset;case'Play':return()=>t.play();case'Stop':case'Pause':return()=>t.halt();case'Ended':return t.en}}
 $s(k,v){const i=this.i;if(k=='Volume')i.vol=nn(v,0,1,.5);else if(k=='Looped')i.loop=truthy(v);else if(k=='SoundId'&&Object.hasOwn(SP,String(v)))i.preset=String(v);else if(k=='Playing')truthy(v)?this.play():this.halt();else if(k=='Name')i.n=tostr(v)}}
class CSq{constructor(a,b){this.a=a;this.b=b||a}$str(){return'ColorSequence'}}
class MW{constructor(i){this.i=i;this.par=null}get n(){return this.i.n}
 $g(k){const i=this.i;switch(k){case'Name':return i.n;case'ClassName':return i.cls;case'CornerRadius':return i.rad;case'Thickness':return i.th;case'Rotation':return i.rot;case'Padding':case'CellPadding':return i.pad;case'FillDirection':return i.dir=='h'?'Horizontal':'Vertical';case'HorizontalAlignment':return i.ha=='c'?'Center':i.ha=='r'?'Right':'Left';case'PaddingTop':return i.pt;case'PaddingBottom':return i.pb;case'PaddingLeft':return i.pl;case'PaddingRight':return i.pr;case'Color':return i.cls=='UIStroke'?hexC(i.col):new CSq(hexC(i.c0),hexC(i.c1))}}
 $s(k,v){const i=this.i;if(k=='Name')i.n=tostr(v);else if(k=='CornerRadius')i.rad=nn(v,0,999,8);else if(k=='Thickness')i.th=nn(v,0,30,2);else if(k=='Rotation')i.rot=nn(v,-360,360,90);
  else if(k=='Color'){if(v instanceof CSq){i.c0=cHex(v.a);i.c1=cHex(v.b)}else if(v instanceof LC)i.col=cHex(v)}
  else if(k=='Padding'||k=='CellPadding')i.pad=nn(v instanceof LU?v.p[1]:v,0,200,6);
  else if(k=='FillDirection')i.dir=/Horizontal/.test(String(v))?'h':'v';
  else if(k=='HorizontalAlignment')i.ha=/Center/.test(String(v))?'c':/Right/.test(String(v))?'r':'l';
  else if(k=='CellSize'&&v instanceof LU){i.cw=nn(v.p[1],8,600,80);i.chh=nn(v.p[3],8,600,80)}
  else if(k=='PaddingTop')i.pt=nn(v,0,200,8);else if(k=='PaddingBottom')i.pb=nn(v,0,200,8);else if(k=='PaddingLeft')i.pl=nn(v,0,200,8);else if(k=='PaddingRight')i.pr=nn(v,0,200,8);
  else if(k=='Parent'){if(v instanceof GW){this.par=v;v.i.ch.push(i)}}
  if(this.par)gSty(this.par.i,this.par.e)}}
G.set('UDim',mkT({new:(s,o)=>+o||0}));G.set('ColorSequence',mkT({new:(a,b)=>new CSq(a,b)}));
const IN=G.get('Instance'),_inw=IN.get('new');
IN.set('new',(cls,par)=>{let w=null;if(SERV.includes(cls))w=new REW(newI(cls));else if(cls=='Sound')w=new SOW(newI('Sound'));else if(MODC.includes(cls))w=new MW(newI(cls));
 if(w){if(par!==undefined)w.$s('Parent',par);return w}return _inw(cls,par)});
const _iw=iW;iW=function(i){if(RT.iw.has(i.id))return RT.iw.get(i.id);let w=null;if(SERV.includes(i.cls))w=new REW(i);else if(i.cls=='Sound')w=new SOW(i);if(w){RT.iw.set(i.id,w);return w}return _iw(i)};
const _gg=GW.prototype.$g,_gw=GW.prototype.$s;
GW.prototype.$g=function(k){if(k=='Image')return this.i.img?'custom':'';return _gg.call(this,k)};
GW.prototype.$s=function(k,v){if(k=='Image'){this.i.img=okImg(tostr(v));gSty(this.i,this.e);return}return _gw.call(this,k,v)};
const _rs=rtStart;rtStart=function(g){_rs(g);try{if(!RT)return;const w=l=>(l||[]).forEach(i=>{if(i.cls=='Sound'&&i.auto)iW(i).$g('Play')();w(i.ch)});Object.values(g.svc||{}).forEach(w)}catch(e){}};
const _rp=rtStop;rtStop=function(){SNDS.forEach(f=>f());SNDS.clear();_rp()};
/* ---- impor proyek: pertahankan field baru ---- */
const _cs=cleanSvc;cleanSvc=function(s){const out=_cs(s);try{
 const cp=(a,b)=>{const c=a.cls;if(c=='UICorner')b.rad=nn(a.rad,0,999,8);if(c=='UIStroke'){b.col=hx(a.col)||'#000000';b.th=nn(a.th,0,30,2)}if(c=='UIGradient'){b.c0=hx(a.c0)||'#ffffff';b.c1=hx(a.c1)||'#000000';b.rot=nn(a.rot,-360,360,90)}
  if(c=='ImageButton'||c=='ImageLabel')b.img=okImg(a.img);if(c=='Sound'){b.preset=Object.hasOwn(SP,a.preset)?a.preset:'coin';b.vol=nn(a.vol,0,1,.6);b.loop=!!a.loop;b.auto=!!a.auto}},
 z=(o,n)=>{const v=(Array.isArray(o)?o:[]).filter(i=>i&&typeof i=='object'&&Object.hasOwn(CL,i.cls));n.forEach((x,k)=>{if(v[k]){cp(v[k],x);z(v[k].ch,x.ch)}})};
 if(s&&typeof s=='object')SKEYS.forEach(k=>z(s[k],out[k]))}catch(e){}return out};
/* ---- TOOLBOX LENGKAP ---- */
const mdl=(rows,pre)=>{pushUndo();const x0=Math.round(sctl.tx),z0=Math.round(sctl.tz);let first=null;rows.forEach(r=>{const[t,dx,y,dz,sx,sy,sz,c,n,ry]=r,o=O(t,f2(x0+dx),f2(y),f2(z0+dz),sx,sy,sz,c,ry||0);o.n=(pre||'')+n;ST.d.objs.push(o);first=first||o});return first};
const sadd=(k,cls,n,p)=>{const i=newI(cls);if(n)i.n=n;Object.assign(i,p||{});ST.d.svc[k].push(i);XP[k]=1;return i};
function rig(pre,sk,sh,pa,r15,extra){let R=[];
 if(!r15)R=[['part',-.5,1,0,1,2,1,pa,'LeftLeg'],['part',.5,1,0,1,2,1,pa,'RightLeg'],['part',0,3,0,2,2,1,sh,'Torso'],['part',-1.5,3,0,1,2,1,sk,'LeftArm'],['part',1.5,3,0,1,2,1,sk,'RightArm'],['part',0,4.6,0,1.2,1.2,1.2,sk,'Head'],['part',-.25,4.75,.62,.2,.25,.05,'#000000','EyeL'],['part',.25,4.75,.62,.2,.25,.05,'#000000','EyeR'],['part',0,4.35,.62,.5,.1,.05,'#000000','Mouth']];
 else{[-1,1].forEach(s=>{const sd=s<0?'Left':'Right',x=s*.5,ax=s*1.5;R.push(['part',x,.15,0,.95,.3,1.1,pa,sd+'Foot'],['part',x,.7,0,.95,.8,.95,pa,sd+'LowerLeg'],['part',x,1.6,0,.95,1,.95,pa,sd+'UpperLeg'],['part',ax,3.8,0,1,1,1,sh,sd+'UpperArm'],['part',ax,2.85,0,1,.9,1,sk,sd+'LowerArm'],['part',ax,2.25,0,1,.3,1,sk,sd+'Hand'])});
  R.push(['part',0,2.4,0,2,.6,1,pa,'LowerTorso'],['part',0,3.5,0,2,1.6,1,sh,'UpperTorso'],['part',0,4.9,0,1.2,1.2,1.2,sk,'Head'],['part',-.25,5.05,.62,.2,.25,.05,'#000000','EyeL'],['part',.25,5.05,.62,.2,.25,.05,'#000000','EyeR'],['part',0,4.65,.62,.5,.1,.05,'#000000','Mouth'])}
 return mdl(R.concat(extra||[]),pre)}
const NPCS='local torso = workspace:FindFirstChild("NPC_Torso")\ntorso.Touched:Connect(function(hit)\n\tprint("NPC: Halo, pemain!")\nend)\n';
const mk=(n,ic,d,f)=>({n,ic,d,f}),gi=(cls,n,p,mods,kids)=>{const i=newI(cls);i.n=n;Object.assign(i,p||{});(mods||[]).forEach(m=>{const x=newI(m[0]);Object.assign(x,m[1]||{});i.ch.push(x)});(kids||[]).forEach(k=>i.ch.push(k));return i},
 sg2=(n,kids)=>{const g=newI('ScreenGui');g.n=n;kids.forEach(k=>g.ch.push(k));ST.d.svc.StarterGui.push(g);XP.StarterGui=1;return g};
const TXI=k=>mk('Lantai '+TXN[k],'','Part 8x1x8 bertekstur '+TXN[k].toLowerCase(),()=>{const o=mdl([['part',0,.5,0,8,1,8,'#ffffff',TXN[k]]]);o.tex=k;return o});
const snd=k=>mk(SNDN[k],'','Sound di Workspace · workspace.'+SNDN[k].replace(/ /g,'')+':Play()',()=>sadd('Workspace','Sound',SNDN[k].replace(/ /g,''),{preset:k,loop:k=='musik'||k=='petualangan'||k=='angin'}));
const TBL={
 Model:[
  mk('Pohon','','Batang + daun',()=>mdl([['cyl',0,2,0,1.2,4,1.2,'#8d5524','Batang'],['ball',0,5.5,0,5,5,5,'#2e9e4f','Daun'],['ball',0,8,0,3.2,3.2,3.2,'#43b85f','DaunAtas']])),
  mk('Rumah','','Rumah dengan pintu & atap',()=>mdl([['part',0,.15,0,8.5,.3,8.5,'#a1693a','Lantai'],['part',0,2.3,-4,8,4,.5,'#e8d9b8','DindingBelakang'],['part',-4,2.3,0,.5,4,8,'#e8d9b8','DindingKiri'],['part',4,2.3,0,.5,4,8,'#e8d9b8','DindingKanan'],['part',-2.75,2.3,4,2.5,4,.5,'#e8d9b8','DindingDepanKiri'],['part',2.75,2.3,4,2.5,4,.5,'#e8d9b8','DindingDepanKanan'],['part',0,3.8,4,3,1,.5,'#e8d9b8','AmbangPintu'],['part',0,4.55,0,9.5,.5,9.5,'#c0392b','Atap'],['part',0,5.1,0,6.5,.6,6.5,'#a93226','AtapAtas']])),
  mk('Mobil','','Body + kabin + roda',()=>mdl([['part',0,1,0,4,1,8,'#e63946','Body'],['part',0,2,-.8,3.4,1,3.6,'#a8dadc','Kabin'],['ball',-2,.7,2.4,1.4,1.4,1.4,'#222222','Roda'],['ball',2,.7,2.4,1.4,1.4,1.4,'#222222','Roda'],['ball',-2,.7,-2.4,1.4,1.4,1.4,'#222222','Roda'],['ball',2,.7,-2.4,1.4,1.4,1.4,'#222222','Roda']])),
  mk('Tangga','','12 anak tangga (bisa dinaiki)',()=>mdl(Array.from({length:12},(_,k)=>['part',0,.125+k*.25,k,4,.25,1,k%2?'#ff90e8':'#7df9ff','Anak'+(k+1)]))),
  mk('Jembatan','','Dek + pagar + tiang',()=>mdl([['part',0,3,0,4,.5,16,'#a1693a','Dek'],['part',-2,3.75,0,.3,1,16,'#6b4423','PagarKiri'],['part',2,3.75,0,.3,1,16,'#6b4423','PagarKanan'],['cyl',-1.5,1.5,-7,.8,3,.8,'#8a8d93','Tiang'],['cyl',1.5,1.5,-7,.8,3,.8,'#8a8d93','Tiang'],['cyl',-1.5,1.5,7,.8,3,.8,'#8a8d93','Tiang'],['cyl',1.5,1.5,7,.8,3,.8,'#8a8d93','Tiang']])),
  mk('Menara Kastil','','Menara + bendera',()=>mdl([['cyl',0,5,0,6,10,6,'#9aa0a6','Menara'],['part',-2,10.75,-2,1.4,1.5,1.4,'#9aa0a6','Gerigi'],['part',2,10.75,-2,1.4,1.5,1.4,'#9aa0a6','Gerigi'],['part',-2,10.75,2,1.4,1.5,1.4,'#9aa0a6','Gerigi'],['part',2,10.75,2,1.4,1.5,1.4,'#9aa0a6','Gerigi'],['cyl',0,12,0,.2,3,.2,'#dddddd','Tiang'],['part',.7,12.9,0,1.2,.7,.1,'#e63946','Bendera']])),
  mk('Pagar','','Pagar kayu 10 stud',()=>mdl([0,1,2,3,4,5].map(k=>['part',-5+k*2,1,0,.4,2,.4,'#c19a6b','Tiang']).concat([['part',0,1.5,0,10.4,.3,.2,'#c19a6b','Palang'],['part',0,.8,0,10.4,.3,.2,'#c19a6b','Palang']]))),
  mk('Peti Harta','','Peti dengan tutup emas',()=>mdl([['part',0,.8,0,3,1.6,2,'#8d5524','Peti'],['part',0,1.8,0,3,.4,2,'#ffc400','Tutup'],['part',0,1.4,1.05,.5,.6,.15,'#ffc400','Kunci']])),
  mk('Lampu Jalan','','Tiang + lampu',()=>mdl([['cyl',0,3.5,0,.4,7,.4,'#333333','Tiang'],['ball',0,7.3,0,1.4,1.4,1.4,'#fff3a0','Lampu']])),
  mk('Meja + Kursi','','Meja dengan 2 kursi',()=>mdl([['part',0,2.2,0,4,.3,2.5,'#a1693a','Meja'],['part',-1.7,1.05,-1,.3,2.1,.3,'#6b4423','Kaki'],['part',1.7,1.05,-1,.3,2.1,.3,'#6b4423','Kaki'],['part',-1.7,1.05,1,.3,2.1,.3,'#6b4423','Kaki'],['part',1.7,1.05,1,.3,2.1,.3,'#6b4423','Kaki'],['part',0,1,-2.5,1.4,.2,1.4,'#c19a6b','Kursi'],['part',0,1.9,-3.1,1.4,1.6,.2,'#c19a6b','SandaranKursi'],['part',0,1,2.5,1.4,.2,1.4,'#c19a6b','Kursi']])),
  mk('Piramida','','5 lapis',()=>mdl([0,1,2,3,4].map(k=>['part',0,.5+k,0,10-2*k,1,10-2*k,'#e6cf8e','Lapisan']))),
  mk('Checkpoint','','Spawn + bendera',()=>mdl([['spawn',0,.2,0,4,.4,4,'#7df9ff','Checkpoint'],['cyl',0,2.5,-1.5,.2,5,.2,'#dddddd','Tiang'],['part',.7,4.3,-1.5,1.4,.9,.1,'#ff3b3b','Bendera']])),
  mk('Awan','','3 bola putih di langit',()=>mdl([['ball',0,16,0,6,3.5,4,'#ffffff','Awan'],['ball',2.5,16.6,0,4,3,3.5,'#ffffff','Awan'],['ball',-2.5,16.4,0,4,2.8,3.2,'#ffffff','Awan']]))],
 Rig:[
  mk('Rig R6','','Karakter blok 6 bagian',()=>rig('','#ffd7b5','#3b82f6','#2b4acb',false)),
  mk('Rig R15','','Karakter 15 bagian (siku, lutut)',()=>rig('','#ffd7b5','#3b82f6','#2b4acb',true)),
  mk('Zombie','','Rig hijau',()=>rig('Zombie_','#7ab648','#3a6b2a','#2d3a55',false)),
  mk('Robot','','Rig logam + antena',()=>rig('Robot_','#b0b7bf','#8d949c','#6f757c',false,[['cyl',0,5.6,0,.1,.8,.1,'#333333','Antena'],['ball',0,6.1,0,.3,.3,.3,'#ff3b3b','UjungAntena']])),
  mk('NPC + Script','','Rig dengan script sapaan',()=>{const h=rig('NPC_','#f1c27d','#b6f25a','#222222',false);sadd('ServerScriptService','Script','NPCScript',{src:NPCS});return h})],
 Suara:Object.keys(SNDN).map(snd),
 Tekstur:Object.keys(TXN).map(TXI),
 GUI:[
  mk('Tombol Modern','','Tombol + UICorner + UIStroke + UIGradient',()=>sg2('TombolModern',[gi('TextButton','Main',{p:[.5,-100,.5,-28],s:[0,200,0,56],bg:'#335fff',tc:'#ffffff',txt:'Mulai',ts:22,bd:false},[['UICorner',{rad:16}],['UIStroke',{col:'#ffffff',th:3}],['UIGradient',{c0:'#6d5bff',c1:'#2f9bff',rot:90}]])])),
  mk('Kartu Gambar','','Frame bulat + ImageLabel + judul',()=>sg2('KartuGambar',[gi('Frame','Kartu',{p:[.5,-110,.5,-100],s:[0,220,0,200],bg:'#2e1519',bd:false},[['UICorner',{rad:18}],['UIStroke',{col:'#ff5a5f',th:2}]],[gi('ImageLabel','Gambar',{p:[0,10,0,10],s:[1,-20,0,130]},[['UICorner',{rad:12}]]),gi('TextLabel','Judul',{p:[0,10,0,148],s:[1,-20,0,40],txt:'Judul Kartu',tc:'#ffffff',bt:1,bd:false})])])),
  mk('Menu Scroll','','ScrollingFrame berisi 8 tombol',()=>sg2('MenuScroll',[gi('ScrollingFrame','Daftar',{p:[.5,-110,.5,-150],s:[0,220,0,300],bg:'#241013',bd:false},[['UICorner',{rad:14}],['UIStroke',{col:'#4a2a2d',th:2}]],Array.from({length:8},(_,k)=>gi('TextButton','Item'+(k+1),{p:[0,10,0,10+k*52],s:[1,-20,0,44],txt:'Item '+(k+1),bg:'#3d2326',tc:'#ffffff',bd:false},[['UICorner',{rad:10}]])))])),
  mk('Toolbar Ikon','','3 ImageButton bulat',()=>sg2('ToolbarIkon',[gi('Frame','Bar',{p:[.5,-110,1,-90],s:[0,220,0,70],bg:'#2e1519',bd:false},[['UICorner',{rad:35}],['UIStroke',{col:'#ffffff',th:2}]],[0,1,2].map(k=>gi('ImageButton','Ikon'+(k+1),{p:[0,12+k*68,0,10],s:[0,50,0,50],bg:['#ff90e8','#7df9ff','#ffde59'][k],bd:false},[['UICorner',{rad:999}]])))])),
  mk('RemoteEvent Demo','','RemoteEvent + Script server + tombol klien',()=>{sadd('ReplicatedStorage','RemoteEvent','PesanEvent');
   sadd('ServerScriptService','Script','RemoteServer',{src:'local rs = game:GetService("ReplicatedStorage")\nlocal ev = rs:WaitForChild("PesanEvent")\nev.OnServerEvent:Connect(function(player, teks)\n\tprint(player.Name .. " mengirim: " .. teks)\n\tev:FireClient(player, "Server menerima: " .. teks)\nend)\n'});
   const ls=newI('LocalScript');ls.src='local gui = script.Parent\nlocal btn = gui:WaitForChild("Kirim")\nlocal ev = game:GetService("ReplicatedStorage"):WaitForChild("PesanEvent")\nev.OnClientEvent:Connect(function(teks)\n\tbtn.Text = teks\nend)\nbtn.MouseButton1Click:Connect(function()\n\tev:FireServer("Halo dari klien")\nend)\n';
   return sg2('RemoteDemo',[gi('TextButton','Kirim',{p:[.5,-110,.5,-28],s:[0,220,0,56],txt:'Kirim Pesan',bg:'#1faa59',tc:'#ffffff',bd:false},[['UICorner',{rad:14}]]),ls])})],
 Efek:[
  mk('Lava Pit','','Kolam lava 8x8',()=>{pushUndo();const o=O('lava',Math.round(sctl.tx),.25,Math.round(sctl.tz),8,.5,8,'#ff3b3b');ST.d.objs.push(o);return o}),
  mk('Part Berkedip','','Part hilang-muncul (script)',()=>{const o=mdl([['part',0,.5,0,4,1,4,'#ff90e8','Berkedip']]);sadd('ServerScriptService','Script','BerkedipScript',{src:'local p = workspace:FindFirstChild("Berkedip")\nwhile true do\n\tp.Transparency = 0.8\n\twait(0.7)\n\tp.Transparency = 0\n\twait(0.7)\nend\n'});return o})],
 'Siap Pakai':TB};
window.SPX={TBL,mdl,rig,sadd,gi,sg2,mk};let TBT='Model';
function tbDraw(){const m=$('#cpick');if(!m)return;m.innerHTML=`<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0"> Toolbox</h3><button class="btn sm o" style="margin:0" data-a="pkx">✕</button></div><div class="mt" style="margin:8px 0">${Object.keys(TBL).map(k=>`<button class="btn sm ${k==TBT?'g':''}" data-a="tbc" data-v="${k}">${k}</button>`).join('')}</div><div class="plist">${TBL[TBT].map((x,j)=>`<div class="pit" data-a="tbm" data-v="${j}"><span>${x.ic}</span><div><b>${x.n}</b><small>${x.d}</small></div></div>`).join('')}</div></div>`}
Object.assign(act,{tbox(){let m=$('#cpick');if(!m){m=document.createElement('div');m.id='cpick';document.body.appendChild(m)}tbDraw()},tbc(v){TBT=v;tbDraw()},
 tbm(v){const it=TBL[TBT][+v];if(!it||!ST||ST.kind!='g')return;act.pkx();let r;try{r=it.f()}catch(e){return toast('Gagal menambahkan: '+e.message)}sBuild();
  if(r&&r.cls)afterIns(r);else{if(r&&r.id){SEL=r.id;SI=null;guiOn=false}selHelper();eRender();pRender();guiRefresh();touch()}slog('Toolbox: '+it.n);toast('Ditambahkan: '+it.n)}});
})();
