/* ===== AKUN CLOUD: login username/email yang sama di HP mana pun =====
   Data akun dienkripsi di perangkat (PBKDF2 + AES-GCM, kunci dari password) lalu disimpan di broker publik.
   Tanpa password yang benar, isinya tidak bisa dibuka. */
(function(){
const ACC='pickare/v9/acc/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)+t.length};
const te=s=>new TextEncoder().encode(s),mq=()=>window.__spMq;
const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const unb=t=>{const s=atob(t),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u};
const sha=async t=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',te(t)))).map(b=>b.toString(16).padStart(2,'0')).join('').slice(0,24);
const pipe=async(d,S)=>{const st=new S('gzip'),w=st.writable.getWriter();w.write(d);w.close();return new Uint8Array(await new Response(st.readable).arrayBuffer())};
const kdf=async(pw,salt)=>{const b=await crypto.subtle.importKey('raw',te(pw),'PBKDF2',false,['deriveBits']);return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:150000,hash:'SHA-256'},b,256))};
const aes=k=>crypto.subtle.importKey('raw',k,'AES-GCM',false,['encrypt','decrypt']);
async function seal(obj,key){let d=te(JSON.stringify(obj)),z=0;if(window.CompressionStream){try{d=await pipe(d,CompressionStream);z=1}catch(e){}}
 const iv=crypto.getRandomValues(new Uint8Array(12)),ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},await aes(key),d));return{iv:b64(iv),ct:b64(ct),z}}
async function open(R,key){try{let d=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb(R.iv)},await aes(key),unb(R.ct)));if(R.z)d=await pipe(d,DecompressionStream);return JSON.parse(new TextDecoder().decode(d))}catch(e){return null}}
async function ready(){return !!(mq()&&(window.mqtt||await mq().lib()))}
function fetchTopic(topic){return new Promise(async res=>{if(!(await ready()))return res(null);let best=null,pend=BR.length,fin=0;const out=()=>{if(!fin){fin=1;res(best)}};
 BR.forEach(url=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}if(--pend===0)out()};
  try{m=mqtt.connect(url,{clientId:'spa_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)out();return}
  m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topic,{qos:0});setTimeout(end,3200)});
  m.on('message',(t,b)=>{try{const s=b.toString();if(!s)return;const d=JSON.parse(s);if(d&&d.ts&&(!best||d.ts>best.ts))best=d}catch(e){}});setTimeout(end,8000)});setTimeout(out,10000)})}
const skip=['pres','ob','role','rm'];
const blobOf=u=>{const o={};for(const k in u)if(!skip.includes(k))o[k]=u[k];return o};
const CK=()=>ls.get('sp_ck',{}),CS=()=>ls.get('sp_cs',{});
const emTop=async em=>ACC+await sha('sp-acc|'+em.toLowerCase());
function applyBlob(u,blob,keepLocal){const keep={};skip.forEach(k=>{if(k in u)keep[k]=u[k]});
 let extraG=[],extraI=[];if(keepLocal){const gi=new Set((blob.games||[]).map(g=>g.id)),ii=new Set((blob.items||[]).map(g=>g.id));extraG=(u.games||[]).filter(g=>g&&!gi.has(g.id));extraI=(u.items||[]).filter(g=>g&&!ii.has(g.id))}
 for(const k in u)delete u[k];Object.assign(u,blob,keep);if(extraG.length)u.games=(u.games||[]).concat(extraG);if(extraI.length)u.items=(u.items||[]).concat(extraI)}
async function push(name,ck){const u=users[name];if(!u)return false;let b=blobOf(u),pay;
 const mk=async()=>{const s=await seal(b,unb(ck.k));return JSON.stringify(Object.assign({v:1,n:name,salt:ck.salt,ts:Date.now()},s))};
 pay=await mk();if(pay.length>900000){b.chat={};pay=await mk()}
 if(pay.length>900000){b.notes=(b.notes||[]).slice(0,10);pay=await mk()}
 if(pay.length>900000){b.games=(b.games||[]).map(g=>Object.assign({},g,{thumb:'',icon:''}));pay=await mk()}
 if(pay.length>900000)return false;
 const eh=await sha('sp-acc|'+u.email.toLowerCase()),ts=JSON.parse(pay).ts;
 const ok=await mq().pushAll([{t:ACC+eh,p:pay},{t:ACC+'u'+await sha('u|'+name.toLowerCase()),p:JSON.stringify({p:eh,ts})}]);
 if(ok){const cs=CS();cs[name]={sy:ts,sig:hs(JSON.stringify(blobOf(u)))};ls.set('sp_cs',cs)}return !!ok}
let busy=0;
async function tick(){if(busy||typeof me==='undefined'||!me||me.role==='owner'||!me.email)return;const name=me.name,ck=CK()[name];if(!ck)return;busy=1;
 try{if(!(await ready()))return;const R=await fetchTopic(await emTop(me.email)),cs=CS(),m=cs[name]||{},sigNow=hs(JSON.stringify(blobOf(me)));let changed=m.sig!==sigNow;
  if(R&&R.ts>(m.sy||0)){const blob=await open(R,unb(ck.k));if(blob){applyBlob(me,blob,changed);cs[name]={sy:R.ts,sig:hs(JSON.stringify(blobOf(me)))};ls.set('sp_cs',cs);save();try{refreshUI()}catch(e){}changed=changed&&true}}
  const m2=CS()[name]||{};if(!R||hs(JSON.stringify(blobOf(me)))!==m2.sig)await push(name,ck)}
 catch(e){}finally{busy=0}}
async function ensure(){const st=window.__spPw;window.__spPw=null;if(typeof me==='undefined'||!me||me.role==='owner'||!me.email)return;
 const cks=CK();if(!cks[me.name]&&st&&st.p&&await ready()){const R=await fetchTopic(await emTop(me.email));
  if(R){const key=await kdf(st.p,unb(R.salt));if(await open(R,key))cks[me.name]={k:b64(key),salt:R.salt}}
  else{const salt=crypto.getRandomValues(new Uint8Array(16)),key=await kdf(st.p,salt);cks[me.name]={k:b64(key),salt:b64(salt)}}
  ls.set('sp_ck',cks)}
 tick()}
async function cloudLogin(em,p){try{let eh;if(em.includes('@'))eh=await sha('sp-acc|'+em.toLowerCase());else{const P=await fetchTopic(ACC+'u'+await sha('u|'+em.toLowerCase()));if(!P||!P.p)return false;eh=P.p}
 const R=await fetchTopic(ACC+eh);if(!R||!R.salt)return false;const key=await kdf(p,unb(R.salt)),blob=await open(R,key);if(!blob||!blob.email)return false;
 const name=String(R.n||'').slice(0,14);if(!name||/^(owner|admin|coowner|co-owner)$/i.test(name))return false;
 const old=users[name];if(old&&!old.rm)applyBlob(old,blob,true);else users[name]=blob;delete users[name].rm;
 const cks=CK();cks[name]={k:b64(key),salt:R.salt};ls.set('sp_ck',cks);const cs=CS();cs[name]={sy:R.ts,sig:hs(JSON.stringify(blobOf(users[name])))};ls.set('sp_cs',cs);save();return true}catch(e){return false}}
window.addEventListener('load',()=>{
 const _a=act.auth;let okE=null;
 act.auth=function(){const e=$('#err'),emv=($('#em').value||'').trim().toLowerCase(),p=$('#pw').value,u=($('#u').value||'').trim(),isOwn=$('#em').type==='password';
  if(isOwn||!emv||!p)return _a.apply(this,arguments);
  if(mode==='reg'){if(okE===emv){okE=null;window.__spPw={p};return _a.apply(this,arguments)}
   e.textContent='Memeriksa email...';emTop(emv).then(fetchTopic).then(R=>{if(R){e.textContent='Email sudah terdaftar di akun lain';const c=$('#acard');if(c){c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')}}else{okE=emv;e.textContent='';act.auth()}});return}
  const k=Object.keys(users).find(x=>users[x].email===emv)||(!emv.includes('@')&&users[emv]?emv:null);
  if(k&&!users[k].rm&&users[k].pass===p){window.__spPw={p};return _a.apply(this,arguments)}
  e.textContent='Memeriksa akun...';
  cloudLogin(emv,p).then(ok=>{e.textContent='';window.__spPw={p};_a.call(act)});};
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(ensure,900);return r};
 setInterval(()=>{if(!document.hidden)tick()},20000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});
 window.spCloudSync=tick});
})();
