/* ===== v13: gift centang biru + akses panel lewat username (huruf besar/kecil bebas) ===== */
window.addEventListener('load',()=>setTimeout(()=>{
 const canon=id=>{const i=document.getElementById(id);if(!i)return null;const raw=String(i.value||'').trim().replace(/^@/,'').toLowerCase();if(!raw)return null;
  const k=Object.keys(users).find(x=>x.toLowerCase()===raw);if(k&&i.value!==k)i.value=k;return k||null};
 ['gbux','gver','grole','bandirect','unbandirect'].forEach(n=>{const o=act[n];if(typeof o!=='function')return;
  const id=(n==='bandirect'||n==='unbandirect')?'bu_u':'pt_u';
  act[n]=function(){const k=canon(id),u=k&&users[k],before=u?!!u.verified:null;const r=o.apply(this,arguments);
   try{if(n==='gver'&&u&&!u.rm&&u!==me&&before!==null&&!!u.verified!==before&&window.spSendCmd)window.spSendCmd(k,'ver',{v:!!u.verified})}catch(e){}
   return r}});
},0));
