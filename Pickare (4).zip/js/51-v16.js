/* ===== v16: Bot di Panel Owner: mengisi map, bisa dihentikan, dipindah map ===== */
(function(){
const HEX=/^#[0-9a-f]{6}$/i,HATS=['none','cap','crown'];
const PH=['halo semua!','ayo main bareng','wkwk seru juga map nya','gg','siapa yang udah sampai finish?','hati-hati lava ya','mantap map nya','ada yang mau jadi teman?','semangat ya!','lompat lompat'];
const isOwner=()=>{try{return !!me&&me.role==='owner'&&staff()}catch(e){return false}};
const cfg=()=>{const c=ls.get('sp_botcfg',null);return c&&Array.isArray(c.bots)?c:{bots:[],chat:true}};
const roster=()=>{const r=ls.get('sp_botr',null);return r&&Array.isArray(r.bots)?r:{bots:[],chat:true}};
const clean=b=>({id:String(b.id||'').replace(/[^\w-]/g,'').slice(0,12),n:String(b.n||'').replace(/[^\w\- ]/g,'').trim().slice(0,14),g:String(b.g||'*').replace(/[^\w\-*]/g,'').slice(0,40)||'*',on:!!b.on,sk:HEX.test(b.sk)?b.sk:SKIN[0],sh:HEX.test(b.sh)?b.sh:SHIRT[0],pa:HEX.test(b.pa)?b.pa:PANTS[0],ht:HATS.includes(b.ht)?b.ht:'none'});
const rnd=a=>a[Math.floor(Math.random()*a.length)];
const BO={};let chatAt=0;

/* ---- jalankan bot di dalam game ---- */
function clear(){for(const id in BO){try{scene.remove(remote['bot_'+id].g)}catch(e){}delete remote['bot_'+id];delete BO[id]}}
function topY(x,z,ref){let y=baseOn?0:null;for(const b of boxes||[])if(!b.sh&&inF(b,x,z,.2)&&b.top<=ref+4&&(y===null||b.top>y))y=b.top;return y}
function spawn(){clear();if(!run||testing||!curG)return;
 roster().bots.map(clean).filter(b=>b.on&&b.n&&(b.g==='*'||b.g===String(curG.id))).slice(0,12).forEach(b=>{
  let x=SP.x+(Math.random()-.5)*10,z=SP.z+(Math.random()-.5)*10,y=topY(x,z,SP.y);if(y===null){x=SP.x;z=SP.z;y=Math.max(0,SP.y-1)}
  const av={skin:b.sk,shirt:b.sh,pants:b.pa,hat:b.ht},g=mkAvatar(av);g.add(tagSprite(b.n));g.position.set(x,y,z);scene.add(g);
  remote['bot_'+b.id]={g,name:b.n,tx:x,ty:y,tz:z,tr:0,ph:0,av,bot:1};BO[b.id]={hx:x,hz:z,dx:x,dz:z,next:0}});
 try{if(document.getElementById('pause').style.display=='flex')plist()}catch(e){}}
function step(){if(!run||paused)return;const now=Date.now();
 for(const id in BO){const e=BO[id],o=remote['bot_'+id];if(!o)continue;
  const dx=e.dx-o.tx,dz=e.dz-o.tz,d=Math.hypot(dx,dz);
  if(d<.6){if(now>e.next){e.next=now+1500+Math.random()*4500;for(let i=0;i<6;i++){const tx=Math.max(-46,Math.min(46,e.hx+(Math.random()-.5)*30)),tz=Math.max(-46,Math.min(46,e.hz+(Math.random()-.5)*30)),y=topY(tx,tz,o.ty);if(y!==null&&Math.abs(y-o.ty)<2.2){e.dx=tx;e.dz=tz;break}}}}
  else{o.tx+=dx/d*.45;o.tz+=dz/d*.45;o.tr=Math.atan2(dx,dz);const y=topY(o.tx,o.tz,o.ty);if(y!==null&&Math.abs(y-o.ty)<2.5)o.ty=y}}
 if(roster().chat&&now>chatAt){chatAt=now+35000+Math.random()*55000;const ks=Object.keys(BO);if(ks.length){const o=remote['bot_'+rnd(ks)];if(o)addChat(o.name,rnd(PH))}}}
setInterval(step,130);
window.spBotsChanged=()=>{if(run)spawn()};
/* syncPeers tidak boleh menghapus bot */
const _sp=syncPeers;syncPeers=function(){const st={};for(const k in remote)if(k.indexOf('bot_')===0){st[k]=remote[k];delete remote[k]}
 try{return _sp.apply(this,arguments)}finally{Object.assign(remote,st)}};
const _sg=startGame;startGame=function(){const r=_sg.apply(this,arguments);setTimeout(()=>{try{window.spBotFetch&&spBotFetch()}catch(e){}spawn()},1500);return r};
const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{try{window.spBotFetch&&spBotFetch()}catch(e){}},3500);return r};
setInterval(()=>{if(typeof me==='undefined'||!me||document.hidden)return;try{window.spBotFetch&&spBotFetch()}catch(e){}
 if(isOwner()&&cfg().dirty)push(true)},45000);

/* ---- panel owner: tab Bot ---- */
const games=()=>{try{return pubGames()}catch(e){return[]}};
const gname=id=>id==='*'?'Semua map':((games().find(g=>String(g.id)===id)||{}).name||'(map dihapus)');
const opts=sel=>'<option value="*"'+(sel==='*'?' selected':'')+'>Semua map</option>'+games().map(g=>'<option value="'+esc(g.id)+'"'+(String(g.id)===sel?' selected':'')+'>'+esc(g.name)+'</option>').join('');
function botHTML(){const c=cfg(),n=c.bots.filter(b=>b.on).length;
 let h='<div class="card" style="margin-bottom:12px"><label>Nama bot (pisahkan dengan koma)</label><input type="text" id="bt_n" placeholder="Raka, Dewi, Bima" autocomplete="off" autocapitalize="none"><label>Isi map</label><select id="bt_g">'+opts('*')+'</select><button class="btn w" data-a="botadd" style="margin-top:10px">+ Tambah &amp; Jalankan</button></div>'
 +'<div class="card" style="margin-bottom:12px"><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><b style="flex:1">'+c.bots.length+' bot · '+n+' aktif</b><button class="btn sm g" data-a="botstartall">Jalankan semua</button><button class="btn sm o" data-a="botstopall">Hentikan semua</button></div><button class="btn sm '+(c.chat?'g':'o')+'" data-a="botchat" style="margin-top:8px">Bot chat: '+(c.chat?'Aktif':'Mati')+'</button></div>';
 h+=c.bots.length?c.bots.map(b=>'<div class="card" style="margin-bottom:10px"><div style="display:flex;align-items:center;gap:10px">'+circ({skin:b.sk,shirt:b.sh,pants:b.pa,hat:b.ht},40)+'<div style="flex:1"><b>'+esc(b.n)+'</b><br><small>'+esc(gname(b.g))+' · '+(b.on?'Aktif':'Berhenti')+'</small></div><button class="btn sm '+(b.on?'o':'g')+'" data-a="botrun" data-v="'+esc(b.id)+'">'+(b.on?'Hentikan':'Jalankan')+'</button></div><div style="display:flex;gap:6px;margin-top:8px"><select id="bm_'+esc(b.id)+'" style="flex:1">'+opts(b.g)+'</select><button class="btn sm g" data-a="botmap" data-v="'+esc(b.id)+'">Pindah map</button><button class="btn sm o" data-a="botdel" data-v="'+esc(b.id)+'">Hapus</button></div></div>').join(''):'<div class="empty2"><p style="margin:0">Belum ada bot. Tambahkan nama di atas.</p></div>';
 return h}
const _ph=panH;panH=function(){if(!isOwner())return _ph.apply(this,arguments);
 const want=!!window.__bt;if(want)pt='rep';let h=_ph.apply(this,arguments);
 const i=h.indexOf('</div>');if(i<0)return h;let head=h.slice(0,i),rest=h.slice(i+6);
 if(want)head=head.replace(/ptb on/g,'ptb ');
 head+='<button class="ptb '+(want?'on':'')+'" data-a="pt" data-v="bot">Bot</button></div>';
 return head+(want?botHTML():rest)};
const _pt=act.pt;act.pt=function(v){window.__bt=(v==='bot'&&isOwner());return _pt.call(this,v==='bot'?'rep':v)};

async function push(silent){const c=cfg(),bots=c.bots.map(clean);let ts=0;try{ts=window.spBotPublish?await spBotPublish(bots,c.chat):0}catch(e){}
 ls.set('sp_botr',{ts:ts||Date.now(),bots,chat:c.chat});c.dirty=!ts;ls.set('sp_botcfg',c);
 if(!silent)toast(ts?'Bot diperbarui untuk semua pemain ✓':'Tersimpan di perangkat ini, dikirim ke semua pemain saat online');
 try{spBotsChanged()}catch(e){}if(!silent)try{render()}catch(e){}}
const guard=f=>function(){if(!isOwner())return toast('Hanya Owner yang bisa mengatur bot');return f.apply(this,arguments)};
Object.assign(act,{
 botadd:guard(function(){const c=cfg(),el=document.getElementById('bt_n'),g=(document.getElementById('bt_g')||{}).value||'*';
  const names=String(el&&el.value||'').split(/[,\n]/).map(x=>x.replace(/[^\w\- ]/g,'').trim().slice(0,14)).filter(Boolean);
  if(!names.length)return toast('Isi nama bot dulu');let add=0;
  names.forEach(n=>{if(c.bots.length>=24||/^(owner|admin|coowner|co-owner)$/i.test(n)||c.bots.some(b=>b.n.toLowerCase()===n.toLowerCase()))return;
   c.bots.push({id:Math.random().toString(36).slice(2,8),n,g,on:true,sk:rnd(SKIN),sh:rnd(SHIRT),pa:rnd(PANTS),ht:rnd(HATS)});add++});
  if(!add)return toast('Nama sudah dipakai atau batas 24 bot tercapai');ls.set('sp_botcfg',c);push()}),
 botrun:guard(function(id){const c=cfg(),b=c.bots.find(x=>x.id===id);if(!b)return;b.on=!b.on;ls.set('sp_botcfg',c);push()}),
 botdel:guard(function(id){const c=cfg();c.bots=c.bots.filter(x=>x.id!==id);ls.set('sp_botcfg',c);push()}),
 botmap:guard(function(id){const c=cfg(),b=c.bots.find(x=>x.id===id),s=document.getElementById('bm_'+id);if(!b||!s)return;b.g=s.value;ls.set('sp_botcfg',c);push()}),
 botstopall:guard(function(){const c=cfg();c.bots.forEach(b=>b.on=false);ls.set('sp_botcfg',c);push()}),
 botstartall:guard(function(){const c=cfg();c.bots.forEach(b=>b.on=true);ls.set('sp_botcfg',c);push()}),
 botchat:guard(function(){const c=cfg();c.chat=!c.chat;ls.set('sp_botcfg',c);push()})});
})();
