/* ===== v18: ROLE ADMIN TERLIHAT SEMUA ORANG + POPUP GIFT UNTUK PENERIMA =====
   1. Gift role (admin / co-admin) dari owner sudah ditandatangani & disebar lewat MQTT (OWN/g/<nama>).
      Sekarang SEMUA perangkat ikut membaca catatan itu, memverifikasi tanda tangan owner,
      lalu menampilkan badge role di samping nama (profil, chat, daftar pemain, nametag 3D, developer game).
   2. Pemain yang digift role / centang biru langsung dapat popup perayaan. */
(function(){
const OWN='pickare/v9/own/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)};
const lw=n=>hs(String(n).toLowerCase()),te=s=>new TextEncoder().encode(s),mq=()=>window.__spMq;
const EC={name:'ECDSA',namedCurve:'P-256'},SG={name:'ECDSA',hash:'SHA-256'};
const unb=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
const msgOf=(n,r,t,k)=>String(n).toLowerCase()+'|'+r+'|'+t+'|'+(k?hs(JSON.stringify(k)):'');
const E=s=>{try{return esc(s)}catch(e){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}};
const LBL={owner:'OWNER',coowner:'CO-ADMIN',admin:'ADMIN'},COL={owner:'#f5a400',coowner:'#8a4dff',admin:'#e5383b'};

/* ---------- 1. registry role global ---------- */
const RLK='sp_rl',rc=()=>{const c=ls.get(RLK,{});return c&&typeof c==='object'&&!Array.isArray(c)?c:{}};
window.spRoleOf=n=>{try{const l=String(n||'').toLowerCase();if(!l)return'';if(l==='owner')return'owner';
 const c=rc()[l];if(c)return LBL[c.role]&&c.role!=='owner'?c.role:'';
 const k=Object.keys(users).find(x=>x.toLowerCase()===l),u=k&&users[k];
 return u&&u.role&&LBL[u.role]?u.role:''}catch(e){return''}};
window.spRoleBadge=n=>{const r=window.spRoleOf(n);return r?'<span class="rbd rbd-'+r+'">'+LBL[r]+'</span>':''};
window.spRoleDraw=(x,r,w,h)=>{x.fillStyle=COL[r];const t=LBL[r],pw=Math.min(w-40,34+t.length*17),px=(w-pw)/2;
 x.beginPath();x.moveTo(px+13,2);x.lineTo(px+pw-13,2);x.quadraticCurveTo(px+pw-2,2,px+pw-2,13);x.lineTo(px+pw-2,h-10);x.quadraticCurveTo(px+pw-2,h-2,px+pw-13,h-2);x.lineTo(px+13,h-2);x.quadraticCurveTo(px+2,h-2,px+2,h-10);x.lineTo(px+2,13);x.quadraticCurveTo(px+2,2,px+13,2);x.closePath();x.fill();
 x.strokeStyle='#000';x.lineWidth=4;x.stroke();x.fillStyle='#fff';x.font='bold 19px Arial';x.textAlign='center';x.textBaseline='middle';x.fillText(t,w/2,h/2+1)};

function sub(url,topics,ms,cb){return new Promise(res=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}res()};
 try{m=mqtt.connect(url,{clientId:'spr_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){return res()}
 m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topics,{qos:0});setTimeout(end,ms)});
 m.on('message',(t,b)=>{try{const s=b.toString();if(s)cb(t,JSON.parse(s))}catch(e){}});setTimeout(end,ms+4000)})}
let busy=0;
async function rlSync(){if(busy||typeof me==='undefined'||!me)return;busy=1;
 try{if(!(mq()&&(window.mqtt||await mq().lib())))return;const G={};let PK=null;
  await Promise.all(BR.map(u=>sub(u,[OWN+'g/+',OWN+'pk'],3000,(t,d)=>{if(!d)return;if(t===OWN+'pk'){if(d.pub&&(!PK||d.ts>PK.ts))PK=d;return}
   if(d.n&&d.sig&&typeof d.ts==='number'){const l=String(d.n).toLowerCase();if(t===OWN+'g/'+lw(l)&&(!G[l]||d.ts>G[l].ts))G[l]=d}})));
  let pin=ls.get('sp_ownpk',null);if(!pin&&PK){pin=PK.pub;ls.set('sp_ownpk',pin)}if(!pin)return;
  const key=await crypto.subtle.importKey('jwk',pin,EC,false,['verify']),c=rc();let ch=0;
  for(const l in G){const g=G[l];if(!['admin','coowner','none'].includes(g.role))continue;if(c[l]&&c[l].ts>=g.ts)continue;
   let ok=false;try{ok=await crypto.subtle.verify(SG,key,unb(g.sig),te(msgOf(g.n,g.role,g.ts,g.pk)))}catch(e){}
   if(!ok)continue;c[l]={role:g.role,ts:g.ts};ch=1}
  if(ch){ls.set(RLK,c);try{window.spVfChanged&&spVfChanged()}catch(e){}try{refreshUI()}catch(e){}}
 }catch(e){}finally{busy=0}}
window.spRoleSync=rlSync;

/* ---------- 2. popup gift untuk penerima ---------- */
function popup(ico,title,txt,col){const old=document.getElementById('gfx');if(old)old.remove();
 const d=document.createElement('div');d.id='gfx';
 d.innerHTML='<div class="gfx-c" style="--gc:'+col+'"><div class="gfx-i">'+ico+'</div><h2>'+E(title)+'</h2><p>'+E(txt)+'</p><button type="button" class="btn g">Mantap!</button></div>';
 d.addEventListener('click',e=>{if(e.target===d||e.target.tagName==='BUTTON')d.remove()});document.body.appendChild(d);setTimeout(()=>{try{d.remove()}catch(e){}},12000)}
window.spGiftPopup=popup;
const SK='sp_gseen';
function watch(){try{if(typeof me==='undefined'||!me||!me.name)return;const S=ls.get(SK,{})||{},k=me.name.toLowerCase(),cur={r:me.role&&me.role!=='owner'?me.role:'',v:!!me.verified&&me.role!=='owner'};
 if(!S[k]){S[k]=cur;ls.set(SK,S);return}
 const o=S[k];if(o.r===cur.r&&o.v===cur.v)return;S[k]=cur;ls.set(SK,S);
 if(cur.r&&cur.r!==o.r)popup('🛡️','Kamu jadi '+LBL[cur.r]+'!','Kamu mendapat akses '+LBL[cur.r]+'. Buka menu → Panel. Badge '+LBL[cur.r]+' kini terlihat oleh semua pemain.',COL[cur.r]);
 else if(!cur.r&&o.r)popup('ℹ️','Akses panel dicabut','Role '+LBL[o.r]+'-mu sudah dicabut.','#888');
 if(cur.v&&!o.v)popup('✔','Centang Biru!','Kamu mendapat Centang Biru. Semua pemain bisa melihatnya di samping namamu.','#1d9bf0');
 else if(!cur.v&&o.v)popup('ℹ️','Centang biru dicabut','Centang biru di akunmu sudah dicabut.','#888')}catch(e){}}

/* ---------- 3. gaya ---------- */
const css=document.createElement('style');css.textContent=`
.rbd{display:inline-block;vertical-align:middle;margin-left:6px;padding:2px 7px;border-radius:99px;color:#fff;font:800 10px/1.3 Inter,Arial,sans-serif;letter-spacing:.4px;border:1px solid rgba(0,0,0,.25);position:relative;top:-1px}
.rbd-owner{background:#f5a400}.rbd-coowner{background:#8a4dff}.rbd-admin{background:#e5383b}
.ur2h .rbd,.card.row .rbd,.pkr-n .rbd{display:none}
#gfx{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.62);display:flex;align-items:center;justify-content:center;padding:20px;animation:gfxf .25s}
.gfx-c{max-width:340px;width:100%;text-align:center;background:linear-gradient(180deg,#2d1114,#1a0b0d);border:2px solid var(--gc,#1d9bf0);border-radius:20px;padding:26px 22px;color:#fff;box-shadow:0 0 0 5px color-mix(in srgb,var(--gc) 25%,transparent),0 20px 60px rgba(0,0,0,.6);animation:gfxp .35s cubic-bezier(.2,1.4,.4,1)}
.gfx-i{width:72px;height:72px;margin:0 auto 10px;border-radius:50%;background:var(--gc);display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:900}
.gfx-c h2{margin:6px 0 8px;font-size:24px}.gfx-c p{margin:0 0 18px;font-size:14px;opacity:.85;line-height:1.45}
@keyframes gfxf{from{opacity:0}to{opacity:1}}@keyframes gfxp{from{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}`;
document.head.appendChild(css);

/* ---------- pasang ---------- */
window.addEventListener('load',()=>{
 try{const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(rlSync,2000);return r}}catch(e){}
 try{const _sg=startGame;startGame=function(){const r=_sg.apply(this,arguments);setTimeout(rlSync,1800);return r}}catch(e){}
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)rlSync()},40000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)rlSync()});
 setInterval(watch,1500);setTimeout(rlSync,6000)});
})();
