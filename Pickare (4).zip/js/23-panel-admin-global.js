/* ===== PANEL ADMIN GLOBAL: gift PickBux, centang biru, ban, takedown map, report -> berlaku di perangkat target =====
   Perintah ditandatangani (owner: kunci owner; admin: kunci akun + bukti gift dari owner) dan diverifikasi penerima. */
(function(){
const CMD='pickare/v9/cmd/',BAN='pickare/v9/ban/',VF='pickare/v9/vf/',REP='pickare/v9/rep/',OWN='pickare/v9/own/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)};
const lw=n=>hs(String(n).toLowerCase()),te=s=>new TextEncoder().encode(s),mq=()=>window.__spMq,EC={name:'ECDSA',namedCurve:'P-256'},SG={name:'ECDSA',hash:'SHA-256'};
const b64=u=>{let s='';u.forEach(c=>s+=String.fromCharCode(c));return btoa(s)},unb=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
const msgOf=(n,r,t,k)=>String(n).toLowerCase()+'|'+r+'|'+t+'|'+(k?hs(JSON.stringify(k)):'');
const cmdMsg=c=>[c.id,c.from,c.to,c.cmd,JSON.stringify(c.args),c.ts].join('|');
const sign=async(priv,m)=>b64(new Uint8Array(await crypto.subtle.sign(SG,await crypto.subtle.importKey('jwk',priv,EC,false,['sign']),te(m))));
const verify=async(pub,sig,m)=>{try{return await crypto.subtle.verify(SG,await crypto.subtle.importKey('jwk',pub,EC,false,['verify']),unb(sig),te(m))}catch(e){return false}};
const ready=async()=>!!(mq()&&(window.mqtt||await mq().lib()));
function collect(topics,ms,cb){return new Promise(async res=>{if(!(await ready()))return res(0);let pend=BR.length;
 BR.forEach(url=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}if(--pend===0)res(1)};
  try{m=mqtt.connect(url,{clientId:'spx_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)res(1);return}
  m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topics,{qos:0});setTimeout(end,ms)});
  m.on('message',(t,b)=>{try{const s=b.toString();if(s)cb(t,JSON.parse(s))}catch(e){}});setTimeout(end,ms+4000)});setTimeout(()=>res(1),ms+6000)})}
const keyOf=n=>{const r=String(n||'').trim().toLowerCase();return r?Object.keys(users).find(k=>k.toLowerCase()===r)||null:null};
const rid=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36);
/* kunci akun (dipakai admin untuk menandatangani) */
async function ensureUkey(){if(!me||me.role==='owner')return;
 if(!me.ukey){const p=await crypto.subtle.generateKey(EC,true,['sign','verify']);me.ukey={priv:await crypto.subtle.exportKey('jwk',p.privateKey),pub:await crypto.subtle.exportKey('jwk',p.publicKey)};save()}
 const sg=hs(JSON.stringify(me.ukey.pub)),S=ls.get('sp_uksig',{});if(S[me.name]&&S[me.name].s===sg&&Date.now()-S[me.name].t<216e5)return;
 if(mq()&&await mq().pushAll([{t:OWN+'uk/'+lw(me.name),p:JSON.stringify({n:me.name,pub:me.ukey.pub,ts:Date.now()})}])){S[me.name]={s:sg,t:Date.now()};ls.set('sp_uksig',S)}}
/* kirim perintah */
async function sendCmd(to,cmd,args,state){try{if(!me||!(await ready()))return;const rec={id:rid(),from:me.name,to,cmd,args,ts:Date.now()};let priv;
 if(me.role==='owner'){const k=ls.get('sp_okey',null);if(!k)return;priv=k.priv;rec.o=1}
 else{if(!me.ukey||!me.grec||!me.grec.pk){toast('Perintah belum bisa menjangkau HP lain: minta owner gift akses ulang');return}priv=me.ukey.priv;rec.g=me.grec}
 rec.sig=await sign(priv,cmdMsg(rec));
 const msgs=[{t:state?BAN+lw(to):CMD+lw(to)+'/'+rec.id,p:JSON.stringify(rec)}];if(cmd==='ver')msgs.push({t:VF+lw(to),p:JSON.stringify(rec)});const ok=await mq().pushAll(msgs);
 toast(ok?'Perintah ke '+to+' terkirim ke semua perangkat ✓':'Gagal mengirim perintah ke server')}catch(e){}}
/* verifikasi pengirim -> level (0 = tidak sah) */
async function authz(rec,state){try{const pin=ls.get('sp_ownpk',null);if(!pin||!rec||!rec.sig||!rec.id||!rec.from||!rec.to||typeof rec.cmd!=='string')return 0;
 if(!state&&Date.now()-rec.ts>6048e5)return 0;
 if(rec.o)return(String(rec.from).toLowerCase()==='owner'&&await verify(pin,rec.sig,cmdMsg(rec)))?3:0;
 const g=rec.g;if(!g||!g.pk||!g.sig||String(g.n).toLowerCase()!==String(rec.from).toLowerCase()||!ROLE[g.role])return 0;
 if(!(await verify(pin,g.sig,msgOf(g.n,g.role,g.ts,g.pk))))return 0;if(!(await verify(g.pk,rec.sig,cmdMsg(rec))))return 0;return ROLE[g.role]}catch(e){return 0}}
const OKV=new Set();
function kick(){try{act.out()}catch(e){}try{toast('Akunmu diblokir oleh staf')}catch(e){}}
async function applyState(rec){if(OKV.has(rec.id))return 0;const lv0=await authz(rec,1);if(!lv0)return 0;OKV.add(rec.id);if(String(rec.to).charAt(0)==='_')return RV.rcv(rec);
 const k=keyOf(rec.to);if(!k)return 0;const u=users[k];if(u.role==='owner'||(u.bts||0)>=rec.ts)return 0;if(!(lv0===3||lv0>lv(u)))return 0;
 if(rec.cmd==='ban'){const b=rec.args&&rec.args.ban;if(!b||(b.perm&&lv0<3))return 0;u.ban={perm:!!b.perm,until:+b.until||0,reason:String(b.reason||'').slice(0,120),by:String(rec.from).slice(0,20),t:+b.t||rec.ts};u.pres=null;u.bts=rec.ts;save();if(u===me&&banOf(me))kick();return 1}
 if(rec.cmd==='unban'){delete u.ban;u.bts=rec.ts;save();return 1}return 0}
async function applyCmd(rec){const lv0=await authz(rec,0);if(!lv0||String(rec.to).toLowerCase()!==me.name.toLowerCase())return;
 me.seen2=me.seen2||[];if(me.seen2.includes(rec.id))return;const a=rec.args||{};let ch=0;
 if(rec.cmd==='bux'){const n=Math.floor(+a.amt);if(n>0&&n<=(lv0>=3?1e7:500)){me.bux=(me.bux||0)+n;me.notes.unshift({t:'Kamu mendapat '+n+' PickBux dari '+(RN[rec.g?rec.g.role:'owner']||'staf'),new:1});ch=1}}
 else if(rec.cmd==='ver'&&(lv0===3||lv0>lv(me))){me.verified=!!a.v;me.notes.unshift({t:a.v?'✔ Kamu mendapat Centang Biru!':'Centang biru dicabut',new:1});ch=1}
 else if(rec.cmd==='take'&&lv0>=1){(me.games||[]).forEach(g=>{if(g.id==a.gid)g.pub=false});ch=1;me.notes.unshift({t:'Salah satu mapmu diturunkan oleh staf',new:1})}
 else if(rec.cmd==='rv'&&lv0>=1){RV.apply(a.k,a.id,me.name,!!a.ok,a.note);ch=1}
 else if(rec.cmd==='rvs'&&lv0>=1){RV.setS(a.k,a.id,me.name,String(a.s),a.note);ch=1}
 else if(rec.cmd==='viol'&&lv0>=1&&(lv0>=3||lv0>lv(me))){RV.viol(me,a.id,a.reason,rec.from);ch=1}
 else if(rec.cmd==='violx'&&lv0>=1){RV.violx(me);ch=1}
 me.seen2.push(rec.id);if(me.seen2.length>200)me.seen2.shift();if(ch){save();try{navRender();rolePill();refreshUI()}catch(e){}}}
/* v12: centang biru terlihat semua pemain. Catatan 'ver' bertanda tangan owner/admin disimpan di VF/<nama>; tiap perangkat memverifikasi tanda tangannya sebelum menampilkan ✔ */
const VFK='sp_vf',vfc=()=>{const c=ls.get(VFK,{});return c&&typeof c==='object'&&!Array.isArray(c)?c:{}};
window.spVb=n=>{try{return window.spVerified(n)?'<span class="vb">✔</span>':''}catch(e){return''}};
window.spVerified=n=>{const l=String(n||'').toLowerCase();if(l==='owner')return true;const c=vfc()[l];return !!(c&&c.v)};
function vfApply(){const c=vfc();let ch=0;
 for(const k in users){const u=users[k],z=c[k.toLowerCase()];if(!z||u.role==='owner')continue;
  if(u===me){if(z.ts>(me.vts||0)){me.vts=z.ts;if(!!me.verified!==z.v)me.verified=z.v;ch=1}continue}
  if(!!u.verified!==z.v){u.verified=z.v;ch=1}}
 if(ch){save();try{refreshUI()}catch(e){}}try{window.spVfChanged&&window.spVfChanged()}catch(e){}}
async function vfSync(){try{if(typeof me==='undefined'||!me||!(await ready()))return;const got={};
 await collect([VF+'+'],2500,(t,d)=>{if(!d||typeof d!=='object'||d.cmd!=='ver'||!d.to||!d.sig||t!==VF+lw(d.to))return;if(!got[t]||d.ts>got[t].ts)got[t]=d});
 const c=vfc();let ch=0;
 for(const t in got){const r=got[t],l=String(r.to).toLowerCase();if(!r.args||typeof r.args.v!=='boolean')continue;if(c[l]&&c[l].ts>=r.ts)continue;if(!(await authz(r,1)))continue;c[l]={v:r.args.v,ts:r.ts};ch=1}
 if(ch)ls.set(VFK,c);vfApply()}catch(e){}}
window.spVfSync=vfSync;
/* v16: roster bot buatan owner, bertanda tangan, dibaca semua perangkat */
const BOTT='pickare/v9/botroster',botMsg=r=>'bots|'+r.ts+'|'+JSON.stringify([r.bots,!!r.chat]);
const ownerKey2=async()=>{let k=ls.get('sp_okey',null);if(k&&k.priv&&k.pub)return k;const p=await crypto.subtle.generateKey(EC,true,['sign','verify']);k={priv:await crypto.subtle.exportKey('jwk',p.privateKey),pub:await crypto.subtle.exportKey('jwk',p.publicKey)};ls.set('sp_okey',k);ls.set('sp_ownpk',k.pub);return k};
window.spBotPublish=async(bots,chat)=>{try{if(!me||me.role!=='owner'||!(await ready()))return 0;const k=await ownerKey2(),rec={ts:Date.now(),bots,chat:!!chat};rec.sig=await sign(k.priv,botMsg(rec));return await mq().pushAll([{t:BOTT,p:JSON.stringify(rec)}])?rec.ts:0}catch(e){return 0}};
window.spBotFetch=async()=>{try{const pin=ls.get('sp_ownpk',null);if(!pin||!(await ready()))return;let best=null;
 await collect([BOTT],2500,(t,d)=>{if(d&&d.sig&&Array.isArray(d.bots)&&(!best||d.ts>best.ts))best=d});
 const cur=ls.get('sp_botr',{ts:0});if(best&&best.ts>(cur.ts||0)&&await verify(pin,best.sig,botMsg(best))){ls.set('sp_botr',{ts:best.ts,bots:best.bots.slice(0,40),chat:!!best.chat});window.spBotsChanged&&spBotsChanged()}}catch(e){}};
/* report lintas perangkat */
const reps=()=>{let r=ls.get('sp_rep',[]);return Array.isArray(r)?r:[]};
async function repSync(){if(!me||!(await ready()))return;const S=ls.get('sp_repsig',{}),push=[];
 reps().forEach(x=>{if(!x||!x.id||push.length>=20)return;const sg=hs(JSON.stringify(x));if(S[x.id]!==sg&&(x.by===me.name||staff())){push.push({t:REP+x.id,p:JSON.stringify({r:x,ts:Date.now()})});S[x.id]=sg}});
 if(push.length&&mq())await mq().pushAll(push);
 if(staff()){const got={};await collect([REP+'+'],3000,(t,d)=>{if(d&&d.r&&d.r.id&&(!got[d.r.id]||d.ts>got[d.r.id].ts))got[d.r.id]=d});
  let r=reps(),ch=0;for(const id in got){const x=got[id].r;if(String(id)!==String(x.id))continue;const l=r.find(y=>y.id===x.id);
   if(!l){r.unshift({id:String(x.id),t:+x.t||Date.now(),st:x.st==='done'?'done':'open',by:String(x.by||'').slice(0,20),type:String(x.type||'').slice(0,20),tg:String(x.tg||'').slice(0,20),txt:String(x.txt||'').slice(0,300),gid:x.gid?String(x.gid).slice(0,30):undefined,gn:x.gn?String(x.gn).slice(0,30):undefined,res:x.res?String(x.res).slice(0,80):undefined,rt:x.rt});ch=1;
    if(x.st!=='done'&&x.by!==me.name)me.notes.unshift({t:'Report baru: '+String(x.by||'').slice(0,20)+(x.tg?' melaporkan '+String(x.tg).slice(0,20):' mengirim laporan'),new:1})}
   else if(x.st==='done'&&l.st!=='done'){l.st='done';l.res=String(x.res||'').slice(0,80);l.rt=x.rt;ch=1}}
  if(ch){r=r.slice(0,200);ls.set('sp_rep',r);r.forEach(x=>{S[x.id]=hs(JSON.stringify(x))});save();try{refreshUI()}catch(e){}}}
 ls.set('sp_repsig',S)}
let busy=0;
async function tick(){if(busy||typeof me==='undefined'||!me||!(await ready()))return;busy=1;
 try{ensureUkey();const st=[],inb=[];RV.b();const okc=await collect([BAN+'+',CMD+lw(me.name)+'/+','pickare/v9/rvq/+'],3000,(t,d)=>{if(t.startsWith(BAN))st.push(d);else if(t.startsWith('pickare/v9/rvq/')){if(staff())RV.got(t,d)}else inb.push([t,d])});if(okc)RV.f();
  for(const r of st)await applyState(r);const clr=[];
  for(const [t,r] of inb){await applyCmd(r);clr.push({t,p:''})}
  if(clr.length&&mq())mq().pushAll(clr);
  await repSync()}catch(e){}finally{busy=0}}
window.spPanelSync=tick;window.spSendCmd=sendCmd;
window.addEventListener('load',()=>{
 const snap=()=>{const s={};for(const k in users){const u=users[k];s[k]={b:u.bux||0,v:!!u.verified,n:JSON.stringify(u.ban||null)}}return s};
 const diff=s0=>{for(const k in users){const u=users[k];if(u===me||!u.rm)continue;const z=s0[k]||{b:0,v:false,n:'null'};
  if((u.bux||0)>z.b)sendCmd(k,'bux',{amt:(u.bux||0)-z.b});
  if(!!u.verified!==z.v)sendCmd(k,'ver',{v:!!u.verified});
  const n=JSON.stringify(u.ban||null);if(n!==z.n){if(u.ban)sendCmd(k,'ban',{ban:u.ban},1);else sendCmd(k,'unban',{},1)}}};
 ['gbux','gver','bandirect','bango','unban','unbandirect'].forEach(a=>{const o=act[a];if(!o)return;act[a]=function(){if(!me||!staff())return o.apply(this,arguments);const s0=snap(),r=o.apply(this,arguments);try{diff(s0)}catch(e){}return r}});
 const rt=act.rtake;if(rt)act.rtake=function(v){const x=reps().find(y=>y.id==v),gid=x&&x.gid,r=rt.apply(this,arguments);
  try{if(gid&&staff()){const g=RPUB.find(y=>y.id==gid);if(g&&g.by){const by=keyOf(g.by)||g.by;RPUB.splice(RPUB.indexOf(g),1);sendCmd(by,'take',{gid})}}}catch(e){}return r};
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(tick,1500);setTimeout(vfSync,2500);return r};
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)tick()},20000);
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)vfSync()},45000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()})});
})();
