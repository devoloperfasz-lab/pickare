/* ===== v11: Terrain rumput bergoyang + kuas terrain, Video & Efek video ===== */
(function(){
const GU={value:0};(function tk(){GU.value=performance.now()/1000;requestAnimationFrame(tk)})();
NM.grass='Rumput';TI.grass='';NM.video='Video';TI.video='';
try{TY.push('grass','video')}catch(e){}
/* ---- penyimpanan video (IndexedDB, hanya di perangkat ini) ---- */
let _db=null;const idb=()=>_db||(_db=new Promise((ok,no)=>{try{const r=indexedDB.open('sbvid',1);r.onupgradeneeded=()=>r.result.createObjectStore('v');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}catch(e){no(e)}}));
const vPut=(k,b)=>idb().then(d=>new Promise((ok,no)=>{const t=d.transaction('v','readwrite');t.objectStore('v').put(b,k);t.oncomplete=ok;t.onerror=()=>no(t.error)}));
const vGet=k=>idb().then(d=>new Promise(ok=>{const q=d.transaction('v').objectStore('v').get(k);q.onsuccess=()=>ok(q.result);q.onerror=()=>ok(null)})).catch(()=>null);
const VC={};
function getVid(o){const k=o.vurl||o.vid;if(!k)return null;if(VC[k])return VC[k];
 const v=document.createElement('video');v.loop=true;v.muted=true;v.playsInline=true;v.setAttribute('playsinline','');v.crossOrigin='anonymous';v.preload='auto';VC[k]=v;
 if(o.vurl)v.src=o.vurl;else vGet(k).then(b=>{if(b){v.src=URL.createObjectURL(b);v.play().catch(()=>{})}});
 v.play&&v.play().catch(()=>{});return v}
document.addEventListener('pointerdown',()=>Object.values(VC).forEach(v=>{if(v.paused&&v.src)v.play().catch(()=>{})}),{passive:true});
/* ---- rumput ---- */
let GM=null;
function grassMat(){if(GM)return GM;GM=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
 GM.onBeforeCompile=sh=>{sh.uniforms.uT=GU;sh.vertexShader='uniform float uT;\n'+sh.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
 float ph=modelMatrix[3].x*.7+modelMatrix[3].z*.9;float kx=length(modelMatrix[0].xyz),ky=length(modelMatrix[1].xyz),kz=length(modelMatrix[2].xyz);
 float sw=sin(uT*1.6+ph+position.x*4.+position.z*3.)*.6+sin(uT*2.7+ph*1.3+position.z*5.)*.3;
 transformed.x+=sw*.09*position.y*ky/kx;transformed.z+=cos(uT*1.3+ph+position.x*3.)*.05*position.y*ky/kz;`)};return GM}
function mkGrass(o){o.cc=false;
 const base=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,.03,28),new THREE.MeshLambertMaterial({color:new THREE.Color(o.c||'#4caf50').multiplyScalar(.5)}));
 const n=Math.min(320,Math.max(30,Math.round(o.sx*o.sz*10)));let s=(Math.abs(Math.round(o.x*131+o.z*977))+7)>>>0;const R=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296};
 const c1=new THREE.Color(o.c||'#4caf50'),c0=c1.clone().multiplyScalar(.45),c2=c1.clone().lerp(new THREE.Color('#ffffff'),.2);
 const P=[],C=[],N=[];
 for(let i=0;i<n;i++){const a=R()*6.2832,r=Math.sqrt(R())*.48,x=Math.cos(a)*r,z=Math.sin(a)*r,h=.55+R()*.45,w=.02+R()*.012,t=R()*3.1416,dx=Math.cos(t)*w,dz=Math.sin(t)*w,lx=(R()-.5)*.06,lz=(R()-.5)*.06;
  P.push(x-dx,0,z-dz,x+dx,0,z+dz,x+lx,h,z+lz);C.push(c0.r,c0.g,c0.b,c0.r,c0.g,c0.b,c2.r,c2.g,c2.b);N.push(0,1,0,0,1,0,0,1,0)}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));g.setAttribute('color',new THREE.Float32BufferAttribute(C,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));
 const bl=new THREE.Mesh(g,grassMat());bl.frustumCulled=false;bl.raycast=()=>{};base.add(bl);place(base,o);base.userData={o};return base}
/* ---- video ---- */
function mkVideo(o){o.cc=false;const el=getVid(o),tx=el?new THREE.VideoTexture(el):null;
 if(tx){tx.minFilter=THREE.LinearFilter;tx.magFilter=THREE.LinearFilter;tx.generateMipmaps=false}
 const mt=new THREE.MeshBasicMaterial({map:tx,color:tx?0xffffff:new THREE.Color(o.c||'#888888'),side:THREE.DoubleSide,transparent:true,opacity:Math.min(1,Math.max(.05,o.vop||(tx?1:.5)))});
 if(o.vmode==='efek'){mt.blending=THREE.AdditiveBlending;mt.depthWrite=false}
 const m=new THREE.Mesh(new THREE.PlaneGeometry(1,1),mt);place(m,o);m.userData={o};return m}
const _mk=mkObj;mkObj=function(o){return o&&o.t==='grass'?mkGrass(o):o&&o.t==='video'?mkVideo(o):_mk(o)};
/* seleksi rumput: cincin datar */
const _sh=selHelper;selHelper=function(){const m=meshes[SEL],o=m&&m.userData&&m.userData.o;
 if(o&&o.t==='grass'){if(helper){SS.remove(helper);helper=null}const pts=[];for(let i=0;i<=48;i++){const t=i/48*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(t)*.5,0,Math.sin(t)*.5))}
  const g=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:0xff0066,depthTest:false,transparent:true}));g.renderOrder=98;
  g.update=()=>{g.position.copy(m.position);g.scale.set(m.scale.x,1,m.scale.z)};g.update();helper=g;SS.add(g);gzBuild();return}
 _sh()};
/* ---- kuas terrain ---- */
const TB={on:false,m:'add',s:3,h:.7,c:'#4caf50'};
let cursor=null;const gcount=()=>ST.d.objs.filter(o=>o.t==='grass').length,MAXG=400;
function curs(){if(!cursor){const pts=[];for(let i=0;i<=40;i++){const t=i/40*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(t)*.5,0,Math.sin(t)*.5))}cursor=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:0x22cc66,depthTest:false,transparent:true}));cursor.renderOrder=99}
 if(cursor.parent!==SS)SS.add(cursor);return cursor}
let painting=false,lastP=null,changed=false,pid=null;
function dab(p){if(!p)return;const s=TB.s;
 if(TB.m==='add'){if(lastP&&Math.hypot(p.x-lastP.x,p.z-lastP.z)<s*.6)return;if(gcount()>=MAXG){toast('Batas rumput tercapai ('+MAXG+')');return}
  const o=O('grass',+(p.x).toFixed(2),.03,+(p.z).toFixed(2),s,TB.h,s,TB.c);o.cc=false;ST.d.objs.push(o);const m=mkObj(o);SS.add(m);meshes[o.id]=m;lastP=p;changed=true}
 else{const r=s/2;const del=ST.d.objs.filter(o=>o.t==='grass'&&Math.hypot(o.x-p.x,o.z-p.z)<r+o.sx*.3);if(!del.length)return;
  del.forEach(o=>{const m=meshes[o.id];if(m)SS.remove(m);delete meshes[o.id]});ST.d.objs=ST.d.objs.filter(o=>!del.includes(o));changed=true}}
const on=()=>TB.on&&ST&&ST.kind==='g'&&$('#ed').classList.contains('on');
sc.addEventListener('pointerdown',e=>{if(!on()||e.button==2||e.button==1||e.shiftKey)return;if(painting){painting=false;return}
 e.preventDefault();e.stopImmediatePropagation();try{sc.setPointerCapture(e.pointerId)}catch(x){}
 pushUndo();painting=true;pid=e.pointerId;lastP=null;changed=false;const p=plane(e,0);const c=curs();if(p){c.position.set(p.x,.06,p.z);c.scale.set(TB.s,1,TB.s)}dab(p)},true);
sc.addEventListener('pointermove',e=>{if(!on())return;const p=plane(e,0);if(p){const c=curs();c.position.set(p.x,.06,p.z);c.scale.set(TB.s,1,TB.s)}
 if(painting&&e.pointerId===pid){e.stopImmediatePropagation();dab(p)}},true);
const endP=e=>{if(!painting||e.pointerId!==pid)return;e.stopImmediatePropagation();painting=false;if(changed){eRender();touch();slog((TB.m==='add'?'+ rumput':'- rumput'))}};
sc.addEventListener('pointerup',endP,true);sc.addEventListener('pointercancel',endP,true);
/* ---- panel Toolbox ---- */
const _tb=tbxRender;
tbxRender=function(){_tb();if(!ST||ST.kind!=='g')return;
 $('#tbx').insertAdjacentHTML('beforeend',`<h4>Terrain</h4>
 <button class="btn sm w ${TB.on?'c':'o'}" id="tr_on">Kuas Terrain: ${TB.on?'HIDUP':'Mati'}</button>
 <label>Mode kuas</label><select id="tr_m"><option value="add" ${TB.m=='add'?'selected':''}>Tambah rumput</option><option value="del" ${TB.m=='del'?'selected':''}>Hapus rumput</option></select>
 <label>Ukuran kuas: <b id="tr_sv">${TB.s}</b></label><input type="range" id="tr_s" min="1" max="12" step=".5" value="${TB.s}">
 <label>Tinggi rumput: <b id="tr_hv">${TB.h}</b></label><input type="range" id="tr_h" min=".2" max="2" step=".1" value="${TB.h}">
 <label>Warna rumput</label><input type="color" id="tr_c" value="${TB.c}">
 <div class="tg"><button class="btn sm" id="tr_gen">Generate</button><button class="btn sm o" id="tr_cl">Clean</button></div>
 <div style="font-size:11px;opacity:.7;margin:4px 0">Hidupkan kuas, lalu seret di viewport. Rumput bergoyang pelan.</div>
 <h4>Video &amp; Efek</h4><button class="btn sm w" id="vd_up">Upload Video</button><button class="btn sm w" id="vd_url">Video dari URL</button>
 <div style="font-size:11px;opacity:.7;margin:4px 0">Pilih video di viewport lalu atur <b>Efek</b> di panel properti (Efek = latar hitam jadi transparan).</div>`);
 const g=id=>$('#'+id);
 g('tr_on').onclick=()=>{TB.on=!TB.on;tbxRender();toast(TB.on?'Kuas terrain hidup: seret di viewport':'Kuas terrain mati')};
 g('tr_m').onchange=e=>TB.m=e.target.value;
 g('tr_s').oninput=e=>{TB.s=+e.target.value;g('tr_sv').textContent=TB.s};g('tr_h').oninput=e=>{TB.h=+e.target.value;g('tr_hv').textContent=TB.h};g('tr_c').onchange=e=>TB.c=e.target.value;
 g('tr_gen').onclick=()=>{pushUndo();ST.d.objs=ST.d.objs.filter(o=>o.t!=='grass');let n=0;for(let x=-36;x<=36;x+=7)for(let z=-36;z<=36;z+=7){const o=O('grass',x,.03,z,8,TB.h,8,TB.c);o.cc=false;ST.d.objs.push(o);n++}
  sBuild();eRender();pRender();touch();slog('+ '+n+' rumput')};
 g('tr_cl').onclick=()=>{pushUndo();ST.d.objs=ST.d.objs.filter(o=>o.t!=='grass');SEL='root';sBuild();eRender();pRender();touch();slog('Rumput dibersihkan')};
 g('vd_up').onclick=()=>{let f=$('#vd_file');if(!f){f=document.createElement('input');f.type='file';f.accept='video/*';f.id='vd_file';f.style.display='none';document.body.appendChild(f);f.onchange=()=>{const fl=f.files[0];f.value='';if(fl)upVid(fl)}}f.click()};
 g('vd_url').onclick=()=>{const u=(prompt('Tempel link video (https, mp4/webm, harus mengizinkan CORS):')||'').trim();if(!u)return;if(!/^https:\/\/[^\s]{4,300}$/i.test(u))return toast('Link harus https');addVid({vurl:u,n:'Video URL'},16/9)}};
function addVid(f,asp){pushUndo();const w=6,h=+(w/(asp||1.78)).toFixed(2),o=O('video',Math.round(sctl.tx),+(h/2+.1).toFixed(2),Math.round(sctl.tz),w,h,.05,'#ffffff');Object.assign(o,f);o.cc=false;
 ST.d.objs.push(o);SEL=o.id;sBuild();eRender();pRender();touch();slog('+ Video')}
async function upVid(fl){if(!/^video\//.test(fl.type))return toast('Pilih file video');if(fl.size>60*1024*1024)return toast('Maksimal 60 MB');
 const key='v_'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);
 try{await vPut(key,fl)}catch(e){return toast('Gagal menyimpan video')}
 const u=URL.createObjectURL(fl),t=document.createElement('video');t.preload='metadata';
 t.onloadedmetadata=()=>{const a=t.videoWidth&&t.videoHeight?t.videoWidth/t.videoHeight:1.78;URL.revokeObjectURL(u);addVid({vid:key,n:fl.name.replace(/\.[^.]+$/,'').slice(0,18)||'Video'},a)};
 t.onerror=()=>{URL.revokeObjectURL(u);addVid({vid:key,n:'Video'},1.78)};t.src=u}
/* ---- properti video ---- */
const _pr=pRender;
pRender=function(){_pr();try{const o=cur();if(!o||o.t!=='video')return;
 $('#props').insertAdjacentHTML('afterbegin',`<h4>Video</h4><label>Efek</label><select data-p="vmode"><option value="normal" ${o.vmode!=='efek'?'selected':''}>Normal</option><option value="efek" ${o.vmode==='efek'?'selected':''}>Efek (hitam transparan)</option></select><label>Transparansi (0.1 - 1)</label><input type="number" step=".1" min=".1" max="1" data-p="vop" value="${o.vop||1}"><label>URL video (opsional, https)</label><input type="text" data-p="vurl" value="${esc(o.vurl||'')}" maxlength="300"><div style="font-size:11px;opacity:.7;margin-bottom:6px">${o.vid&&!o.vurl?'Video tersimpan di perangkat ini saja. Pakai URL agar terlihat di perangkat lain.':''}</div>`)}catch(e){}};
})();
