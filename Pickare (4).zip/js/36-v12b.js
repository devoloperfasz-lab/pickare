/* ===== v12b: efek lewat script (ParticleEmitter, Fire, Smoke, Sparkles, Explosion, PointLight) ===== */
(function(){
const TYPES={ParticleEmitter:1,Fire:1,Smoke:1,Sparkles:1,Explosion:1,PointLight:1};
const MAXP=500;let live=[],parts=[],raf=0,last=0;
const BG=new THREE.BoxGeometry(1,1,1);
const col=(v,d)=>{try{if(v&&typeof v.r==='number')return new THREE.Color(v.r,v.g,v.b)}catch(e){}return new THREE.Color(d)};
const num=(v,d,a,b)=>{v=+v;if(!isFinite(v))v=d;return Math.max(a,Math.min(b,v))};
const DEF={
 ParticleEmitter:{Rate:20,Lifetime:1.5,Speed:5,Size:.3,Spread:35,Gravity:0,Color:[1,1,1],Grow:0,Add:1},
 Fire:{Rate:28,Lifetime:.9,Speed:3,Size:.7,Spread:14,Gravity:-4,Color:[1,.45,.05],Grow:-.6,Add:1},
 Smoke:{Rate:10,Lifetime:2.6,Speed:2,Size:.8,Spread:20,Gravity:-1,Color:[.45,.45,.45],Grow:1.4,Add:0},
 Sparkles:{Rate:24,Lifetime:.8,Speed:2.2,Size:.18,Spread:180,Gravity:0,Color:[1,.9,.3],Grow:-.5,Add:1},
 Explosion:{Rate:0,Lifetime:.8,Speed:18,Size:.5,Spread:180,Gravity:12,Color:[1,.5,.1],Grow:-.4,Add:1},
 PointLight:{}};
class EW{
 constructor(cls){this.cls=cls;this.nm=cls;this.par=null;this.en=true;this.acc=0;this.alive=true;this.eid=Math.random().toString(36).slice(2,8);this.an=null;this.p=Object.assign({},DEF[cls]);
  this.p.Color=new THREE.Color(...(DEF[cls].Color||[1,1,1]));this.pos=null;this.age=0;
  if(cls==='PointLight'){this.p.Brightness=1;this.p.Range=16;this.p.Color=new THREE.Color(1,1,1);this.l=new THREE.PointLight(0xffffff,1,16)}
  if(cls==='Explosion'){this.p.BlastRadius=6;this.fired=false}}
 origin(){let x=0,y=3,z=0;try{const A=this.an;
  if(A==='part'){const i=this.pinf();if(i)return{x:i.x,y:i.y,z:i.z}}
  if(this.rem){const g=this.rem.g;if(this.q&&A==='rbody'){const v=g.localToWorld(new THREE.Vector3(this.q[0],this.q[1],this.q[2]));return{x:v.x,y:v.y,z:v.z}}if(A==='rtool'&&this.rem.hg){const v=new THREE.Vector3();this.rem.hg.getWorldPosition(v);return{x:v.x,y:v.y,z:v.z}}return{x:g.position.x,y:g.position.y+1.5,z:g.position.z}}
  if(A==='tool'&&window.__heldMesh&&window.__heldTool===this.tid){const v=new THREE.Vector3();window.__heldMesh.getWorldPosition(v);return{x:v.x,y:v.y,z:v.z}}
  if(A==='body'||A==='tool')return{x:P.x,y:P.y+1.5,z:P.z};
  if(this.pos){x=this.pos.x;y=this.pos.y;z=this.pos.z}else if(this.par&&this.par.$g){const v=this.par.$g('Position');if(v&&typeof v.x==='number'){x=v.x;y=v.y;z=v.z}}}catch(e){}return{x,y,z}}
 /* efek di dalam Part aksesoris: keluar dari part itu & ukuran/jumlah/kecepatan ikut ukuran part */
 pinf(){try{if(this.am){const m=this.am,v=new THREE.Vector3(),q=new THREE.Quaternion(),s=new THREE.Vector3();m.updateWorldMatrix(true,false);m.matrixWorld.decompose(v,q,s);return{x:v.x,y:v.y,z:v.z,k:Math.max(.05,Math.min(20,(s.x+s.y+s.z)/3)),m}}
  if(this.q&&typeof plr!=='undefined'&&plr){const v=plr.localToWorld(new THREE.Vector3(this.q[0],this.q[1],this.q[2]));return{x:v.x,y:v.y,z:v.z,k:Math.max(.05,Math.min(20,+this.q[3]||1))}}}catch(e){}return null}
 kf(){if(this.an==='part'){const i=this.pinf();return i?i.k:1}if(this.q&&this.rem)return Math.max(.05,Math.min(20,+this.q[3]||1));return 1}
 rf(){return(this.an==='part'||(this.q&&this.rem))?(.5+.8*this.kf()):1}
 $g(k){const p=this.p;switch(k){
  case'Name':return this.nm;case'ClassName':return this.cls;case'Parent':return this.par;
  case'Enabled':return this.en;case'Destroy':return()=>this.destroy();case'Emit':return(_,n)=>this.emit(num(n,10,0,200));
  case'Rate':return p.Rate;case'Lifetime':return p.Lifetime;case'Speed':return p.Speed;case'Size':return p.Size;case'SpreadAngle':return p.Spread;
  case'Acceleration':return p.Gravity;case'Color':return new LC(p.Color.r,p.Color.g,p.Color.b);
  case'Brightness':return p.Brightness;case'Range':return p.Range;case'BlastRadius':return p.BlastRadius;
  case'Position':{const o=this.origin();return new LV(o.x,o.y,o.z)}}}
 $s(k,v){const p=this.p;switch(k){
  case'Name':this.nm=String(v);break;
  case'Parent':if(v==null){this.destroy();break}this.par=v;this.an=null;try{if(v&&(v.$am||v.$q)){this.an='part';this.am=v.$am||null;this.q=Array.isArray(v.$q)&&v.$q.length===4?v.$q.map(Number):null}else if(v===RT.ch||v instanceof RootW)this.an='body';else if(v&&v.i&&v.i.cls==='Tool'){this.an='tool';this.tid=String(v.i.id)}}catch(x){}if(!live.includes(this)){live.push(this);if(this.l)scene.add(this.l);kick()}break;
  case'Enabled':this.en=!!v;break;
  case'Rate':p.Rate=num(v,p.Rate,0,200);break;case'Lifetime':p.Lifetime=num(v,p.Lifetime,.05,15);break;
  case'Speed':p.Speed=num(v,p.Speed,0,80);break;case'Size':p.Size=num(v,p.Size,.02,20);break;
  case'SpreadAngle':p.Spread=num(v,p.Spread,0,180);break;case'Acceleration':p.Gravity=num(v,p.Gravity,-80,80);break;
  case'Color':p.Color=col(v,'#ffffff');if(this.l)this.l.color.copy(p.Color);break;
  case'Brightness':p.Brightness=num(v,1,0,20);if(this.l)this.l.intensity=p.Brightness;break;
  case'Range':p.Range=num(v,16,1,200);if(this.l)this.l.distance=p.Range;break;
  case'BlastRadius':p.BlastRadius=num(v,6,.5,60);break;
  case'Position':if(v&&typeof v.x==='number'){this.pos={x:v.x,y:v.y,z:v.z};if(!live.includes(this)){live.push(this);kick()}}break}}
 emit(n){const o=this.origin(),p=this.p,sp=p.Spread*Math.PI/180,K=this.kf(),PI=this.an==='part'?this.pinf():null,Kp=(this.an==='part'||(this.q&&this.rem))?(.4+.6*K):1;
  for(let i=0;i<n&&parts.length<MAXP;i++){
   const a=Math.random()*Math.PI*2,t=Math.acos(1-Math.random()*(1-Math.cos(sp))),sx=Math.sin(t)*Math.cos(a),sy=Math.cos(t),sz=Math.sin(t)*Math.sin(a);
   const mt=new THREE.MeshBasicMaterial({color:p.Color.clone(),transparent:true,opacity:1,depthWrite:false});
   if(this.cls!=='Smoke')mt.blending=THREE.AdditiveBlending;
   if(this.cls==='Sparkles')mt.color.setHSL(Math.random(),1,.65);
   const m=new THREE.Mesh(BG,mt),sz0=p.Size*(.6+Math.random()*.8)*K;
   if(PI&&PI.m)m.position.copy(PI.m.localToWorld(new THREE.Vector3(Math.random()-.5,Math.random()-.5,Math.random()-.5)));
   else if(K!==1)m.position.set(o.x+(Math.random()-.5)*K,o.y+(Math.random()-.5)*K,o.z+(Math.random()-.5)*K);
   else m.position.set(o.x+(Math.random()-.5)*.6,o.y+(Math.random()-.5)*.3,o.z+(Math.random()-.5)*.6);m.scale.setScalar(sz0);m.rotation.set(Math.random()*6,Math.random()*6,0);
   const sv=p.Speed*(.5+Math.random()*.7)*Kp;
   parts.push({m,mt,vx:sx*sv,vy:sy*sv,vz:sz*sv,g:p.Gravity,life:p.Lifetime*(.7+Math.random()*.6),age:0,s0:sz0,gr:this.cls==='Explosion'?-.4:(this.cls==='Smoke'?1.4:this.cls==='Fire'?-.6:this.cls==='Sparkles'?-.5:0)});scene.add(m)}}
 destroy(){if(!this.alive)return;this.alive=false;const i=live.indexOf(this);if(i>=0)live.splice(i,1);if(this.l&&this.l.parent)this.l.parent.remove(this.l)}}
function clearAll(){live.forEach(e=>{e.alive=false;if(e.l&&e.l.parent)e.l.parent.remove(e.l)});live=[];parts.forEach(q=>{try{q.m.parent&&q.m.parent.remove(q.m);q.mt.dispose()}catch(e){}});parts=[]}
function kick(){if(!raf){last=performance.now();raf=requestAnimationFrame(tick)}}
function tick(now){raf=0;const dt=Math.min(.05,(now-last)/1000);last=now;
 if(typeof RT==='undefined'||!RT||!RT.alive){clearAll();return}
 for(const e of live.slice()){if(!e.alive)continue;e.age+=dt;
  if(e.rem&&!Object.values(remote).includes(e.rem)){e.destroy();continue}
  if(e.l){const o=e.origin();e.l.position.set(o.x,o.y,o.z)}
  else if(e.cls==='Explosion'){if(!e.fired){e.fired=true;e.emit(70);const o=e.origin();try{burst(o.x,o.y,o.z,'#ffc400',18)}catch(x){}
    e.flash=new THREE.Mesh(new THREE.SphereGeometry(1,16,12),new THREE.MeshBasicMaterial({color:0xffaa33,transparent:true,opacity:.7,depthWrite:false,blending:THREE.AdditiveBlending}));e.flash.position.set(o.x,o.y,o.z);scene.add(e.flash)}
   if(e.flash){const u=e.age/.45;e.flash.scale.setScalar(.5+u*e.p.BlastRadius*.5);e.flash.material.opacity=Math.max(0,.7*(1-u));if(u>=1){scene.remove(e.flash);e.flash.geometry.dispose();e.flash.material.dispose();e.flash=null}}
   if(e.age>2&&!e.flash)e.destroy()}
  else if(e.en&&e.p.Rate>0&&(e.an!=='tool'||window.__heldTool===e.tid)&&(e.an!=='rtool'||e.rem.hg)){e.acc+=e.p.Rate*dt*e.rf();const n=Math.floor(e.acc);if(n>0){e.acc-=n;e.emit(n)}}}
 for(let i=parts.length-1;i>=0;i--){const q=parts[i];q.age+=dt;const u=q.age/q.life;
  if(u>=1){scene.remove(q.m);q.mt.dispose();parts.splice(i,1);continue}
  q.vy-=q.g*dt;
  q.m.position.x+=q.vx*dt;q.m.position.y+=q.vy*dt;q.m.position.z+=q.vz*dt;
  q.m.scale.setScalar(Math.max(.01,q.s0*(1+q.gr*u)));q.mt.opacity=1-u*u;q.m.rotation.z+=dt*2}
 if(live.length||parts.length)raf=requestAnimationFrame(tick)}
const hex=c=>'#'+c.getHexString();
const r1=v=>Math.round((+v||0)*100)/100;
let fxSig='';
const qo=e=>{try{if(e.an!=='part')return undefined;if(e.q)return e.q.map(r1);const o=e.am&&e.am.userData&&e.am.userData.o;if(!o)return undefined;return[o.x,o.y,o.z,(+o.sx+ +o.sy+ +o.sz)/3].map(r1)}catch(x){return undefined}};
window.__ownFx=function(){const o=live.filter(e=>e.alive&&!e.rem&&(e.an==='body'||e.an==='part'||(e.an==='tool'&&window.__heldTool===e.tid))&&!(e.cls==='Explosion'&&e.age>2.2)).slice(0,6).map(e=>{const p=e.p;
  return{i:e.eid,c:e.cls,q:qo(e),t:e.an==='tool'?'tool':'body',e:e.en?1:0,r:r1(p.Rate),l:r1(p.Lifetime),s:r1(p.Speed),z:r1(p.Size),a:r1(p.Spread),g:r1(p.Gravity),k:hex(p.Color),b:r1(p.BlastRadius||p.Brightness||0),n:r1(p.Range||0)}});
 const sg=JSON.stringify(o);if(sg!==fxSig){fxSig=sg;try{lastSent=''}catch(x){}}return o};
window.__applyFx=function(o,list){if(!o)return;const m=o.fxm=o.fxm||{},seen={};
 (Array.isArray(list)?list.slice(0,6):[]).forEach(d=>{try{if(!d||typeof d.i!=='string'||!TYPES[d.c])return;const id=d.i.slice(0,8);seen[id]=1;let e=m[id];
  const hx6=/^#[0-9a-f]{6}$/i.test(d.k||'')?d.k:'#ffffff';
  if(!e){e=new EW(d.c);e.rem=o;e.an=d.t==='tool'?'rtool':'rbody';e.eid=id;m[id]=e;live.push(e);if(e.l)scene.add(e.l);kick()}
  const p=e.p;e.en=!!d.e;e.q=Array.isArray(d.q)&&d.q.length===4?d.q.map(v=>num(v,0,-30,30)):null;
  if(d.c==='PointLight'){p.Brightness=num(d.b,1,0,5);p.Range=num(d.n,16,1,40);e.l.intensity=p.Brightness;e.l.distance=p.Range;p.Color=new THREE.Color(hx6);e.l.color.copy(p.Color)}
  else{p.Rate=num(d.r,p.Rate,0,60);p.Lifetime=num(d.l,p.Lifetime,.05,6);p.Speed=num(d.s,p.Speed,0,30);p.Size=num(d.z,p.Size,.02,4);p.Spread=num(d.a,p.Spread,0,180);p.Gravity=num(d.g,p.Gravity,-30,30);p.Color=new THREE.Color(hx6);if(d.c==='Explosion')p.BlastRadius=num(d.b,6,.5,20)}}catch(x){}});
 for(const id in m)if(!seen[id]){try{m[id].destroy()}catch(x){}delete m[id]}};
const I=G.get('Instance'),_n=I&&I.get('new');
if(I&&_n)I.set('new',function(cls,par){if(TYPES[cls]){const w=new EW(cls);if(par!==undefined)w.$s('Parent',par);return w}return _n.apply(this,arguments)});
/* referensi Luau */
try{const r=document.getElementById('sref');if(r)r.insertAdjacentHTML('beforeend','<br><b>Efek:</b> <code>Instance.new("Fire"|"Smoke"|"Sparkles"|"ParticleEmitter"|"Explosion"|"PointLight", part)</code> <code>.Rate .Lifetime .Speed .Size .Color .Enabled</code> <code>:Emit(n)</code> <code>:Destroy()</code>')}catch(e){}
})();
