/* ===== v12: foto profil + centang biru terlihat di dalam game (nametag 3D, chat, daftar pemain) ===== */
(function(){
const HEX=/^#[0-9a-f]{6}$/i,HATS=['none','cap','crown'];
const vf=n=>{try{if(window.spVerified&&spVerified(n))return true;const l=String(n||'').toLowerCase(),k=Object.keys(users).find(x=>x.toLowerCase()===l);return !!(k&&users[k].verified)}catch(e){return false}};
const vbn=n=>(vf(n)?'<span class="vb">✔</span>':'')+(window.spRoleBadge?spRoleBadge(n):'');
const PAV={};
const cleanAv=q=>({skin:HEX.test(q.sk)?q.sk:SKIN[0],shirt:HEX.test(q.sh)?q.sh:SHIRT[0],pants:HEX.test(q.pa)?q.pa:PANTS[0],hat:HATS.includes(q.ht)?q.ht:'none'});
const avFor=n=>{try{if(me&&n===me.name)return me.av;if(PAV[n])return PAV[n];for(const k in remote)if(remote[k].name===n&&remote[k].av)return remote[k].av;const p=pinfo(n);return p&&p.av||null}catch(e){return null}};
window.spUI={vf,avFor};

/* nametag 3D: foto profil di kiri, nama di tengah, centang biru di kanan */
tagSprite=function(name){const nm=String(name).slice(0,14),V=vf(nm),RL=window.spRoleOf?spRoleOf(nm):'',RH=RL?30:0,c=document.createElement('canvas');c.width=384;c.height=64+RH;const x=c.getContext('2d');
 const paint=img=>{x.clearRect(0,0,384,64+RH);if(RL&&window.spRoleDraw)spRoleDraw(x,RL,384,RH);x.save();x.translate(0,RH);x.fillStyle='#ffde59';x.fillRect(0,0,384,64);x.strokeStyle='#000';x.lineWidth=8;x.strokeRect(0,0,384,64);
  x.save();x.beginPath();x.arc(38,32,23,0,Math.PI*2);x.closePath();x.fillStyle='#3b1f23';x.fill();x.clip();if(img)x.drawImage(img,15,9,46,46);x.restore();
  x.strokeStyle='#000';x.lineWidth=3;x.beginPath();x.arc(38,32,23,0,Math.PI*2);x.stroke();
  const x0=70,x1=V?326:372;x.fillStyle='#000';x.textAlign='center';x.textBaseline='middle';let fs=30;do{x.font='bold '+fs+'px Arial';fs-=2}while(x.measureText(nm).width>x1-x0&&fs>12);x.fillText(nm,(x0+x1)/2,34);
  if(V){x.fillStyle='#1d9bf0';x.beginPath();x.arc(350,32,17,0,Math.PI*2);x.fill();x.strokeStyle='#fff';x.lineWidth=4.5;x.lineCap='round';x.lineJoin='round';x.beginPath();x.moveTo(341,32.5);x.lineTo(347.5,39);x.lineTo(359,26);x.stroke()}x.restore()};
 paint(null);const tex=new THREE.CanvasTexture(c);
 try{const a=avFor(nm),url=a?avShot(a):'';if(url){const im=new Image();im.onload=()=>{paint(im);tex.needsUpdate=true};im.src=url}}catch(e){}
 const s=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,depthTest:false}));s.scale.set(3.6,.6*(64+RH)/64,1);s.position.y=3.6+(RH?.15:0);s.renderOrder=9;s.userData.sptag=1;return s};

/* data avatar pemain lain dari presence + perbarui tag bila centang/foto berubah */
function retag(o){try{if(!o||!o.g)return;const key=o.name+'|'+(vf(o.name)?1:0)+'|'+(window.spRoleOf?spRoleOf(o.name):'')+'|'+JSON.stringify(PAV[o.name]||0);
 if(o.tgk===key)return;const first=o.tgk===undefined;o.tgk=key;if(first)return;
 o.g.children.filter(c=>c.userData&&c.userData.sptag).forEach(c=>{o.g.remove(c);try{c.material.map.dispose()}catch(e){}});o.g.add(tagSprite(o.name))}catch(e){}}
window.spVfChanged=()=>{try{for(const k in remote)retag(remote[k])}catch(e){}};
const _spv=syncPeers;
syncPeers=function(peers){
 try{(peers||[]).forEach(p=>{const q=p&&p.presence;if(!q||p.isMe||q.n==null)return;PAV[String(q.n).slice(0,14)]=cleanAv(q)})}catch(e){}
 const r=_spv.apply(this,arguments);
 try{(peers||[]).forEach(p=>{const q=p&&p.presence;if(!q||p.isMe||q.n==null)return;const o=remote[p.peer];if(!o)return;o.av=PAV[o.name];retag(o)})}catch(e){}
 return r};

/* daftar pemain (menu jeda): foto + nama + centang */
plist=function(){const l=document.getElementById('plist');if(!l||typeof me==='undefined'||!me)return;
 const row=(n,a,ex)=>'<div style="display:flex;align-items:center;gap:8px;margin:4px 0">'+circ(a,28)+'<b>'+esc(n)+'</b>'+vbn(n)+(ex||'')+'</div>';
 let h='<b>Pemain:</b>'+row(me.name,me.av,'<small style="opacity:.7">(kamu · ID '+esc(me.uid||'-')+')</small>');
 for(const k in remote)h+=row(remote[k].name,remote[k].av||avFor(remote[k].name));
 if(!RM)h+='<br><i>Mode solo (koneksi ke server mabar gagal, coba lagi)</i>';l.innerHTML=h};

/* chat di game: foto kecil + centang di samping nama pengirim */
function decorate(){try{document.querySelectorAll('#rchat .rlog .rm:not(.s):not(.k) > b:not([data-d])').forEach(b=>{const m=/^\[(.*)\]:$/.exec(b.textContent);b.dataset.d='1';if(!m)return;const n=m[1],a=avFor(n);
  b.innerHTML=(a?'<span style="display:inline-flex;vertical-align:middle;margin-right:4px">'+circ(a,18)+'</span>':'')+'['+esc(n)+vbn(n)+']:'})}catch(e){}}
function watch(){const lg=document.querySelector('#rchat .rlog');if(!lg)return setTimeout(watch,1000);new MutationObserver(decorate).observe(lg,{childList:true});decorate()}
watch();

/* ambil data centang biru terbaru tiap kali masuk game */
const _sgu=startGame;startGame=function(){const r=_sgu.apply(this,arguments);setTimeout(()=>{try{window.spVfSync&&spVfSync()}catch(e){}},1500);return r};
})();
