/* ===== v10: UserId, TweenService, Enum GUI, Voice chat (WebRTC lewat room Mabar) ===== */
(function(){
const cp=(t,msg)=>{const ok=()=>toast(msg),fb=()=>{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;opacity:0';document.body.appendChild(a);a.select();try{document.execCommand('copy');ok()}catch(e){toast(t)}a.remove()};try{navigator.clipboard.writeText(t).then(ok,fb)}catch(e){fb()}};

/* ---------- UserId ---------- */
function ensureAllUid(){let ch=0;const used=new Set(Object.values(users).map(u=>u&&u.uid).filter(Boolean).map(String));
 Object.keys(users).forEach(k=>{const u=users[k];if(!u||typeof u!=='object')return;if(!/^\d{6,12}$/.test(String(u.uid||''))){let n;do{n=String(Math.floor(1e8+Math.random()*9e8))}while(used.has(n));used.add(n);u.uid=+n;ch=1}});
 if(ch)try{save()}catch(e){}}
window.ensureAllUid=ensureAllUid;
const _en=enter;enter=function(){ensureAllUid();return _en.apply(this,arguments)};
if(typeof me!=='undefined'&&me)ensureAllUid();
const _rd=render;render=function(){const r=_rd.apply(this,arguments);
 try{if(page=='set'&&me){const m=document.getElementById('main');if(m&&!document.getElementById('uidc')){ensureAllUid();
  m.insertAdjacentHTML('beforeend','<div class="card" id="uidc" style="margin-top:14px"><h3>User ID</h3><p style="margin:0 0 8px;font-size:13px">ID unik akunmu. Di script: <code>player.UserId</code></p><div style="display:flex;gap:8px"><input type="text" readonly value="'+me.uid+'" style="margin:0"><button class="btn sm g" data-a="uidcopy">Salin</button></div></div>')}}}catch(e){}
 return r};
act.uidcopy=()=>cp(String(me.uid),'UserId disalin');

/* ---------- Enum tambahan ---------- */
{const E=G.get('Enum'),en=o=>mkT(o);
 E.set('FillDirection',en({Horizontal:'Horizontal',Vertical:'Vertical'}));
 E.set('HorizontalAlignment',en({Left:'Left',Center:'Center',Right:'Right'}));
 E.set('VerticalAlignment',en({Top:'Top',Center:'Center',Bottom:'Bottom'}));
 E.set('SortOrder',en({LayoutOrder:'LayoutOrder',Name:'Name'}));
 E.set('EasingStyle',en({Linear:'Linear',Sine:'Sine',Quad:'Quad',Cubic:'Cubic',Quart:'Quart',Quint:'Quint',Exponential:'Exponential',Back:'Back',Bounce:'Bounce',Elastic:'Elastic'}));
 E.set('EasingDirection',en({In:'In',Out:'Out',InOut:'InOut'}))}

/* ---------- TweenService ---------- */
const ob=t=>{const n=7.5625,d=2.75;if(t<1/d)return n*t*t;if(t<2/d)return n*(t-=1.5/d)*t+.75;if(t<2.5/d)return n*(t-=2.25/d)*t+.9375;return n*(t-=2.625/d)*t+.984375};
const EIN={Linear:t=>t,Sine:t=>1-Math.cos(t*Math.PI/2),Quad:t=>t*t,Cubic:t=>t**3,Quart:t=>t**4,Quint:t=>t**5,Exponential:t=>t<=0?0:2**(10*t-10),Back:t=>2.70158*t*t*t-1.70158*t*t,Bounce:t=>1-ob(1-t),Elastic:t=>t<=0?0:t>=1?1:-(2**(10*t-10))*Math.sin((t*10-10.75)*(2*Math.PI/3))};
const ease=(st,dr,t)=>{const f=EIN[st]||EIN.Quad;if(dr=='In')return f(t);if(dr=='InOut')return t<.5?f(2*t)/2:1-f(2-2*t)/2;return 1-f(1-t)};
const lerp=(a,b,t)=>{if(typeof a=='number'&&typeof b=='number')return a+(b-a)*t;if(a instanceof LU&&b instanceof LU)return new LU(a.p.map((x,i)=>x+(b.p[i]-x)*t));
 if(a instanceof LC&&b instanceof LC)return new LC(a.r+(b.r-a.r)*t,a.g+(b.g-a.g)*t,a.b+(b.b-a.b)*t);if(a instanceof LV&&b instanceof LV)return new LV(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t);return b};
class TInfo{constructor(t,st,dr,rc,rv,dl){this.t=Math.max(0,+t||1);this.st=String(st||'Quad').replace(/^Enum\.EasingStyle\./,'');this.dr=String(dr||'Out').replace(/^Enum\.EasingDirection\./,'');this.rc=Math.max(0,Math.floor(+rc||0));this.rv=!!rv;this.dl=Math.max(0,+dl||0)}
 $g(k){return{Time:this.t,EasingStyle:this.st,EasingDirection:this.dr,RepeatCount:this.rc,Reverses:this.rv,DelayTime:this.dl}[k]}}
class TweenW{constructor(inst,info,goals){this.inst=inst;this.info=info;this.goals=goals;this.done=new Sig();this.raf=0;this.state='Begin'}
 $g(k){switch(k){case'Play':return()=>this.play();case'Cancel':case'Pause':return()=>this.stop();case'Completed':return this.done;case'PlaybackState':return this.state;case'Instance':return this.inst}}
 stop(){if(this.raf)cancelAnimationFrame(this.raf);this.raf=0;if(this.state=='Playing')this.state='Cancelled'}
 play(){this.stop();const inf=this.info,from=new Map(),to=new Map();
  if(this.goals&&this.goals.h)for(const[k,v]of this.goals.h){let f;try{f=this.inst.$g(k)}catch(e){}if(f!==undefined){from.set(k,f);to.set(k,v)}}
  const dur=Math.max(.001,inf.t)*1000,cyc=inf.rv?dur*2:dur,total=cyc*(inf.rc+1),t0=performance.now()+inf.dl*1000;this.state='Playing';
  const step=now=>{if(this.state!=='Playing')return;if(typeof RT==='undefined'||!RT||!RT.alive){this.state='Cancelled';return}
   const el=now-t0;if(el<0){this.raf=requestAnimationFrame(step);return}
   const fin=el>=total;let u;if(fin)u=inf.rv?0:1;else{u=(el%cyc)/dur;if(u>1)u=2-u}
   const e=ease(inf.st,inf.dr,Math.max(0,Math.min(1,u)));for(const[k,b]of to){try{this.inst.$s(k,lerp(from.get(k),b,e))}catch(x){}}
   if(fin){this.raf=0;this.state='Completed';this.done.fire('Completed')}else this.raf=requestAnimationFrame(step)};
  this.raf=requestAnimationFrame(step)}}
G.set('TweenInfo',mkT({new:(t,st,dr,rc,rv,dl)=>new TInfo(t,st,dr,rc,rv,dl)}));
window.mkTweenSvc=()=>new FW('TweenService',()=>[],{Create:(s,inst,info,goals)=>new TweenW(inst,info instanceof TInfo?info:new TInfo(1),goals)});

/* ---------- Voice chat: WebRTC mesh, signaling lewat presence room Firebase ---------- */
const ICE={iceServers:[{urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302']}]};
window.mkVoice=function(env){
 const S={on:0,muted:0,stream:null,room:null,id:'',pcs:{},sig:{},aud:{},an:{},sp:new Set(),tm:0,sp_t:0};let ac=null;
 const nonce=()=>Math.random().toString(36).slice(2,9),say=m=>{try{env.toast&&env.toast(m)}catch(e){}},chg=()=>{try{env.onChange&&env.onChange(api)}catch(e){}};
 const roomNow=()=>{try{return env.room()}catch(e){return null}};
 const pushSig=()=>{const r=S.room;if(r)try{r.presence({vs:Object.assign({},S.sig)})}catch(e){}};
 const gather=pc=>new Promise(res=>{if(pc.iceGatheringState==='complete')return res();const f=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',f);res()}};pc.addEventListener('icegatheringstatechange',f);setTimeout(res,2000)});
 function close(pid){const e=S.pcs[pid];if(e){e.dead=1;try{e.pc.ontrack=null;e.pc.onconnectionstatechange=null;e.pc.close()}catch(x){}}delete S.pcs[pid];
  const a=S.aud[pid];if(a){try{a.pause();a.srcObject=null;a.remove()}catch(x){}delete S.aud[pid]}
  if(S.an[pid]){try{S.an[pid].src.disconnect()}catch(x){}delete S.an[pid]}S.sp.delete(pid);if(pid in S.sig){delete S.sig[pid];pushSig()}}
 function watch(id,st){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state==='suspended')ac.resume();const src=ac.createMediaStreamSource(st),an=ac.createAnalyser();an.fftSize=256;src.connect(an);S.an[id]={src,an,buf:new Uint8Array(an.fftSize),last:0}}catch(x){}}
 function speak(){const now=Date.now();let ch=0;for(const id in S.an){const o=S.an[id];try{o.an.getByteTimeDomainData(o.buf)}catch(x){continue}let m=0;for(let i=0;i<o.buf.length;i++){const v=Math.abs(o.buf[i]-128);if(v>m)m=v}if(m>6)o.last=now;const sp=now-o.last<350;if(sp!==S.sp.has(id)){sp?S.sp.add(id):S.sp.delete(id);ch=1}}if(ch)chg()}
 function attach(pid,st){let a=S.aud[pid];if(!a){a=document.createElement('audio');a.autoplay=true;a.playsInline=true;a.style.display='none';(env.audioParent||document.body).appendChild(a);S.aud[pid]=a}a.srcObject=st;a.play&&a.play().catch(()=>{});if(S.an[pid]){try{S.an[pid].src.disconnect()}catch(x){}delete S.an[pid]}watch(pid,st);chg()}
 function newPc(pid,n,role){const pc=new RTCPeerConnection(ICE),e={pc,n,role,t:Date.now(),ok:0,dead:0,badAt:0,ans:0};S.pcs[pid]=e;
  pc.ontrack=ev=>attach(pid,(ev.streams&&ev.streams[0])||new MediaStream([ev.track]));
  pc.onconnectionstatechange=()=>{const s=pc.connectionState;
   if(s==='connected'){e.ok=1;e.badAt=0;setTimeout(()=>{if(S.pcs[pid]===e&&S.sig[pid]&&S.sig[pid].n===n){delete S.sig[pid];pushSig()}},2500);chg()}
   else if(s==='failed'||s==='closed')e.dead=1;else if(s==='disconnected')e.badAt=e.badAt||Date.now()}
  return e}
 function addLocal(pc){const tr=S.stream&&S.stream.getAudioTracks()[0],free=pc.getTransceivers().find(t=>!t.sender.track&&t.receiver&&t.receiver.track&&t.receiver.track.kind==='audio');
  if(tr){if(free){free.direction='sendrecv';free.sender.replaceTrack(tr);try{free.sender.setStreams(S.stream)}catch(x){}}else pc.addTrack(tr,S.stream)}
  else if(free)free.direction='recvonly';else pc.addTransceiver('audio',{direction:'recvonly'})}
 async function offer(pid){const n=nonce(),e=newPc(pid,n,'o');try{addLocal(e.pc);const o=await e.pc.createOffer();await e.pc.setLocalDescription(o);await gather(e.pc);if(e.dead||S.pcs[pid]!==e)return;S.sig[pid]={k:'o',n,s:e.pc.localDescription.sdp};pushSig()}catch(x){e.dead=1}}
 async function accept(pid,sg){close(pid);const e=newPc(pid,sg.n,'a');try{await e.pc.setRemoteDescription({type:'offer',sdp:sg.s});addLocal(e.pc);const a=await e.pc.createAnswer();await e.pc.setLocalDescription(a);await gather(e.pc);if(e.dead||S.pcs[pid]!==e)return;S.sig[pid]={k:'a',n:sg.n,s:e.pc.localDescription.sdp};pushSig()}catch(x){e.dead=1}}
 function tick(){if(!S.on)return;const r=roomNow();if(!r)return;let ps;try{ps=r.peers()}catch(x){return}const mine=ps.find(p=>p.isMe);if(!mine)return;
  if(S.room!==r||S.id!==mine.peer){Object.keys(S.pcs).forEach(close);S.sig={};S.room=r;S.id=mine.peer;try{r.presence({vc:1,vm:S.muted?1:0,vs:{}})}catch(x){}}
  const live=new Set(),now=Date.now();
  ps.forEach(p=>{if(p.isMe||!p.presence||p.presence.vc!==1)return;const pid=p.peer;live.add(pid);const sg=(p.presence.vs||{})[S.id];let e=S.pcs[pid];
   if(e&&(e.dead||(!e.ok&&now-e.t>25000)||(e.badAt&&now-e.badAt>6000))){close(pid);e=null}
   if(S.id<pid){if(!e)offer(pid);else if(e.role==='o'&&!e.ans&&sg&&sg.k==='a'&&sg.n===e.n){e.ans=1;e.pc.setRemoteDescription({type:'answer',sdp:sg.s}).catch(()=>{e.dead=1})}}
   else if(sg&&sg.k==='o'&&(!e||e.n!==sg.n))accept(pid,sg)});
  Object.keys(S.pcs).forEach(pid=>{if(!live.has(pid))close(pid)})}
 async function join(){if(S.on)return true;const r=roomNow();if(!r){say('Voice chat hanya di mode online (Mabar)');return false}
  if(!navigator.mediaDevices||!window.RTCPeerConnection){say('Browser tidak mendukung voice chat');return false}
  try{S.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}})}catch(x){S.stream=null;say('Mikrofon tidak diizinkan, kamu masuk sebagai pendengar')}
  S.on=1;S.muted=0;S.room=null;S.id='';if(S.stream)watch('_me',S.stream);S.tm=setInterval(tick,1000);S.sp_t=setInterval(speak,150);tick();chg();return true}
 function leave(){if(!S.on)return;S.on=0;clearInterval(S.tm);clearInterval(S.sp_t);const r=S.room||roomNow();Object.keys(S.pcs).forEach(close);S.sig={};
  if(S.stream){S.stream.getTracks().forEach(t=>{try{t.stop()}catch(x){}})}S.stream=null;for(const id in S.an){try{S.an[id].src.disconnect()}catch(x){}}S.an={};S.sp.clear();
  try{r&&r.presence({vc:0,vm:0,vs:{}})}catch(x){}S.room=null;chg()}
 function mute(m){S.muted=m===undefined?!S.muted:!!m;if(S.stream)S.stream.getAudioTracks().forEach(t=>t.enabled=!S.muted);const r=S.room;try{r&&r.presence({vm:S.muted?1:0})}catch(x){}chg()}
 const api={join,leave,mute,tick,
  get on(){return!!S.on},get muted(){return!!S.muted},get hasMic(){return!!S.stream},
  state(){const o={};for(const k in S.pcs)o[k]={ok:S.pcs[k].ok,role:S.pcs[k].role,tracks:S.aud[k]&&S.aud[k].srcObject?S.aud[k].srcObject.getAudioTracks().length:0};return{id:S.id,peers:o,speaking:[...S.sp]}},
  speakers(){const r=S.room||roomNow();let ps=[];try{ps=r?r.peers():[]}catch(x){}const names=[];S.sp.forEach(id=>{if(id==='_me')names.push('Kamu');else{const p=ps.find(q=>q.peer===id);names.push((p&&p.presence&&p.presence.n)||'Pemain')}});return names}};
 return api};

/* ---------- Voice: tombol mic di HUD game ---------- */
const MIC={off:'<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/><path d="M4 4l16 16" stroke="#ff4040"/></svg>',
 on:'<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg>',
 mute:'<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/><path d="M4 4l16 16" stroke="#ff4040"/></svg>'};
const gameEl=document.getElementById('game')||document.body;
gameEl.insertAdjacentHTML('beforeend','<div id="vcs"></div>');
const micBtn=()=>document.querySelector('#topl .rpill button[data-a=mic]');
function ui(v){const b=micBtn();if(b){const keep='<i id="camb" style="display:none"></i>';b.innerHTML=(!v.on?MIC.off:v.muted?MIC.mute:MIC.on)+keep;b.classList.toggle('vcon',v.on&&!v.muted);b.title=!v.on?'Voice chat':v.muted?'Mic mati (tap untuk nyalakan)':'Mic menyala (tap untuk mute, tahan untuk keluar)'}
 const el=document.getElementById('vcs');if(el){const n=v.on?v.speakers():[];el.style.display=n.length?'block':'none';el.textContent=n.length?'🔊 '+n.join(', '):''}}
const V=window.spVoice=mkVoice({room:()=>(typeof RM!=='undefined'?RM:null),toast:t=>toast(t),onChange:ui});
act.mic=async()=>{if(!V.on){const ok=await V.join();if(ok)toast(V.hasMic?'Voice aktif · tap = mute, tahan = keluar':'Voice aktif sebagai pendengar')}else V.mute()};
{const b=micBtn();if(b){let t=0,lp=0;b.addEventListener('pointerdown',()=>{lp=0;clearTimeout(t);t=setTimeout(()=>{if(V.on){lp=1;V.leave();toast('Keluar dari voice chat')}},650)});
 ['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>clearTimeout(t)));
 b.addEventListener('click',e=>{if(lp){lp=0;e.stopImmediatePropagation();e.preventDefault()}},true)}}
const _sg=stopGame;stopGame=function(){try{V.leave()}catch(e){}return _sg.apply(this,arguments)};
})();
