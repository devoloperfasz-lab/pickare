/* ===== LUAU-SUBSET INTERPRETER (async, mendukung wait/task) ===== */
class LT{constructor(){this.h=new Map();this.mt=null}get(k){return this.h.get(k)}set(k,v){v===undefined?this.h.delete(k):this.h.set(k,v)}len(){let n=0;while(this.h.has(n+1))n++;return n}}
class LV{constructor(x,y,z){this.x=x;this.y=y;this.z=z}$g(k){switch(k){case'X':case'x':return this.x;case'Y':case'y':return this.y;case'Z':case'z':return this.z;case'Magnitude':return Math.hypot(this.x,this.y,this.z);case'Unit':{const m=Math.hypot(this.x,this.y,this.z)||1;return new LV(this.x/m,this.y/m,this.z/m)}}}$str(){return this.x+', '+this.y+', '+this.z}}
let OUT=()=>{};const rerr=e=>{if(!e||!e.kill)OUT('err',e&&e.message||String(e))};
const truthy=v=>v!==undefined&&v!==null&&v!==false;
const tyn=v=>v==null?'nil':typeof v=='boolean'?'boolean':typeof v=='number'?'number':typeof v=='string'?'string':v instanceof LT?'table':typeof v=='function'?'function':'userdata';
const tn=v=>typeof v=='number'?v:typeof v=='string'&&v.trim()!==''&&!isNaN(+v)?+v:null;
function tostr(v){if(v==null)return'nil';if(typeof v=='number')return Number.isInteger(v)?String(v):isFinite(v)?String(+v.toPrecision(14)):isNaN(v)?'nan':v>0?'inf':'-inf';if(typeof v=='string')return v;if(typeof v=='boolean')return String(v);if(v instanceof LT)return'table';if(typeof v=='function')return'function';return v.$str?v.$str():'Instance'}
function arith(op,a,b){if(a instanceof LV||b instanceof LV){const A=a instanceof LV?a:new LV(a,a,a),B=b instanceof LV?b:new LV(b,b,b),f={'+':(p,q)=>p+q,'-':(p,q)=>p-q,'*':(p,q)=>p*q,'/':(p,q)=>p/q}[op];if(!f)throw new Error('operasi vektor tidak valid');return new LV(f(A.x,B.x),f(A.y,B.y),f(A.z,B.z))}
 const x=tn(a),y=tn(b);if(x===null||y===null)throw new Error('mencoba operasi aritmatika "'+op+'" pada '+tyn(a)+' dan '+tyn(b));
 switch(op){case'+':return x+y;case'-':return x-y;case'*':return x*y;case'/':return x/y;case'//':return Math.floor(x/y);case'%':return x-Math.floor(x/y)*y;case'^':return Math.pow(x,y)}}
const cat=(a,b)=>{if((typeof a=='string'||typeof a=='number')&&(typeof b=='string'||typeof b=='number'))return tostr(a)+tostr(b);throw new Error('mencoba menyambung (..) '+tyn(a)+' dan '+tyn(b))};
const eq=(a,b)=>a===b||(a==null&&b==null)||(a instanceof LV&&b instanceof LV&&a.x===b.x&&a.y===b.y&&a.z===b.z);
const lt=(a,b)=>{if(typeof a=='number'&&typeof b=='number'||typeof a=='string'&&typeof b=='string')return a<b;throw new Error('mencoba membandingkan '+tyn(a)+' dengan '+tyn(b))};
function lex(s){const t=[];let i=0,L=1;const E=m=>{throw new Error('baris '+L+': '+m)},KW=new Set('and break do else elseif end false for function if in local nil not or repeat return then true until while continue'.split(' '));
 const OP=['...','..=','==','~=','<=','>=','..','//','+=','-=','*=','/=','%=','^=','+','-','*','/','%','^','#','<','>','=','(',')','{','}','[',']',';',':',',','.'];
 while(i<s.length){const c=s[i];
  if(c=='\n'){L++;i++;continue}if(/\s/.test(c)){i++;continue}
  if(c=='-'&&s[i+1]=='-'){i+=2;const m=/^\[(=*)\[/.exec(s.slice(i));if(m){const e=s.indexOf(']'+m[1]+']',i);if(e<0)E('komentar tidak ditutup');L+=(s.slice(i,e).match(/\n/g)||[]).length;i=e+m[1].length+2}else while(i<s.length&&s[i]!='\n')i++;continue}
  if(/[A-Za-z_]/.test(c)){let j=i;while(j<s.length&&/\w/.test(s[j]))j++;const w=s.slice(i,j);t.push({k:KW.has(w)?w:'name',v:w,l:L});i=j;continue}
  if(/\d/.test(c)||(c=='.'&&/\d/.test(s[i+1]))){const m=/^(0[xX][0-9a-fA-F]+|\d*\.?\d+(?:[eE][+-]?\d+)?)/.exec(s.slice(i));t.push({k:'num',v:Number(m[0]),l:L});i+=m[0].length;continue}
  if(c=='"'||c=="'"){let j=i+1,r='';while(j<s.length&&s[j]!=c){if(s[j]=='\\'){j++;const n=s[j];r+=n=='n'?'\n':n=='t'?'\t':n=='r'?'\r':n=='0'?'\0':n}else{if(s[j]=='\n')E('string tidak ditutup');r+=s[j]}j++}if(j>=s.length)E('string tidak ditutup');t.push({k:'str',v:r,l:L});i=j+1;continue}
  const ms=c=='['?/^\[(=*)\[/.exec(s.slice(i)):null;if(ms){const e=s.indexOf(']'+ms[1]+']',i);if(e<0)E('string tidak ditutup');let v=s.slice(i+ms[0].length,e);if(v[0]=='\n')v=v.slice(1);t.push({k:'str',v,l:L});L+=(s.slice(i,e).match(/\n/g)||[]).length;i=e+ms[1].length+2;continue}
  const op=OP.find(o=>s.startsWith(o,i));if(!op)E('karakter tidak dikenal "'+c+'"');t.push({k:op,v:op,l:L});i+=op.length}
 t.push({k:'eof',l:L});return t}
const BP={'or':[1,1],'and':[2,2],'<':[3,3],'>':[3,3],'<=':[3,3],'>=':[3,3],'~=':[3,3],'==':[3,3],'..':[5,4],'+':[6,6],'-':[6,6],'*':[7,7],'/':[7,7],'//':[7,7],'%':[7,7],'^':[10,9]};
function parse(src){const T=lex(src);let p=0;const END=['end','else','elseif','until','eof'],ck=k=>T[p].k==k,ac=k=>T[p].k==k?(p++,true):false,nx=()=>T[p++],
 ex=k=>{if(T[p].k!=k)throw new Error('baris '+T[p].l+': diharapkan "'+k+'" dekat "'+(T[p].v??T[p].k)+'"');return T[p++]},nm=()=>ex('name').v,exl=()=>{const a=[expr()];while(ac(','))a.push(expr());return a};
 function block(){const b=[];while(!END.includes(T[p].k)){const s=stat();if(s){b.push(s);if(s.t=='ret'||s.t=='brk'||s.t=='cont')break}}return b}
 function stat(){const l=T[p].l,n=st0();if(n)n.l=l;return n}
 function st0(){const k=T[p].k;
  if(k==';'){p++;return null}
  if(k=='if'){p++;const cs=[];let c=expr();ex('then');cs.push([c,block()]);let el=null;while(ac('elseif')){c=expr();ex('then');cs.push([c,block()])}if(ac('else'))el=block();ex('end');return{t:'if',cs,el}}
  if(k=='while'){p++;const c=expr();ex('do');const b=block();ex('end');return{t:'wh',c,b}}
  if(k=='do'){p++;const b=block();ex('end');return{t:'do',b}}
  if(k=='for'){p++;const n=nm();if(ac('=')){const a=expr();ex(',');const b=expr(),c=ac(',')?expr():null;ex('do');const body=block();ex('end');return{t:'fnum',n,a,b,c,body}}const ns=[n];while(ac(','))ns.push(nm());ex('in');const es=exl();ex('do');const body=block();ex('end');return{t:'fin',ns,es,body}}
  if(k=='repeat'){p++;const b=block();ex('until');return{t:'rep',b,c:expr()}}
  if(k=='function'){p++;const path=[nm()];let meth=null;while(ac('.'))path.push(nm());if(ac(':'))meth=nm();return{t:'fdef',path,meth,f:fb(!!meth)}}
  if(k=='local'){p++;if(ac('function')){const n=nm();return{t:'lfn',n,f:fb(false)}}const ns=[nm()];while(ac(','))ns.push(nm());const es=ac('=')?exl():[];return{t:'loc',ns,es}}
  if(k=='return'){p++;const es=END.includes(T[p].k)||ck(';')?[]:exl();ac(';');return{t:'ret',es}}
  if(k=='break'){p++;return{t:'brk'}}if(k=='continue'){p++;return{t:'cont'}}
  const e=suf(),k2=T[p].k;
  if(['+=','-=','*=','/=','%=','^=','..='].includes(k2)){p++;return{t:'cas',op:k2.slice(0,-1),tg:e,v:expr()}}
  if(k2=='='||k2==','){const tg=[e];while(ac(','))tg.push(suf());ex('=');return{t:'asg',tg,es:exl()}}
  if(e.t!='call'&&e.t!='mcall')throw new Error('baris '+T[p].l+': sintaks tidak valid dekat "'+(T[p].v??T[p].k)+'"');return{t:'ex',e}}
 function fb(self){ex('(');const ps=self?['self']:[];let va=false;while(!ck(')')){if(ac('...')){va=true;break}ps.push(nm());if(!ac(','))break}ex(')');const body=block();ex('end');return{ps,va,body}}
 function prim(){const t=T[p];if(t.k=='name'){p++;return{t:'var',n:t.v}}if(t.k=='('){p++;const e=expr();ex(')');return{t:'par',e}}throw new Error('baris '+t.l+': token tidak terduga "'+(t.v??t.k)+'"')}
 function suf(){let e=prim();for(;;){const k=T[p].k,l=T[p].l;
  if(k=='.'){p++;e={t:'idx',o:e,k:{t:'str',v:nm()}}}
  else if(k=='['){p++;const i=expr();ex(']');e={t:'idx',o:e,k:i}}
  else if(k==':'){p++;const n=nm();e={t:'mcall',o:e,n,a:args(),l}}
  else if(k=='('||k=='str'||k=='{')e={t:'call',f:e,a:args(),l};else return e}}
 function args(){if(ac('(')){const a=ck(')')?[]:exl();ex(')');return a}if(ck('str'))return[{t:'str',v:nx().v}];return[tb()]}
 function tb(){ex('{');const f=[];while(!ck('}')){if(ck('[')){p++;const k=expr();ex(']');ex('=');f.push({k,v:expr()})}else if(ck('name')&&T[p+1].k=='='){const k={t:'str',v:nm()};p++;f.push({k,v:expr()})}else f.push({v:expr()});if(!ac(',')&&!ac(';'))break}ex('}');return{t:'tbl',f}}
 function simple(){const t=T[p];switch(t.k){case'num':case'str':p++;return{t:t.k,v:t.v};case'nil':p++;return{t:'nil'};case'true':p++;return{t:'true'};case'false':p++;return{t:'false'};case'...':p++;return{t:'va'};case'function':p++;return{t:'fn',f:fb(false)};case'{':return tb();case'if':{p++;const c=expr();ex('then');const a=expr();ex('else');return{t:'ife',c,a,b:expr()}}}return suf()}
 function expr(lim=0){let l;const k=T[p].k;if(k=='not'||k=='-'||k=='#'){p++;l={t:'un',op:k,e:expr(8)}}else l=simple();
  for(;;){const o=T[p].k,b=BP[o];if(!b||b[0]<=lim)break;p++;l={t:'bin',op:o,a:l,b:expr(b[1])}}return l}
 const body=block();ex('eof');return body}
function idx(o,k){if(o instanceof LT){let v=o.h.get(k);if(v===undefined&&o.mt){const m=o.mt.get('__index');if(m instanceof LT)return idx(m,k)}return v}
 if(typeof o=='string')return STR.get(k);if(o&&o.$g)return o.$g(k);throw new Error('mencoba mengindeks '+tyn(o)+' dengan "'+tostr(k)+'"')}
function setidx(o,k,v){if(o instanceof LT)return o.set(k,v);if(o&&o.$s)return o.$s(k,v);throw new Error('mencoba mengubah properti "'+tostr(k)+'" pada '+tyn(o))}
async function call(f,a){if(typeof f=='function'){const r=await f(...a);return r==null?[]:Array.isArray(r)?r:[r]}if(f instanceof LT&&f.mt&&f.mt.get('__call'))return call(f.mt.get('__call'),[f,...a]);throw new Error('mencoba memanggil nilai '+tyn(f))}
let OPS=0;
async function xb(b,s){for(const st of b){if(++OPS%2500==0)await new Promise(r=>setTimeout(r,0));if(s.$rt&&!s.$rt.alive)throw Object.assign(new Error('dihentikan'),{kill:1});
 try{const r=await xs(st,s);if(r)return r}catch(e){if(e&&!e.ln&&!e.kill){e.ln=st.l;e.message='baris '+st.l+': '+e.message}throw e}}}
function setv(s,n,v){for(let c=s;c;c=Object.getPrototypeOf(c))if(Object.hasOwn(c,n)){c[n]=v;return}G.set(n,v)}
async function asg(tg,v,s){if(tg.t=='var')setv(s,tg.n,v);else if(tg.t=='idx')setidx(await ev(tg.o,s),await ev(tg.k,s),v);else throw new Error('target tidak valid')}
function mkf(f,s){return async(...a)=>{const e=Object.create(s);f.ps.forEach((p,i)=>e[p]=a[i]);if(f.va)e['...']=a.slice(f.ps.length);const r=await xb(f.body,e);return r&&r.ret?r.ret:[]}}
async function evl(es,s){const r=[];for(let i=0;i<es.length;i++){const e=es[i],last=i==es.length-1;if(last&&(e.t=='call'||e.t=='mcall'))r.push(...await evm(e,s));else if(last&&e.t=='va')r.push(...(s['...']||[]));else r.push(await ev(e,s))}return r}
async function evm(n,s){if(n.t=='call'){const f=await ev(n.f,s);if(f==null)throw new Error('mencoba memanggil nilai nil'+(n.f.t=='var'?' ("'+n.f.n+'")':n.f.t=='idx'&&n.f.k.t=='str'?' ("'+n.f.k.v+'")':''));return call(f,await evl(n.a,s))}
 const o=await ev(n.o,s),f=idx(o,n.n);if(f==null)throw new Error('"'+n.n+'" bukan method/properti dari '+tyn(o));return call(f,[o,...await evl(n.a,s)])}
async function ev(n,s){switch(n.t){
 case'num':case'str':return n.v;case'nil':return;case'true':return true;case'false':return false;case'va':return(s['...']||[])[0];
 case'var':return n.n in s?s[n.n]:G.get(n.n);case'par':return ev(n.e,s);
 case'idx':return idx(await ev(n.o,s),await ev(n.k,s));
 case'call':case'mcall':return(await evm(n,s))[0];case'fn':return mkf(n.f,s);
 case'ife':return truthy(await ev(n.c,s))?ev(n.a,s):ev(n.b,s);
 case'tbl':{const t=new LT();let i=1;for(let j=0;j<n.f.length;j++){const f=n.f[j];if(f.k)t.set(await ev(f.k,s),await ev(f.v,s));else if(j==n.f.length-1&&(f.v.t=='call'||f.v.t=='mcall'||f.v.t=='va')){(f.v.t=='va'?(s['...']||[]):await evm(f.v,s)).forEach(x=>t.set(i++,x))}else t.set(i++,await ev(f.v,s))}return t}
 case'un':{const v=await ev(n.e,s);if(n.op=='not')return!truthy(v);if(n.op=='-'){if(v instanceof LV)return new LV(-v.x,-v.y,-v.z);const x=tn(v);if(x===null)throw new Error('mencoba negasi pada '+tyn(v));return-x}if(typeof v=='string')return v.length;if(v instanceof LT)return v.len();throw new Error('mencoba mengukur '+tyn(v))}
 case'bin':{if(n.op=='and'){const a=await ev(n.a,s);return truthy(a)?ev(n.b,s):a}if(n.op=='or'){const a=await ev(n.a,s);return truthy(a)?a:ev(n.b,s)}
  const a=await ev(n.a,s),b=await ev(n.b,s);switch(n.op){case'==':return eq(a,b);case'~=':return!eq(a,b);case'<':return lt(a,b);case'>':return lt(b,a);case'<=':return!lt(b,a);case'>=':return!lt(a,b);case'..':return cat(a,b);default:return arith(n.op,a,b)}}}
 throw new Error('node tidak dikenal '+n.t)}
async function xs(n,s){switch(n.t){
 case'ex':await evm(n.e,s);return;
 case'loc':{const v=await evl(n.es,s);n.ns.forEach((x,i)=>s[x]=v[i]);return}
 case'lfn':s[n.n]=undefined;s[n.n]=mkf(n.f,s);return;
 case'asg':{const v=await evl(n.es,s);for(let i=0;i<n.tg.length;i++)await asg(n.tg[i],v[i],s);return}
 case'cas':{const c=await ev(n.tg,s),v=await ev(n.v,s);await asg(n.tg,n.op=='..'?cat(c,v):arith(n.op,c,v),s);return}
 case'fdef':{let t={t:'var',n:n.path[0]};for(let i=1;i<n.path.length;i++)t={t:'idx',o:t,k:{t:'str',v:n.path[i]}};if(n.meth)t={t:'idx',o:t,k:{t:'str',v:n.meth}};await asg(t,mkf(n.f,s),s);return}
 case'if':{for(const[c,b]of n.cs)if(truthy(await ev(c,s)))return xb(b,Object.create(s));if(n.el)return xb(n.el,Object.create(s));return}
 case'do':return xb(n.b,Object.create(s));
 case'wh':while(truthy(await ev(n.c,s))){const r=await xb(n.b,Object.create(s));if(r){if(r.brk)break;if(r.cont)continue;return r}}return;
 case'rep':for(;;){const e=Object.create(s),r=await xb(n.b,e);if(r){if(r.brk)break;if(!r.cont)return r}if(truthy(await ev(n.c,e)))break}return;
 case'fnum':{const a=tn(await ev(n.a,s)),b=tn(await ev(n.b,s)),c=n.c?tn(await ev(n.c,s)):1;if(a===null||b===null||!c)throw new Error("'for' butuh angka");
  for(let i=a;c>0?i<=b:i>=b;i+=c){const e=Object.create(s);e[n.n]=i;const r=await xb(n.body,e);if(r){if(r.brk)break;if(r.cont)continue;return r}}return}
 case'fin':{let[f,st,ctl]=await evl(n.es,s);if(f instanceof LT)[f,st]=G.get('pairs')(f);
  for(;;){const v=await call(f,[st,ctl]);if(v[0]===undefined)break;ctl=v[0];const e=Object.create(s);n.ns.forEach((x,i)=>e[x]=v[i]);const r=await xb(n.body,e);if(r){if(r.brk)break;if(r.cont)continue;return r}}return}
 case'ret':return{ret:await evl(n.es,s)};case'brk':return{brk:1};case'cont':return{cont:1}}
 throw new Error('statement tidak dikenal '+n.t)}
/* ---- library ---- */
const mkT=o=>{const t=new LT();for(const k in o)t.set(k,o[k]);return t},sleep=ms=>new Promise(r=>setTimeout(r,ms));
function lpat(p){let r='',i=0;const C={a:'A-Za-z',d:'0-9',s:'\\s',w:'A-Za-z0-9',l:'a-z',u:'A-Z',p:'!-\\/:-@\\[-`{-~',x:'0-9A-Fa-f'};
 while(i<p.length){const c=p[i];
  if(c=='%'){const n=p[++i],k=n.toLowerCase();r+=C[k]?(n==k?'['+C[k]+']':'[^'+C[k]+']'):'\\'+n;i++}
  else if(c=='['){let j=i+1,q='[';if(p[j]=='^'){q+='^';j++}if(p[j]==']'){q+='\\]';j++}while(j<p.length&&p[j]!=']'){if(p[j]=='%'){j++;const n=p[j],k=n.toLowerCase();q+=C[k]?(n==k?C[k]:''):'\\'+n}else q+=p[j]=='\\'?'\\\\':p[j];j++}r+=q+']';i=j+1}
  else if(c=='-'){r+='*?';i++}else if('\\|{}/'.includes(c)){r+='\\'+c;i++}else{r+=c;i++}}return r}
function fmt(f,a){let i=0;return f.replace(/%([-+ 0#]*)(\d+)?(?:\.(\d+))?([dioxXfgGeEsqc%])/g,(m,fl,w,pr,c)=>{if(c=='%')return'%';const v=a[i++];let r;switch(c){case'd':case'i':r=String(Math.trunc(tn(v)));break;case'f':r=tn(v).toFixed(pr===undefined?6:+pr);break;case'x':r=(tn(v)>>>0).toString(16);break;case'X':r=(tn(v)>>>0).toString(16).toUpperCase();break;case'g':case'G':r=String(+tn(v).toPrecision(pr?+pr:6));break;case'e':case'E':r=tn(v).toExponential(pr===undefined?6:+pr);break;case'c':r=String.fromCharCode(tn(v));break;case'q':r=JSON.stringify(String(v));break;default:r=tostr(v)}
 if(pr!==undefined&&c=='s')r=r.slice(0,+pr);if(w)r=fl.includes('-')?r.padEnd(+w):r.padStart(+w,fl.includes('0')&&c!='s'?'0':' ');return r})}
const sidx=(s,i,d)=>i===undefined?d:i<0?Math.max(0,s.length+i+1):i;
const STR=mkT({len:s=>s.length,upper:s=>s.toUpperCase(),lower:s=>s.toLowerCase(),rep:(s,n,sep)=>Array(Math.max(0,n)).fill(s).join(sep||''),reverse:s=>[...s].reverse().join(''),
 sub:(s,i,j)=>{i=sidx(s,i,1);j=j===undefined?s.length:j<0?s.length+j+1:j;return s.slice(Math.max(0,i-1),Math.max(0,j))},format:(f,...a)=>fmt(f,a),byte:(s,i)=>s.charCodeAt((i||1)-1),char:(...a)=>String.fromCharCode(...a),
 find:(s,p,i,pl)=>{i=sidx(s,i,1);if(pl===true){const k=s.indexOf(p,i-1);return k<0?undefined:[k+1,k+p.length]}const m=new RegExp(lpat(p)).exec(s.slice(i-1));return m?[m.index+i,m.index+i-1+m[0].length,...m.slice(1)]:undefined},
 match:(s,p,i)=>{const m=new RegExp(lpat(p)).exec(s.slice(sidx(s,i,1)-1));return m?(m.length>1?m.slice(1):m[0]):undefined},
 gmatch:(s,p)=>{const ms=[...s.matchAll(new RegExp(lpat(p),'g'))];let j=0;return()=>{const m=ms[j++];return m?(m.length>1?m.slice(1):m[0]):undefined}},
 gsub:async(s,p,r,n)=>{const ms=[...s.matchAll(new RegExp(lpat(p),'g'))].slice(0,n||1e9);let o='',last=0;for(const m of ms){o+=s.slice(last,m.index);let v;if(typeof r=='string')v=r.replace(/%(\d)/g,(_,d)=>d=='0'?m[0]:m[+d]);else if(r instanceof LT)v=r.get(m[1]??m[0]);else v=(await call(r,m.length>1?m.slice(1):[m[0]]))[0];o+=v===undefined||v===false?m[0]:tostr(v);last=m.index+m[0].length}return[o+s.slice(last),ms.length]}});
async function msort(a,c){if(a.length<2)return a;const m=a.length>>1,l=await msort(a.slice(0,m),c),r=await msort(a.slice(m),c),o=[];let i=0,j=0;while(i<l.length&&j<r.length){const less=c?truthy((await call(c,[r[j],l[i]]))[0]):lt(r[j],l[i]);if(less)o.push(r[j++]);else o.push(l[i++])}return o.concat(l.slice(i),r.slice(j))}
const arr=t=>{const a=[];for(let i=1;t.h.has(i);i++)a.push(t.h.get(i));return a};
const MATH=mkT({floor:Math.floor,ceil:Math.ceil,abs:Math.abs,sqrt:Math.sqrt,sin:Math.sin,cos:Math.cos,tan:Math.tan,asin:Math.asin,acos:Math.acos,atan:Math.atan,atan2:Math.atan2,exp:Math.exp,log:(x,b)=>b?Math.log(x)/Math.log(b):Math.log(x),pow:Math.pow,min:Math.min,max:Math.max,pi:Math.PI,huge:Infinity,
 random:(m,n)=>m===undefined?Math.random():n===undefined?1+Math.floor(Math.random()*m):m+Math.floor(Math.random()*(n-m+1)),randomseed:()=>{},clamp:(x,a,b)=>Math.min(b,Math.max(a,x)),round:x=>Math.round(x),sign:x=>Math.sign(x),deg:x=>x*180/Math.PI,rad:x=>x*Math.PI/180,fmod:(a,b)=>a%b,noise:()=>0});
const wait=async t=>{const a=performance.now();await sleep((+t||.03)*1000);return[(performance.now()-a)/1000]},spawn=(f,...a)=>{call(f,a).catch(rerr)};
const G=mkT({print:(...a)=>{OUT('print',a.map(tostr).join('\t'))},warn:(...a)=>{OUT('warn',a.map(tostr).join(' '))},type:tyn,tostring:tostr,
 tonumber:(v,b)=>{if(typeof v=='number')return v;if(typeof v!='string')return;const x=b?parseInt(v,b):tn(v.trim().toLowerCase().startsWith('0x')?String(parseInt(v,16)):v);return x===null||isNaN(x)?undefined:x},
 pairs:t=>{if(!(t instanceof LT))throw new Error('pairs butuh tabel');const ks=[];let n=t.len();for(let i=1;i<=n;i++)ks.push(i);for(const k of t.h.keys())if(!(Number.isInteger(k)&&k>=1&&k<=n))ks.push(k);let j=0;return[()=>{while(j<ks.length){const k=ks[j++],v=t.h.get(k);if(v!==undefined)return[k,v]}return[undefined]},t]},
 ipairs:t=>{let i=0;return[()=>{i++;const v=t.get(i);return v===undefined?[undefined]:[i,v]},t]},
 next:(t,k)=>{const ks=[...t.h.keys()],i=k===undefined?0:ks.indexOf(k)+1;return i<ks.length?[ks[i],t.h.get(ks[i])]:undefined},
 select:(n,...a)=>n=='#'?a.length:a.slice(n-1),unpack:(t,i,j)=>arr(t).slice((i||1)-1,j),
 setmetatable:(t,m)=>{t.mt=m;return t},getmetatable:t=>t.mt,rawget:(t,k)=>t.get(k),rawset:(t,k,v)=>{t.set(k,v);return t},
 pcall:async(f,...a)=>{try{return[true,...await call(f,a)]}catch(e){if(e&&e.kill)throw e;return[false,e&&e.message||String(e)]}},
 error:m=>{throw new Error(tostr(m))},assert:(v,m)=>{if(!truthy(v))throw new Error(m===undefined?'assertion failed!':tostr(m));return v},
 string:STR,math:MATH,
 table:mkT({insert:(t,a,b)=>{if(b===undefined)t.set(t.len()+1,a);else{const n=t.len();for(let i=n;i>=a;i--)t.set(i+1,t.get(i));t.set(a,b)}},remove:(t,i)=>{const n=t.len();if(!n)return;i=i===undefined?n:i;const v=t.get(i);for(let j=i;j<n;j++)t.set(j,t.get(j+1));t.set(n,undefined);return v},
  concat:(t,s,i,j)=>arr(t).slice((i||1)-1,j).map(tostr).join(s||''),unpack:(t,i,j)=>arr(t).slice((i||1)-1,j),getn:t=>t.len(),clear:t=>t.h.clear(),
  sort:async(t,c)=>{const a=await msort(arr(t),c);a.forEach((v,i)=>t.set(i+1,v))},find:(t,v)=>{const i=arr(t).indexOf(v);return i<0?undefined:i+1}}),
 os:mkT({time:()=>Math.floor(Date.now()/1000),clock:()=>performance.now()/1000,date:(f)=>new Date().toLocaleString()}),
 wait,spawn,delay:(t,f,...a)=>{sleep(t*1000).then(()=>call(f,a)).catch(rerr)},
 task:mkT({wait,spawn,defer:spawn,delay:(t,f,...a)=>{sleep(t*1000).then(()=>call(f,a)).catch(rerr)}})});

/* ===== PICKARE STUDIO v3: Explorer service, GUI editor, Script editor, Toolbox, runtime Luau ===== */
class LC{constructor(r,g,b){this.r=r;this.g=g;this.b=b}$g(k){return{R:this.r,G:this.g,B:this.b}[k]}$str(){return this.r+', '+this.g+', '+this.b}}
class LU{constructor(p){this.p=p}$g(k){return k=='X'||k=='Y'?undefined:undefined}$str(){return'{'+this.p.join(', ')+'}'}}
const hexC=h=>new LC(parseInt(h.slice(1,3),16)/255,parseInt(h.slice(3,5),16)/255,parseInt(h.slice(5,7),16)/255),
 cHex=c=>c instanceof LC?'#'+[c.r,c.g,c.b].map(v=>Math.round(Math.max(0,Math.min(1,v))*255).toString(16).padStart(2,'0')).join(''):'#ffffff';
const GN={ScreenGui:1,Frame:1,ScrollingFrame:1,TextLabel:1,TextButton:1,TextBox:1};
const FNT={Lilita:["'Lilita One','Arial Black',sans-serif",400],Gotham:["Inter,'Segoe UI',sans-serif",600],GothamBold:["Inter,'Segoe UI',sans-serif",800],GothamBlack:["Inter,'Segoe UI',sans-serif",900],SourceSans:["'Space Grotesk',system-ui,sans-serif",500],SourceSansBold:["'Space Grotesk',system-ui,sans-serif",700],Arial:["Arial,Helvetica,sans-serif",400],ArialBold:["Arial,Helvetica,sans-serif",700],Cartoon:["Fredoka,'Comic Sans MS',sans-serif",500],Arcade:["'Press Start 2P','Courier New',monospace",400],SciFi:["Orbitron,'Trebuchet MS',sans-serif",700],Bangers:["Bangers,Impact,sans-serif",400],Creepster:["Creepster,Impact,fantasy",400],PermanentMarker:["'Permanent Marker','Comic Sans MS',cursive",400],Pacifico:["Pacifico,'Brush Script MT',cursive",400],Nunito:["Nunito,'Segoe UI',sans-serif",700],Oswald:["Oswald,Impact,sans-serif",500],Merriweather:["Merriweather,Georgia,serif",700],Antique:["Georgia,'Times New Roman',serif",400],Code:["'Roboto Mono','Courier New',monospace",500],Impact:["Impact,'Arial Black',sans-serif",400]},
 FNA={Legacy:'Lilita',GothamMedium:'Gotham',FredokaOne:'Cartoon',LuckiestGuy:'Bangers',Roboto:'Nunito',RobotoMono:'Code',SpecialElite:'Code',Highway:'Oswald',Fantasy:'Creepster',Bodoni:'Merriweather',Garamond:'Merriweather',SourceSansLight:'SourceSans',SourceSansItalic:'SourceSans',Michroma:'SciFi',Jura:'SciFi',TitilliumWeb:'Nunito',Ubuntu:'Nunito',IndieFlower:'PermanentMarker',Kalam:'PermanentMarker',PatrickHand:'PermanentMarker'},
 fnt=k=>FNT[k]||FNT.Lilita,fkey=v=>{v=String(v).replace(/^Enum\.Font\./,'');return FNT[v]?v:FNA[v]||null};
const CL={ScreenGui:'',Frame:'▭',ScrollingFrame:'',TextLabel:'',TextButton:'',TextBox:'',Script:'',LocalScript:'',ModuleScript:'',Folder:'',Team:''};
const CD={ScreenGui:'Wadah semua GUI di layar',Frame:'Kotak/panel',ScrollingFrame:'Panel yang bisa di-scroll',TextLabel:'Teks biasa',TextButton:'Tombol yang bisa diklik',TextBox:'Kolom input teks',Script:'Kode Luau (server)',LocalScript:'Kode Luau (client/GUI)',ModuleScript:'Library, dipakai lewat require()',Folder:'Pengelompok objek',Team:'Tim pemain',part:'Balok',cyl:'Tabung',ball:'Bola',coin:'Koin PickBux',lava:'Lava',spawn:'Titik spawn',finish:'Garis finish'};
const SRC={Script:'-- Script (berjalan saat game dimulai)\nprint("Halo dari Script Pickare!")\n',LocalScript:'-- LocalScript: membuat GUI (panel) lewat script\nlocal Players = game:GetService("Players")\nlocal TweenService = game:GetService("TweenService")\nlocal player = Players.LocalPlayer\n\nlocal gui = Instance.new("ScreenGui")\ngui.Name = "PanelSaya"\ngui.Parent = player.PlayerGui\n\nlocal panel = Instance.new("Frame")\npanel.Size = UDim2.new(0, 260, 0, 190)\npanel.Position = UDim2.new(0.5, 0, 0.5, 0)\npanel.AnchorPoint = Vector2.new(0.5, 0.5)\npanel.BackgroundColor3 = Color3.fromRGB(35, 38, 50)\npanel.Parent = gui\nInstance.new("UICorner", panel).CornerRadius = UDim.new(0, 14)\nInstance.new("UIListLayout", panel).Padding = UDim.new(0, 8)\nInstance.new("UIPadding", panel)\n\nlocal title = Instance.new("TextLabel")\ntitle.Size = UDim2.new(1, 0, 0, 40)\ntitle.BackgroundTransparency = 1\ntitle.Font = Enum.Font.GothamBold\ntitle.TextColor3 = Color3.new(1, 1, 1)\ntitle.TextSize = 18\ntitle.Text = "Halo, " .. player.Name\ntitle.Parent = panel\n\nlocal info = Instance.new("TextLabel")\ninfo.Size = UDim2.new(1, 0, 0, 30)\ninfo.BackgroundTransparency = 1\ninfo.Font = Enum.Font.Gotham\ninfo.TextColor3 = Color3.fromRGB(170, 180, 200)\ninfo.TextSize = 14\ninfo.Text = "UserId: " .. player.UserId\ninfo.Parent = panel\n\nlocal btn = Instance.new("TextButton")\nbtn.Size = UDim2.new(1, 0, 0, 44)\nbtn.BackgroundColor3 = Color3.fromRGB(51, 95, 255)\nbtn.TextColor3 = Color3.new(1, 1, 1)\nbtn.Font = Enum.Font.GothamBold\nbtn.TextSize = 16\nbtn.Text = "Klik aku"\nbtn.Parent = panel\nInstance.new("UICorner", btn).CornerRadius = UDim.new(0, 10)\n\nlocal n = 0\nbtn.MouseButton1Click:Connect(function()\n\tn = n + 1\n\tbtn.Text = "Diklik " .. n .. "x"\n\tTweenService:Create(panel, TweenInfo.new(0.25), {BackgroundColor3 = Color3.fromHSV((n * 0.17) % 1, 0.5, 0.35)}):Play()\nend)\n',ModuleScript:'local M = {}\n\nfunction M.hello(name)\n\treturn "Halo " .. name\nend\n\nreturn M\n'};
const SVC=[['Workspace','',1],['Players','',0],['Lighting','',0],['ReplicatedFirst','',1],['ReplicatedStorage','',1],['ServerScriptService','',1],['ServerStorage','',1],['StarterGui','',1],['StarterPack','',1],['StarterPlayer','',0],['Teams','',1]];
const SKEYS=['Workspace','ReplicatedFirst','ReplicatedStorage','ServerScriptService','ServerStorage','StarterGui','StarterPack','StarterPlayerScripts','Teams'];
const PL={Workspace:['Script'],StarterGui:['ScreenGui','LocalScript','Folder'],ServerScriptService:['Script','ModuleScript','Folder'],ServerStorage:['Script','ModuleScript','Folder'],ReplicatedStorage:['ModuleScript','Folder'],ReplicatedFirst:['LocalScript','ModuleScript'],StarterPlayerScripts:['LocalScript','Folder'],StarterPack:['LocalScript'],Teams:['Team']};
const GUIK=['Frame','ScrollingFrame','TextLabel','TextButton','TextBox','LocalScript'];
let SI=null,guiOn=false,gdr=null,XP={Workspace:1,StarterGui:1,ServerScriptService:1};
function newI(cls){const i={id:nid(),cls,n:cls,ch:[]};
 if(GN[cls]&&cls!='ScreenGui'){const big=cls=='Frame'||cls=='ScrollingFrame';Object.assign(i,{p:[0,30,0,30],s:big?[0,240,0,150]:[0,160,0,50],bg:big?'#ffffff':cls=='TextButton'?'#7df9ff':'#ffde59',bt:big?.3:0,tc:'#000000',ts:18,txt:cls=='TextLabel'?'Label':cls=='TextButton'?'Tombol':'',vis:true,bd:true})}
 if(cls=='ScreenGui')i.vis=true;if(/Script$/.test(cls))i.src=SRC[cls];if(cls=='Team')i.tcol='#ff3b3b';return i}
function ensureSvc(d){d.svc=d.svc||{};SKEYS.forEach(k=>d.svc[k]=d.svc[k]||[])}
const fI=(id,l)=>{for(const i of l){if(i.id==id)return{i,list:l};const r=fI(id,i.ch);if(r)return r}},
 loc=id=>{if(!ST)return;if(ST.d.svc)for(const k in ST.d.svc){const r=fI(id,ST.d.svc[k]);if(r)return r}for(const o of (ST.d.objs||[])){if(o.ch&&o.ch.length){const r=fI(id,o.ch);if(r)return r}}if(ST.d.ch&&ST.d.ch.length){const r=fI(id,ST.d.ch);if(r)return r}};
const tgtList=t=>{if(t==='@acc')return ST.d.ch=ST.d.ch||[];if(ST.d.svc&&ST.d.svc[t])return ST.d.svc[t];const r=loc(t);if(r)return r.i.ch;const o=(ST.d.objs||[]).find(x=>x.id==t);if(o)return o.ch=o.ch||[];return[]};
function pickL(t){let c,k=[];if(PL[t])c=PL[t];else{const r=loc(t);if(!r)return[];const cl=r.i.cls;c=cl=='Folder'?['Folder','Script','LocalScript','ModuleScript']:GN[cl]&&cl!='TextLabel'&&cl!='TextButton'&&cl!='TextBox'?GUIK:[]}
 const o=t=='Workspace'?['part','cyl','ball','lava','spawn','finish'].map(v=>({id:v,k:'obj',n:NM[v],ic:TI[v],d:CD[v]})):[];
 return o.concat(c.map(v=>({id:v,k:'inst',n:v,ic:CL[v],d:CD[v]})))}

/* ---- GUI DOM (dipakai editor & runtime) ---- */
function gSty(i,e){const s=e.style,sg=i.cls=='ScreenGui',tx=i.cls=='TextLabel'||i.cls=='TextButton'||i.cls=='TextBox';
 s.position='absolute';s.boxSizing='border-box';s.margin='0';s.display=i.vis===false?'none':tx?'flex':'block';s.alignItems='center';s.justifyContent=i.ta=='l'?'flex-start':i.ta=='r'?'flex-end':'center';
 if(sg){s.left=s.top='0';s.width=s.height='100%';s.background='transparent';s.border='0';return}
 s.left=`calc(${i.p[0]*100}% + ${i.p[1]}px)`;s.top=`calc(${i.p[2]*100}% + ${i.p[3]}px)`;s.width=`calc(${i.s[0]*100}% + ${i.s[1]}px)`;s.height=`calc(${i.s[2]*100}% + ${i.s[3]}px)`;
 s.background=i.bg+Math.round((1-(i.bt||0))*255).toString(16).padStart(2,'0');s.color=i.tc;s.fontSize=i.ts+'px';s.border=i.bd===false?'0':'3px solid '+(/^#[0-9a-f]{6}$/i.test(i.bc)?i.bc:'#000');s.borderRadius='8px';{const f=fnt(i.f);s.fontFamily=f[0];s.fontWeight=f[1]}s.padding='0 4px';s.overflow=i.cls=='ScrollingFrame'?'auto':i.cl===false?'visible':'hidden';s.textAlign=i.ta=='l'?'left':i.ta=='r'?'right':'center';
 s.zIndex=i.z?String(i.z):'';const ap=i.ap||[0,0];s.transform=(ap[0]||ap[1]||i.rn)?`translate(${-ap[0]*100}%,${-ap[1]*100}%) rotate(${+i.rn||0}deg)`:'';if(e.tagName=='INPUT')e.placeholder=i.ph||''}
function gDom(i,hook,par){const e=document.createElement(i.cls=='TextButton'?'button':i.cls=='TextBox'?'input':'div');e.dataset.gid=i.id;if(i.cls=='ScrollingFrame')e.className='gsc';gSty(i,e);
 if(i.cls=='TextBox')e.value=i.txt||'';else if(i.cls=='TextLabel'||i.cls=='TextButton')e.textContent=i.txt;
 if(hook)hook(i,e,par);(i.ch||[]).forEach(c=>{if(GN[c.cls])e.appendChild(gDom(c,hook,i))});return e}

/* ---- runtime Luau API ---- */
let RT=null;
class Sig{constructor(){this.h=[]}fire(...a){this.h.slice().forEach(f=>call(f,a).catch(rerr))}
 $g(k){if(k=='Connect'||k=='connect')return(s,f)=>{this.h.push(f);const c=new LT();c.set('Disconnect',()=>{this.h=this.h.filter(x=>x!==f)});return c};
  if(k=='Wait')return()=>new Promise(r=>{const f=(...a)=>{this.h=this.h.filter(x=>x!==f);r(a)};this.h.push(f)})}}
const tbl2=l=>{const t=new LT();l.forEach((x,j)=>t.set(j+1,x));return t};
class FW{constructor(n,kf,x){this.n=n;this.kf=kf;this.x=x||{}}
 $g(k){if(k=='Name')return this.n;if(k=='ClassName')return'Folder';if(k=='FindFirstChild'||k=='WaitForChild')return(s,n)=>this.kf().find(c=>c.n==n);if(k=='GetChildren')return()=>tbl2(this.kf());if(k in this.x)return this.x[k];return this.kf().find(c=>c.n==k)}
 $s(k,v){this.x[k]=v}}
class GW{constructor(i,e,par){this.i=i;this.e=e;this.par=par;this.sg={}}get n(){return this.i.n}
 sig(k){return this.sg[k]||(this.sg[k]=new Sig())}kids(){return this.i.ch.map(c=>RT.gw.get(c.id)).filter(Boolean)}
 det(){const p=this.par;if(p instanceof GW){const a=p.i.ch,k=a.indexOf(this.i);if(k>=0)a.splice(k,1)}if(RT)RT.pgk=RT.pgk.filter(x=>x!==this)}
 $g(k){const i=this.i;switch(k){case'Font':return i.f||'Lilita';case'TextXAlignment':return i.ta=='l'?'Left':i.ta=='r'?'Right':'Center';case'BorderSizePixel':return i.bd===false?0:1;case'BorderColor3':return hexC(i.bc||'#000000');case'ZIndex':return i.z||1;case'AnchorPoint':return new LV((i.ap||[0,0])[0],(i.ap||[0,0])[1],0);case'ClipsDescendants':return i.cl!==false;case'PlaceholderText':return i.ph||'';case'Rotation':return +i.rn||0;case'AbsoluteSize':{const r=this.e.getBoundingClientRect();return new LV(r.width,r.height,0)}case'AbsolutePosition':{const r=this.e.getBoundingClientRect();return new LV(r.left,r.top,0)}case'Name':return i.n;case'ClassName':return i.cls;case'Text':return i.cls=='TextBox'?this.e.value:i.txt;case'Visible':case'Enabled':return i.vis!==false;
  case'BackgroundColor3':return hexC(i.bg||'#ffffff');case'TextColor3':return hexC(i.tc||'#000000');case'TextSize':return i.ts;case'BackgroundTransparency':return i.bt||0;case'Position':return new LU(i.p||[0,0,0,0]);case'Size':return new LU(i.s||[0,0,0,0]);case'Parent':return this.par;
  case'MouseButton1Click':case'Activated':return this.sig('click');case'FocusLost':return this.sig('focus');
  case'FindFirstChild':case'WaitForChild':return(s,n)=>this.kids().find(x=>x.i.n==n);case'GetChildren':return()=>tbl2(this.kids());case'Destroy':return()=>{this.det();this.e.remove();if(RT)RT.gw.delete(i.id)}}
  return this.kids().find(x=>x.i.n==k)}
 $s(k,v){const i=this.i;switch(k){case'Font':{const f=fkey(v);if(f)i.f=f;break}case'TextXAlignment':{const a=String(v).replace(/^Enum\.TextXAlignment\./,'');i.ta=a=='Left'?'l':a=='Right'?'r':'c';break}case'BorderSizePixel':i.bd=+v>0;break;case'BorderColor3':i.bc=cHex(v);break;case'ZIndex':i.z=Math.max(0,Math.min(999,+v||0));break;case'AnchorPoint':if(v instanceof LV)i.ap=[v.x,v.y];break;case'ClipsDescendants':i.cl=truthy(v);break;case'PlaceholderText':i.ph=tostr(v);break;case'Rotation':i.rn=+v||0;break;case'Name':i.n=tostr(v);break;case'Text':i.txt=tostr(v);if(this.e.tagName=='INPUT')this.e.value=i.txt;else this.e.textContent=i.txt;break;case'Visible':case'Enabled':i.vis=truthy(v);break;case'BackgroundColor3':i.bg=cHex(v);break;case'TextColor3':i.tc=cHex(v);break;case'TextSize':i.ts=+v;break;case'BackgroundTransparency':i.bt=+v;break;
  case'Position':i.p=v.p.slice();break;case'Size':i.s=v.p.slice();break;
  case'Parent':this.det();if(v instanceof GW){v.e.appendChild(this.e);v.i.ch.push(i);this.par=v}else if(v===RT.pg||(v instanceof FW&&/^(StarterGui|PlayerGui|CoreGui)$/.test(v.n))){RT.gui.appendChild(this.e);RT.pgk.push(this);this.par=RT.pg}else if(v==null){this.e.remove();this.par=null}return;default:return}
  gSty(i,this.e)}}
class PtW{constructor(o,m){this.o=o;this.m=m;this.t=new Sig();this.nm=o.n;this.in=false}get n(){return this.nm}
 $g(k){const m=this.m;switch(k){case'Name':return this.nm;case'ClassName':return'Part';case'Position':return new LV(m.position.x,m.position.y,m.position.z);case'Size':return new LV(m.scale.x,m.scale.y,m.scale.z);case'Color':return hexC(this.col||this.o.c||'#ffffff');case'Transparency':return m.material&&m.material.transparent?1-m.material.opacity:0;case'Touched':return this.t;case'Anchored':return true;case'CanCollide':return this.o.cc!==false;case'Parent':return RT.ws;case'Destroy':return()=>{if(m.parent)m.parent.remove(m)};case'FindFirstChild':return()=>undefined}}
 $s(k,v){const m=this.m;switch(k){case'Name':this.nm=tostr(v);break;case'Position':m.position.set(v.x,v.y,v.z);break;case'Size':m.scale.set(v.x,v.y,v.z);break;case'Color':this.col=cHex(v);m.material.color.set(this.col);break;case'Transparency':m.material.transparent=true;m.material.opacity=1-v;break;case'Parent':if(v===RT.ws){scene.add(m);if(!RT.parts.includes(this))RT.parts.push(this)}else if(v==null&&m.parent)m.parent.remove(m)}}}
class RootW{get n(){return'HumanoidRootPart'}$g(k){switch(k){case'Name':return this.n;case'Position':return new LV(P.x,P.y+1.5,P.z);case'Parent':return RT.ch;case'ClassName':return'Part'}}$s(k,v){if(k=='Position'&&v instanceof LV){P.x=v.x;P.y=v.y-1.5;P.z=v.z;P.vy=0}}}
class HumW{get n(){return'Humanoid'}$g(k){switch(k){case'Name':return this.n;case'Health':return RT.hp;case'MaxHealth':return 100;case'Parent':return RT.ch;case'ClassName':return'Humanoid'}}$s(k,v){if(k=='Health'){RT.hp=+v;if(RT.hp<=0){RT.hp=100;act.respawn()}}}}
class SW{constructor(i,par){this.i=i;this.par=par}get n(){return this.i.n}$g(k){return k=='Name'?this.i.n:k=='ClassName'?this.i.cls:k=='Parent'?this.par:undefined}}
function mkGw(i,e,par){const gw=new GW(i,e,par?RT.gw.get(par.id):RT.pg);RT.gw.set(i.id,gw);e.addEventListener('click',()=>gw.sig('click').fire());if(i.cls=='TextBox')e.addEventListener('blur',()=>gw.sig('focus').fire(true));return gw}
function iW(i){if(RT.iw.has(i.id))return RT.iw.get(i.id);const w=i.cls=='Folder'?new FW(i.n,()=>i.ch.map(iW)):new SW(i,null);RT.iw.set(i.id,w);return w}
async function runSrc(i,par){const s=Object.create(null);s.$rt=RT;s.script=new SW(i,par);return xb(parse(i.src||''),s)}
async function runScript(i,par){try{await runSrc(i,par)}catch(e){if(!e.kill)OUT('err',i.n+' → '+(e.message||e))}}
const MODS=new Map();
G.set('require',async m=>{if(!(m instanceof SW))throw new Error('require butuh ModuleScript');if(MODS.has(m.i)&&MODS.get(m.i).rt===RT)return MODS.get(m.i).v;const r=await runSrc(m.i,m.par);const v=r&&r.ret?r.ret[0]:undefined;MODS.set(m.i,{rt:RT,v});return v});
G.set('Vector3',mkT({new:(x,y,z)=>new LV(+x||0,+y||0,+z||0),zero:new LV(0,0,0),one:new LV(1,1,1)}));
G.set('Color3',mkT({fromRGB:(r,g,b)=>new LC(r/255,g/255,b/255),new:(r,g,b)=>new LC(r||0,g||0,b||0),fromHex:h=>hexC(h)}));
G.set('Vector2',mkT({new:(x,y)=>new LV(+x||0,+y||0,0),zero:new LV(0,0,0),one:new LV(1,1,0)}));
{const fm={};Object.keys(FNT).concat(Object.keys(FNA)).forEach(k=>fm[k]=k);G.set('Enum',mkT({Font:mkT(fm),TextXAlignment:mkT({Left:'Left',Center:'Center',Right:'Right'})}));
 G.get('Color3').set('fromHSV',(h,sa,v)=>{h=((+h||0)%1+1)%1*6;const c=(+v||0)*(+sa||0),x=c*(1-Math.abs(h%2-1)),m=(+v||0)-c,k=Math.floor(h),r=[[c,x,0],[x,c,0],[0,c,x],[0,x,c],[x,0,c],[c,0,x]][k%6];return new LC(r[0]+m,r[1]+m,r[2]+m)})}
G.set('UDim2',mkT({new:(a,b,c,d)=>new LU([a||0,b||0,c||0,d||0]),fromScale:(a,b)=>new LU([a||0,0,b||0,0]),fromOffset:(a,b)=>new LU([0,a||0,0,b||0])}));
G.set('typeof',v=>v instanceof LV?'Vector3':v instanceof LC?'Color3':v instanceof LU?'UDim2':v instanceof Sig?'RBXScriptSignal':v&&v.$g&&!(v instanceof LT)?'Instance':tyn(v));
G.set('Instance',mkT({new:(cls,par)=>{let w;if(GN[cls]){const i=newI(cls);if(i.cls!='ScreenGui'){i.p=[0,0,0,0];if(!/^Image/.test(i.cls)){i.s=[0,100,0,100];i.bg='#ffffff';i.bt=0;i.ts=14;i.txt=i.cls=='TextLabel'?'Label':i.cls=='TextButton'?'Button':''}}w=mkGw(i,gDom(i,mkGw,null),null)}
 else if(cls=='Part'){const o=O('part',0,5,0,4,1,4,'#ffffff');o.n='Part';w=new PtW(o,mkObj(o))}else if(cls=='Folder')w=new FW('Folder',()=>[]);else throw new Error('Instance.new("'+cls+'") belum didukung');
 if(par!==undefined)w.$s('Parent',par);return w}}));
function rtStop(){if(RT){RT.alive=false;if(RT.gui)RT.gui.remove();RT=null}}
function rtStart(g){rtStop();if(!g.svc)return;const sv=g.svc;
 RT={alive:true,gw:new Map(),iw:new Map(),lt:performance.now(),hp:100,hb:new Sig(),pa:new Sig(),svc:{},pgk:[]};const rt=RT;
 const gui=document.createElement('div');gui.id='guir';$('#game').appendChild(gui);RT.gui=gui;RT.pg=new FW('PlayerGui',()=>RT.pgk);
 RT.parts=scene.children.filter(m=>m.userData&&m.userData.o&&m.userData.o.t!='coin').map(m=>new PtW(m.userData.o,m));
 RT.ws=new FW('Workspace',()=>RT.parts.concat((sv.Workspace||[]).map(iW)));RT.root=new RootW();RT.hum=new HumW();RT.ch=new FW(me.name,()=>[RT.root,RT.hum],{HumanoidRootPart:RT.root,Humanoid:RT.hum,Parent:RT.ws});
 RT.pl=new FW(me.name,()=>[RT.pg],{Name:me.name,Character:RT.ch,PlayerGui:RT.pg,UserId:+me.uid||1,DisplayName:me.name,AccountAge:30,CharacterAdded:new Sig()});
 const st=k=>new FW(k,()=>(sv[k]||[]).map(iW));
 RT.svc={Workspace:RT.ws,Players:new FW('Players',()=>[RT.pl],{LocalPlayer:RT.pl,PlayerAdded:RT.pa,GetPlayers:()=>tbl2([RT.pl]),GetPlayerByUserId:(s,id)=>+id===(+me.uid||1)?RT.pl:undefined,GetPlayerFromCharacter:()=>RT.pl,
   GetNameFromUserIdAsync:(s,id)=>Object.keys(users).find(n=>users[n]&&+users[n].uid===+id),GetUserIdFromNameAsync:(s,nm)=>{const k=Object.keys(users).find(n=>n.toLowerCase()===String(nm).toLowerCase());return k?+users[k].uid:undefined}}),
  RunService:new FW('RunService',()=>[],{Heartbeat:RT.hb,RenderStepped:RT.hb,Stepped:RT.hb,IsClient:()=>true,IsServer:()=>false}),
  Lighting:new FW('Lighting',()=>[],{Brightness:1,ClockTime:12}),ReplicatedStorage:st('ReplicatedStorage'),ReplicatedFirst:st('ReplicatedFirst'),ServerStorage:st('ServerStorage'),ServerScriptService:st('ServerScriptService'),StarterGui:st('StarterGui'),Teams:new FW('Teams',()=>(sv.Teams||[]).map(iW)),CoreGui:new FW('CoreGui',()=>RT.pgk),TweenService:window.mkTweenSvc?window.mkTweenSvc():new FW('TweenService',()=>[],{})};
 RT.game=new FW('Game',()=>Object.values(RT.svc),{GetService:(s,n)=>RT.svc[n],PlaceId:1});G.set('game',RT.game);G.set('workspace',RT.ws);
 (sv.StarterGui||[]).forEach(i0=>{if(i0.cls!='ScreenGui')return;const i=JSON.parse(JSON.stringify(i0));gui.appendChild(gDom(i,mkGw,null));RT.pgk.push(RT.gw.get(i.id))});
 const guiScripts=(i,w)=>i.ch.forEach(c=>{if(c.cls=='LocalScript')runScript(c,w);else if(GN[c.cls])guiScripts(c,RT.gw.get(c.id))});
 const lst=(a,par,cls)=>(a||[]).forEach(i=>{if(i.cls==cls)runScript(i,par);else if(i.cls=='Folder')lst(i.ch,iW(i),cls)});
 lst(sv.ReplicatedFirst,RT.svc.ReplicatedFirst,'LocalScript');lst(sv.ServerScriptService,RT.svc.ServerScriptService,'Script');lst(sv.Workspace,RT.ws,'Script');
 lst(sv.StarterPlayerScripts,RT.pl,'LocalScript');lst(sv.StarterPack,RT.pl,'LocalScript');
 (sv.StarterGui||[]).forEach(i0=>{const w=RT.gw.get(i0.id);if(i0.cls=='ScreenGui'&&w){const cl=JSON.parse(JSON.stringify(i0));guiScripts(cl,w)}else if(i0.cls=='LocalScript')runScript(i0,RT.pg)});
 setTimeout(()=>{if(RT===rt){RT.pa.fire(RT.pl);RT.pl.x.CharacterAdded.fire(RT.ch)}},60)}
function rtTick(){if(!RT||!RT.alive||!P)return;const t=performance.now(),dt=Math.min(.1,(t-RT.lt)/1000);RT.lt=t;RT.hb.fire(dt);
 RT.parts.forEach(w=>{if(!w.t.h.length||!w.m.parent)return;const m=w.m,hw=m.scale.x/2+.35,hd=m.scale.z/2+.35,top=m.position.y+m.scale.y/2,bot=m.position.y-m.scale.y/2,
  inn=Math.abs(P.x-m.position.x)<hw&&Math.abs(P.z-m.position.z)<hd&&P.y<top+.15&&P.y+2.7>bot-.1;if(inn&&!w.in)w.t.fire(RT.root);w.in=inn})}
OUT=(k,t)=>{const s=String(t).slice(0,140);if(RT&&RT.alive)addChat(k=='err'?'Error':k=='warn'?'Peringatan':'Script',s);else if(typeof slog=='function')slog((k=='err'?'Error: ':k=='warn'?'Peringatan: ':'')+s)};
const _lp=loop;loop=function(t){_lp(t);rtTick()};
const _sg3=startGame;startGame=function(g,t){_sg3(g,t);try{rtStart(g)}catch(e){OUT('err',e.message)}};
const _st3=stopGame;stopGame=function(){rtStop();_st3()};

/* ---- explorer ---- */
const _eR=eRender;
eRender=function(){if(!ST||ST.kind!='g')return _eR();const d=ST.d;ensureSvc(d);$('#etitle').textContent=''+d.name;
 const IR=(i,dep)=>{const on=SI==i.id,cont=pickL(i.id).length;let h=`<div class="er ${on?'on':''}" style="padding-left:${6+dep*12}px" data-a="isel" data-v="${i.id}"><span>${CL[i.cls]||'▫'} ${esc(i.n)}</span><span>${on&&/Script/.test(i.cls)?'<b class="px" data-a="sedit"></b>':''}${cont?`<b class="px" data-a="padd" data-v="${i.id}">＋</b>`:''}${on?`<b class="px dx" data-a="idel" data-v="${i.id}">✕</b>`:''}</span></div>`;i.ch.forEach(c=>h+=IR(c,dep+1));return h},
  SR2=(k,ic,pl,dep)=>`<div class="er sv" style="margin-left:${dep*10}px" data-a="xtg" data-v="${k}"><span>${XP[k]?'▾':'▸'} ${ic} ${k}</span>${pl?`<b class="px" data-a="padd" data-v="${k}">＋</b>`:''}</div>`;
 let h=`<div class="er ${SEL=='root'&&!SI?'on':''}" data-a="esel" data-v="root"><span><b>${esc(d.name)}</b></span></div>`;
 SVC.forEach(([k,ic,pl])=>{
  if(k=='StarterPlayer'){h+=SR2(k,ic,0,0);if(XP[k]){h+=SR2('StarterPlayerScripts','',1,1);if(XP.StarterPlayerScripts)d.svc.StarterPlayerScripts.forEach(i=>h+=IR(i,2));h+=`<div class="er ind" style="padding-left:20px">StarterCharacterScripts</div>`}return}
  h+=SR2(k,ic,pl,0);if(!XP[k])return;
  if(k=='Workspace')d.objs.forEach(o=>h+=`<div class="er ${o.id==SEL&&!SI?'on':''}" style="padding-left:18px" data-a="esel" data-v="${o.id}"><span>${TI[o.t]||''} ${esc(o.n)}</span><span><b class="px" data-a="padd" data-v="${o.id}">＋</b>${o.id==SEL&&!SI?`<b class="px dx" data-a="edel" data-v="${o.id}">✕</b>`:''}</span></div>${(o.ch||[]).map(c=>IR(c,2)).join('')}`);
  if(k=='Players')h+='<div class="er ind" style="padding-left:18px"> LocalPlayer</div>';
  (d.svc[k]||[]).forEach(i=>h+=IR(i,1))});
 $('#expl').innerHTML=h};
function iProps(i){const sc=/Script$/.test(i.cls),gu=GN[i.cls],q4=(k,a)=>'<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:3px">'+i[k].map((v,j)=>`<input type="number" step="${j%2?1:.1}" data-q="${k}${j}" value="${v}">`).join('')+'</div>';
 let h=`<h4>${CL[i.cls]||''} ${i.cls}</h4><label>Nama</label><input type="text" data-q="n" value="${esc(i.n)}" maxlength="24">`;
 if(sc)h+=`<button class="btn sm g w" data-a="sedit">Edit Script</button><div style="font-size:11px">${(i.src||'').split('\n').length} baris · Luau</div>`;
 if(gu&&i.cls!='ScreenGui'){h+=`<label>Position (skalaX, offsetX, skalaY, offsetY)</label>${q4('p')}<label>Size (skalaX, offsetX, skalaY, offsetY)</label>${q4('s')}<label>BackgroundColor3</label><input type="color" data-q="bg" value="${i.bg}"><label>BackgroundTransparency (0–1)</label><input type="number" step=".1" min="0" max="1" data-q="bt" value="${i.bt}">`;
  if(i.cls!='Frame'&&i.cls!='ScrollingFrame')h+=`<label>Text</label><input type="text" data-q="txt" value="${esc(i.txt||'')}"><label>TextColor3</label><input type="color" data-q="tc" value="${i.tc}"><label>TextSize</label><input type="number" data-q="ts" value="${i.ts}"><label>Font</label><select data-q="f">${Object.keys(FNT).map(k=>`<option value="${k}" ${(i.f||'Lilita')==k?'selected':''}>${k}</option>`).join('')}</select><label>TextXAlignment</label><select data-q="ta">${[['c','Center'],['l','Left'],['r','Right']].map(a=>`<option value="${a[0]}" ${(i.ta||'c')==a[0]?'selected':''}>${a[1]}</option>`).join('')}</select>`;
  h+=`<label class="ck"><input type="checkbox" data-q="bd" ${i.bd!==false?'checked':''}> Border</label>`}
 if(gu)h+=`<label class="ck"><input type="checkbox" data-q="vis" ${i.vis!==false?'checked':''}> ${i.cls=='ScreenGui'?'Enabled':'Visible'}</label>`;
 if(i.cls=='Team')h+=`<label>TeamColor</label><input type="color" data-q="tcol" value="${i.tcol}">`;
 return h+`<div style="display:flex;gap:6px;margin-top:8px"><button class="btn sm c" data-a="idup">⧉ Duplikat</button><button class="btn sm o" data-a="idel" data-v="${i.id}">Hapus</button></div>`}
const _pR2=pRender;
pRender=function(){if(ST&&ST.kind=='g'&&SI){const r=loc(SI);if(!r||SEL!='root')SI=null;else{$('#props').innerHTML=iProps(r.i);return}}_pR2()};
$('#props').addEventListener('change',e=>{const t=e.target,q=t.dataset&&t.dataset.q;if(!q||!ST||!SI)return;const r=loc(SI);if(!r)return;const i=r.i,v=t.type=='checkbox'?t.checked:t.type=='number'?(parseFloat(t.value)||0):t.value;
 if(/^[ps]\d$/.test(q))i[q[0]][+q[1]]=v;else if(q=='n')i.n=String(v).trim()||i.cls;else i[q]=v;touch();eRender();guiRefresh()});
/* picker */
function pickOpen(t){let m=$('#cpick');if(!m){m=document.createElement('div');m.id='cpick';document.body.appendChild(m)}m.dataset.t=t;const L=pickL(t);
 m.innerHTML=`<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">＋ Insert Object</h3><button class="btn sm o" style="margin:0" data-a="pkx">✕</button></div><input type="text" id="pq" placeholder="Cari objek…" style="margin:8px 0"><div class="plist">${L.map(x=>`<div class="pit" data-n="${x.n.toLowerCase()}" data-a="pins" data-v="${x.id}" data-k="${x.k}"><span>${x.ic}</span><div><b>${x.n}</b><small>${x.d}</small></div></div>`).join('')||'<div class="pit">Tidak ada objek yang bisa ditambahkan di sini.</div>'}</div></div>`}
document.addEventListener('input',e=>{if(e.target.id=='pq'){const q=e.target.value.toLowerCase();document.querySelectorAll('#cpick .pit').forEach(p=>p.style.display=!q||(p.dataset.n||'').includes(q)?'':'none')}});
const afterIns=i=>{SI=i.id;SEL='root';guiOn=!!GN[i.cls]||(guiOn&&i.cls=='LocalScript');selHelper();eRender();pRender();guiRefresh();touch()};
Object.assign(act,{
 xtg(v){XP[v]=!XP[v];eRender()},padd(v){pickOpen(v)},pkx(){const m=$('#cpick');if(m)m.remove()},
 pins(v,t){const m=$('#cpick'),tg=m.dataset.t;act.pkx();if(t.dataset.k=='obj')return act.ins(v);const i=newI(v);tgtList(tg).push(i);XP[tg]=1;afterIns(i);slog('+ '+v)},
 isel(v){const r=loc(v);if(!r)return;if(SI==v&&/Script/.test(r.i.cls))return act.sedit();SI=v;SEL='root';if(GN[r.i.cls])guiOn=true;selHelper();eRender();pRender();guiRefresh()},
 idel(v){const r=loc(v||SI);if(!r)return;r.list.splice(r.list.indexOf(r.i),1);SI=null;eRender();pRender();guiRefresh();touch();slog('Objek dihapus')},
 idup(){const r=loc(SI);if(!r)return;const c=JSON.parse(JSON.stringify(r.i)),re=x=>{x.id=nid();x.ch.forEach(re)};re(c);c.n+='2';r.list.push(c);afterIns(c)},
 gui(){guiOn=!guiOn;guiRefresh()},
 sedit(){const r=SI&&loc(SI);if(!r||!/Script$/.test(r.i.cls))return;sedOpen(r.i)},sclose(){const m=$('#sed');if(m)m.remove();touch()},
 schk(){const r=SI&&loc(SI);try{parse(r.i.src||'');$('#sst').textContent='✔ Syntax OK';$('#sst').style.color='#7dff9a'}catch(e){$('#sst').textContent=' '+e.message;$('#sst').style.color='#ff8080'}},
 sdemo(){act.sclose();act.edtest()}});
const _es=act.esel;act.esel=function(v){SI=null;guiOn=false;_es(v);guiRefresh()};
const _ed=act.edexit;act.edexit=function(){act.sclose();act.pkx();_ed()};
const _eo=edOpen;edOpen=function(d,k){SI=null;guiOn=false;if(k=='g')ensureSvc(d);_eo(d,k);const g=k=='g';['guib','tbxb'].forEach(i=>{const b=$('#'+i);if(b)b.style.display=g?'':'none'});guiRefresh()};
$('#snap').insertAdjacentHTML('afterend','<button class="btn sm" data-a="gui" id="guib"> GUI</button><button class="btn sm v" data-a="tbox" id="tbxb"> Toolbox</button>');
/* GUI editor overlay */
$('#vp').insertAdjacentHTML('beforeend','<div id="guiv"><div class="stg"></div></div>');
function guiRefresh(){const v=$('#guiv');if(!v)return;const on=guiOn&&ST&&ST.kind=='g';v.style.display=on?'flex':'none';$('#guib').classList.toggle('on',!!on);if(!on)return;
 const vp=$('#vp');let W=vp.clientWidth*.94,H=W*9/16;if(H>vp.clientHeight*.94){H=vp.clientHeight*.94;W=H*16/9}const st=v.querySelector('.stg');st.style.width=W+'px';st.style.height=H+'px';st.innerHTML='';
 ST.d.svc.StarterGui.forEach(i=>{if(i.cls=='ScreenGui')st.appendChild(gDom(i))});
 if(!st.children.length)st.innerHTML='<div class="gem">Belum ada GUI.<br>Klik ＋ di StarterGui → ScreenGui</div>';
 const el=SI&&st.querySelector('[data-gid="'+SI+'"]');if(el){el.classList.add('gsel');const l=loc(SI);if(l&&l.i.cls!='ScreenGui')el.insertAdjacentHTML('beforeend','<s class="rh"></s>')}}
{const gv=$('#guiv');
 gv.addEventListener('pointerdown',e=>{const st=gv.querySelector('.stg'),el=e.target.closest('[data-gid]'),rh=e.target.closest('.rh');
  if(!el){if(SI){SI=null;eRender();pRender();guiRefresh()}return}
  const id=el.dataset.gid;if(SI!=id)act.isel(id);const r=loc(id);if(!r||r.i.cls=='ScreenGui')return;try{gv.setPointerCapture(e.pointerId)}catch(x){}
  gdr={i:r.i,el:st.querySelector('[data-gid="'+id+'"]'),x:e.clientX,y:e.clientY,p:r.i.p.slice(),s:r.i.s.slice(),rs:!!rh};e.preventDefault()});
 gv.addEventListener('pointermove',e=>{if(!gdr)return;const dx=Math.round(e.clientX-gdr.x),dy=Math.round(e.clientY-gdr.y),i=gdr.i;if(gdr.rs){i.s[1]=Math.max(8,gdr.s[1]+dx);i.s[3]=Math.max(8,gdr.s[3]+dy)}else{i.p[1]=gdr.p[1]+dx;i.p[3]=gdr.p[3]+dy}gSty(i,gdr.el)});
 const up=()=>{if(gdr){gdr=null;touch();pRender()}};gv.addEventListener('pointerup',up);gv.addEventListener('pointercancel',up)}
new ResizeObserver(()=>guiRefresh()).observe($('#vp'));
/* script editor */
function sedOpen(i){let m=$('#sed');if(!m){m=document.createElement('div');m.id='sed';document.body.appendChild(m)}
 m.innerHTML=`<div class="sh"><b>${CL[i.cls]} ${esc(i.n)} <small>${i.cls} · Luau</small></b><span style="flex:1"></span><button class="btn sm g" data-a="schk">✔ Cek</button><button class="btn sm c" data-a="sdemo">▶ Test</button><button class="btn sm o" data-a="sclose">✕ Tutup</button></div><div class="sb"><pre id="sgut"></pre><textarea id="sta" spellcheck="false" autocapitalize="off" autocomplete="off" wrap="off"></textarea></div><div id="sst">Tab = indentasi · print() tampil di chat saat Test</div>`;
 const ta=$('#sta'),gut=()=>{$('#sgut').textContent=ta.value.split('\n').map((_,j)=>j+1).join('\n')};ta.value=i.src||'';gut();
 ta.addEventListener('input',()=>{i.src=ta.value;gut();touch()});ta.addEventListener('scroll',()=>$('#sgut').scrollTop=ta.scrollTop);
 ta.addEventListener('keydown',e=>{if(e.key=='Tab'){e.preventDefault();ta.setRangeText('  ',ta.selectionStart,ta.selectionEnd,'end');i.src=ta.value;gut()}});ta.focus()}
/* toolbox */
const pa=(x,y,z,sx,sy,sz,c,n)=>{const o=O('part',x,y,z,sx,sy,sz,c);o.n=n;return o},
 sg=(k,cls,src,n)=>{const i=newI(cls);i.src=src;if(n)i.n=n;ST.d.svc[k].push(i);return i};
const TB=[
 {n:'Kill Brick',ic:'',d:'Balok merah + Script: sentuh = respawn',f(){ST.d.objs.push(pa(6,.5,6,4,1,4,'#ff3b3b','KillBrick'));return sg('ServerScriptService','Script','local brick = workspace:FindFirstChild("KillBrick")\nbrick.Touched:Connect(function(hit)\n\tlocal hum = hit.Parent:FindFirstChild("Humanoid")\n\tif hum then\n\t\thum.Health = 0\n\tend\nend)\n','KillBrickScript')}},
 {n:'Balok Pelangi',ic:'',d:'Balok yang berganti warna tiap 0.5 detik',f(){ST.d.objs.push(pa(-6,.5,6,4,1,4,'#ff90e8','Rainbow'));return sg('ServerScriptService','Script','local part = workspace:FindFirstChild("Rainbow")\nwhile true do\n\tpart.Color = Color3.fromRGB(math.random(0,255), math.random(0,255), math.random(0,255))\n\twait(0.5)\nend\n','RainbowScript')}},
 {n:'Teleporter',ic:'',d:'Sentuh balok biru → pindah ke atas',f(){ST.d.objs.push(pa(10,.5,0,3,1,3,'#7df9ff','Teleport'));return sg('ServerScriptService','Script','local tp = workspace:FindFirstChild("Teleport")\ntp.Touched:Connect(function(hit)\n\thit.Parent.HumanoidRootPart.Position = Vector3.new(0, 15, 0)\nend)\n','TeleportScript')}},
 {n:'HUD Skor',ic:'',d:'ScreenGui: label skor + tombol +1',f(){const g=newI('ScreenGui');g.n='HUD';const l=newI('TextLabel');l.n='Skor';l.txt='Skor: 0';l.p=[0,20,0,70];l.s=[0,160,0,46];const b=newI('TextButton');b.n='Tambah';b.txt='+1';b.p=[0,20,0,124];b.s=[0,160,0,46];const s=newI('LocalScript');s.src='local gui = script.Parent\nlocal label = gui:WaitForChild("Skor")\nlocal btn = gui:WaitForChild("Tambah")\nlocal n = 0\nbtn.MouseButton1Click:Connect(function()\n\tn = n + 1\n\tlabel.Text = "Skor: " .. n\nend)\n';g.ch.push(l,b,s);ST.d.svc.StarterGui.push(g);return g}},
 {n:'Panel Info',ic:'',d:'Frame di tengah + tombol Tutup',f(){const g=newI('ScreenGui');g.n='InfoGui';const f=newI('Frame');f.n='Panel';f.p=[.5,-130,.5,-80];f.s=[0,260,0,160];const t=newI('TextLabel');t.txt='Selamat datang di mapku!';t.p=[0,10,0,10];t.s=[1,-20,0,60];t.bt=1;t.bd=false;const b=newI('TextButton');b.n='Tutup';b.txt='Tutup';b.p=[.5,-60,1,-60];b.s=[0,120,0,44];f.ch.push(t,b);const s=newI('LocalScript');s.src='local gui = script.Parent\nlocal panel = gui:WaitForChild("Panel")\npanel:WaitForChild("Tutup").MouseButton1Click:Connect(function()\n\tpanel.Visible = false\nend)\n';g.ch.push(f,s);ST.d.svc.StarterGui.push(g);return g}},
 {n:'Module Util + Script',ic:'',d:'ModuleScript di ReplicatedStorage + require()',f(){sg('ReplicatedStorage','ModuleScript',SRC.ModuleScript,'Util');return sg('ServerScriptService','Script','local Util = require(game:GetService("ReplicatedStorage"):WaitForChild("Util"))\nprint(Util.hello("Pickare"))\n','UseUtil')}},
 {n:'Hello Output',ic:'',d:'Script contoh: print + loop',f(){return sg('ServerScriptService','Script','for i = 1, 3 do\n\tprint("Hitung", i)\n\twait(1)\nend\nprint("Selesai!")\n','Hello')}}];
Object.assign(act,{tbox(){let m=$('#cpick');if(!m){m=document.createElement('div');m.id='cpick';document.body.appendChild(m)}
 m.innerHTML=`<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0"> Toolbox</h3><button class="btn sm o" style="margin:0" data-a="pkx">✕</button></div><div class="plist" style="margin-top:8px">${TB.map((x,j)=>`<div class="pit" data-a="tbi" data-v="${j}"><span>${x.ic}</span><div><b>${x.n}</b><small>${x.d}</small></div></div>`).join('')}</div></div>`},
 tbi(v){act.pkx();const i=TB[+v].f();sBuild();afterIns(i);slog('Toolbox: '+TB[+v].n);toast('Ditambahkan: '+TB[+v].n)}});
if(ST)eRender();
