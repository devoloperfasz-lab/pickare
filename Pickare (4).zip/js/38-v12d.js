/* ===== v12d: Tool terlihat di pemain lain + label User ID & username ===== */
(function(){
function findTool(id){const sv=(typeof curG!=='undefined'&&curG&&curG.svc)||{};let r=null;
 const f=l=>(l||[]).forEach(i=>{if(r||!i)return;if(i.cls==='Tool'&&String(i.id)===id)r=i;else if(i.cls==='Folder')f(i.ch)});
 f(sv.StarterPack);f(sv.Workspace);f(sv.ServerStorage);return r}
function dropTool(o){try{if(o.hg&&o.hg.parent)o.hg.parent.remove(o.hg)}catch(e){}o.hg=null}
function setTool(o,id){if(o.tlId===id)return;o.tlId=id;dropTool(o);if(!id)return;
 try{const it=findTool(id);if(!it||!window.__tbuild||!o.g||!o.g.a)return;const b=window.__tbuild(it);
  b.g.rotation.x=(isFinite(+it.gp)?+it.gp:90)*Math.PI/180;b.g.position.set(+it.gx||0,-.95+(+it.gy||0),+it.gz||0);o.g.a[1].add(b.g);o.hg=b.g}catch(e){}}
function subTag(n,u){const c=document.createElement('canvas');c.width=320;c.height=56;const x=c.getContext('2d');
 x.fillStyle='rgba(0,0,0,.62)';x.beginPath();x.roundRect?x.roundRect(2,2,316,52,14):x.rect(2,2,316,52);x.fill();
 const t='@'+String(n).slice(0,16)+(u?'  ·  ID '+u:'');let fs=26;x.textAlign='center';x.textBaseline='middle';
 do{x.font='bold '+fs+'px Arial';fs-=2}while(x.measureText(t).width>296&&fs>12);x.fillStyle='#fff';x.fillText(t,160,30);
 const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false,transparent:true}));s.scale.set(2.6,.455,1);s.position.y=3.12;s.renderOrder=9;return s}
const _sp2=syncPeers;
syncPeers=function(peers){_sp2.apply(this,arguments);
 try{(peers||[]).forEach(p=>{const q=p&&p.presence;if(!q||p.isMe||q.n==null)return;const o=remote[p.peer];if(!o)return;
  setTool(o,typeof q.tl==='string'?q.tl.slice(0,24):'');try{window.__applyFx&&window.__applyFx(o,q.fx)}catch(e){}
  const u=+q.u>0?Math.floor(+q.u):0,key=String(o.name)+'|'+u;
  if(o.idk!==key){o.idk=key;if(o.idt&&o.idt.parent)o.idt.parent.remove(o.idt);o.idt=subTag(o.name,u);o.g.add(o.idt)}})}catch(e){}};
})();
