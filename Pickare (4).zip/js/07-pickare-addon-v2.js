/* ===== PICKARE ADDON v2: Owner/Panel, Marketplace, Gizmo 3D, Menu, Publish ===== */
const SALT='shinpo$7',OH='44f5c37692c7b98dbfa4113b64620a093d00201fab356daae5431b5a927659aa',OU='29adcd14fc4904eb2a7429e3e4878ef8ea701d76e77ab4f848ffc6c4ee4ee8e9',OPH='6127a8072727aeae825ec31a99c3b917b99fed1bfd385ffb5a5096635960b3ba';
const sha=(()=>{const K=[],H0=[],p=[];for(let n=2;p.length<64;n++)if(p.every(q=>n%q))p.push(n);
 p.forEach((q,i)=>{K[i]=(Math.cbrt(q)%1*4294967296)|0;if(i<8)H0[i]=(Math.sqrt(q)%1*4294967296)|0});
 const r=(x,n)=>x>>>n|x<<32-n;
 return s=>{const b=[...new TextEncoder().encode(s)],l=b.length*8;b.push(128);while(b.length%64!=56)b.push(0);for(let i=7;i>=0;i--)b.push(i>3?0:(l>>>(i*8))&255);
  let h=H0.slice();for(let o=0;o<b.length;o+=64){const w=[];for(let i=0;i<16;i++)w[i]=b[o+i*4]<<24|b[o+i*4+1]<<16|b[o+i*4+2]<<8|b[o+i*4+3];
   for(let i=16;i<64;i++){const a=w[i-15],c=w[i-2];w[i]=w[i-16]+(r(a,7)^r(a,18)^a>>>3)+w[i-7]+(r(c,17)^r(c,19)^c>>>10)|0}
   let[a,B,c,d,e,f,g,H]=h;
   for(let i=0;i<64;i++){const t1=H+(r(e,6)^r(e,11)^r(e,25))+(e&f^~e&g)+K[i]+w[i]|0,t2=(r(a,2)^r(a,13)^r(a,22))+(a&B^a&c^B&c)|0;H=g;g=f;f=e;e=d+t1|0;d=c;c=B;B=a;a=t1+t2|0}
   h=[h[0]+a|0,h[1]+B|0,h[2]+c|0,h[3]+d|0,h[4]+e|0,h[5]+f|0,h[6]+g|0,h[7]+H|0]}
  return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('')}})();
const ROLE={owner:3,coowner:2,admin:1},RN={owner:'OWNER',coowner:'CO-ADMIN',admin:'ADMIN'};
const lv=u=>u&&ROLE[u.role]||0,vb=u=>{if(!u)return'';let v=!!u.verified,rb='';try{const k=Object.keys(users).find(x=>users[x]===u);if(k){if(window.spVerified&&window.spVerified(k))v=true;if(window.spRoleBadge)rb=window.spRoleBadge(k)}}catch(e){}return (v?'<span class="vb">✔</span>':'')+rb},staff=()=>!!me&&lv(me)>0,okT=u=>lv(me)==3||lv(me)>lv(u);
let pt='gift',avt='cust',mtab='play';
const reps=()=>ls.get('sp_rep',[]),gf=()=>Object.assign({q:'2',sh:'normal',fog:'1'},S.gfx||{});

/* ---- login owner (email tidak pernah ditampilkan / disimpan, hanya hash) ---- */
const _auth=act.auth;
act.auth=function(){const raw=$('#u').value.trim(),p=$('#pw').value,bad=m=>{$('#err').textContent=m;const c=$('#acard');c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')};
 if(raw.includes('@')){if(mode!='login'||(sha(SALT+raw.toLowerCase())!==OH&&sha(SALT+raw.toLowerCase())!==OU))return bad('Username atau password salah');
  if(p.length<6)return bad('Password owner min. 6 karakter');const ph=sha(SALT+'pw:'+p);let o=users.Owner;
  if(!o)o=users.Owner={pass:'',ph,bux:99999,daily:'',av:{skin:SKIN[0],shirt:SHIRT[1],pants:PANTS[1],hat:'crown'},games:[],items:[],notes:[{t:'Akun Owner aktif ',new:1}],role:'owner',verified:true};
  else if(o.ph!==ph)return bad('Username atau password salah');
  save();me=o;me.name='Owner';me.notes=me.notes||[];me.games=me.games||[];ls.set('sp_sess','Owner');$('#u').value='';$('#pw').value='';$('#u').type='text';return enter()}
 if(/^(owner|admin|coowner|co-owner)$/i.test(raw))return bad(mode=='reg'?'Username dicadangkan':'Username atau password salah');
 if(mode=='reg'&&raw.length>14)return bad('Username maks. 14 karakter');
 _auth()};
$('#u').removeAttribute('maxlength');$('#u').setAttribute('autocomplete','off');
$('#u').addEventListener('input',e=>{e.target.type=e.target.value.includes('@')?'password':'text'});

/* ---- render hooks ---- */
const _r=render;
render=function(){if(page=='panel'&&!staff())page='home';_r();const m=$('#main');
 if(page=='avatar')m.innerHTML='<div class="page">'+avH()+'</div>';
 if(page=='panel')m.innerHTML='<div class="page">'+panH()+'</div>';
 if(page=='home'){const h=m.querySelector('.hero h1');if(h)h.insertAdjacentHTML('beforeend',vb(me))}rolePill()};
function rolePill(){if(!me)return;let e=$('#rolep');if(!e){e=document.createElement('div');e.id='rolep';e.className='pill';$('#buxp').before(e)}const t=(RN[me.role]||'')+(me.verified?' ✔':'');e.style.display=t?'':'none';e.textContent=t}
const _en=enter;
enter=function(){_en();if(staff())$('#nav').insertAdjacentHTML('beforeend','<button data-a="go" data-v="panel" id="n_panel"><span></span>Panel</button>');navRender();rolePill()};

/* ---- panel (hanya staff) ---- */
const usersOpt=()=>Object.keys(users).filter(k=>users[k]!==me).map(k=>`<option>${esc(k)}</option>`).join('');
function panH(){if(!staff())return'';const T=[['gift','Gift'],['user','Pengguna'],['lap','Laporan']];
 let h='<h2>Panel '+(RN[me.role]||'')+'</h2><div class="mt" style="margin-bottom:12px">'+T.map(x=>`<button class="btn sm ${pt==x[0]?'c':''}" data-a="pt" data-v="${x[0]}">${x[1]}</button>`).join('')+'</div>';
 if(pt=='gift'){const ro=[['admin','Admin',2],['coowner','Co-Owner',3]].filter(r=>lv(me)>=r[2]);
  h+=`<div class="card"><label>Pilih pemain</label><select id="pt_u">${usersOpt()}</select>
  <label>Gift PickBux${lv(me)<3?' (maks. 500)':''}</label><input type="text" inputmode="numeric" id="pt_n" value="100"><button class="btn w g" data-a="gbux">Kirim PickBux</button>
  <label style="margin-top:14px">✔ Gift Centang Biru</label><div style="display:flex;gap:8px;margin-top:6px"><button class="btn w c" data-a="gver" data-v="1">Beri ✔</button><button class="btn w o" data-a="gver" data-v="0">Cabut</button></div>`
  +(ro.length?`<label style="margin-top:14px">Gift Akses Panel</label><select id="pt_r" style="margin-bottom:8px">${ro.map(r=>`<option value="${r[0]}">${r[1]}</option>`).join('')}<option value="none">Cabut akses</option></select><button class="btn w v" data-a="grole">Berikan Akses</button>`:'')+'</div>'}
 if(pt=='user')h+=Object.keys(users).map(k=>{const u=users[k];return`<div class="card row"><b style="flex:1">${esc(k)}${vb(u)}</b><span class="pill" style="font-size:12px">${RN[u.role]||'User'}</span><span class="pill" style="font-size:12px">${u.bux||0}</span></div>`}).join('');
 if(pt=='lap')h+=reps().map((r,i)=>`<div class="note"><b>${esc(r.type)}</b> · ${esc(r.by)} → ${esc(r.tg||'-')}<br>${esc(r.txt)}<br><small>${esc(r.gn||'')}</small><div style="margin-top:6px">${r.gid?`<button class="btn sm o" data-a="rtake" data-v="${i}">Turunkan map</button> `:''}<button class="btn sm" data-a="rdel" data-v="${i}">Hapus</button></div></div>`).join('')||'<div class="note">Belum ada laporan.</div>';
 return h}
const tgt=()=>{const k=$('#pt_u')&&$('#pt_u').value,u=users[k];if(!u)toast('Pilih pemain dulu');return u?[k,u]:null},
 nt=(u,t)=>(u.notes=u.notes||[]).unshift({t,new:1});
Object.assign(act,{
 pt(v){pt=v;render()},
 gbux(){const t=tgt();if(!t||!staff())return;let n=Math.floor(+$('#pt_n').value);if(!(n>0))return toast('Jumlah tidak valid');if(lv(me)<3)n=Math.min(n,500);t[1].bux=(t[1].bux||0)+n;nt(t[1],'Kamu mendapat '+n+' PickBux dari '+RN[me.role]);save();toast('Terkirim '+n+' PickBux ke '+t[0])},
 gver(v){const t=tgt();if(!t||!staff()||!okT(t[1]))return toast('Tidak diizinkan');t[1].verified=v=='1';nt(t[1],v=='1'?'✔ Kamu mendapat Centang Biru!':'Centang biru dicabut');save();toast(v=='1'?'Centang biru diberikan':'Centang biru dicabut')},
 grole(){const t=tgt(),r=$('#pt_r')&&$('#pt_r').value;if(!t||!r||!okT(t[1])||(r!='none'&&lv({role:r})>=lv(me)))return toast('Tidak diizinkan');
  if(r=='none'){delete t[1].role;nt(t[1],'Akses panelmu dicabut')}else{t[1].role=r;nt(t[1],'Kamu mendapat akses '+RN[r]+'. Login ulang untuk membuka Panel.')}save();toast('Akses diperbarui')},
 rdel(v){if(!staff())return;const r=reps();r.splice(+v,1);ls.set('sp_rep',r);render()},
 rtake(v){if(!staff())return;const r=reps()[+v];Object.values(users).forEach(u=>(u.games||[]).forEach(g=>{if(g.id==r.gid)g.pub=false}));save();toast('Map diturunkan jadi draft')}
});

/* ---- avatar: kostumisasi + marketplace ---- */
const PRICE={mahkota:60,kerucut:30,sayap:90,kacamata:25,jubah:45};
function mkItems(){const a=Object.keys(AT).filter(k=>PRICE[k]).map(k=>({key:'t_'+k,name:AT[k].n,e:AT[k].e,price:PRICE[k],by:'Pickare',v:1,objs:AT[k].f(),desc:'Item resmi Pickare'}));
 Object.keys(users).forEach(un=>(users[un].items||[]).forEach(i=>{if(i.pub===true&&!(i.rv&&i.rv.s&&i.rv.s!=='approved'))a.push({key:'u_'+un+'_'+i.id,name:i.name,e:'',icon:i.icon,price:i.price||0,by:un,v:users[un].verified,objs:i.objs,desc:i.desc,slot:i.slot})}));return a}
function avH(){const tb=[['cust','Kostumisasi'],['mkt','Marketplace']].map(x=>`<button class="btn sm ${avt==x[0]?'c':''}" data-a="avt" data-v="${x[0]}">${x[1]}</button>`).join(' ');
 let h=`<h2>Avatar</h2><div class="card" style="display:flex;justify-content:center;background:var(--c);padding:26px 20px 20px">${avHTML(me.av,12)}</div><div class="mt" style="margin:14px 0">${tb}</div>`;
 if(avt=='cust'){const sw=(k,arr)=>arr.map(c=>`<span class="sw ${me.av[k]==c?'sel':''}" style="background:${c}" data-a="av" data-k="${k}" data-v="${c}"></span>`).join('');
  h+=`<div class="card"><label>Kulit</label><br>${sw('skin',SKIN)}<br><label>Baju</label><br>${sw('shirt',SHIRT)}<br><label>Celana</label><br>${sw('pants',PANTS)}<br><label>Topi</label><br>${['none','cap','crown'].map(x=>`<button class="btn sm ${me.av.hat==x?'g':''}" style="margin:6px 6px 0 0" data-a="av" data-k="hat" data-v="${x}">${x}</button>`).join('')}</div>`+accHTML()}
 else h+=`<div class="note">Kamu punya ${me.bux} PickBux. Aksesoris buatan kreator lain muncul di sini setelah dipublish.</div><div class="grid">`+mkItems().map((it,i)=>{const own=(me.items||[]).some(x=>x.src==it.key||'u_'+me.name+'_'+x.id==it.key);
  return`<div class="card gcard"><div class="th" style="background-color:${PAL[i%6]}">${it.icon?`<img src="${it.icon}" style="width:100%;height:100%;object-fit:cover">`:'<span>'+esc(it.e||String(it.name||'?').charAt(0).toUpperCase())+'</span>'}</div><div class="in"><b>${esc(it.name)}</b><small>${esc(it.desc||'')} · ${esc(it.by)}${it.v?'<span class="vb">✔</span>':''}</small><button class="btn w ${own?'':'g'}" data-a="buy" data-v="${it.key}">${own?'✓ Dimiliki':''+it.price}</button></div></div>`}).join('')+'</div>';
 return h}
Object.assign(act,{avt(v){avt=v;render()},
 buy(v){const it=mkItems().find(x=>x.key==v);if(!it)return;if((me.items||[]).some(x=>x.src==v||'u_'+me.name+'_'+x.id==v))return toast('Sudah dimiliki');
  if(me.bux<it.price)return toast('PickBux tidak cukup');addBux(-it.price);const cr=users[it.by];if(cr&&cr!==me){cr.bux=(cr.bux||0)+it.price;nt(cr,''+me.name+' membeli "'+it.name+'" +'+it.price+' PickBux')}
  (me.items=me.items||[]).push({id:'i'+Date.now(),name:it.name,slot:it.slot||'Kepala',objs:it.objs.map(o=>Object.assign({},o,{id:nid()})),src:v});save();notify('Membeli "'+it.name+'"');toast('Dibeli! Pakai di Kostumisasi');render()}});

/* ---- publish (nama, deskripsi, icon, thumbnail, API key wajib) ---- */
const pmKeep=()=>{const g=i=>$('#'+i)?$('#'+i).value:undefined;window._pm=Object.assign(window._pm||{},{n:g('pm_n'),d:g('pm_d'),k:g('pm_k'),p:g('pm_p')})};
function pubOpen(re){if(!me.apiKey){me.apiKey=genKey();save()}const d=ST.d,a=ST.kind=='a';let m=$('#pubm');if(re&&m)pmKeep();else window._pm={};const P=window._pm;
 if(!m){m=document.createElement('div');m.id='pubm';document.body.appendChild(m)}m.dataset.open=1;
 const im=(k,l)=>`<label>${l} ${a?'<span style="opacity:.6">(opsional)</span>':'<b style="color:#d00">*</b>'}</label><div style="display:flex;gap:8px;align-items:center;margin:4px 0 10px"><div class="pv" style="width:${k=='icon'?'64px':'120px'};aspect-ratio:${k=='icon'?'1':'16/9'};margin:0">${d[k]?`<img src="${d[k]}" style="width:100%;height:100%;object-fit:cover">`:'kosong'}</div><button class="btn sm" style="margin:0" data-a="upimg" data-v="${k}">Pilih</button></div>`;
 m.innerHTML=`<div class="card"><h2>Publish ${a?'Aksesoris':'Map'}</h2><label>Nama ${a?'aksesoris':'map'} *</label><input type="text" id="pm_n" maxlength="22" value="${esc(P.n!=null?P.n:d.name)}"><label>Deskripsi * (min. 10 huruf)</label><input type="text" id="pm_d" maxlength="140" value="${esc(P.d!=null?P.d:d.desc||'')}">${im('icon','Icon')}${im('thumb','Thumbnail')}${a?`<label>Harga PickBux (0 = gratis)</label><input type="text" inputmode="numeric" id="pm_p" value="${esc(P.p!=null?P.p:d.price||0)}">`:''}<label>API Key Creator *</label><input type="password" id="pm_k" autocomplete="off" value="${esc(P.k||'')}" placeholder="spk_..."><div style="font-size:11px;margin:-6px 0 8px">Ambil dari Studio → API Key Creator. Key asal-asalan akan ditolak.</div>${a?'<div style="font-size:12px;margin:0 0 8px;font-weight:700">Biaya publish aksesoris: '+(window.accFeeDue(d)?window.ACC_FEE.toLocaleString('id-ID')+' PickBux (saldomu '+(me.bux||0).toLocaleString('id-ID')+')':'sudah dibayar')+'</div>':''}<div class="err" id="pm_e"></div><div style="display:flex;gap:8px"><button class="btn w" data-a="pmx">Batal</button><button class="btn w g" data-a="pmgo">Publish</button></div></div>`}
const _pR=pRender;pRender=function(){_pR();const m=$('#pubm');if(m&&m.dataset.open)pubOpen(1)};
const _pl=pubLabel;pubLabel=function(){_pl();$('#pubb').textContent=ST.d.pub===true?'Published':(ST.d.rv&&ST.d.rv.s=='pending'?'Menunggu review':'Publish')};
Object.assign(act,{
 edpub(){const d=ST.d;if(d.pub===true){d.pub=false;save();pubLabel();return toast('Kembali menjadi draft')}if(d.rv&&d.rv.s=='pending'){RV.cancel(d);pubLabel();return toast('Pengajuan dibatalkan')}pubOpen()},
 pmx(){const m=$('#pubm');if(m)m.remove()},
 pmgo(){pmKeep();const d=ST.d,a=ST.kind=='a',P=window._pm,k=(P.k||'').trim(),n=(P.n||'').trim(),ds=(P.d||'').trim(),err=m=>{$('#pm_e').textContent=m};
  if(n.length<3)return err('Nama minimal 3 karakter');if(ds.length<10)return err('Deskripsi minimal 10 karakter');if(!a&&!d.icon)return err('Icon wajib diupload');if(!a&&!d.thumb)return err('Thumbnail wajib diupload');
  {const kr=keyChk(k,a?'universe-accessory':'universe-place','w');if(kr)return err(kr)}
  let pr=0;if(a){pr=Math.floor(+P.p||0);if(!(pr>=0&&pr<=9999))return err('Harga 0–9999')}
  Object.assign(d,{name:n,desc:ds,by:me.name,price:pr});if(RV.blk(d))return err('Diblokir/off sale oleh admin, tidak bisa dipublish');if(a){const fe=window.accFeeErr(d);if(fe)return err(fe);window.accFeePay(d)}const dr=RV.submit(d,a?'acc':'map');act.pmx();pubLabel();eRender();toast(dr?(a?'Aksesoris':'Map')+' dipublish':'Dikirim ke admin untuk dicek ⏳')}});

/* ---- gizmo 3D (panah) ---- */
let GZ=null,gd=null;const V3=THREE.Vector3,GAX={x:new THREE.Vector3(1,0,0),y:new THREE.Vector3(0,1,0),z:new THREE.Vector3(0,0,1)};
function gzBuild(){if(!SS)return;if(GZ){SS.remove(GZ);GZ=null}const o=cur();if(!o||tool=='select'||((tool=='scale'||tool=='rot')&&o.t=='coin'))return;
 GZ=new THREE.Group();const C={x:0xff3b3b,y:0x2ecc40,z:0x3b6bff},M=(c,op)=>new THREE.MeshBasicMaterial({color:c,depthTest:false,transparent:true,opacity:op==null?1:op}),AX=GAX,Y=new V3(0,1,0);
 if(tool=='rot'){['x','y','z'].forEach(ax=>{const g=new THREE.Group(),vis=new THREE.Mesh(new THREE.TorusGeometry(2.2,.07,8,72),M(C[ax])),hit=new THREE.Mesh(new THREE.TorusGeometry(2.2,.25,6,48),M(C[ax],0));g.add(vis,hit);if(ax=='x')g.rotation.y=Math.PI/2;if(ax=='y')g.rotation.x=Math.PI/2;g.children.forEach(x=>{x.userData.ax=ax;x.renderOrder=99});GZ.add(g)})}
 else['x','y','z'].forEach(ax=>[1,-1].forEach(sg=>{const col=sg>0?C[ax]:new THREE.Color(C[ax]).multiplyScalar(.7).getHex(),c=M(col),g=new THREE.Group(),
  sh=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,2.3,8),c),tip=tool=='move'?new THREE.Mesh(new THREE.ConeGeometry(.26,.7,14),c):new THREE.Mesh(new THREE.BoxGeometry(.4,.4,.4),c),hit=new THREE.Mesh(new THREE.CylinderGeometry(.32,.32,3.4,6),M(col,0));
  sh.position.y=1.65;tip.position.y=3.1;hit.position.y=1.9;g.add(sh,tip,hit);g.quaternion.setFromUnitVectors(Y,AX[ax].clone().multiplyScalar(sg));g.children.forEach(x=>{x.userData.ax=ax;x.userData.sg=sg;x.renderOrder=99});GZ.add(g)}));
 SS.add(GZ)}
function gzUpd(){if(!GZ)return;const o=cur(),m=o&&meshes[o.id];GZ.visible=!!m;if(m){GZ.position.copy(m.position);if(o.t=='coin')GZ.quaternion.identity();else GZ.quaternion.copy(m.quaternion);GZ.scale.setScalar(Math.max(.3,sctl.dist*.075))}}
const _sh=selHelper;selHelper=function(){_sh();gzBuild()};
const _tl=act.tool;act.tool=function(v){_tl(v);if(ST)gzBuild()};
const _el=edLoop;edLoop=function(){gzUpd();_el()};
function axS(e,P,u){rc.setFromCamera(ndc(e),SC);const w=P.clone().sub(rc.ray.origin),d=rc.ray.direction,b=u.dot(d),den=1-b*b;return den<1e-4?null:(b*d.dot(w)-u.dot(w))/den}
function ringA(e,P,n,e1,e2){rc.setFromCamera(ndc(e),SC);const pl=new THREE.Plane().setFromNormalAndCoplanarPoint(n,P),q=new V3();if(!rc.ray.intersectPlane(pl,q))return null;const r=q.sub(P);return Math.atan2(r.dot(e2),r.dot(e1))}
const mod=(v,m)=>((v%m)+m)%m,s5=d=>Math.round(d/5)*5;
sc.addEventListener('pointerdown',e=>{if(!GZ||!GZ.visible||!ST||Object.keys(ptr).length)return;rc.setFromCamera(ndc(e),SC);const h=rc.intersectObjects(GZ.children,true);if(!h.length)return;const ud=h[0].object.userData,ax=ud.ax,sg=ud.sg||1,o=cur(),m=o&&meshes[o.id];if(!o||!m)return;
 const P=m.position.clone(),Q=o.t=='coin'?new THREE.Quaternion():m.quaternion.clone(),u=GAX[ax].clone().applyQuaternion(Q);
 const g0={id:e.pointerId,ax,sg,o,m:tool,P,Q,u,v0:{x:o.x,y:o.y,z:o.z,sx:o.sx,sy:o.sy,sz:o.sz},s0:0,a0:0,last:0};
 if(tool=='rot'){const e1=(Math.abs(u.y)<.9?new V3(0,1,0):new V3(1,0,0)).cross(u).normalize(),e2=u.clone().cross(e1),a=ringA(e,P,u,e1,e2);if(a==null)return;g0.e1=e1;g0.e2=e2;g0.a0=a}
 else{const s=axS(e,P,u);if(s==null)return;g0.s0=s}
 e.stopImmediatePropagation();e.preventDefault();try{sc.setPointerCapture(e.pointerId)}catch(x){}pushUndo();gd=g0},true);
sc.addEventListener('pointermove',e=>{if(!gd||e.pointerId!==gd.id)return;e.stopImmediatePropagation();e.preventDefault();const o=gd.o,ax=gd.ax;
 if(gd.m=='rot'){const a=ringA(e,gd.P,gd.u,gd.e1,gd.e2);if(a==null)return;let d=a-gd.a0;d=Math.atan2(Math.sin(d),Math.cos(d));const q=new THREE.Quaternion().setFromAxisAngle(gd.u,d).multiply(gd.Q),eu=new THREE.Euler().setFromQuaternion(q,'YXZ'),R=180/Math.PI,nx=mod(s5(eu.x*R),360),ny=mod(s5(eu.y*R),360),nz=mod(s5(eu.z*R),360);
  if(nx===o.rx&&ny===o.ry&&nz===(o.rz||0))return;o.rx=nx;o.ry=ny;o.rz=nz}
 else{const s=axS(e,gd.P,gd.u);if(s==null)return;const dl=s-gd.s0,sp=snapV||.1;
  if(gd.m=='scale'){const k='s'+ax,nv=Math.max(.1,f2(Math.round((gd.v0[k]+dl*gd.sg*2)/sp)*sp));if(nv===o[k])return;o[k]=nv}
  else{const nx=sn(gd.v0.x+gd.u.x*dl),ny=sn(gd.v0.y+gd.u.y*dl),nz=sn(gd.v0.z+gd.u.z*dl);if(nx===o.x&&ny===o.y&&nz===o.z)return;o.x=nx;o.y=ny;o.z=nz}}
 place(meshes[o.id],o);if(helper)helper.update()},true);
const gu=e=>{if(gd&&e.pointerId===gd.id){gd=null;touch();pRender()}};sc.addEventListener('pointerup',gu);sc.addEventListener('pointercancel',gu);

/* ---- menu in-game ala Roblox ---- */
$('#pause').innerHTML=`<div class="card"><h2>☰ Menu</h2><div class="mt">${[['play','Pemain'],['set','Setelan'],['gfx','Grafik'],['rep','Laporan'],['help','Info']].map(x=>`<button class="btn sm" data-a="mt" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><div id="mb"></div><div class="mf"><button class="btn g" data-a="resume">▶ Lanjut</button><button class="btn o" data-a="respawn">↺ Reset</button><button class="btn p" data-a="leave"> Keluar</button></div></div>`;
const SHF={normal:'none',bright:'saturate(1.35) brightness(1.08)',cine:'contrast(1.2) saturate(.85) sepia(.18)',retro:'saturate(1.6) contrast(1.15)',bw:'grayscale(1)'};
function gfxApply(){const g=gf();cv.style.filter=SHF[g.sh]||'none';cv.style.imageRendering=g.sh=='retro'?'pixelated':'';
 if(R){R.setPixelRatio(Math.max(.3,Math.min(+g.q,window.devicePixelRatio||1)*(g.sh=='retro'?.5:1)));resize()}if(scene&&scene.fog)scene.fog.far=g.fog=='1'?140:600;$('#chatlog').style.display=S.nochat?'none':''}
function mtR(v){mtab=v;const g=gf(),op=(k,a)=>a.map(x=>`<button class="btn sm ${g[k]==x[0]?'g':''}" style="margin:4px 4px 0 0" data-a="gfx" data-k="${k}" data-v="${x[0]}">${x[1]}</button>`).join('');let h='';
 if(v=='play')h='<div id="plist"></div>';
 if(v=='set')h=`<label>Sensitivitas Kamera</label><input type="range" min="1" max="10" value="${S.sens}" oninput="act.sens(0,this)" style="width:100%"><label>Kamera</label><button class="btn sm" data-a="cam">Ganti Kamera</button><label style="margin-top:8px">Log Chat</label><button class="btn sm" data-a="chl">${S.nochat?'Tampilkan':'Sembunyikan'}</button>`;
 if(v=='gfx')h='<label>Kualitas</label>'+op('q',[['.6','Rendah'],['1','Sedang'],['2','Tinggi']])+'<label style="margin-top:8px">Shader</label>'+op('sh',[['normal','Normal'],['bright','Cerah'],['cine','Sinematik'],['retro','Retro'],['bw','Hitam Putih']])+'<label style="margin-top:8px">Kabut</label>'+op('fog',[['1','Nyala'],['0','Mati']]);
 if(v=='rep')h=`<label>Jenis</label><select id="rp_t"><option>Pemain</option><option>Map</option><option>Bug</option></select><label>Nama pemain / map</label><input type="text" id="rp_g" maxlength="30"><label>Alasan</label><input type="text" id="rp_x" maxlength="120"><button class="btn w p" data-a="rsend"> Kirim Laporan</button>`;
 if(v=='help')h='<b>Kontrol</b><br>WASD / joystick: gerak<br>Spasi / LOMPAT: lompat<br>C: ganti kamera · Enter: chat · Esc: menu<br><br>Map: '+esc(curG?curG.name:'-');
 $('#mb').innerHTML=h;document.querySelectorAll('#pause .mt .btn').forEach(b=>b.classList.toggle('act',b.dataset.v==v));if(v=='play')plist()}
Object.assign(act,{pause(){paused=true;$('#pause').style.display='flex';mtR(mtab)},mt(v){mtR(v)},
 gfx(v,t){const g=gf();g[t.dataset.k]=v;S.gfx=g;save();gfxApply();mtR('gfx')},chl(){S.nochat=!S.nochat;save();gfxApply();mtR('set')},
 rsend(){const t=($('#rp_x').value||'').trim();if(t.length<5)return toast('Tulis alasan (min. 5 huruf)');const r=reps();r.unshift({by:me.name,type:$('#rp_t').value,tg:$('#rp_g').value.trim(),txt:t,gid:curG&&curG.id,gn:curG&&curG.name,t:Date.now()});ls.set('sp_rep',r.slice(0,100));$('#rp_x').value='';toast('Laporan terkirim ✓')}});
const _sg=startGame;startGame=function(g,t){_sg(g,t);gfxApply();mtab='play'};

if(me)enter();
