(function(){
const DK='sp_devban',rd=()=>{try{return JSON.parse(localStorage.getItem(DK)||'null')}catch(e){return null}},wr=d=>{try{d?localStorage.setItem(DK,JSON.stringify(d)):localStorage.removeItem(DK)}catch(e){}};
const live=d=>d&&(d.perm||(+d.until||0)>Date.now());
const fmt=d=>d.perm?'permanen':'sampai '+new Date(d.until).toLocaleString('id-ID');
function setDev(n,b){const o=rd();if(o&&o.name===n&&o.t===b.t)return;wr({name:n,perm:!!b.perm,until:+b.until||0,reason:String(b.reason||'').slice(0,120),t:b.t||Date.now()})}
function check(){let d=rd();if(d){const u=users[d.name];if(!live(d)||(u&&!banOf(u)&&u.bts))d=null,wr(null)}
 let o=document.getElementById('banov');
 if(!d){if(o)o.remove();return}
 if(!o){o=document.createElement('div');o.id='banov';document.body.appendChild(o)}
 o.innerHTML='<div class="bx"><h2>Akun diblokir</h2><p>Akun <b></b> diblokir '+fmt(d)+'.</p><p class="rs"></p><small>Perangkat ini tidak dapat login atau membuat akun baru selama blokir aktif.</small><button type="button" id="banck">Cek status</button></div>';
 o.querySelector('b').textContent=d.name;o.querySelector('.rs').textContent='Alasan: '+(d.reason||'-');
 o.querySelector('#banck').onclick=recheck}
async function recheck(){const d=rd();if(!d)return check();const u=users[d.name];
 if(u&&window.spPanelSync&&!me){try{me=u;me.name=d.name;me.notes=me.notes||[];await window.spPanelSync()}catch(e){}finally{me=null}}
 check()}
const _en=enter;
const pend=()=>!!(me&&(me.viol||[]).some(v=>!v.ack&&!v.done&&v.ban));
enter=function(){if(me&&banOf(me)&&!pend()){const n=me.name,b=banOf(me);setDev(n,b);me=null;try{ls.set('sp_sess','')}catch(e){}check();return}
 const r=_en.apply(this,arguments);return r};
const _au=act.auth;
act.auth=function(){check();if(document.getElementById('banov'))return;const r=_au.apply(this,arguments);
 const hit=()=>{const n=(($('#u')||{}).value||'').trim().toLowerCase(),em=(($('#em')||{}).value||'').trim().toLowerCase(),k=Object.keys(users).find(x=>x.toLowerCase()==n||(em&&users[x].email===em));if(k&&banOf(users[k])){setDev(k,banOf(users[k]));check()}};
 hit();setTimeout(hit,600);setTimeout(hit,2000);return r};
setInterval(()=>{try{if(me&&banOf(me)&&!pend()){setDev(me.name,banOf(me));const n=me.name;try{act.out()}catch(e){me=null}}check()}catch(e){}},1500);
setInterval(()=>{if(document.getElementById('banov')&&!document.hidden)recheck()},30000);
setInterval(()=>{try{if(typeof me==='undefined'||!me||document.getElementById('rvVio')||document.getElementById('banov')||document.getElementById('annPop'))return;
 const A=ls.get('sp_ann',[]).filter(x=>!x.dead),seen=me.annSeen=me.annSeen||[],x=A.find(a=>!seen.includes(a.id));
 if(!x||!document.getElementById('app')||document.getElementById('app').style.display==='none')return;
 const cl=(me.claimed||[]).includes(x.id),o=document.createElement('div');o.id='annPop';o.className='apop';
 o.innerHTML='<div class="bx'+(x.r?' rw':'')+'"><div style="font-size:42px">'+(x.r?'🎁':'📢')+'</div><h3></h3><p></p>'+(x.r&&!cl?'<button class="g" id="apk">Klaim '+(+x.r)+' PickBux</button>':'')+'<button id="apx">Tutup</button></div>';
 document.body.appendChild(o);o.querySelector('h3').textContent=x.t;o.querySelector('p').textContent=x.x;
 const done=()=>{if(!seen.includes(x.id))seen.push(x.id);if(seen.length>50)seen.shift();save();o.remove()};
 o.querySelector('#apx').onclick=done;const k=o.querySelector('#apk');if(k)k.onclick=()=>{try{act.rvwk(x.id)}catch(e){}done()}}catch(e){}},3500);
window.spDevBan=setDev;window.spBanCheck=check;
document.addEventListener('DOMContentLoaded',check);check();
})();
