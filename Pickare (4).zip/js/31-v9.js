/* ===== v9: Marketplace, Kustomisasi & Info Game — gaya terang ===== */
(function(){
const S=(p,s,f)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="${f||'none'}" stroke="${f?'none':'currentColor'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const I={
 back:s=>S('<path d="M19 12H5M11 6l-6 6 6 6"/>',s||30),
 search:s=>S('<circle cx="11" cy="11" r="7.5"/><path d="M21 21l-4.6-4.6"/>',s||30),
 x:s=>S('<path d="M6 6l12 12M18 6L6 18"/>',s||28),
 undo:s=>S('<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 010 12h-3"/>',s||26),
 redo:s=>S('<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 000 12h3"/>',s||26),
 filt:s=>S('<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2.2"/><circle cx="8" cy="17" r="2.2"/>',s||26),
 tag:s=>S('<path d="M12 2.5l8.2 3.3.1 8.5-6.1 6.1a2 2 0 01-2.8 0l-5.9-5.9a2 2 0 010-2.8z" fill="#335fff" stroke="none"/><circle cx="14.6" cy="9.4" r="1.4" fill="#fff" stroke="none"/>',s||30),
 pgear:s=>S('<circle cx="10" cy="6" r="3"/><path d="M4 20v-3a4 4 0 014-4h2"/><circle cx="17" cy="17" r="2.2"/><path d="M17 12.6v1.2M17 20.2v1.2M12.6 17h1.2M20.2 17h1.2"/>',s||26),
 plus:s=>S('<path d="M12 5v14M5 12h14"/>',s||34),
 chev:s=>S('<path d="M9 5l7 7-7 7"/>',s||18),
 ver:'<svg width="16" height="16" viewBox="0 0 24 24"><path fill="#2f6bff" d="M12 1l2.6 1.8 3.1-.2 1.2 2.9 2.7 1.6-.6 3.1 1.1 2.9-2 2.4-.2 3.1-3 .9-2.1 2.3L12 21.8l-2.8 1.3-2.1-2.3-3-.9-.2-3.1-2-2.4 1.1-2.9-.6-3.1 2.7-1.6 1.2-2.9 3.1.2z"/><path d="M8 12.3l2.6 2.6L16 9.5" stroke="#fff" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 play:s=>S('<path d="M7 4.5v15l13-7.5z" fill="#fff" stroke="#fff" stroke-linejoin="round"/>',s||34),
 more:s=>S('<circle cx="12" cy="12" r="9.5"/><circle cx="7.5" cy="12" r=".9" fill="currentColor"/><circle cx="12" cy="12" r=".9" fill="currentColor"/><circle cx="16.5" cy="12" r=".9" fill="currentColor"/>',s||34),
 inv:s=>S('<rect x="4" y="3" width="8" height="8" rx="1.5"/><path d="M5 21v-2.5A3.5 3.5 0 018.5 15H11"/><path d="M15 15l6 3.5-6 3.5z" fill="currentColor"/>',s||34),
 up:s=>S('<path d="M7 10v11H3V10zM7 10l4-7a2.2 2.2 0 012 2.2V9h6a2 2 0 012 2.3l-1.2 7A2 2 0 0117.8 20H7"/>',s||22),
 dn:s=>S('<path d="M17 14V3h4v11zM17 14l-4 7a2.2 2.2 0 01-2-2.2V15H5a2 2 0 01-2-2.3l1.2-7A2 2 0 016.2 4H17"/>',s||22),
 grp:s=>S('<circle cx="9" cy="8" r="3.2"/><path d="M3 20v-1a5 5 0 015-5h2a5 5 0 015 5v1"/><circle cx="17" cy="9" r="2.4"/><path d="M17.5 14a4 4 0 013.5 4v1"/>',s||22),
 bell:s=>S('<path d="M6 17V11a6 6 0 0112 0v6l1.5 2h-15z"/><path d="M10 21h4"/>',s||22),
 star:s=>S('<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1L3.2 9.6l6.1-.8z"/>',s||22)
};
const hex=s=>(typeof ico=='function'?ico('hex',s):'');
const nf=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
const BGS={senja:['Latar Senja','linear-gradient(#ffd9a8,#ff8fa3)'],laut:['Latar Laut','linear-gradient(#c3ecff,#4aa8d8)'],malam:['Latar Malam','linear-gradient(#3a3f7a,#12142e)'],hutan:['Latar Hutan','linear-gradient(#d2f5bd,#3f9a58)']};
const EXTRA=[].concat(Object.keys(BGS).map(k=>({key:'bg_'+k,name:BGS[k][0],e:'',price:15,by:'Pickare',v:1,objs:[],desc:'Latar Belakang',slot:'Latar Belakang',cloth:{bg:k}})),
 [['b_zamrud','Kulit Zamrud','#6fcf97'],['b_langit','Kulit Langit','#7ec8ff'],['b_ungu','Kulit Ungu','#c9a6ff']].map(c=>({key:c[0],name:c[1],e:'',price:30,by:'Pickare',v:1,objs:[],desc:'Tubuh',slot:'Tubuh',cloth:{skin:c[2]}})));
const _mk9=mkItems;
mkItems=function(){const a=_mk9.apply(this,arguments),k=new Set(a.map(x=>x.key));return a.concat(EXTRA.filter(x=>!k.has(x.key)))};


const SLK=[['Kepala','Kepala'],['Wajah','Wajah'],['Leher','Leher'],['Belakang','Belakang'],['Pinggang','Pinggang'],['Bahu','Bahu'],['Depan','Depan'],['Alat','Perlengkapan']];
const NORM={Punggung:'Belakang',Badan:'Depan',Perlengkapan:'Alat'},OFSLOT={t_mahkota:'Kepala',t_kerucut:'Kepala',t_sayap:'Belakang',t_kacamata:'Wajah',t_jubah:'Belakang'};
const slotOf=i=>{const s=OFSLOT[i.src||i.key]||NORM[i.slot]||i.slot||'Kepala';return (SLK.some(x=>x[0]==s)||s=='Pakaian'||s=='Sepatu'||s=='Tubuh'||s=='Avatar')?s:'Kepala'};
const _mk10=mkItems;mkItems=function(){return _mk10.apply(this,arguments).map(it=>OFSLOT[it.key]?Object.assign({},it,{slot:OFSLOT[it.key]}):it)};
let cslot='Kepala',clslot='top';
const SI={Kepala:'<path d="M5 17c0-6 3-10 7-10s7 4 7 10zM3 17h18"/>',Wajah:'<circle cx="7" cy="14" r="3.5"/><circle cx="17" cy="14" r="3.5"/><path d="M10.5 14h3M3.5 14L5 7M20.5 14L19 7"/>',Leher:'<path d="M5 5c0 8 3 11 7 11s7-3 7-11"/><rect x="9.5" y="16" width="5" height="5" rx="1"/>',Belakang:'<path d="M12 3v14M9 17l3 4 3-4M8 7h8"/>',Pinggang:'<rect x="3" y="8" width="18" height="8" rx="3"/><rect x="9" y="10" width="6" height="4" rx="1"/>',Bahu:'<path d="M5 20V9c0-3 2-5 5-5l4 4 3-1c2 0 3 2 2 4l-3 9z"/>',Depan:'<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M8 8a4 4 0 018 0"/>',Alat:'<path d="M5 19L17 7l2 2L7 21zM15 5l2-2 4 4-2 2z"/>',top:'<path d="M8 4L3 8l3 4 2-1v9h8v-9l2 1 3-4-5-4a4 4 0 01-8 0z"/>',outer:'<path d="M9 4L4 8v12h16V8l-5-4-3 4zM12 8v12"/>',bottom:'<path d="M6 3h12l1 18h-6l-1-10-1 10H5z"/>',shoe:'<path d="M3 15l4-1 3-5 3 3 6 1c2 0 2 4 2 4H3z"/>'};
const sico=(k,s)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="#a9adb8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${SI[k]}</svg>`;
const slotBtn=(act2,key,label,sel,worn)=>`<button class="sl9 ${sel?'sel':''}" data-a="${act2}" data-v="${key}"><span class="sb9x">${worn?worn:sico(key,28)}${worn?'':'<b>+</b>'}</span><em>${label}</em></button>`;
const wornThumb=i=>{const im=okImg(i.icon);return im?`<img src="${im}" alt="">`:`<span style="font-size:22px;font-weight:800;color:#555">${esc(String(i.name||'?').charAt(0).toUpperCase())}</span>`};
const clothCat=c=>c.bg?'bg':(c.shirt&&c.pants&&c.skin)?'pack':(c.skin&&!c.shirt&&!c.pants)?'body':'cloth';
const catOf=it=>{if(it.slot=='Tubuh')return 'body';if(it.slot=='Pakaian'||it.slot=='Sepatu')return 'cloth';if(it.cloth){const k=clothCat(it.cloth);return k=='pack'?'avatar':k}const s=it.slot||'';return s=='Avatar'?'avatar':s=='Latar Belakang'?'bg':s=='Tubuh'?'body':(s=='Baju'||s=='Celana')?'cloth':'acc'};
const MC=[['all','Semua'],['avatar','Avatar'],['bg','Latar Belakang'],['body','Tubuh'],['cloth','Pakaian'],['acc','Aksesori'],['anim','Animasi'],['mk','Makeup']];
const CC=[['av','Avatar'],['body','Tubuh'],['cloth','Pakaian'],['acc','Aksesori'],['bg','Latar Belakang'],['anim','Animasi'],['emo','Emoji'],['mk','Makeup']];
let mcat='all',msearch=false,msq='',bnx=false,big=false,hist=[],redo=[];
const own=it=>(me.items||[]).some(x=>x.src==it.key||'u_'+me.name+'_'+x.id==it.key);
const wearing=c=>c&&Object.keys(c).every(k=>me.av[k]==c[k]);

function thumb(it,u){const im=okImg(it.icon);if(im)return `<img src="${im}" alt="">`;const c=it.cloth;
 if(c&&c.bg&&BGS[c.bg])return `<i style="position:absolute;inset:0;background:${BGS[c.bg][1]}"></i>`;
 if(c)return avHTML(Object.assign({},me.av,{hat:'none',acc:[]},c),u);
 return `<span style="font-size:38px;font-weight:800;color:#8a8fa0">${esc(it.e||String(it.name||'?').charAt(0).toUpperCase())}</span>`}
function mktCard(it){const o=own(it);return `<button class="c9" data-a="buy" data-v="${esc(it.key)}"><span class="th">${thumb(it,5)}</span><strong>${esc(it.name)}</strong><small>${esc(it.by)}${it.v?I.ver:''}</small><em>${o?'Dimiliki':hex(18)+' '+nf(+it.price||0)}</em></button>`}
function mktList(){const q=msq.trim().toLowerCase();
 return mkItems().filter(it=>(mcat=='all'||catOf(it)==mcat)&&(mfil=='all'||(mfil=='off'?it.by=='Pickare':it.by!='Pickare'))&&(!q||String(it.name).toLowerCase().includes(q)||String(it.by).toLowerCase().includes(q)))}
function mktGrid(){const f=mktList();return f.length?f.map(mktCard).join(''):`<div class="em9">${msq?'Tidak ada item yang cocok.':'Belum ada item di kategori ini.'}</div>`}
function ownTile(i,u){const im=okImg(i.icon),on=i.cloth?wearing(i.cloth):(me.av.acc||[]).includes(i.id);
 const th=i.cloth?thumb({cloth:i.cloth,name:i.name,icon:i.icon},u):(im?`<img src="${im}" alt="">`:`<span style="font-size:34px;font-weight:800;color:#8a8fa0">${esc(String(i.name||'?').charAt(0).toUpperCase())}</span>`);
 return `<button class="c9 o9 ${on?'on':''}" data-a="${i.cloth?'acc':'wear'}" data-v="${esc(i.id)}"><span class="th">${th}${on&&!i.cloth?'<u class="lp9">Lepas</u>':''}</span><strong>${esc(i.name)}</strong></button>`}
function ownGrid(f){const a=(me.items||[]).filter(f);return a.length?`<div class="ig c4">${a.map(i=>ownTile(i,4)).join('')}</div>`:'<div class="h9s">Belum ada item. Beli di Marketplace.</div>'}
const swatches=(k,arr)=>`<div class="sw9w">${arr.map(c=>`<span class="sw9 ${me.av[k]==c?'sel':''}" style="background:${c}" data-a="av" data-k="${k}" data-v="${c}"></span>`).join('')}</div>`;
const sameAv=a=>{try{return JSON.stringify(a)==JSON.stringify(me.av)}catch(e){return false}};
function custBody(){
 if(ctab=='av'){const os=me.outfits||[];
  return `<div class="ig c4"><button class="c9 o9 add" data-a="oedit"><span class="th">${I.plus(36)}</span><strong>Tambah/Edit</strong></button>${os.map(o=>`<button class="c9 o9 ${sameAv(o.av)?'on':''}" data-a="outfit" data-v="${esc(o.id)}"><span class="th" style="${o.av&&o.av.bg&&BGS[o.av.bg]?'background:'+BGS[o.av.bg][1]:''}">${avHTML(Object.assign({acc:[]},o.av),4)}</span><strong>${esc(o.n)}</strong></button>`).join('')}</div>`}
 if(ctab=='body')return `<div class="h9s" style="margin-top:18px">Warna kulit</div>${swatches('skin',SKIN)}<div class="h9s">Model tubuh saya (bentuk)</div>`+ownGrid(i=>i.slot=='Tubuh'||(i.cloth&&clothCat(i.cloth)=='body'));

 if(ctab=='cloth'){const sl=[['top','Atasan'],['outer','Pakaian Luar'],['bottom','Bawahan'],['shoe','Sepatu']];
  let h=`<div class="slr">${sl.map(s=>slotBtn('clslot',s[0],s[1],clslot==s[0])).join('')}</div>`;
  if(clslot=='top')h+=`<div class="h9s" style="margin-top:18px">Warna baju</div>${swatches('shirt',SHIRT)}<div class="h9s">Item atasan &amp; paket saya</div>`+ownGrid(i=>i.cloth&&(i.cloth.shirt&&!i.cloth.pants||clothCat(i.cloth)=='pack'));
  else if(clslot=='bottom')h+=`<div class="h9s" style="margin-top:18px">Warna celana</div>${swatches('pants',PANTS)}<div class="h9s">Item bawahan saya</div>`+ownGrid(i=>i.cloth&&i.cloth.pants&&!i.cloth.shirt);
  else h+=`<div class="h9s" style="margin-top:18px">${clslot=='outer'?'Pakaian luar':'Sepatu'} saya</div>`+ownGrid(i=>!i.cloth&&i.slot==(clslot=='outer'?'Pakaian':'Sepatu'));
  return h}
 if(ctab=='acc'){const worn=s=>(me.items||[]).find(i=>!i.cloth&&(me.av.acc||[]).includes(i.id)&&slotOf(i)==s);
  const its=(me.items||[]).filter(i=>!i.cloth&&i.slot!='Tubuh'&&i.slot!='Avatar'&&i.slot!='Pakaian'&&i.slot!='Sepatu'&&slotOf(i)==cslot),lb=(SLK.find(x=>x[0]==cslot)||[])[1];
  return `<div class="slr">${SLK.map(s=>{const w=worn(s[0]);return slotBtn('cslot',s[0],s[1],cslot==s[0],w?wornThumb(w):'')}).join('')}<button class="sl9" data-a="accclr"><span class="sb9x"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#6b7080" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 11-2.6-5.9M20 4v5h-5"/></svg></span><em>Hapus</em></button></div>
  <div class="h9s" style="margin-top:6px;padding-top:12px">Topi &amp; aksesori dasar</div>${cslot=='Kepala'?`<div class="pl9w">${[['none','Polos'],['cap','Topi'],['crown','Mahkota']].map(x=>`<button class="pl9 ${me.av.hat==x[0]?'on':''}" data-a="av" data-k="hat" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`:'<div class="pl9w" style="color:#000;font-weight:500">—</div>'}
  <div class="h9s">Aksesori ${esc(lb||cslot)} saya</div>`+(its.length?`<div class="ig c4">${its.map(i=>ownTile(i,4)).join('')}</div>`:`<div class="em9" style="padding:20px 22px">Belum ada aksesori ${esc((lb||cslot).toLowerCase())}.<br>Beli di Marketplace atau buat di Studio.</div><button class="wide9" data-a="avt" data-v="mkt">Buka Marketplace</button>`)}
 if(ctab=='bg'){const a=(me.items||[]).filter(i=>i.cloth&&i.cloth.bg);return `<div class="ig c4" style="padding-top:18px!important"><button class="c9 o9 ${!me.av.bg?'on':''}" data-a="av" data-k="bg" data-v=""><span class="th" style="background:linear-gradient(#dcdce0,#f1f1f3)"></span><strong>Default</strong></button>${a.map(i=>ownTile(i,4)).join('')}</div>`+(a.length?'':'<div class="h9s">Beli latar belakang di Marketplace.</div>')}
 return `<div class="ig"><div class="em9">Belum ada item di kategori ini.</div></div>`}
function city(){return [[-3,24,70],[16,18,52],[30,26,84],[52,20,58],[68,24,76],[88,16,46]].map(b=>`<i style="left:${b[0]}%;width:${b[1]}%;height:${b[2]}%"></i>`).join('')}

avP=function(){const mkt=avt=='mkt',bg=me.av&&me.av.bg&&BGS[me.av.bg]?BGS[me.av.bg][1]:'';
 let h=`<div class="avx${big?' big':''}"><div class="city" style="${bg?'background:'+bg:''}">${bg?'':city()}</div><div class="stage v3" id="av3s"></div>
 <div class="tb"><button class="rb9" data-a="go" data-v="home" aria-label="Kembali">${I.back(30)}</button><div class="sg9"><button class="${mkt?'on':''}" data-a="avt" data-v="mkt">Marketplace</button><button class="${mkt?'':'on'}" data-a="avt" data-v="cust">Kustomisasi</button></div><button class="rb9" data-a="msearch" aria-label="Cari" style="${mkt?'':'visibility:hidden'}">${I.search(30)}</button></div>
 <div class="lp glass"><span class="circ" style="--s:42px">${avHTML(me.av,4.2)}</span><button data-a="av2" aria-label="Edit avatar">${I.pgear(26)}</button></div>
 <div class="cp glass" data-a="shop" role="button">${hex(24)}<span>${nf(me.bux)}</span></div>
 <div class="ur9 glass"><button class="${hist.length?'on':''}" data-a="avundo" aria-label="Urungkan">${I.undo(26)}</button><button class="${redo.length?'on':''}" data-a="avredo" aria-label="Ulangi">${I.redo(26)}</button></div>
 <div class="sheet"><div class="sh9h"><button class="gb9" data-a="bigx" aria-label="Perbesar"><i class="grab"></i></button>`;
 if(mkt){
  if(!bnx)h+=`<div class="bn9">${I.tag(30)}<span>Kamu punya <b>${nf(me.bux)}</b> PickBux. Item kreator muncul setelah dipublish.</span><button data-a="bnx" aria-label="Tutup">${I.x(22)}</button></div>`;
  if(msearch)h+=`<div class="sb9">${I.search(22)}<input id="mq" type="text" placeholder="Cari item" value="${esc(msq)}" autocomplete="off" maxlength="30"><button data-a="msearch" aria-label="Tutup pencarian">${I.x(22)}</button></div>`;
  h+=`<div class="tw9"><div class="tabs9">${MC.map(c=>`<button class="t9 ${mcat==c[0]?'on':''}" data-a="mcat" data-v="${c[0]}">${c[1]}</button>`).join('')}</div><button class="fb9" data-a="mfilt" aria-label="Filter">${I.filt(26)}</button></div></div>`;
  h+=`<h3 class="h9">${mcat=='all'?'Direkomendasikan Untukmu':esc(MC.find(c=>c[0]==mcat)[1])}</h3><div class="ig">${mktGrid()}</div>`;
 }else{
  h+=`<div class="tw9"><div class="tabs9">${CC.map(c=>`<button class="t9 ${ctab==c[0]?'on':''}" data-a="ct" data-v="${c[0]}">${c[1]}</button>`).join('')}</div></div></div>${custBody()}`;
 }
 return h+'</div></div>'};

/* ---- aksi ---- */
const snap=()=>{try{hist.push(JSON.stringify(me.av));if(hist.length>30)hist.shift();redo=[]}catch(e){}};
['av','acc'].forEach(k=>{const o=act[k];act[k]=function(){snap();return o.apply(this,arguments)}});
const setAv=s=>{me.av=JSON.parse(s);save();render()};
Object.assign(act,{
 cslot(v){cslot=v;render()},clslot(v){clslot=v;render()},
 wear(v){const it=(me.items||[]).find(x=>x.id==v);if(!it)return;snap();let a=me.av.acc=me.av.acc||[];const i=a.indexOf(v);
  if(i>-1){a.splice(i,1);toast(it.name+' dilepas')}else{const sl=slotOf(it),keep=new Set((me.items||[]).filter(x=>!x.cloth&&slotOf(x)==sl).map(x=>x.id));me.av.acc=a=a.filter(id=>!keep.has(id));a.push(v);toast(it.name+' dipakai')}
  save();render()},
 accclr(){snap();me.av.acc=[];me.av.hat='none';save();toast('Semua aksesori dilepas');render()},
 mcat(v){mcat=v;render()},
 msearch(){msearch=!msearch;if(!msearch)msq='';render();if(msearch){const e=document.getElementById('mq');if(e)e.focus()}},
 bnx(){bnx=true;render()},
 bigx(){big=!big;const a=document.querySelector('.avx');if(a)a.classList.toggle('big',big)},
 mfilt(){shOpen(`<div class="shn" style="margin-top:6px">Filter</div>${[['all','Semua item'],['off','Resmi (Pickare)'],['cr','Buatan kreator']].map(x=>`<button class="sb ${mfil==x[0]?'pr':''}" data-a="mf2" data-v="${x[0]}">${x[1]}</button>`).join('')}<button class="sb ln" data-a="shx">Tutup</button>`)},
 mf2(v){mfil=v;shClose();render()},
 av2(){avt='cust';ctab='av';render()},
 avundo(){if(!hist.length)return;redo.push(JSON.stringify(me.av));setAv(hist.pop())},
 avredo(){if(!redo.length)return;hist.push(JSON.stringify(me.av));setAv(redo.pop())},
 oedit(){const os=me.outfits||[];shOpen(`<div class="shn" style="margin-top:6px">Avatar Saya</div><input class="shin" id="on9" type="text" maxlength="14" placeholder="Nama avatar" autocomplete="off"><button class="sb pr" data-a="osave">Simpan avatar saat ini</button>${os.length?`<div class="pvm" style="margin-top:16px">Tersimpan</div>`+os.map(o=>`<div style="display:flex;align-items:center;gap:12px;padding:8px 2px"><b style="flex:1;font-weight:600">${esc(o.n)}</b><button class="sb" style="width:auto;margin:0;padding:10px 16px;font-size:15px" data-a="odel" data-v="${esc(o.id)}">Hapus</button></div>`).join(''):''}<button class="sb ln" data-a="shx">Tutup</button>`)},
 osave(){const os=me.outfits=me.outfits||[];if(os.length>=24)return toast('Maksimal 24 avatar tersimpan');const e=document.getElementById('on9'),n=((e&&e.value)||'').trim().slice(0,14)||('avatar '+(os.length+1));os.push({id:Math.random().toString(36).slice(2,9),n,av:JSON.parse(JSON.stringify(me.av))});save();shClose();toast('Avatar "'+n+'" disimpan');render()},
 odel(v){me.outfits=(me.outfits||[]).filter(o=>o.id!=v);save();act.oedit();render()},
 outfit(v){const o=(me.outfits||[]).find(x=>x.id==v);if(!o)return;snap();me.av=JSON.parse(JSON.stringify(o.av));save();toast('Memakai "'+o.n+'"');render()}
});
document.addEventListener('input',e=>{if(e.target.id!='mq')return;msq=e.target.value;const g=document.querySelector('.avx .ig');if(g)g.innerHTML=mktGrid()});

/* ---- info game ---- */
const fd=t=>{const d=new Date(t);return(!t||isNaN(d))?'—':d.toLocaleDateString('en-US')};
gameOv=function(id){const g=allGames().find(x=>x.id==id);
 if(!g)return `<div class="gx2"><div class="gx2t"><button class="gx2x" data-a="ovb" aria-label="Tutup">${I.x(30)}</button></div><div class="gx2e">Game tidak ditemukan.</div></div>`;
 const t=okImg(g.thumb),ic=okImg(g.icon),c1=hexc(g.col,'#b6f25a'),c2=hexc(g.sky,'#7df9ff'),grad=`linear-gradient(135deg,${c1},${c2})`,
 lk=(me.lk||{})[g.id]||0,fav=(me.favs||[]).includes(g.id),nt=(me.nots||{})[g.id],pf=playingFriends(g.id),by=g.by||'Pickare',bu=users[by],
 vis=(ls.get('sp_vis',{})[g.id]||0)+(g.pl||1)*1300,L=String(g.emoji||String(g.name||'?').charAt(0).toUpperCase()),
 ds=String(g.desc||('Selamat datang di '+g.name+'! Lompati platform dan capai garis finish bersama teman.')),
 row=(a,b,cl)=>`<div class="ir9"><span>${a}</span><b>${b}</b></div>`;
 return `<div class="gx2"><div class="gx2t"><button class="gx2x" data-a="ovb" aria-label="Tutup">${I.x(30)}</button></div>
 <div class="gx2b"><i class="gx2g"></i>
 <div class="gh9"><span class="gi9" style="background:${ic?`url(${ic})`:grad}">${ic?'':esc(L)}</span><div><h1>${esc(g.name)}</h1><p>${esc(by)}${bu?vb(bu):(window.spVb?spVb(by):'')}</p><small>Kedewasaan: Minimal • Semua usia</small></div></div>
 <div class="gs9" style="background:${t?`url(${t})`:grad}">${t?'':esc(L)}</div>
 <div class="gc9"><span class="ch9 sp"><button class="${lk==1?'on':''}" data-a="glike" data-v="${esc(g.id)}">${I.up(22)} ${g.lk>0?(+g.lk)+'%':'Baru'}</button><hr><button class="${lk==-1?'on':''}" data-a="gdis" data-v="${esc(g.id)}" aria-label="Tidak suka">${I.dn(22)}</button></span><span class="ch9">${I.grp(22)} ${fmtN((g.pl||1)+pf.length)} aktif</span><button class="ch9 ${nt?'on':''}" data-a="gnot" data-v="${esc(g.id)}">${I.bell(22)} Notifikasi</button><button class="ch9 ${fav?'on':''}" data-a="gfav" data-v="${esc(g.id)}">${I.star(22)} Favorit</button></div>
 ${pf.length?`<button class="pb9" data-a="gfrp" data-v="${esc(g.id)}" style="cursor:pointer"><span class="stk">${pf.slice(0,3).map(n=>circ(pinfo(n).av,34)).join('')}</span><span>Dimainkan oleh <b>${esc(pf[0])}</b>${pf.length>1?' dan <b>'+(pf.length-1)+' teman lainnya</b>':''}</span></button>`:''}
 <h3>Deskripsi</h3><p class="ds9${ds.length>120?' cl':''}" id="ds9">${esc(ds)}</p>${ds.length>120?`<button class="mo9" data-a="gmore">lebih banyak</button>`:''}
 <h3>Informasi</h3>
 ${row('Kunjungan',nf(vis))}${row('Kedewasaan Konten','Minimal')}
 ${bu?`<button class="ir9" data-a="prof" data-v="${esc(by)}"><span>Pengembang</span><b>${esc(by)}${vb(bu)}${I.chev(18)}</b></button>`:row('Pengembang',esc(by)+(window.spVb?spVb(by):''))}
 ${row('Ukuran Server','8')}${row('Genre',g.mine?'Buatan Pemain':'Obby')}${row('Dibuat',fd(g.t||g.ts||g.created||g.at))}${row('Di-update',fd(g.upd||g.u||g.ut||g.ts||g.t||Date.now()))}${row('Chat Suara','Didukung')}${row('Kamera','Didukung')}
 <button class="ir9" data-a="srv" data-v="${esc(g.id)}"><span>Server</span><b>Lihat ${I.chev(18)}</b></button>
 </div><div class="bar9"><button class="sm9" data-a="gmenu" aria-label="Opsi">${I.more(36)}</button><button class="sm9" data-a="srv" data-v="${esc(g.id)}" aria-label="Server">${I.inv(34)}</button><button class="pp9" data-a="play" data-v="${esc(g.id)}" aria-label="Main">${I.play(34)}</button></div></div>`};
act.gmore=function(){const d=document.getElementById('ds9'),b=document.querySelector('.gx2 .mo9');if(!d)return;const c=d.classList.toggle('cl');if(b)b.textContent=c?'lebih banyak':'lebih sedikit'};

/* ---- tema terang untuk sheet & overlay ---- */
function syncLt(){const o=document.getElementById('ov'),lt=!!(o&&o.querySelector('.gx2'));if(o)o.classList.toggle('lt',lt);document.body.classList.toggle('lt9',lt||(typeof page!='undefined'&&page=='avatar'))}
const _ov9=ovRender;ovRender=function(){const r=_ov9.apply(this,arguments);syncLt();return r};
const _rn9=render;render=function(){const r=_rn9.apply(this,arguments);syncLt();return r};
if(me&&document.getElementById('app').classList.contains('on')){try{render()}catch(e){}}
})();
