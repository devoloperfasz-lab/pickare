/* ===== UI TIDY v4 + GUI palette + script helpers ===== */
(function(){
 /* toolbar: aksi utama selalu terlihat di kanan */
 const tb=$('#etb'),l=document.createElement('div'),r=document.createElement('div');l.id='etl';r.id='etr';
 [...tb.children].forEach(c=>{const a=c.dataset&&c.dataset.a;if(c.tagName=='SPAN'&&c.style.flex){c.remove();return}
  if(['edtest','edsave','edpub'].includes(a))r.appendChild(c);else l.appendChild(c)});
 tb.append(l,r);
 const tbxb=$('#tbxb'),gb=$('#guib');if(tbxb){tbxb.textContent='';tbxb.title='Toolbox'}if(gb)gb.title='Editor GUI';
 /* panel kanan: tab Explorer / Properti */
 $('#rgt').insertAdjacentHTML('afterbegin','<div id="rtabs"><button data-a="rtab" data-v="expl"> Explorer</button><button data-a="rtab" data-v="props"> Properti</button></div>');
})();
function rtab(v){const g=$('#rgt');g.dataset.t=v;g.querySelectorAll('#rtabs button').forEach(b=>b.classList.toggle('act',b.dataset.v==v))}
rtab('expl');
const _eo4=edOpen;edOpen=function(d,k){_eo4(d,k);rtab('expl')};
const _es4=act.esel;act.esel=function(v){const same=v==SEL&&!SI&&v!='root';_es4(v);if(same)rtab('props')};
const _is4=act.isel;act.isel=function(v){const same=SI==v;_is4(v);if(same)rtab('props')};
$('#guiv').addEventListener('pointerup',e=>{if(e.target.closest&&e.target.closest('[data-gid]')&&SI)rtab('props')});

/* palet GUI di panel kiri saat mode GUI */
let tbxMode;
const _tr4=tbxRender;
tbxRender=function(){if(ST&&ST.kind=='g'&&guiOn){
  $('#tbx').innerHTML='<h4>GUI</h4><div class="tg">'+['Frame','ScrollingFrame','TextLabel','TextButton','TextBox'].map(c=>`<button class="btn sm" data-a="gadd" data-v="${c}">${CL[c]}<br>${c=='ScrollingFrame'?'Scroll':c}</button>`).join('')+'</div><button class="btn sm w g" data-a="gadd" data-v="ScreenGui">＋ ScreenGui</button><h4>Script</h4><button class="btn sm w" data-a="gadd" data-v="LocalScript"> LocalScript</button><div class="hint">Ketuk elemen untuk pilih · seret untuk geser · kotak pink = ubah ukuran · ketuk elemen terpilih lagi / tab Properti untuk edit.</div>';return}
 _tr4();document.querySelectorAll('#tbx [data-a=ins]').forEach(b=>{b.innerHTML=b.innerHTML.replace('SpawnLocation','Spawn')})};
const _gr4=guiRefresh;guiRefresh=function(){_gr4();const k=!!(ST&&ST.kind=='g'&&guiOn);if(k!==tbxMode){tbxMode=k;if(ST)tbxRender()}};
function findPar(list,t){for(const i of list){if(i.ch.includes(t))return i;const r=findPar(i.ch,t);if(r)return r}return null}
act.gadd=function(cls){if(!ST||ST.kind!='g')return;ensureSvc(ST.d);const sg=ST.d.svc.StarterGui;XP.StarterGui=1;
 if(cls=='ScreenGui'){const i=newI(cls);i.n='ScreenGui'+(sg.filter(x=>x.cls=='ScreenGui').length+1);sg.push(i);return afterIns(i)}
 let par=null;const sel=SI&&loc(SI);
 if(sel){par=['ScreenGui','Frame','ScrollingFrame'].includes(sel.i.cls)?sel.i:findPar(sg,sel.i)}
 if(!par||!['ScreenGui','Frame','ScrollingFrame'].includes(par.cls))par=sg.find(x=>x.cls=='ScreenGui');
 if(!par){par=newI('ScreenGui');sg.push(par)}
 const i=newI(cls),n=par.ch.length;if(i.p){i.p[1]=20+n*16;i.p[3]=20+n*16}par.ch.push(i);afterIns(i);slog('+ '+cls)};

/* editor script: bar simbol + referensi */
const _so4=sedOpen;sedOpen=function(i){_so4(i);const m=$('#sed');if(!m)return;
 const keys=['  ','(',')','{','}','[',']','"',"'",'=','==','~=','.',':',',','..','#','+','-','*','/','end','then','do','local','function','if','else','for','while','return','print()'];
 m.querySelector('.sh').insertAdjacentHTML('beforeend','<button class="btn sm" data-a="sref">Ref</button>');
 m.querySelector('.sb').insertAdjacentHTML('beforebegin','<div id="ssn">'+keys.map(k=>`<button class="btn sm" data-a="sins" data-v="${esc(k)}">${k=='  '?'⇥':esc(k)}</button>`).join('')+'</div>');
 m.insertAdjacentHTML('beforeend','<div id="sref"><b>Referensi Luau Pickare</b><br><code>print(...)</code> <code>wait(s)</code> <code>task.spawn/delay</code> <code>pcall</code> <code>require(m)</code><br><code>game:GetService("Players").LocalPlayer</code> → <code>.Character.HumanoidRootPart.Position</code>, <code>.PlayerGui</code><br><code>workspace:FindFirstChild("Nama")</code> → <code>.Touched:Connect(f)</code>, <code>.Color</code>, <code>.Position</code>, <code>.Transparency</code><br><code>Instance.new("TextLabel", parent)</code> (ScreenGui, Frame, TextLabel, TextButton, TextBox, Part, Folder)<br>GUI: <code>.Text</code> <code>.Visible</code> <code>.BackgroundColor3</code> <code>.Position</code> <code>.Size</code> <code>.MouseButton1Click:Connect(f)</code><br>GUI lanjut: <code>.Font = Enum.Font.GothamBold</code> <code>.TextXAlignment</code> <code>.AnchorPoint = Vector2.new(.5,.5)</code> <code>.ZIndex</code> <code>.BorderSizePixel</code> <code>.PlaceholderText</code><br>Layout: <code>Instance.new("UIListLayout", frame)</code> <code>UIGridLayout</code> <code>UIPadding</code> <code>UICorner</code> <code>UIStroke</code><br><code>TweenService:Create(gui, TweenInfo.new(0.3), {Size = UDim2.new(...)}):Play()</code><br><code>player.UserId</code> <code>Players:GetPlayerByUserId(id)</code> <code>Players:GetNameFromUserIdAsync(id)</code><br><code>Vector3.new</code> <code>Color3.fromRGB</code> <code>UDim2.new</code><br><code>Color3.fromHSV</code> <code>Vector2.new</code> <code>Enum.Font.X</code><br><code>RunService.Heartbeat:Connect(function(dt)</code><br><code>math</code> <code>string</code> <code>table</code> <code>os.time()</code> · operator <code>+=</code> <code>continue</code> <code>if…then…else</code> ekspresi</div>');
 $('#ssn').addEventListener('pointerdown',e=>e.preventDefault());$('#sref').addEventListener('pointerdown',e=>e.stopPropagation())};
act.sref=function(){const e=$('#sref');if(e)e.style.display=e.style.display=='block'?'none':'block'};
act.sins=function(v){const ta=$('#sta');if(!ta)return;ta.focus();ta.setRangeText(v,ta.selectionStart,ta.selectionEnd,'end');if(v=='print()')ta.setSelectionRange(ta.selectionStart-1,ta.selectionStart-1);ta.dispatchEvent(new Event('input'))};

/* perbaikan kecil: Enter di TextBox game tidak mengirim chat; nil eksplisit di tonumber/find/match */
window.addEventListener('keydown',e=>{const a=document.activeElement;if(run&&e.key=='Enter'&&a&&a.tagName=='INPUT'&&a.id!='ci')e.stopImmediatePropagation()},true);
['find','match'].forEach(k=>{const f=STR.get(k);STR.set(k,(...a)=>{const r=f(...a);return r===undefined?[undefined]:r})});
{const f=G.get('tonumber');G.set('tonumber',(v,b)=>{const r=f(v,b);return r===undefined?[undefined]:r})}

/* sanitasi proyek hasil impor (Explorer + script) */
function cleanSvc(s){const out={};SKEYS.forEach(k=>out[k]=[]);if(!s||typeof s!='object')return out;let cnt=0;
 const hx=c=>/^#[0-9a-f]{6}$/i.test(c)?c:'#ffffff',n4=a=>Array.isArray(a)&&a.length==4&&a.every(x=>isFinite(+x))?a.map(Number):[0,0,0,0],
 cl=(i,d)=>{if(!i||typeof i!='object'||!Object.hasOwn(CL,i.cls)||cnt++>300||d>8)return null;const o=newI(i.cls);o.n=String(i.n||i.cls).slice(0,24);
  if(GN[i.cls]){o.vis=i.vis!==false;if(i.cls!='ScreenGui'){o.p=n4(i.p);o.s=n4(i.s);o.bg=hx(i.bg);o.tc=hx(i.tc);o.bt=Math.min(1,Math.max(0,+i.bt||0));o.ts=Math.min(72,Math.max(6,+i.ts||18));o.txt=String(i.txt||'').slice(0,200);o.bd=i.bd!==false;if(FNT[i.f])o.f=i.f;if(i.ta=='l'||i.ta=='r')o.ta=i.ta}}
  if(/Script$/.test(i.cls))o.src=String(i.src||'').slice(0,20000);if(i.cls=='Team')o.tcol=hx(i.tcol);
  o.ch=(Array.isArray(i.ch)?i.ch:[]).map(c=>cl(c,d+1)).filter(Boolean);return o};
 SKEYS.forEach(k=>{out[k]=(Array.isArray(s[k])?s[k]:[]).map(i=>cl(i,0)).filter(Boolean)});return out}
