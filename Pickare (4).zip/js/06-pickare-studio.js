/* ===== PICKARE STUDIO ===== */
let oidn=0;const nid=()=>'o'+Date.now().toString(36)+(++oidn);
const NM={part:'Part',cyl:'Cylinder',ball:'Ball',coin:'PickBux',lava:'Lava',spawn:'SpawnLocation',finish:'Finish'},TI={part:'',cyl:'',ball:'',coin:'',lava:'',spawn:'',finish:''};
const PAL=['#ff90e8','#ffde59','#7df9ff','#b6f25a','#ff9f43','#ffffff'];
function O(t,x,y,z,sx,sy,sz,c,ry){return{id:nid(),t,n:NM[t],x,y,z,sx,sy,sz,ry:ry||0,c:c||'#ffffff',cc:true}}
const f2=v=>+(+v).toFixed(2);
function genObjs(g){const r=rng(g.seed||1),n=g.n||22,a=[O('spawn',0,.2,0,4,.4,4,'#7df9ff')];
 for(let i=0;i<n;i++){const an=i*.42,rad=Math.max(8,17-i*.2),top=.8*(i+1),x=f2(Math.cos(an)*rad),z=f2(Math.sin(an)*rad),fl=i==n-1,w=fl?6:4.2;
  a.push(O(fl?'finish':'part',x,f2(top-.5),z,w,1,w,fl?'#ffc400':PAL[Math.floor(r()*6)]));}
 for(let i=0;i<6;i++){const x=(r()-.5)*70,z=(r()-.5)*70,s=2+r()*3,h=1+r()*2;if(Math.hypot(x,z)<5)continue;a.push(O('part',f2(x),f2(h/2),f2(z),f2(s),f2(h),f2(s),PAL[i%6]))}
 return a}
const GT={
 kosong:{n:'Baseplate Kosong',e:'',f:()=>({objs:[O('spawn',0,.2,0,6,.4,6,'#7df9ff')]})},
 obby:{n:'Obby Spiral',e:'',f:()=>({objs:genObjs({seed:3,n:22})})},
 menara:{n:'Menara Tinggi',e:'',f:()=>({objs:genObjs({seed:7,n:30}),sky:'#ffde59',col:'#ff90e8'})},
 kota:{n:'Kota Mini',e:'',f:()=>{const r=rng(5),a=[O('spawn',0,.2,0,6,.4,6,'#7df9ff')];
  for(let i=0;i<10;i++){const x=Math.round((r()-.5)*40),z=Math.round((r()-.5)*40),h=1+Math.floor(r()*2);if(Math.hypot(x,z)<6)continue;a.push(O('part',x,h/2,z,4,h,4,PAL[i%6]))}
  for(let i=0;i<5;i++)a.push(O(i==4?'finish':'part',22,(i+1)*.8-.4,-14+i*3.5,4,.8,3,i==4?'#ffc400':'#ffde59'));return{objs:a,col:'#7df9ff',sky:'#fff4d6'}}},
 arena:{n:'Arena Lava',e:'',f:()=>{const r=rng(9),a=[O('lava',0,-1,0,140,1,140,'#ff3b3b'),O('spawn',0,.2,0,6,.4,6,'#7df9ff')];let x=0,z=0;
  for(let i=0;i<12;i++){x+=Math.round((r()-.2)*5)+3;z+=Math.round((r()-.5)*6);const y=f2(.4+i*.3);a.push(i==11?O('finish',x,y,z,5,.8,5,'#ffc400'):O('part',x,y,z,3.2,.8,3.2,PAL[i%6]))}
  return{objs:a,base:false,sky:'#ff90e8'}}}};
const AT={
 kosong:{n:'Aksesoris Kosong',e:'',f:()=>[O('part',0,2.9,0,.6,.3,.6,'#ffde59')]},
 mahkota:{n:'Mahkota Emas',e:'',f:()=>[O('cyl',0,2.85,0,1,.3,1,'#ffc400'),O('part',-.35,3.1,0,.2,.3,.2,'#ffc400'),O('part',0,3.15,0,.2,.4,.2,'#ffc400'),O('part',.35,3.1,0,.2,.3,.2,'#ffc400')]},
 kerucut:{n:'Topi Pesta',e:'',f:()=>[O('part',0,2.85,0,.9,.3,.9,'#ff90e8'),O('part',0,3.15,0,.6,.3,.6,'#7df9ff'),O('part',0,3.45,0,.3,.3,.3,'#ffde59')]},
 sayap:{n:'Sayap',e:'',f:()=>[O('part',-.9,1.7,-.45,.15,1.4,1,'#ffffff',20),O('part',.9,1.7,-.45,.15,1.4,1,'#ffffff',-20)]},
 kacamata:{n:'Kacamata',e:'',f:()=>[O('part',0,2.38,.42,.95,.22,.1,'#222222'),O('part',-.2,2.38,.45,.3,.18,.05,'#7df9ff'),O('part',.2,2.38,.45,.3,.18,.05,'#7df9ff')]},
 jubah:{n:'Jubah Merah',e:'',f:()=>[O('part',0,1.15,-.38,1.1,1.7,.1,'#ff3b3b')]}};

function mkObj(o){let m;
 if(o.t=='coin'){m=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.14,6),mat('#00d4ff'));m.rotation.x=Math.PI/2;m.position.set(o.x,o.y,o.z);m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),EL));m.userData={o,y:o.y};return m}
 const g=o.t=='cyl'?new THREE.CylinderGeometry(.5,.5,1,20):o.t=='ball'?new THREE.SphereGeometry(.5,16,12):new THREE.BoxGeometry(1,1,1);
 m=new THREE.Mesh(g,mat(o.c||'#ffffff'));if(o.t!='ball'&&o.t!='cyl')m.add(new THREE.LineSegments(new THREE.EdgesGeometry(g),EL));place(m,o);m.userData={o};return m}
function place(m,o){m.position.set(o.x,o.y,o.z);if(o.t!='coin'){m.scale.set(o.sx,o.sy,o.sz);m.rotation.order='YXZ';m.rotation.set((o.rx||0)*Math.PI/180,o.ry*Math.PI/180,(o.rz||0)*Math.PI/180)}}
function buildW(g){scene=new THREE.Scene();scene.background=new THREE.Color(g.sky);scene.fog=new THREE.Fog(g.sky,40,140);
 scene.add(new THREE.HemisphereLight(0xffffff,0x998877,1));const d=new THREE.DirectionalLight(0xffffff,.5);d.position.set(30,50,20);scene.add(d);
 baseOn=g.base!==false;if(baseOn){const gr=new THREE.Mesh(new THREE.PlaneGeometry(100,100),mat(g.col));gr.rotation.x=-Math.PI/2;scene.add(gr);
  const gh=new THREE.GridHelper(100,50,0x000000,0x000000);gh.material.transparent=true;gh.material.opacity=.25;gh.position.y=.02;scene.add(gh)}
 boxes=[];coins=[];lavas=[];pts=[];SP={x:0,y:2,z:0};let sd=false;
 (g.objs||genObjs(g)).forEach(o=>{if(o.t=='coin')return;const m=mkObj(o);scene.add(m);
  const a=o.ry*Math.PI/180,c=Math.abs(Math.cos(a)),s=Math.abs(Math.sin(a)),b={x:o.x,z:o.z,hw:(c*o.sx+s*o.sz)/2,hd:(s*o.sx+c*o.sz)/2,top:o.y+o.sy/2,bot:o.y-o.sy/2,fl:o.t=='finish'};
  if(o.t=='ball'||o.t=='cyl'){b.sh=o.t;b.rx=o.sx/2;b.rz=o.sz/2;b.cy=o.y;b.ry=o.sy/2;b.ca=Math.cos(a);b.sa=Math.sin(a)}
  if(o.t=='lava')lavas.push(b);else if(o.cc!==false)boxes.push(b);
  if(o.t=='spawn'&&!sd){sd=true;SP={x:o.x,y:b.top+1,z:o.z}}})}
function genKey(){let a=new Uint8Array(12);try{crypto.getRandomValues(a)}catch(e){for(let i=0;i<12;i++)a[i]=Math.random()*256|0}return 'spk_'+Array.from(a).map(b=>b.toString(16).padStart(2,'0')).join('')}

/* ---- dashboard ---- */
function accHTML(){const it=me.items||[];return '<div class="card" style="margin-top:16px"><label>Aksesoris Saya</label><br>'+(it.length?it.map(i=>{const on=(me.av.acc||[]).includes(i.id);return `<button class="btn ${on?'g':''}" style="margin:8px 8px 0 0" data-a="acc" data-v="${i.id}">${on?'✓ ':''}${esc(i.name)}</button>`}).join(''):'<div style="margin-top:6px;font-size:13px">Belum ada. Buat di tab Studio</div>')+'</div>'}
function dash(){me.items=me.items||[];if(!me.apiKey){me.apiKey=genKey();save()}
 const tc=(k,T,a,i)=>`<div class="card gcard" style="animation-delay:${i*50}ms"><div class="th" style="background-color:${PAL[i%6]}"><span>${T.e}</span></div><div class="in"><b>${T.n}</b><button class="btn w g" style="margin-top:8px" data-a="${a}" data-v="${k}">+ Pakai</button></div></div>`;
 const gl=Object.keys(GT).map((k,i)=>tc(k,GT[k],'newg',i)).join(''),al=Object.keys(AT).map((k,i)=>tc(k,AT[k],'newa',i)).join('');
 const bt=(id,k)=>`<button class="btn sm g" data-a="edopen" data-v="${id}" data-k="${k}">Edit</button> `+(k=='g'?`<button class="btn sm" data-a="play" data-v="${id}">▶</button> `:'')+`<button class="btn sm c" data-a="exp" data-v="${id}" data-k="${k}">Ekspor</button> <button class="btn sm o" data-a="del" data-v="${id}" data-k="${k}">Hapus</button>`;
 const rows=me.games.map(g=>`<div class="card row" style="flex-wrap:wrap"><div style="font-size:30px;width:44px;text-align:center">${g.icon?`<img src="${g.icon}" width="44" height="44" style="border:2px solid #000;border-radius:8px;display:block">`:g.emoji}</div><div style="flex:1;min-width:120px"><b>${esc(g.name)}</b><br><small>${g.pub===false?'Draft':'Published'} · ${g.objs?g.objs.length:'-'} objek</small></div><div>${bt(g.id,'g')}</div></div>`).join('')
  +me.items.map(i=>`<div class="card row" style="flex-wrap:wrap"><div style="font-size:30px;width:44px;text-align:center"></div><div style="flex:1;min-width:120px"><b>${esc(i.name)}</b><br><small>Aksesoris · ${i.objs.length} objek</small></div><div>${bt(i.id,'a')}</div></div>`).join('');
 return `<h2>Pickare Studio</h2><div class="card hero" style="background:var(--v)"><div class="big"></div><h1>Bikin duniamu</h1><p>Susun objek lewat Explorer &amp; Properties, uji langsung, lalu publish. Editor otomatis memakai mode landscape.</p></div>
 <h3 style="margin-top:18px">Proyek Baru · Map</h3><div class="grid">${gl}</div>
 <h3 style="margin-top:18px">Proyek Baru · Aksesoris</h3><div class="grid">${al}</div>
 <h3 style="margin-top:18px">Proyek Saya</h3>${rows||'<div class="note">Belum ada proyek. Pilih template di atas.</div>'}
 <div class="card" style="margin-top:18px"><h3>API Key Creator</h3><p style="margin:0 0 8px;font-size:13px">Identitas kreator akunmu. Tertanam di file ekspor proyek. Tersimpan lokal di perangkat ini.</p><input type="password" id="ak" readonly value="${me.apiKey}"><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm" data-a="keyshow">Lihat</button><button class="btn sm c" data-a="keycopy">Salin</button><button class="btn sm o" data-a="keyregen">Buat Ulang</button><button class="btn sm g" data-a="impb">Impor Proyek</button></div></div>`}

/* ---- editor state ---- */
let ST=null,SR,SS,SC,SEL='root',tool='move',snapV=1,undo=[],meshes={},helper=null,sctl={yaw:.8,pit:.6,dist:36,tx:0,ty:2,tz:0},sdrag=null,svT,edRun=false,edRaf,upk='thumb',pinch=0;const ptr={},rc=new THREE.Raycaster(),sc=$('#scv');
const cur=()=>ST&&ST.d.objs.find(o=>o.id==SEL);
const sn=v=>+(Math.round(v/snapV)*snapV).toFixed(3);
function slog(m){const e=$('#outp'),d=document.createElement('div');d.textContent=m;e.appendChild(d);while(e.children.length>4)e.firstChild.remove();setTimeout(()=>d.remove(),6000)}
function touch(){clearTimeout(svT);svT=setTimeout(save,500)}
function pushUndo(){undo.push(JSON.stringify(ST.d.objs));if(undo.length>40)undo.shift()}
function edOpen(d,kind){if(!d.objs)d.objs=genObjs(d);d.objs=d.objs.filter(o=>o&&o.t!='coin');if(kind=='g'&&d.base==null)d.base=true;
 try{if(!SR){SR=new THREE.WebGLRenderer({canvas:sc,antialias:true});SC=new THREE.PerspectiveCamera(55,1,.1,500)}}catch(e){return toast('Browser tidak mendukung WebGL')}
 ST={d,kind};SEL='root';undo=[];sctl=kind=='a'?{yaw:.6,pit:.25,dist:9,tx:0,ty:1.6,tz:0}:{yaw:.8,pit:.6,dist:36,tx:0,ty:2,tz:0};snapV=kind=='a'?.1:1;$('#snap').value=String(snapV);
 try{const de=document.documentElement,r=(de.requestFullscreen||de.webkitRequestFullscreen).call(de);if(r&&r.catch)r.catch(()=>{})}catch(e){}
 try{const l=screen.orientation.lock('landscape');if(l&&l.catch)l.catch(()=>{})}catch(e){}
 show('ed');act.tool('move');pubLabel();sBuild();tbxRender();eRender();pRender();edRun=true;cancelAnimationFrame(edRaf);edLoop();slog('Proyek dibuka: '+d.name);
 setTimeout(edSize,60)}
function edSize(){if(!SR)return;const v=$('#vp'),w=v.clientWidth,h=v.clientHeight;if(!w||!h)return;SR.setPixelRatio(Math.min(window.devicePixelRatio||1,2));SR.setSize(w,h,false);SC.aspect=w/h;SC.updateProjectionMatrix()}
if(window.ResizeObserver)new ResizeObserver(edSize).observe($('#vp'));window.addEventListener('resize',edSize);window.addEventListener('orientationchange',()=>setTimeout(edSize,250));
function edBack(){show('ed');edRun=true;cancelAnimationFrame(edRaf);edLoop();setTimeout(edSize,60);slog('Kembali dari Test')}
function edLoop(){if(!edRun)return;edRaf=requestAnimationFrame(edLoop);const c=sctl,cp=Math.cos(c.pit);
 SC.position.set(c.tx+Math.sin(c.yaw)*cp*c.dist,c.ty+Math.sin(c.pit)*c.dist,c.tz+Math.cos(c.yaw)*cp*c.dist);SC.lookAt(c.tx,c.ty,c.tz);if(helper)helper.update();SR.render(SS,SC)}
function sBuild(){const d=ST.d,acc=ST.kind=='a';SS=new THREE.Scene();SS.background=new THREE.Color(acc?'#cfeeff':d.sky);
 SS.add(new THREE.HemisphereLight(0xffffff,0x998877,1));const dl=new THREE.DirectionalLight(0xffffff,.5);dl.position.set(30,50,20);SS.add(dl);
 if(acc){SS.add(mkAvatar(me.av,(me.av.acc||[]).filter(i=>i!=d.id)));const gh=new THREE.GridHelper(12,24,0x000000,0x000000);gh.material.transparent=true;gh.material.opacity=.3;SS.add(gh)}
 else{if(d.base!==false){const gr=new THREE.Mesh(new THREE.PlaneGeometry(100,100),mat(d.col));gr.rotation.x=-Math.PI/2;SS.add(gr)}const gh=new THREE.GridHelper(100,50,0x000000,0x000000);gh.material.transparent=true;gh.material.opacity=.25;gh.position.y=.02;SS.add(gh)}
 meshes={};d.objs.forEach(o=>{const m=mkObj(o);SS.add(m);meshes[o.id]=m});selHelper()}
function selHelper(){if(helper){SS.remove(helper);helper=null}const m=meshes[SEL];if(m){helper=new THREE.BoxHelper(m,0xff0066);SS.add(helper)}}
function pubLabel(){const b=$('#pubb'),d=ST.d;b.textContent=ST.kind=='g'?(d.pub===true||(d.pub===undefined)?'Published':'Publish'):' Pakai';$('#etitle').textContent=(ST.kind=='g'?'':' ')+d.name}
/* panels */
function tbxRender(){const g=ST.kind=='g',ins=g?['part','cyl','ball','lava','spawn','finish']:['part','cyl','ball'],T=g?GT:AT;
 $('#tbx').innerHTML='<h4>Sisipkan</h4><div class="tg">'+ins.map(t=>`<button class="btn sm" data-a="ins" data-v="${t}">${TI[t]}<br>${NM[t]}</button>`).join('')+'</div><h4>Template</h4>'+Object.keys(T).map(k=>`<button class="btn sm w" data-a="tpl" data-v="${k}">${T[k].e} ${T[k].n}</button>`).join('')}
function eRender(){const d=ST.d,g=ST.kind=='g';$('#etitle').textContent=(g?'':' ')+d.name;
 $('#expl').innerHTML=`<div class="er ${SEL=='root'?'on':''}" data-a="esel" data-v="root">${g?'':''} <b>${esc(d.name)}</b></div><div class="er ind"> Workspace (${d.objs.length})</div>`+d.objs.map(o=>`<div class="er ind2 ${o.id==SEL?'on':''}" data-a="esel" data-v="${o.id}"><span>${TI[o.t]||''} ${esc(o.n)}</span>${o.id==SEL?`<i data-a="edel" data-v="${o.id}">✕</i>`:''}</div>`).join('')}
function pRender(){const d=ST.d,o=cur(),g=ST.kind=='g';let h='';
 if(!o){h=`<h4>${g?'Game':'Aksesoris'}</h4><label>Nama</label><input type="text" data-p="name" value="${esc(d.name)}" maxlength="22">`;
  if(g){const em=[...new Set([d.emoji,'','','','','','','','','','',''])];
   h+=`<label>Ikon Emoji</label><select data-p="emoji">${em.map(e=>`<option ${e==d.emoji?'selected':''}>${e}</option>`).join('')}</select><label>Warna Tanah</label><input type="color" data-p="col" value="${d.col}"><label>Warna Langit</label><input type="color" data-p="sky" value="${d.sky}"><label class="ck"><input type="checkbox" data-p="base" ${d.base!==false?'checked':''}> Baseplate</label><h4>Aset Gambar</h4><div class="ups"><div>Thumbnail${d.thumb?`<img class="pv" src="${d.thumb}">`:'<div class="pv">16:9</div>'}<button class="btn sm w" data-a="upimg" data-v="thumb">Upload</button></div><div>Icon${d.icon?`<img class="pv" src="${d.icon}">`:'<div class="pv">1:1</div>'}<button class="btn sm w" data-a="upimg" data-v="icon">Upload</button></div></div>`}
  else h+=`<label>Slot</label><select data-p="slot">${['Kepala','Wajah','Leher','Belakang','Pinggang','Bahu','Depan','Perlengkapan','Pakaian','Sepatu','Tubuh','Avatar'].map(s=>`<option ${s==(d.slot=='Alat'?'Perlengkapan':d.slot||'Kepala')?'selected':''}>${s}</option>`).join('')}</select>`;
  h+=`<div style="font-size:11px;margin-top:8px">Pilih objek di Explorer atau ketuk di viewport.</div>`}
 else{const n3=(ps)=>'<div class="v3">'+ps.map(p=>`<input type="number" step="${p=='ry'||p=='rx'||p=='rz'?5:snapV}" data-p="${p}" value="${f2(o[p])}">`).join('')+'</div>';
  h=`<h4>${TI[o.t]} ${esc(NM[o.t]||o.t)}</h4><label>Nama</label><input type="text" data-p="n" value="${esc(o.n)}" maxlength="20"><label>Posisi X Y Z</label>${n3(['x','y','z'])}`;
  if(o.t!='coin')h+=`<label>Ukuran X Y Z</label>${n3(['sx','sy','sz'])}<label>Rotasi X Y Z (derajat)</label>${n3(['rx','ry','rz'])}<label>Warna</label><input type="color" data-p="c" value="${/^#[0-9a-f]{6}$/i.test(o.c)?o.c:'#ffffff'}">`+(o.t=='lava'?'':`<label class="ck"><input type="checkbox" data-p="cc" ${o.cc!==false?'checked':''}> CanCollide</label>`);
  h+=`<div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm c" data-a="edup">⧉ Duplikat</button><button class="btn sm o" data-a="edel" data-v="${o.id}">Hapus</button></div>`}
 $('#props').innerHTML=h}
$('#props').addEventListener('change',e=>{const t=e.target,p=t.dataset&&t.dataset.p;if(!p||!ST)return;pushUndo();const o=cur(),d=ST.d,v=t.type=='checkbox'?t.checked:t.type=='number'?(parseFloat(t.value)||0):t.value;
 if(!o){d[p]=p=='name'?(String(v).trim()||'Tanpa Nama'):v}
 else if(['sx','sy','sz'].includes(p))o[p]=Math.max(.1,v);else if(p=='ry')o[p]=((v%360)+360)%360;else o[p]=p=='n'?(String(v).trim()||'Part'):v;
 touch();sBuild();eRender();if(o&&['x','y','z'].includes(p))pRender()});
/* viewport input */
function ndc(e){const r=sc.getBoundingClientRect();return new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1)}
function pick(e){rc.setFromCamera(ndc(e),SC);const h=rc.intersectObjects(Object.values(meshes),false);return h.length?h[0].object.userData.o:null}
function plane(e,y){rc.setFromCamera(ndc(e),SC);const p=new THREE.Vector3();return rc.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),-y),p)?p:null}
function pdist(){const k=Object.keys(ptr);if(k.length<2)return 0;const a=ptr[k[0]],b=ptr[k[1]];return Math.hypot(a.x-b.x,a.y-b.y)}
function panBy(dx,dy){const k=sctl.dist*.0016,y=sctl.yaw;sctl.tx+=-Math.cos(y)*dx*k-Math.sin(y)*dy*k;sctl.tz+=Math.sin(y)*dx*k-Math.cos(y)*dy*k}
sc.addEventListener('pointerdown',e=>{e.preventDefault();try{sc.setPointerCapture(e.pointerId)}catch(x){}
 ptr[e.pointerId]={x:e.clientX,y:e.clientY};if(Object.keys(ptr).length>1){sdrag=null;pinch=pdist();return}
 if(e.button==2||e.button==1||e.shiftKey){sdrag={m:'pan'};return}
 const o=pick(e);
 if(o){SEL=o.id;selHelper();eRender();pRender();
  if(tool!='select'){const p=plane(e,o.y);sdrag={m:tool,o,ox:p?o.x-p.x:0,oz:p?o.z-p.z:0,mv:0,acc:o.ry,tdy:0,s0:[o.sx,o.sy,o.sz]};return}
  sdrag={m:'orbit',tap:0,mv:0};return}
 sdrag={m:'orbit',tap:1,mv:0}});
sc.addEventListener('pointermove',e=>{const p=ptr[e.pointerId];if(!p)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
 if(Object.keys(ptr).length>1){const d=pdist();if(pinch&&d)sctl.dist=Math.max(3,Math.min(150,sctl.dist*pinch/d));pinch=d;panBy(dx/2,dy/2);return}
 if(!sdrag)return;sdrag.mv=(sdrag.mv||0)+Math.abs(dx)+Math.abs(dy);
 if(sdrag.m=='orbit'){sctl.yaw-=dx*.008;sctl.pit=Math.max(.05,Math.min(1.5,sctl.pit+dy*.008))}
 else if(sdrag.m=='pan')panBy(dx,dy);
 else{const o=sdrag.o;if(!sdrag.u){if(sdrag.mv<5)return;sdrag.u=1;pushUndo()}
  if(sdrag.m=='move'){const q=plane(e,o.y);if(q){o.x=sn(q.x+sdrag.ox);o.z=sn(q.z+sdrag.oz)}}
  else if(sdrag.m=='rot'){sdrag.acc+=dx*.7;o.ry=((Math.round(sdrag.acc/5)*5)%360+360)%360}
  else if(sdrag.m=='scale'){sdrag.tdy+=dy;const f=Math.max(.1,1-sdrag.tdy*.01);o.sx=Math.max(.1,f2(Math.round(sdrag.s0[0]*f*10)/10));o.sy=Math.max(.1,f2(Math.round(sdrag.s0[1]*f*10)/10));o.sz=Math.max(.1,f2(Math.round(sdrag.s0[2]*f*10)/10))}
  place(meshes[o.id],o);if(helper)helper.update()}});
const pup=e=>{if(!ptr[e.pointerId])return;delete ptr[e.pointerId];pinch=0;
 if(!Object.keys(ptr).length&&sdrag){if(sdrag.m=='orbit'&&sdrag.tap&&sdrag.mv<6&&SEL!='root'){SEL='root';selHelper();eRender();pRender()}
  if(sdrag.u){touch();pRender()}sdrag=null}};
sc.addEventListener('pointerup',pup);sc.addEventListener('pointercancel',pup);
sc.addEventListener('wheel',e=>{e.preventDefault();sctl.dist=Math.max(3,Math.min(150,sctl.dist*(1+e.deltaY*.0012)))},{passive:false});
sc.addEventListener('contextmenu',e=>e.preventDefault());
$('#snap').addEventListener('change',e=>{snapV=parseFloat(e.target.value)||1;if(ST)pRender()});
window.addEventListener('keydown',e=>{if(!ST||!$('#ed').classList.contains('on'))return;const tg=document.activeElement&&document.activeElement.tagName;if(tg=='INPUT'||tg=='SELECT')return;const k=e.key.toLowerCase();
 if((k=='delete'||k=='backspace')&&cur())act.edel(SEL);else if((e.ctrlKey||e.metaKey)&&k=='z'){e.preventDefault();act.undo()}else if((e.ctrlKey||e.metaKey)&&k=='d'){e.preventDefault();act.edup()}
 else if(k.length==1&&'1234'.includes(k))act.tool(['select','move','rot','scale'][+k-1])});
/* upload gambar */
$('#fi').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f||!ST)return;if(!/^image\//.test(f.type))return toast('File harus berupa gambar');
 const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const W=upk=='icon'?128:320,H=upk=='icon'?128:180,c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d'),s=Math.max(W/im.width,H/im.height),w=im.width*s,h=im.height*s;
  x.drawImage(im,(W-w)/2,(H-h)/2,w,h);ST.d[upk]=c.toDataURL('image/jpeg',.82);save();pRender();slog('Upload '+upk+' berhasil');toast('Gambar '+(upk=='icon'?'icon':'thumbnail')+' tersimpan')};im.onerror=()=>toast('Gambar tidak valid');im.src=fr.result};fr.readAsDataURL(f)});
/* export / import */
async function expo(rec,kind){const j=JSON.stringify({shinpo:1,kind,by:(me.apiKey||'').slice(0,12),data:rec});
 try{const dl=await claude.use('downloads');if(dl){await dl.save({filename:String(rec.name||'proyek').replace(/\W+/g,'_')+'.pickare.json',data:j});return}}catch(e){}
 try{await navigator.clipboard.writeText(j);toast('JSON proyek disalin ke clipboard')}catch(e){toast('Ekspor tidak tersedia di browser ini')}}
$('#imp').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const fr=new FileReader();
 fr.onload=()=>{try{const j=JSON.parse(fr.result);if(j.shinpo!==1||!j.data||!Array.isArray(j.data.objs))throw 0;const s=j.data,hx=c=>/^#[0-9a-f]{6}$/i.test(c)?c:'#ffffff',nm=v=>isFinite(+v)?+v:0,im=u=>/^data:image\/(jpeg|png);base64,[A-Za-z0-9+\/=]+$/.test(u||'')?u:undefined;
  const d={id:(()=>{const o=String(s.id||''),ex=(me.games||[]).concat(me.items||[]).some(x=>x.id==o);return /^[ci]\d{10,14}$/.test(o)&&!ex?o:(j.kind=='g'?'c':'i')+Date.now()})(),name:String(s.name||'Impor').slice(0,14)+' (impor)',emoji:esc(String(s.emoji||'').slice(0,4)),col:hx(s.col||'#b6f25a'),sky:hx(s.sky||'#7df9ff'),base:s.base!==false,slot:String(s.slot||'Kepala').slice(0,10),seed:1,n:0,pl:1,lk:0,pub:false,by:String(j.by||'').slice(0,12),thumb:im(s.thumb),icon:im(s.icon),
   objs:s.objs.slice(0,400).map(o=>({id:nid(),t:NM[o.t]?o.t:'part',n:String(o.n||'Part').slice(0,20),x:nm(o.x),y:nm(o.y),z:nm(o.z),sx:Math.max(.1,nm(o.sx)||1),sy:Math.max(.1,nm(o.sy)||1),sz:Math.max(.1,nm(o.sz)||1),ry:nm(o.ry),rx:nm(o.rx),rz:nm(o.rz),c:hx(o.c),cc:o.cc!==false})),svc:(typeof cleanSvc=='function'?cleanSvc(s.svc):undefined)};
  if(j.kind=='g'){d.mine=1;me.games.push(d)}else{me.items=me.items||[];me.items.push(d)}save();toast('Proyek diimpor ✓');render()}catch(x){toast('File proyek tidak valid')}};fr.readAsText(f)});
/* aksi */
Object.assign(act,{
 newg(v){const T=GT[v],t=T.f(),g=Object.assign({id:'c'+Date.now(),name:T.n,emoji:T.e,col:'#b6f25a',sky:'#7df9ff',seed:1,n:0,pl:1,lk:0,mine:1,pub:false,base:true},t);me.games.push(g);save();edOpen(g,'g')},
 newa(v){const T=AT[v],i={id:'i'+Date.now(),name:T.n,slot:'Kepala',objs:T.f()};me.items=me.items||[];me.items.push(i);save();edOpen(i,'a')},
 edopen(v,t){const k=t.dataset.k,d=k=='g'?me.games.find(g=>g.id==v):(me.items||[]).find(i=>i.id==v);if(d)edOpen(d,k)},
 del(v,t){if(!t.dataset.arm){t.dataset.arm=1;t.textContent='Yakin?';setTimeout(()=>{delete t.dataset.arm;t.textContent='Hapus'},2500);return}
  if(t.dataset.k=='g')me.games=me.games.filter(g=>g.id!=v);else{me.items=me.items.filter(i=>i.id!=v);me.av.acc=(me.av.acc||[]).filter(i=>i!=v)}save();render()},
 exp(v,t){const k=t.dataset.k,r=k=='g'?me.games.find(g=>g.id==v):me.items.find(i=>i.id==v);if(r)expo(r,k)},
 impb(){$('#imp').click()},
 keyshow(){const i=$('#ak');i.type=i.type=='password'?'text':'password'},
 keycopy(){const i=$('#ak'),old=i.type;i.type='text';i.select();try{document.execCommand('copy')}catch(e){}if(navigator.clipboard)navigator.clipboard.writeText(me.apiKey).catch(()=>{});i.type=old;toast('API key disalin')},
 keyregen(){me.apiKey=genKey();save();render();toast('API key baru dibuat')},
 acc(v){const a=me.av.acc=me.av.acc||[],i=a.indexOf(v);i<0?a.push(v):a.splice(i,1);save();render()},
 tool(v){tool=v;document.querySelectorAll('#etb [data-a=tool]').forEach(b=>b.classList.toggle('on',b.dataset.v==v))},
 esel(v){SEL=v;selHelper();eRender();pRender()},
 ins(v){if(v=='coin')return;pushUndo();const a=ST.kind=='a',k=a?.2:1,d={part:[4,1,4],cyl:[3,1,3],ball:[3,3,3],coin:[1,1,1],lava:[6,.5,6],spawn:[4,.4,4],finish:[5,.8,5]}[v].map(s=>a&&v!='coin'?f2(s*k):s),
  col={lava:'#ff3b3b',spawn:'#7df9ff',finish:'#ffc400',coin:'#00d4ff'}[v]||PAL[Math.random()*6|0],x=a?0:Math.round(sctl.tx),z=a?0:Math.round(sctl.tz),y=a?2.9:(v=='coin'?1.5:f2(d[1]/2)),o=O(v,x,y,z,d[0],d[1],d[2],col);
  ST.d.objs.push(o);SEL=o.id;sBuild();eRender();pRender();touch();slog('+ '+o.n)},
 edel(v){pushUndo();ST.d.objs=ST.d.objs.filter(o=>o.id!=v);SEL='root';sBuild();eRender();pRender();touch();slog('Objek dihapus')},
 edup(){const o=cur();if(!o)return;pushUndo();const c=Object.assign({},o,{id:nid(),x:f2(o.x+Math.max(snapV,.5))});ST.d.objs.push(c);SEL=c.id;sBuild();eRender();pRender();touch()},
 undo(){if(!undo.length)return slog('Tidak ada yang bisa di-undo');ST.d.objs=JSON.parse(undo.pop());if(!cur())SEL='root';sBuild();eRender();pRender();touch()},
 yup(){const o=cur();if(!o)return;pushUndo();o.y=f2(o.y+snapV);place(meshes[o.id],o);if(helper)helper.update();pRender();touch()},
 ydn(){const o=cur();if(!o)return;pushUndo();o.y=f2(o.y-snapV);place(meshes[o.id],o);if(helper)helper.update();pRender();touch()},
 tpl(v){pushUndo();const d=ST.d;if(ST.kind=='g'){const t=GT[v].f();d.objs=t.objs;d.base=t.base!=null?t.base:true;if(t.sky)d.sky=t.sky;if(t.col)d.col=t.col}else d.objs=AT[v].f();SEL='root';sBuild();eRender();pRender();touch();slog('Template diterapkan (bisa Undo)')},
 upimg(v){upk=v;$('#fi').click()},
 edsave(){save();slog('Tersimpan');toast('Proyek tersimpan')},
 edpub(){const d=ST.d;if(ST.kind=='g'){d.pub=d.pub===false;save();pubLabel();toast(d.pub?'Game dipublikasikan! Muncul di Home':'Game kembali menjadi draft');if(d.pub)notify('Game "'+d.name+'" dipublikasikan')}
  else{const a=me.av.acc=me.av.acc||[];if(!a.includes(d.id))a.push(d.id);save();toast('Aksesoris dipakai di avatarmu ');notify('Aksesoris "'+d.name+'" dipakai')}},
 edtest(){save();edRun=false;cancelAnimationFrame(edRaf);if(ST.kind=='g')startGame(ST.d,true);else{forceAcc=(me.av.acc||[]).filter(i=>i!=ST.d.id).concat(ST.d.id);startGame(TESTMAP,true)}},
 edexit(){save();edRun=false;cancelAnimationFrame(edRaf);try{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}try{screen.orientation.unlock()}catch(e){}show('app');page='create';render()}
});
