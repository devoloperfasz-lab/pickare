Object.assign(act,{grolev(v){const r=document.getElementById('pt_r');if(!r)return;r.value=v;act.grole()}});
