(function(){
const ED=$('#ed'),ETB=$('#etb'),EB=$('#ebody'),SPXx=window.SPX,TBL=SPXx.TBL;
const E=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
const rb=(ic,t,a,v,x)=>`<button class="rb ${x||''}" data-a="${a}"${v!=null?` data-v="${E(v)}"`:''} title="${E(t)}"><i>${ico(t)}</i><span>${E(t)}</span></button>`;
const A='#4da3ff',SV=b=>`<svg viewBox="0 0 24 24" fill="none" stroke="#d7dde6" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">${b}</svg>`;
const IC={Select:SV(`<path d="M6 3l12 9-6 1.5L9.5 20z" fill="${A}"/>`),Move:SV('<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>'),Rotate:SV('<path d="M20 12a8 8 0 11-3-6.2M20 4v5h-5"/>'),Scale:SV(`<rect x="4" y="9" width="11" height="11" fill="${A}" fill-opacity=".4"/><path d="M13 11l7-7M15 4h5v5"/>`),Undo:SV('<path d="M9 7L4 12l5 5M4 12h10a6 6 0 010 8"/>'),Naik:SV(`<path d="M12 4l8 10h-5v6H9v-6H4z" fill="${A}" fill-opacity=".5"/>`),Turun:SV(`<path d="M12 20l8-10h-5V4H9v6H4z" fill="${A}" fill-opacity=".5"/>`),Part:SV(`<path d="M12 3l8 4v10l-8 4-8-4V7z" fill="${A}" fill-opacity=".45"/><path d="M4 7l8 4 8-4M12 11v10"/>`),Terrain:SV(`<path d="M2 19l7-12 4 7 3-4 6 9z" fill="#5cc26b" fill-opacity=".6"/>`),Karakter:SV(`<circle cx="12" cy="6" r="3" fill="${A}"/><path d="M12 9v6M7 11h10M12 15l-3 6M12 15l3 6"/>`),GUI:SV(`<rect x="3" y="5" width="18" height="14" rx="2" fill="${A}" fill-opacity=".3"/><path d="M3 9h18M7 13h6"/>`),Script:SV(`<path d="M6 3h9l4 4v14H6z" fill="#6fd37f" fill-opacity=".35"/><path d="M9 11h7M9 15h7"/>`),Material:SV(`<rect x="3" y="5" width="18" height="14" fill="#d9703a" fill-opacity=".5"/><path d="M3 10h18M3 15h18M9 5v5M15 10v5M9 15v4"/>`),Color:SV('<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.6" fill="#ff5a5a"/><circle cx="12" cy="7.5" r="1.6" fill="#ffd54a"/><circle cx="16" cy="10" r="1.6" fill="#5acb6a"/><circle cx="9" cy="15" r="1.6" fill="#4da3ff"/>'),Duplikat:SV(`<rect x="8" y="8" width="12" height="12"/><rect x="4" y="4" width="12" height="12" fill="${A}" fill-opacity=".3"/>`),Hapus:SV('<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>'),Tempel:SV(`<rect x="5" y="5" width="14" height="16" rx="2" fill="${A}" fill-opacity=".3"/><path d="M9 5V3h6v2M9 11h6M9 15h6"/>`),Salin:SV('<rect x="9" y="9" width="11" height="12" rx="1.5"/><path d="M5 15V4a1 1 0 0 1 1-1h9"/>'),Potong:SV('<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><path d="M8 7.5L20 18M8 16.5L20 6"/>'),Toolbox:SV(`<rect x="3" y="8" width="18" height="12" rx="2" fill="#d9703a" fill-opacity=".5"/><path d="M9 8V5h6v3M3 13h18"/>`)};
const ico=t=>IC[t]||IC.Part;
const sp='<div class="rsep"></div>';
const tbi=(cat,list)=>(list||TBL[cat]||[]).map(x=>rb(x.ic,x.n,'rb','tb:'+cat+':'+x.n,'gonly')).join('');
/* ---- pita atas, menu, tab ---- */
const etl=$('#etl'),etr=$('#etr'),title=$('#etitle'),pub=$('#pubb'),snap=$('#snap'),guib=$('#guib'),tbxb=$('#tbxb'),tst=etr.querySelector('[data-a=edtest]'),sav=etr.querySelector('[data-a=edsave]');
const top=document.createElement('div');top.id='rtop';ED.insertBefore(top,ETB);
const back=etl.querySelector('[data-a=edexit]');top.append(back,title,sav,pub);
const MN={File:[['Simpan','edsave'],['Publish / Draft','edpub'],['Keluar Studio','edexit']],
 Edit:[['Undo (Ctrl+Z)','undo'],['Duplikat (Ctrl+D)','edup'],['Hapus','rb','del']],
 Object:[['Part','ins','part'],['Silinder','ins','cyl'],['Bola','ins','ball'],['Spawn','ins','spawn'],['Finish','ins','finish'],['Lava','ins','lava']],
 View:[['Toolbox','tbox'],['Editor GUI','gui'],['Terrain Editor','rb','terp'],['Output','rb','out']],
 Plugins:[['Tidak ada plugin terpasang','rb','noplug']],
 Help:[['Pintasan keyboard','rb','help'],['Referensi Luau','rb','luau']]};
const row=document.createElement('div');row.id='rrow';ED.insertBefore(row,ETB);
row.innerHTML='<div id="rmenu">'+Object.keys(MN).map(k=>`<div class="mn"><b data-a="mnu" data-v="${k}">${k}</b><div class="dd">${MN[k].map(m=>`<button data-a="${m[1]}"${m[2]?` data-v="${m[2]}"`:''}>${m[0]}</button>`).join('')}</div></div>`).join('')+'</div><div id="rtabs2"><b class="on" data-a="rt2" data-v="home">Home</b><b data-a="rt2" data-v="model">Model</b><b class="gonly" data-a="rt2" data-v="avatar">Avatar</b><b class="gonly" data-a="rt2" data-v="ui">UI</b><b class="gonly" data-a="rt2" data-v="script">Script</b></div><div class="go"></div>';
row.querySelector('.go').appendChild(tst);
/* ---- pita ribbon ---- */
const shapes=[['','Part','part'],['','Silinder','cyl'],['⚪','Bola','ball'],['','Lava','lava'],['','Spawn','spawn'],['','Finish','finish']];
ETB.innerHTML='';
const pg=(k,h)=>{const d=document.createElement('div');d.className='rpg'+(k=='home'?' on':'');d.dataset.t=k;d.innerHTML=h;ETB.appendChild(d);return d};
const home=pg('home',rb('','Select','tool','select')+rb('✛','Move','tool','move','on')+rb('⟳','Rotate','tool','rot')+rb('⤢','Scale','tool','scale')+sp+rb('↶','Undo','undo')+rb('','Naik','yup')+rb('','Turun','ydn')+sp+'<div class="rsn"><span>Snap</span></div>'+sp+rb('','Part','ins','part')+rb('','Terrain','rb','terp','gonly')+rb('','Karakter','rb','tb:Rig:Rig R6','gonly')+'<span id="gslot" style="display:contents"></span>'+rb('','Script','rb','add:Script','gonly')+rb('','Material','rb','mat')+'<label class="rb" title="Warna"><i>'+ico('Color')+'</i><span>Color</span><input type="color" id="rcol" value="#ff5a5a" style="position:absolute;opacity:0;inset:0;width:100%;height:100%;cursor:pointer"></label>'+sp+rb('⧉','Duplikat','edup')+rb('','Tempel','pst')+rb('','Salin','cpy')+rb('','Potong','cut')+rb('','Hapus','rb','del')+'<span id="tslot" style="display:contents"></span>');
home.querySelector('.rsn').appendChild(snap);
for(const [b,ic,t,slot] of [[guib,'','GUI','#gslot'],[tbxb,'','Toolbox','#tslot']]){b.className='rb gonly';b.innerHTML=`<i>${ico(t)}</i><span>${t}</span>`;home.querySelector(slot).appendChild(b)}
const mdlp=pg('model','');const avp=pg('avatar','');const uip=pg('ui','');const scp=pg('script','');
const fillTabs=()=>{
 mdlp.innerHTML=shapes.map(s=>rb(s[0],s[1],'ins',s[2])).join('')+sp+tbi('Model')+sp+tbi('Tekstur')+sp+tbi('Efek');
 avp.innerHTML=tbi('Rig');
 uip.innerHTML=rb('','ScreenGui','gadd','ScreenGui')+['Frame','ScrollingFrame','TextLabel','TextButton','TextBox','ImageLabel','ImageButton'].map(c=>rb(CL[c]||'▫',c=='ScrollingFrame'?'Scroll':c.replace('Image','Img'),'gadd',c)).join('')+sp+['UICorner','UIStroke','UIGradient'].map(c=>rb(CL[c]||'▫',c.slice(2),'gadd',c)).join('')+sp+tbi('GUI');
 scp.innerHTML=[['','Script','Script'],['','LocalScript','LocalScript'],['','ModuleScript','ModuleScript'],['','RemoteEvent','RemoteEvent'],['','RemoteFunc','RemoteFunction'],['','BindableEv','BindableEvent'],['','Sound','Sound'],['','Folder','Folder']].map(s=>rb(s[0],s[1],'rb','add:'+s[2])).join('')+sp+tbi('Suara')+sp+tbi('Siap Pakai')};
fillTabs();
/* ---- kolom kiri: Terrain + Toolbox ---- */
const lcol=document.createElement('div');lcol.id='lcol';
lcol.innerHTML='<div id="terp" class="gonly"><div class="phd">Terrain Editor<b data-a="rb" data-v="terp">✕</b></div><div class="tt"><b class="on" data-a="rb" data-v="tt:c">Create</b><b data-a="rb" data-v="tt:e">Edit</b><b data-a="rb" data-v="tt:b">Tipe Brush</b></div><div class="tgr"></div></div><div class="phd">Toolbox<b data-a="tbox" title="Toolbox lengkap"></b></div>';
EB.insertBefore(lcol,EB.firstChild);lcol.appendChild($('#tbx'));
/* ---- tengah: viewport + Output ---- */
const vpc=document.createElement('div');vpc.id='vpc';EB.insertBefore(vpc,$('#rgt'));vpc.appendChild($('#vp'));
const op=document.createElement('div');op.id='opan';op.innerHTML='<div class="phd">Output<span><b data-a="rb" data-v="clr"></b> &nbsp;<b data-a="rb" data-v="out">✕</b></span></div>';op.appendChild($('#outp'));vpc.appendChild(op);
/* ---- kanan: header Explorer / Properti ---- */
$('#expl').insertAdjacentHTML('beforebegin','<div class="phd">Explorer</div>');$('#props').insertAdjacentHTML('beforebegin','<div class="phd">Properti</div>');
/* ---- Output log ---- */
const OUTP=$('#outp');
slog=function(m){const d=document.createElement('div'),s=String(m);d.textContent=s;if(/^Error/.test(s))d.className='er2';else if(/^Peringatan/.test(s))d.className='wr';OUTP.appendChild(d);while(OUTP.children.length>120)OUTP.firstChild.remove();OUTP.scrollTop=OUTP.scrollHeight};
slog('Selamat datang di Pickare Studio');
/* ---- Terrain ---- */
let TT='c';const TR=()=>ST.d.objs.filter(o=>o.n=='Terrain'),trR=()=>{sBuild();eRender();pRender();touch()};
const TG={c:[['','Import',()=>toast('Import heightmap belum didukung')],['','Generate',()=>{pushUndo();const x0=Math.round(sctl.tx),z0=Math.round(sctl.tz);for(let i=-3;i<=3;i++)for(let j=-3;j<=3;j++){const h=Math.max(1,Math.round(3+(Math.sin(i*.9)+Math.cos(j*.7))*1.6)),o=O('part',x0+i*8,h/2,z0+j*8,8,h,8,'#5aa14a',0);o.n='Terrain';o.tex='grass';ST.d.objs.push(o)}trR();slog('Terrain dibuat (49 blok)')}],['','Clean',()=>{if(!TR().length)return toast('Tidak ada Terrain');pushUndo();ST.d.objs=ST.d.objs.filter(o=>o.n!='Terrain');SEL='root';trR();slog('Terrain dibersihkan')}]],
 e:[['','Naikkan',()=>{pushUndo();TR().forEach(o=>{o.sy=f2(o.sy+1);o.y=f2(o.y+.5)});trR()}],['','Turunkan',()=>{pushUndo();TR().forEach(o=>{o.sy=Math.max(1,f2(o.sy-1));o.y=o.sy/2});trR()}],['➖','Ratakan',()=>{const t=TR();if(!t.length)return;pushUndo();t.forEach(o=>{o.sy=3;o.y=1.5});trR()}]],
 b:[['','Rumput',()=>br('#5aa14a','grass')],['','Pasir',()=>br('#e6cf8e','sand')],['','Batu',()=>br('#8a8a8a','stone')],['','Air',()=>br('#3b82f6','water')],['','Salju',()=>br('#f4f8ff','')],['','Tanah',()=>br('#8d5524','')]]};
function br(c,t){if(!TR().length)return toast('Buat Terrain dulu (Generate)');pushUndo();TR().forEach(o=>{o.c=c;o.tex=t});trR()}
const TGR=lcol.querySelector('.tgr');
function drawT(){lcol.querySelectorAll('.tt b').forEach(b=>b.classList.toggle('on',b.dataset.v=='tt:'+TT));TGR.innerHTML=TG[TT].map((x,i)=>`<button data-a="rb" data-v="tf:${i}"><i>${ico(x[1])}</i>${x[1]}</button>`).join('')}drawT();
/* ---- aksi ---- */
const curO=()=>ST&&ST.d.objs.find(o=>o.id==SEL);
const SVCM={Script:'ServerScriptService',LocalScript:'StarterPlayerScripts',ModuleScript:'ReplicatedStorage',RemoteEvent:'ReplicatedStorage',RemoteFunction:'ReplicatedStorage',BindableEvent:'ReplicatedStorage',Sound:'Workspace',Folder:'Workspace'};
function runTB(cat,name){const it=(TBL[cat]||[]).find(x=>x.n==name);if(!it||!ST||ST.kind!='g')return;let r;try{r=it.f()}catch(e){return toast('Gagal menambahkan: '+e.message)}sBuild();
 if(r&&r.cls)afterIns(r);else{if(r&&r.id){SEL=r.id;SI=null;guiOn=false}selHelper();eRender();pRender();guiRefresh();touch()}slog('Toolbox: '+it.n);toast('Ditambahkan: '+it.n)}
function addS(cls){if(!ST||ST.kind!='g')return;try{ensureSvc(ST.d)}catch(e){}const i=SPXx.sadd(SVCM[cls],cls,null,/Script$/.test(cls)&&SRC[cls]?{src:SRC[cls]}:null);afterIns(i);slog(cls+' ditambahkan ke '+SVCM[cls]);toast(cls+' → '+SVCM[cls])}
act.rb=function(v){const a=String(v).split(':');switch(a[0]){
 case'terp':$('#terp').classList.toggle('off');break;case'out':op.classList.toggle('off');break;case'clr':OUTP.innerHTML='';break;
 case'tt':TT=a[1];drawT();break;case'tf':if(ST&&ST.kind=='g')TG[TT][+a[1]][2]();break;
 case'del':{const o=curO();if(!o)return toast('Pilih objek dulu');act.edel(o.id);break}
 case'mat':rtab('props');toast('Atur Tekstur & Warna di panel Properti (pilih objek dulu)');break;
 case'tb':runTB(a[1],a.slice(2).join(':'));break;case'add':addS(a[1]);break;
 case'noplug':toast('Belum ada plugin');break;
 case'help':toast('1-4: alat · Ctrl+Z undo · Ctrl+D duplikat · Ctrl+C salin · Ctrl+X potong · Ctrl+V tempel · Delete hapus');break;
 case'luau':toast('Lihat Referensi Luau di editor Script');break}};
act.rt2=function(v){ETB.querySelectorAll('.rpg').forEach(p=>p.classList.toggle('on',p.dataset.t==v));row.querySelectorAll('#rtabs2 b').forEach(b=>b.classList.toggle('on',b.dataset.v==v))};
act.mnu=function(v,el){const m=el.parentNode,was=m.classList.contains('op');document.querySelectorAll('#rmenu .mn.op').forEach(x=>x.classList.remove('op'));if(!was)m.classList.add('op')};
document.addEventListener('click',e=>{if(!e.target.closest('[data-a=mnu]'))document.querySelectorAll('#rmenu .mn.op').forEach(x=>x.classList.remove('op'))});
$('#rcol').addEventListener('input',e=>{const o=curO();if(!o)return toast('Pilih objek dulu');const el=$('#props [data-p=c]');if(!el)return;el.value=e.target.value;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))});
/* ---- kind accessory + langit viewport ---- */
const _eo=edOpen;edOpen=function(d,k){_eo(d,k);ED.dataset.k=k;if(k!='g')act.rt2('home');fillTabs()};
let skyT=null;const sky=()=>{if(skyT)return skyT;const c=document.createElement('canvas');c.width=4;c.height=256;const x=c.getContext('2d'),g=x.createLinearGradient(0,0,0,256);g.addColorStop(0,'#7e92ab');g.addColorStop(.42,'#c7d0da');g.addColorStop(.5,'#5a5348');g.addColorStop(.56,'#3a3026');g.addColorStop(1,'#271f17');x.fillStyle=g;x.fillRect(0,0,4,256);return skyT=new THREE.CanvasTexture(c)};
const _sb=sBuild;sBuild=function(){_sb();if(ST&&ST.kind=='g'&&SS){try{SS.background=sky();SS.fog=null}catch(e){}}};
})();
