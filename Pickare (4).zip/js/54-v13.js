/* ===== v13: kode redeem global (semua pemain bisa pakai) =====
   Owner menandatangani kode (ECDSA) lalu dikirim ke broker MQTT; pemain memverifikasi dengan public key Owner.
   Kode disimpan sebagai hash (tidak bisa dibaca dari broker). Pemakaian dicatat per akun. */
(function(){
const BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'],CD='pickare/v9/code/',CU='pickare/v9/cuse/',OWN='pickare/v9/own/';
const EC={name:'ECDSA',namedCurve:'P-256'},SG={name:'ECDSA',hash:'SHA-256'},te=s=>new TextEncoder().encode(s);
const b64=u=>{let s='';u.forEach(c=>s+=String.fromCharCode(c));return btoa(s)},unb=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
const sha=async t=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',te(t)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const norm=v=>String(v||'').toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,24);
const mq=()=>window.__spMq,ready=async()=>!!(mq()&&(window.mqtt||await mq().lib()));
const codes=()=>{const c=ls.get('sp_codes',{});return c&&typeof c=='object'&&!Array.isArray(c)?c:{}};
const msgOf=r=>['code',r.h,r.amt,r.max,r.exp,r.c,r.ts,r.del?1:0].join('|');
function collect(topics,ms,cb){return new Promise(async res=>{if(!(await ready()))return res(0);let pend=BR.length;
 BR.forEach(url=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}if(--pend===0)res(1)};
  try{m=mqtt.connect(url,{clientId:'spk_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)res(1);return}
  m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topics,{qos:0});setTimeout(end,ms)});
  m.on('message',(t,b)=>{try{const s=b.toString();if(s)cb(t,JSON.parse(s))}catch(e){}});setTimeout(end,ms+4000)});setTimeout(()=>res(1),ms+6000)})}
async function pin(){let p=ls.get('sp_ownpk',null);if(p)return p;let best=null;await collect([OWN+'pk'],2500,(t,d)=>{if(d&&d.pub&&(!best||d.ts>best.ts))best=d});if(best){ls.set('sp_ownpk',best.pub);return best.pub}return null}
const verify=async(pub,r)=>{try{return await crypto.subtle.verify(SG,await crypto.subtle.importKey('jwk',pub,EC,false,['verify']),unb(r.sig),te(msgOf(r)))}catch(e){return false}};
/* owner: kirim kode */
async function publish(k,d,del){try{const ok=ls.get('sp_okey',null);if(!ok||!ok.priv||!(await ready()))return false;const h=await sha('sp-code|'+k);
 const r={h,amt:d.amt|0,max:d.max|0,exp:d.exp|0,c:d.t|0,ts:Date.now(),del:del?1:0};
 r.sig=b64(new Uint8Array(await crypto.subtle.sign(SG,await crypto.subtle.importKey('jwk',ok.priv,EC,false,['sign']),te(msgOf(r)))));
 const msgs=[{t:CD+h,p:JSON.stringify(r)}];
 if(!del)for(const n of (d.used||[]))msgs.push({t:CU+h+'/'+(await sha('u|'+String(n).toLowerCase())).slice(0,24),p:JSON.stringify({n,ts:Math.max(r.c,Date.now())})});
 return !!(await mq().pushAll(msgs))}catch(e){return false}}
async function pubNew(before){const c=codes();let any=0;for(const k of Object.keys(c)){if(before&&before.has(k))continue;if(c[k].g)continue;
  const ok=await publish(k,c[k],0);if(ok){const c2=codes();if(c2[k]){c2[k].g=1;ls.set('sp_codes',c2)}any=1;try{toast('Kode '+k+' aktif untuk semua pemain ✓')}catch(e){}}
  else try{toast('Kode tersimpan, tapi gagal dikirim ke server. Dicoba lagi otomatis.')}catch(e){}}return any}
/* owner: ambil catatan pemakaian dari semua perangkat */
async function pullUses(){const c=codes(),ks=Object.keys(c);if(!ks.length)return;const H={};for(const k of ks)H[await sha('sp-code|'+k)]=k;let ch=0;
 await collect([CU+'+/+'],3000,(t,d)=>{const h=t.slice(CU.length).split('/')[0],k=H[h];if(!k||!d||!d.n)return;const c2=codes();const x=c2[k];if(!x||(d.ts||0)<(x.t||0))return;x.used=x.used||[];
  if(!x.used.some(n=>String(n).toLowerCase()===String(d.n).toLowerCase())){x.used.push(String(d.n).slice(0,20));ls.set('sp_codes',c2);ch=1}});
 if(ch)try{if(typeof page!=='undefined'&&page==='panel'&&typeof pt!=='undefined'&&pt==='code')render()}catch(e){}}
let busy=0;
async function redeem(){const e=$('#rd_e');if(!e)return;const bad=m=>{e.textContent=m},now=Date.now();
 me.rdf=(me.rdf||[]).filter(t=>now-t<60000);if(me.rdf.length>=5)return bad('Terlalu banyak percobaan. Coba lagi sebentar.');
 const k=norm($('#rd_k').value);if(!k)return bad('Masukkan kodenya dulu');if(busy)return;busy=1;bad('Memeriksa kode...');
 try{const h=await sha('sp-code|'+k);let best=null;const uses={};
  const on=await collect([CD+h,CU+h+'/+'],2500,(t,d)=>{if(t===CD+h){if(d&&d.sig&&(!best||d.ts>best.ts))best=d}else if(d&&d.n)uses[t]=d});
  if(!on)return bad('Tidak ada koneksi internet. Coba lagi.');
  if(!best||best.del||best.h!==h){me.rdf.push(now);save();return bad('Kode tidak valid')}
  const pk=await pin();if(!pk)return bad('Belum bisa memverifikasi kode. Coba lagi sebentar.');
  if(!(await verify(pk,best))){me.rdf.push(now);save();return bad('Kode tidak valid')}
  if(best.exp&&best.exp<now)return bad('Kode sudah kedaluwarsa');
  const nm=me.name.toLowerCase(),L=Object.values(uses).filter(u=>(u.ts||0)>=(best.c||0));me.rdc=me.rdc||[];
  if(me.rdc.includes(h)||L.some(u=>String(u.n).toLowerCase()===nm))return bad('Kamu sudah memakai kode ini');
  if(best.max&&L.length>=best.max)return bad('Kode sudah habis dipakai');
  const amt=Math.max(1,Math.min(1000000,best.amt|0)),un=(await sha('u|'+nm)).slice(0,24);
  me.rdc.push(h);save();
  const ok=await mq().pushAll([{t:CU+h+'/'+un,p:JSON.stringify({n:me.name,ts:Date.now()})}]);
  if(!ok){me.rdc=me.rdc.filter(x=>x!==h);save();return bad('Gagal mencatat pemakaian. Coba lagi.')}
  addBux(amt);notify('Redeem kode '+k+': +'+amt+' PickBux');shClose();toast('+'+amt+' PickBux berhasil ditambahkan');render()
 }catch(x){bad('Terjadi kesalahan. Coba lagi.')}finally{busy=0}}
window.addEventListener('load',()=>setTimeout(()=>{
 act.rdgo=function(){return redeem()};
 const cg=act.cdgo,cdl=act.cddel;
 if(cg)act.cdgo=function(){const b=new Set(Object.keys(codes())),r=cg.apply(this,arguments);setTimeout(()=>pubNew(b),60);return r};
 if(cdl)act.cddel=function(v){const d=codes()[v],r=cdl.apply(this,arguments);if(d&&!codes()[v])publish(v,d,1).then(ok=>{try{toast(ok?'Kode dihapus untuk semua pemain':'Dihapus di sini, gagal dikirim ke server')}catch(e){}});return r};
 const own=()=>typeof me!=='undefined'&&me&&me.role==='owner'&&!document.hidden;
 setTimeout(()=>{if(own()){pubNew(null);pullUses()}},7000);
 setInterval(()=>{if(own()){pubNew(null);pullUses()}},45000);
},0));
})();
