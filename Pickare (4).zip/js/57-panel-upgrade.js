/* ===== v15: Panel — daftar pemain custom (scroll, cari, avatar) + sub-tab Review: Aksesoris / Map / Works ===== */
(function(){
const ID=i=>document.getElementById(i);
const RN2={owner:'OWNER',coowner:'CO-ADMIN',admin:'ADMIN'};
const isStaff=()=>{try{return typeof me!=='undefined'&&!!me&&staff()}catch(e){return false}};
const E=s=>{try{return esc(s)}catch(e){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}};

/* ---------- 1. DAFTAR PEMAIN (menggantikan datalist) ---------- */
let sel={pt_u:'',bu_u:''},scr={pt_u:0,bu_u:0},lastSync=0;
function players(withSelf){
 const out=[];
 for(const k in users){const u=users[k];if(!u)continue;if(u===me&&!withSelf)continue;out.push({k,u,me:u===me})}
 out.sort((a,b)=>(b.me-a.me)||((lvl(b.u))-(lvl(a.u)))||(a.k.toLowerCase()<b.k.toLowerCase()?-1:1));
 return out;
}
function lvl(u){return u.role=='owner'?3:u.role=='coowner'?2:u.role=='admin'?1:0}
function avOfP(k,u){try{return(window.spUI&&spUI.avFor&&spUI.avFor(k))||u.av||null}catch(e){return u.av||null}}
function row(p,on){
 const u=p.u,k=p.k,ver=u.verified||(window.spVerified&&(()=>{try{return spVerified(k)}catch(e){return 0}})());
 const av=(typeof circ==='function')?circ(avOfP(k,u),38):'<span class="pkr-ph">'+E(k.charAt(0).toUpperCase())+'</span>';
 return '<button type="button" class="pkr-row'+(on?' on':'')+'" data-k="'+E(k)+'">'+av
  +'<span class="pkr-n"><b>'+E(k)+(ver?'<i class="pkr-v">✔</i>':'')+(p.me?'<em>(kamu)</em>':'')+'</b>'
  +'<small>'+(RN2[u.role]||'Pemain')+(u.rm?' · online lain':'')+'</small></span>'
  +'<span class="pkr-b">'+(+u.bux||0)+'</span><span class="pkr-ck">✓</span></button>';
}
function build(box,input,withSelf){
 const id=input.id,q=String(input.value||'').trim().replace(/^@/,'').toLowerCase();
 const all=players(withSelf),list=all.filter(p=>!q||p.k.toLowerCase().includes(q));
 const cur=String(input.value||'').trim().toLowerCase();
 const lst=box.querySelector('.pkr-list');
 scr[id]=lst?lst.scrollTop:scr[id];
 box.querySelector('.pkr-list').innerHTML=list.length?list.map(p=>row(p,p.k.toLowerCase()===cur)).join(''):'<div class="pkr-empty">'+(all.length?'Tidak ada pemain yang cocok':'Belum ada pemain')+'</div>';
 box.querySelector('.pkr-cnt').textContent=list.length+(q?' dari '+all.length:'')+' pemain';
 box.querySelector('.pkr-list').scrollTop=scr[id]||0;
}
function enhance(id,withSelf){
 const input=ID(id);if(!input||input.tagName!=='INPUT'||input.dataset.pkr)return;
 input.dataset.pkr='1';input.removeAttribute('list');input.setAttribute('autocomplete','off');
 const dl=ID(id=='pt_u'?'pt_dl':'bu_dl');if(dl)dl.remove();
 if(!input.value&&sel[id]&&users[sel[id]])input.value=sel[id];
 const box=document.createElement('div');box.className='pkr';
 box.innerHTML='<div class="pkr-top"><span class="pkr-cnt"></span>'+(withSelf?'<button type="button" class="pkr-me">Pilih diriku</button>':'')+'</div><div class="pkr-list" role="listbox"></div>';
 input.insertAdjacentElement('afterend',box);
 build(box,input,withSelf);
 input.addEventListener('input',()=>{sel[id]='';build(box,input,withSelf)});
 box.addEventListener('click',e=>{
  const b=e.target.closest('.pkr-row'),m=e.target.closest('.pkr-me');
  if(b){const k=b.dataset.k;sel[id]=k;input.value=k;build(box,input,withSelf);return}
  if(m&&me){sel[id]=me.name;input.value=me.name;build(box,input,withSelf)}
 });
 box.querySelector('.pkr-list').addEventListener('scroll',e=>{scr[id]=e.target.scrollTop},{passive:true});
 /* ambil akun dari perangkat lain, lalu segarkan daftar */
 if(Date.now()-lastSync>30000){lastSync=Date.now();try{window.spDirSync&&spDirSync()}catch(e){}
  setTimeout(()=>{if(document.body.contains(box))build(box,input,withSelf)},3500)}
}
function enhanceAll(){
 if(typeof page==='undefined'||page!=='panel'||!isStaff())return;
 enhance('pt_u',true);enhance('bu_u',false);
}

/* ---------- 2. REVIEW: tombol Aksesoris / Map / Works ---------- */
function installReview(){
 if(typeof RV==='undefined'||!RV||typeof RV.tab!=='function'||RV.__pk)return;RV.__pk=1;
 const _tab=RV.tab,_list=RV.list;
 const isMap=e=>e&&e.k==='map';
 RV.tab=function(t){
  if(t!=='rv')return _tab.apply(this,arguments);
  const all=_list.call(RV),nm=all.filter(isMap).length,na=all.length-nm;
  let f=window.__rvf;if(f!=='acc'&&f!=='map'&&f!=='wk')f=(na>0||nm==0)?'acc':'map';
  const chip=(v,l,n)=>'<button type="button" class="ptb'+(f==v?' on':'')+'" data-a="rvf" data-v="'+v+'">'+l+(n?'<i>'+n+'</i>':'')+'</button>';
  const bar='<div class="rvsub">'+chip('acc','Aksesoris',na)+chip('map','Map',nm)+chip('wk','Works',0)+'</div>';
  if(f==='wk')return bar+RV.worksH();
  RV.list=function(){return _list.apply(this,arguments).filter(e=>f==='map'?isMap(e):!isMap(e))};
  let h;try{h=_tab.call(RV,'rv')}finally{RV.list=_list}
  if(f==='map'&&/empty2/.test(h)&&nm==0)h=h.replace(/<b>[^<]*<\/b><p[^>]*>[^<]*<\/p>/,'<b>Tidak ada map yang menunggu</b><p style="margin:0">Map baru dari pemain muncul di sini sebelum tayang.</p>');
  if(f==='acc'&&/empty2/.test(h)&&na==0)h=h.replace(/<b>[^<]*<\/b><p[^>]*>[^<]*<\/p>/,'<b>Tidak ada aksesoris yang menunggu</b><p style="margin:0">Aksesori, tubuh, avatar, model, dan suara baru muncul di sini sebelum tayang.</p>');
  return bar+h;
 };
 Object.assign(act,{rvf(v){if(!isStaff())return;window.__rvf=(v==='map'||v==='wk')?v:'acc';try{render()}catch(e){}}});
}

/* ---------- 3. gaya ---------- */
const css=document.createElement('style');
css.textContent=`
.pkr{margin:8px 0 12px;border:1px solid rgba(127,127,127,.35);border-radius:14px;overflow:hidden;background:rgba(127,127,127,.07)}
.pkr-top{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px;font-size:12px;font-weight:700;opacity:.85;border-bottom:1px solid rgba(127,127,127,.25)}
.pkr-me{border:0;border-radius:99px;background:#335fff;color:#fff;font:700 12px Inter,sans-serif;padding:6px 12px;cursor:pointer}
.pkr-list{max-height:248px;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;scrollbar-width:thin}
.pkr-row{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;padding:9px 12px;border:0;border-bottom:1px solid rgba(127,127,127,.18);background:transparent;color:inherit;font:inherit;text-align:left;cursor:pointer;min-height:56px}
.pkr-row:last-child{border-bottom:0}
.pkr-row:active{background:rgba(127,127,127,.18)}
.pkr-row.on{background:#335fff;color:#fff}
.pkr-row .circ{flex:0 0 auto}
.pkr-ph{flex:0 0 38px;width:38px;height:38px;border-radius:50%;background:rgba(127,127,127,.35);display:flex;align-items:center;justify-content:center;font-weight:800}
.pkr-n{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.pkr-n b{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pkr-n em{font-style:normal;font-weight:600;font-size:12px;opacity:.7;margin-left:6px}
.pkr-n small{font-size:11px;font-weight:700;opacity:.65;letter-spacing:.3px}
.pkr-v{font-style:normal;display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;border-radius:50%;background:#1d9bf0;color:#fff;font-size:10px;margin-left:5px;vertical-align:middle}
.pkr-b{flex:0 0 auto;font-size:12px;font-weight:800;padding:3px 9px;border-radius:99px;background:rgba(127,127,127,.22)}
.pkr-row.on .pkr-b{background:rgba(255,255,255,.28)}
.pkr-ck{flex:0 0 auto;width:20px;text-align:center;font-weight:900;opacity:0}
.pkr-row.on .pkr-ck{opacity:1}
.pkr-empty{padding:22px 14px;text-align:center;opacity:.65;font-size:14px}
.rvsub{display:flex;gap:6px;margin:0 0 12px;flex-wrap:wrap}
`;
document.head.appendChild(css);

/* ---------- pasang ---------- */
if(typeof render==='function'){const _r=render;render=function(){const r=_r.apply(this,arguments);try{enhanceAll()}catch(e){}return r}}
const iv=setInterval(()=>{if(typeof RV!=='undefined'&&RV){installReview();clearInterval(iv)}},200);
installReview();
})();
