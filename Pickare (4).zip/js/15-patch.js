(function(){
const nf=n=>Number(n||0).toLocaleString('id-ID');
const CAP=8,PSMAX=2,CCOST=100;
Object.assign(IC,{
 pencil:'<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
 copy:'<rect x="8" y="8" width="11" height="12" rx="1.5"/><path d="M5 16V5a1 1 0 0 1 1-1h9"/>',
 up:'<path d="M12 19V5M6 11l6-6 6 6"/>',
 trash:'<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
 img:'<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M5 17l5-4 3 2 3-3 3 3"/>',
 chevd:'<path d="M6 9l6 6 6-6"/>'
});
const emptyPage=m=>`<div class="v8top"><button class="rb" data-a="ovb" aria-label="Kembali">${ico('back',28)}</button></div><div class="empty">${m}</div>`;
const gBg=g=>{const t=okImg(g.thumb),ic=okImg(g.icon);return ic?`url(${ic})`:t?`url(${t})`:`linear-gradient(135deg,${hexc(g.col,'#b6f25a')},${hexc(g.sky,'#7df9ff')})`};
const gLetter=g=>okImg(g.icon)||okImg(g.thumb)?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase());

/* ================= SERVER PRIVAT ================= */
const PS=()=>ls.get('sp_ps',{}),PSs=o=>ls.set('sp_ps',o);
function PSmod(id,fn){const o=PS();if(o[id]){fn(o[id]);PSs(o)}}
const canJoin=s=>s.owner==me.name||(s.on&&(s.mem.includes(me.name)||(s.fr&&rel(s.owner)=='friend')));
const inRoom=(gid,room)=>Object.keys(users).filter(k=>{const p=users[k].pres;return p&&p.g==gid&&p.room==room});
let PSJOIN=0;
function avStack(names){if(!names.length)return'<div class="v8av"><small style="grid-column:1/3;align-self:center">Belum ada pemain</small></div>';
 const sh=names.slice(0,names.length>6?5:6);return `<div class="v8av">${sh.map(n=>circ(users[n].av,46)).join('')}${names.length>6?`<span class="more">+${names.length-5}</span>`:''}</div>`}
function srvCard(gid,room,title,idTxt){const p=inRoom(gid,room);
 return `<div class="v8sv">${avStack(p)}<small>${p.length} dari maksimal ${CAP} pemain</small><div class="v8bar"><i style="width:${Math.min(100,p.length/CAP*100)}%"></i></div><button class="v8btn w" data-a="psgo" data-v="${esc(gid)}|${esc(room)}">${p.length>=CAP?'Penuh':'Bergabung'}</button><span class="id">${esc(title)} · ID: ${esc(idTxt)}</span></div>`}
function srvOv(gid){const g=allGames().find(x=>x.id==gid);if(!g)return emptyPage('Game tidak ditemukan.');
 const all=Object.values(PS()),owned=all.filter(s=>s.owner==me.name),
  list=all.filter(s=>s.gid==gid&&(s.owner==me.name||canJoin(s))).sort((a,b)=>(a.owner==me.name?0:1)-(b.owner==me.name?0:1)),
  limit=owned.length>=PSMAX,pf=playingFriends(gid),
  rooms=['publik'];Object.keys(users).forEach(k=>{const p=users[k].pres;if(p&&p.g==gid&&p.room&&!String(p.room).startsWith('ps-')&&!rooms.includes(p.room))rooms.push(p.room)});
 const row=s=>{const c=inRoom(gid,'ps-'+s.id).length;return `<div class="v8row"><span class="ic2" style="background-image:${gBg(g)}">${gLetter(g)}</span><span class="tx"><b>${esc(s.name)}</b><small>${c} dari maksimal ${CAP} pemain${s.owner!=me.name?' · oleh '+esc(s.owner):''}${s.owner==me.name&&!s.on?' · Nonaktif':''}</small></span>${s.owner==me.name?`<button class="v8btn" data-a="psc" data-v="${esc(s.id)}" aria-label="Edit">${ico('pencil',20)}</button>`:''}<button class="v8btn bl" data-a="psgo" data-v="${esc(gid)}|ps-${esc(s.id)}">Bergabung</button></div>`};
 return `<div class="v8top"><button class="rb" data-a="ovb" aria-label="Tutup">${ico('x',30)}</button><h2>Server</h2></div><div class="v8b">
 <h3 class="v8h" style="margin-top:6px">Server privatmu</h3><p class="v8p">Bermain di ruangmu sendiri, sendirian atau bersama pengguna yang kamu undang.</p>
 <div class="v8row"><span class="ic2" style="border-radius:50%">${ico('invite',28)}</span><span class="tx"><b>Buat server privat</b><small>${limit?'Batas jumlah server privat tercapai':'Maksimal '+PSMAX+' server ('+owned.length+' terpakai)'}</small></span><button class="v8btn ${limit?'off':''}" data-a="pscreate" data-v="${esc(gid)}">Buat</button></div>
 ${list.map(row).join('')}
 <div class="v8sh"><b>Server yang Ada Teman Saya</b><button class="v8btn" style="background:none" data-a="psref">Refresh ${ico('swap',20)}</button></div>
 ${pf.length?pf.map(n=>`<div class="v8row"><span class="ic2" style="border-radius:50%;background:none">${circ(pinfo(n).av,48)}</span><span class="tx"><b>${esc(n)}</b><small>Sedang bermain</small></span><button class="v8btn bl" data-a="join" data-v="${esc(n)}">Gabung</button></div>`).join(''):'<div class="v8none">Tidak menemukan server.</div>'}
 <div class="v8sh"><b>Layanan Lainnya</b><button class="v8btn" style="background:none" data-a="psref">Refresh ${ico('swap',20)}</button></div>
 <div class="v8g" style="margin-top:12px">${rooms.map(r=>srvCard(gid,r,r=='publik'?'Server publik':'Server',r)).join('')}</div></div>`}
function pscOv(id){const s=PS()[id];if(!s||s.owner!=me.name)return emptyPage('Server tidak ditemukan.');const g=allGames().find(x=>x.id==s.gid)||{name:'-'};
 const lnk=s.link?location.href.split('#')[0]+'#ps='+s.link:'';
 return `<div class="v8top"><button class="rb" data-a="ovb" aria-label="Kembali">${ico('back',28)}</button><h2>Konfigurasi Server Privat</h2></div><div class="v8b">
 <div class="v8sq" style="background-image:${gBg(g)}">${gLetter(g)}</div>
 <div class="v8kv"><span>Nama Server</span><b><em>${esc(s.name)}</em><button class="v8ico" data-a="psren" data-v="${esc(id)}" aria-label="Ubah nama">${ico('pencil',22)}</button></b></div>
 <div class="v8kv"><span>Pengalaman Virtual</span><b><em>${esc(g.name)}</em></b></div>
 <div class="v8kv"><span>Harga Subscription</span><b>Gratis</b></div>
 <div class="v8box"><div class="hd">Izinkan Bergabung<button class="v8sw ${s.on?'on':''}" data-a="pson" data-v="${esc(id)}" aria-label="Izinkan bergabung"></button></div><p>Menonaktifkan ini akan membuat server privat tidak dapat diakses untuk kamu dan pengguna lain yang telah kamu undang ke server privat ini dan akan membatalkan kode tautan saat ini. Kamu dapat mengaktifkan kembali server privat kapan saja.</p></div>
 <div class="v8box"><div class="hd">Teman Diizinkan<button class="v8sw ${s.fr?'on':''}" data-a="psfr" data-v="${esc(id)}" aria-label="Teman diizinkan"></button></div><hr>
  <div class="hd">Anggota Server<button class="v8btn" data-a="psadd" data-v="${esc(id)}">Tambahkan Pengguna</button></div>
  ${s.mem.length?s.mem.map(n=>`<div class="v8row"><span class="ic2" style="border-radius:50%;background:none">${circ(pinfo(n)?pinfo(n).av:undefined,44)}</span><span class="tx"><b>${esc(n)}${users[n]?vb(users[n]):''}</b></span><button class="v8btn dg" data-a="psrm" data-v="${esc(id)}|${esc(n)}">Hapus</button></div>`).join(''):'<p style="color:var(--mut);margin:12px 0 0">Tidak ada</p>'}<hr>
  <div class="hd">Tautan Server Privat<button class="v8btn" data-a="pslink" data-v="${esc(id)}">${s.link?'Buat Ulang':'Buat'}</button></div>
  <div class="v8kv" style="border:1px solid #5a3236;border-radius:12px;padding:12px 14px;margin-top:12px"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1;font-size:14px">${s.link?esc(lnk):'Bergabung ke Tautan Pengalaman Virtual...'}</span><button class="v8ico" data-a="pscopy" data-v="${esc(id)}" aria-label="Salin">${ico('copy',22)}</button></div>
  <p style="margin-top:10px;font-size:13px;color:var(--mut)">Server privat tersimpan di perangkat ini. Tautan berlaku untuk akun yang membukanya di perangkat yang sama.</p></div>
 <button class="v8btn dg w" data-a="psdel" data-v="${esc(id)}">${ico('trash',20)} Hapus Server</button></div>`}
function psRef(){ovRender()}
Object.assign(act,{
 srv(gid){ovOpen('srv',gid)},
 psref(){ovRender();toast('Daftar server diperbarui')},
 psc(id){ovOpen('psc',id)},
 pscreate(gid){const o=PS();if(Object.values(o).filter(s=>s.owner==me.name).length>=PSMAX)return toast('Batas jumlah server privat tercapai');
  const id=Math.random().toString(36).slice(2,8);o[id]={id,gid,owner:me.name,name:'Server '+me.name,on:true,fr:false,mem:[],link:'',t:Date.now()};PSs(o);toast('Servermu berhasil dibuat');ovRender()},
 psgo(v){const i=v.indexOf('|'),gid=v.slice(0,i),room=v.slice(i+1),g=allGames().find(x=>x.id==gid);if(!g)return toast('Game tidak ditemukan');
  if(room.startsWith('ps-')){const s=PS()[room.slice(3)];if(!s||!canJoin(s))return toast('Kamu tidak diizinkan masuk ke server ini')}
  else if(inRoom(gid,room).filter(n=>n!=me.name).length>=CAP)return toast('Server penuh');
  roomCode=room;save();PSJOIN=1;act.play(gid)},
 psren(id){const s=PS()[id];if(!s)return;shOpen(`<div class="shn" style="margin-top:6px">Nama Server</div><input class="shin" id="v8nm" type="text" maxlength="30" value="${esc(s.name)}" autocomplete="off"><button class="sb pr" data-a="psrens" data-v="${esc(id)}">Simpan</button><button class="sb ln" data-a="shx">Batal</button>`)},
 psrens(id){const el=$('#v8nm'),n=(el&&el.value||'').trim();if(n.length<3)return toast('Nama minimal 3 huruf');PSmod(id,s=>s.name=n);shClose();toast('Nama server disimpan');ovRender()},
 pson(id){PSmod(id,s=>{s.on=!s.on;if(!s.on)s.link=''});toast(PS()[id].on?'Server dapat dimasuki':'Server dinonaktifkan, tautan dibatalkan');ovRender()},
 psfr(id){PSmod(id,s=>s.fr=!s.fr);toast(PS()[id].fr?'Semua temanmu boleh bergabung':'Hanya anggota yang boleh bergabung');ovRender()},
 psadd(id){shOpen(`<div class="shn" style="margin-top:6px">Tambahkan Pengguna</div><input class="shin" id="v8aq" data-id="${esc(id)}" placeholder="Cari username" autocomplete="off" autocapitalize="none" maxlength="20"><div id="v8al">${addList(id,'')}</div><button class="sb ln" data-a="shx">Tutup</button>`)},
 psaddu(v){const i=v.indexOf('|'),id=v.slice(0,i),n=v.slice(i+1);const s=PS()[id];if(!s||!users[n])return;if(!s.mem.includes(n)){PSmod(id,x=>x.mem.push(n));pushNote(users[n],me.name+' mengundangmu ke server privat "'+s.name+'"')}toast(n+' ditambahkan');const q=$('#v8aq'),l=$('#v8al');if(l)l.innerHTML=addList(id,q?q.value:'');ovRender()},
 psrm(v){const i=v.indexOf('|'),id=v.slice(0,i),n=v.slice(i+1);PSmod(id,s=>s.mem=s.mem.filter(x=>x!=n));toast(n+' dihapus dari server');ovRender()},
 pslink(id){PSmod(id,s=>{if(!s.on)return;s.link=Math.random().toString(36).slice(2,10)});if(!PS()[id].on)return toast('Aktifkan "Izinkan Bergabung" dulu');toast('Tautan server dibuat');ovRender()},
 pscopy(id){const s=PS()[id];if(!s||!s.link)return toast('Buat tautan dulu');const t=location.href.split('#')[0]+'#ps='+s.link;try{navigator.clipboard.writeText(t)}catch(e){}toast('Tautan disalin')},
 psdel(id){const s=PS()[id];if(!s)return;shOpen(`<div class="shn" style="margin-top:6px">Hapus "${esc(s.name)}"?</div><p class="v8p" style="text-align:center">Server dan tautannya akan dihapus permanen.</p><button class="sb" style="color:#ff9aa0" data-a="psdel2" data-v="${esc(id)}">Hapus Server</button><button class="sb ln" data-a="shx">Batal</button>`)},
 psdel2(id){const o=PS();delete o[id];PSs(o);shClose();OVS.pop();ovRender();toast('Server dihapus')},
 gmenu(){const tp=OVS[OVS.length-1],id=tp&&tp.t=='game'?tp.a:'';shOpen(`<div class="shn" style="margin-top:6px">Opsi</div><button class="sb" data-a="srv" data-v="${esc(id)}">Server</button><button class="sb" data-a="gcpid" data-v="${esc(id)}">Salin ID game</button>${(me.games||[]).some(g=>g.id==id)?`<button class="sb" data-a="shshare" data-v="${esc(id)}">Bagikan ke teman</button>`:''}<button class="sb ln" data-a="shx">Tutup</button>`)},
 gcpid(id){try{navigator.clipboard.writeText(id)}catch(e){}shClose();toast('ID game disalin')}
});
function addList(id,q){const s=PS()[id];q=String(q||'').trim().toLowerCase();const f=FRD(me).f;
 const l=allPeople().filter(n=>users[n]&&!s.mem.includes(n)&&n!=s.owner&&(!q||n.toLowerCase().includes(q))).sort((a,b)=>f.includes(b)-f.includes(a)).slice(0,30);
 return l.length?l.map(n=>`<div class="ur"><span class="ura">${circ(users[n].av,44)}<span><b>${esc(n)}${vb(users[n])}</b><small>${f.includes(n)?'Teman':subOf(n)}</small></span></span><button class="ub bl" data-a="psaddu" data-v="${esc(id)}|${esc(n)}">Tambah</button></div>`).join(''):'<div class="empty">Pengguna tidak ditemukan.</div>'}
const _pl8=act.play;act.play=function(v,t){if(!PSJOIN){roomCode='publik';save()}PSJOIN=0;return _pl8.call(act,v,t)};
const _jn8=act.join;act.join=function(n){const ps=presOf(n),r=ps&&ps.room;if(r&&String(r).startsWith('ps-')){const s=PS()[String(r).slice(3)];if(s&&!canJoin(s))return toast('Server privat: kamu belum diizinkan masuk')}return _jn8.call(act,n)};
function hashPS(){const m=/#ps=([a-z0-9]+)/i.exec(location.hash||'');if(!m||!me)return;try{history.replaceState(null,'',location.pathname+location.search)}catch(e){}
 const s=Object.values(PS()).find(x=>x.link&&x.link==m[1]);if(!s)return toast('Tautan server tidak valid atau sudah diganti');if(!s.on&&s.owner!=me.name)return toast('Server privat sedang dinonaktifkan');
 if(s.owner!=me.name&&!s.mem.includes(me.name)){PSmod(s.id,x=>x.mem.push(me.name));if(users[s.owner])pushNote(users[s.owner],me.name+' bergabung ke servermu "'+s.name+'"')}
 ovOpen('srv',s.gid);toast('Kamu diizinkan masuk ke "'+s.name+'"')}
window.addEventListener('hashchange',hashPS);

/* ================= DETAIL GAME ================= */
const _go8=gameOv;
gameOv=function(id){let h=_go8(id);
 h=h.replace(/<div class="irow"><span>Kode room<\/span><b>[^<]*<\/b><\/div>/,`<button class="irow v8lnk" data-a="srv" data-v="${esc(id)}"><span>Server</span><b>Lihat ${ico('chev',18)}</b></button>`);
 h=h.replace('data-a="gmenu" aria-label="Undang"',`data-a="srv" data-v="${esc(id)}" aria-label="Server"`);return h};

/* ================= BERANDA ================= */
const _hm8=homeH;
homeH=function(){return _hm8.apply(this,arguments).replace(/<h3 class="sec">Mabar bareng teman<\/h3>[\s\S]*$/,'')};

/* ================= BELI PICKBUX ================= */
const PK=[[80,'Rp 18 rb'],[400,'Rp 90 rb'],[800,'Rp 180 rb'],[1200,'Rp 249 rb'],[1700,'Rp 360 rb'],[3150,'Rp 599 rb'],[4500,'Rp 900 rb'],[10000,'Rp 1,799 jt'],[22500,'Rp 3,599 jt']].reverse();
function shopOv(){const fq=(q,a)=>`<details class="v8fq"><summary>${q}${ico('chevd',22)}</summary><p>${a}</p></details>`;
 return `<div class="v8top"><button class="rb" data-a="ovb" aria-label="Tutup">${ico('x',30)}</button><span class="v8bal">${ico('hex',30)} ${nf(me.bux)}</span><span class="sp"></span><button class="v8btn" data-a="kirim">${ico('up',18)} Kirim</button></div><div class="v8b">
 <h2 class="v8h" style="margin-top:14px">Paket PickBux</h2><p class="v8p">Dengan membeli PickBux, kamu menyetujui aturan komunitas Pickare.</p>
 <div class="v8box" style="padding:6px 18px">${PK.map((p,i)=>`<div class="v8pk"><b>${ico('hex',30)} ${nf(p[0])}</b><button class="pr ${i==PK.length-1?'hi':''}" data-a="pkg" data-v="${p[0]}">${p[1]}</button></div>`).join('')}</div>
 <h2 class="v8h">Cara lain untuk mendapatkan PickBux</h2>
 <div class="v8box"><div class="hd">Bonus Harian</div><p>Ambil +50 PickBux gratis setiap hari.</p><button class="v8btn w" style="margin-top:14px" data-a="daily">Ambil Bonus</button></div>
 <div class="v8box"><div class="hd">Kode Redeem</div><p>Punya kode dari Owner atau staf? Tukarkan dengan PickBux.</p><button class="v8btn w" style="margin-top:14px" data-a="redeem">Tukar Kode</button></div>
 <div class="v8box"><div class="hd">Gift Card</div><p>Beli gift card Pickare.</p><button class="v8btn w" style="margin-top:14px" data-a="soon" data-v="Gift Card">Beli</button></div>
 <h2 class="v8h">FAQ</h2>
 ${fq('Apa itu PickBux?','PickBux adalah mata uang di Pickare. Pakai untuk membeli item avatar di Marketplace dan membeli aksesori kreator lain.')}
 ${fq('Di mana PickBux-ku?','Saldomu tampil di pojok atas halaman ini dan di halaman Avatar. Tiap item yang kamu beli masuk ke Inventaris.')}
 ${fq('Apakah PickBux kedaluwarsa?','Tidak. PickBux di akunmu tidak kedaluwarsa.')}</div>`}
Object.assign(act,{
 shop(){ovOpen('shop')},
 pkg(n){shOpen(`<div class="shn" style="margin-top:6px">${nf(n)} PickBux</div><p class="v8p" style="text-align:center;margin-top:8px">Pembayaran uang asli belum tersedia di Pickare. Dapatkan PickBux lewat Bonus Harian atau kode redeem.</p><button class="sb pr" data-a="pkgd">Ambil Bonus Harian</button><button class="sb" data-a="pkgr">Tukar Kode</button><button class="sb ln" data-a="shx">Tutup</button>`)},
 pkgd(){shClose();act.daily()},pkgr(){shClose();act.redeem()},
 kirim(){const fl=FRD(me).f.filter(n=>users[n]);shOpen(`<div class="shn" style="margin-top:6px">Kirim PickBux</div><p class="v8p">Saldo: ${nf(me.bux)} PickBux. Kamu hanya bisa mengirim ke temanmu.</p><input class="shin" id="v8ku" list="v8kl" placeholder="Username teman" autocomplete="off" autocapitalize="none" maxlength="20"><datalist id="v8kl">${fl.map(n=>`<option value="${esc(n)}">`).join('')}</datalist><input class="shin" id="v8ka" inputmode="numeric" placeholder="Jumlah PickBux" maxlength="9"><button class="sb pr" data-a="kirim2">Kirim</button><button class="sb ln" data-a="shx">Batal</button>`)},
 kirim2(){const n=(($('#v8ku')||{}).value||'').trim().replace(/^@/,''),k=Object.keys(users).find(x=>x.toLowerCase()==n.toLowerCase()),a=Math.floor(+String((($('#v8ka')||{}).value||'')).replace(/\D/g,''));
  if(!k||k==me.name)return toast('Username tidak ditemukan');if(rel(k)!='friend')return toast('Kamu hanya bisa mengirim ke teman');if(!(a>0))return toast('Jumlah tidak valid');if(a>me.bux)return toast('PickBux tidak cukup');
  addBux(-a);users[k].bux=(users[k].bux||0)+a;pushNote(users[k],me.name+' mengirim '+nf(a)+' PickBux kepadamu');notify('Kamu mengirim '+nf(a)+' PickBux ke '+k);save();shClose();toast('Terkirim '+nf(a)+' PickBux ke '+k);ovRender()}
});
addBux=function(n){me.bux+=n;save();const p=document.querySelector('.hb[data-a=shop]');if(p){p.classList.remove('bump');void p.offsetWidth;p.classList.add('bump')}navRender()};
const _bc8=buildChrome;
buildChrome=function(){_bc8.apply(this,arguments);const b=document.querySelector('#app header .hb[data-a=daily]');if(b){b.dataset.a='shop';b.setAttribute('aria-label','Beli PickBux')}};
const _df8=drawerFill;
drawerFill=function(){_df8.apply(this,arguments);const d=$('#dpn');
 const c=[...d.querySelectorAll('.mi')].find(x=>x.dataset.v=='soon:Komunitas');if(c)c.dataset.v='comm';
 const r=d.querySelector('.mi[data-a="redeem"]');if(r)r.insertAdjacentHTML('beforebegin',`<button class="mi" data-a="dnav" data-v="shop">${ico('hex',27)}<span>Beli PickBux</span></button>`)};
const _dn8=act.dnav;
act.dnav=function(v){if(v=='comm'){act.dclose();return act.comm()}if(v=='shop'){act.dclose();return act.shop()}return _dn8.apply(this,arguments)};

/* ================= TERATAS ================= */
const actv=g=>(g.pl||0)+Object.keys(users).filter(k=>users[k].pres&&users[k].pres.g==g.id).length;
function TOPS(k){const gs=pubGames(),vis=ls.get('sp_vis',{}),sc=g=>(vis[g.id]||0)+(g.pl||0);
 if(k=='trend')return{t:'Tren Teratas',l:gs.slice().sort((a,b)=>sc(b)-sc(a)),c:actv,e:''};
 if(k=='new')return{t:'Baru Dirilis',l:gs.map((g,i)=>[g,i]).sort((a,b)=>(b[0].upd||0)-(a[0].upd||0)||b[1]-a[1]).map(x=>x[0]),c:actv,e:''};
 if(k=='active')return{t:'Paling Banyak Dimainkan Sekarang',l:gs.slice().sort((a,b)=>actv(b)-actv(a)),c:actv,e:''};
 return{t:'Lebih Seru Bersama Teman',l:gs.filter(g=>playingFriends(g.id).length),c:g=>playingFriends(g.id).length,e:'Belum ada temanmu yang sedang bermain.'}}
function tcard(g,n){const t=okImg(g.thumb);return `<button class="gc" data-a="gopen" data-v="${esc(g.id)}"><span class="gt" style="background:${t?`url(${t}) center/cover`:`linear-gradient(135deg,${hexc(g.col,'#b6f25a')},${hexc(g.sky,'#7df9ff')})`}">${t?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())}</span><strong>${esc(g.name)}</strong><small>${ico('thumb',15)} ${g.lk>0?(+g.lk)+'%':'Baru'} ${ico('friends',15)} ${fmtN(n)}</small></button>`}
function leaders(){const us=Object.keys(users).filter(k=>!users[k].role&&!banOf(users[k])).sort((a,b)=>(users[b].bux||0)-(users[a].bux||0)).slice(0,10);
 return '<h3 class="sec">Pemain Teratas</h3>'+(us.length?us.map((k,i)=>`<div class="lbr ${i==0?'t1':''}" data-a="prof" data-v="${esc(k)}" style="cursor:pointer"><div class="rank">${i+1}</div>${circ(users[k].av,36)}<b>${esc(k)}${vb(users[k])}${k==me.name?' (kamu)':''}</b><span class="v">${nf(users[k].bux||0)} PickBux</span></div>`).join(''):'<div class="empty2"><p style="margin:0">Belum ada pemain.</p></div>')}
function topV8(){const gs=pubGames();if(!gs.length)return '<h2>Teratas</h2><div class="empty2"><b>Belum ada game</b><p>Belum ada game yang dipublish.</p></div>'+leaders();
 const sec=k=>{const s=TOPS(k);return `<h3 class="sec" data-a="tsec" data-v="${k}" style="cursor:pointer">${s.t} ${ico('chev',20)}</h3>`+(s.l.length?`<div class="hs">${s.l.slice(0,10).map(g=>tcard(g,s.c(g))).join('')}</div>`:`<div class="v8none">${s.e}</div>`)};
 return '<h2>Teratas</h2>'+sec('trend')+sec('new')+sec('active')+sec('fr')+leaders()}
function tsecOv(k){const s=TOPS(k);return `<div class="v8top"><button class="rb" data-a="ovb" aria-label="Kembali">${ico('back',28)}</button><h2>${s.t}</h2></div><div class="v8b">${s.l.length?`<div class="gg" style="margin-top:12px">${s.l.map(g=>tcard(g,s.c(g))).join('')}</div>`:`<div class="v8none">${s.e||'Belum ada game.'}</div>`}</div>`}
act.tsec=function(k){ovOpen('tsec',k)};
const _r9=render;
render=function(){_r9.apply(this,arguments);if(!me)return;if(page=='top'){const m=$('#main');m.innerHTML='<div class="page">'+topV8()+'</div>';navRender()}
 const tp=OVS[OVS.length-1];if(tp&&(tp.t=='shop'||tp.t=='srv'||tp.t=='psc'))ovRender()};

/* ================= KOMUNITAS ================= */
const CM=()=>ls.get('sp_comm',[]),CMs=a=>ls.set('sp_comm',a);
function CMmod(id,fn){const a=CM(),c=a.find(x=>x.id==id);if(c){fn(c);CMs(a)}}
const cmCnt=c=>Object.keys(c.mem).length;
const cmSt=c=>c.mem[me.name]=='owner'?'own':c.mem[me.name]?'mem':(c.pend||[]).includes(me.name)?'pen':'non';
const cmIc=(c,s)=>`<span class="ic2" style="width:${s}px;height:${s}px;${okImg(c.icon)?`background-image:url(${c.icon})`:''}">${okImg(c.icon)?'':esc(c.name.charAt(0).toUpperCase())}</span>`;
let CT='mine',CQ='',CD=null;
const cdNew=()=>{CD={name:'',desc:'',icon:'',cover:'',mode:'open'}};
function cmList(){const q=CQ.trim().toLowerCase(),a=CM().filter(c=>!q||c.name.toLowerCase().includes(q));
 const row=c=>{const s=cmSt(c);return `<button class="v8row v8lnk" data-a="cview" data-v="${esc(c.id)}">${cmIc(c,60)}<span class="tx"><b>${esc(c.name)}</b><small>${nf(cmCnt(c))} anggota</small></span><span class="v8pill ${s=='own'?'own':''}">${s=='own'?'Dimiliki':s=='mem'?'Member':s=='pen'?'Menunggu':'Lihat'}</span></button>`};
 if(CT=='all')return a.length?a.map(row).join(''):'<div class="v8none">Belum ada komunitas.</div>';
 const own=a.filter(c=>cmSt(c)=='own'),mem=a.filter(c=>cmSt(c)=='mem');
 if(!own.length&&!mem.length)return `<div class="empty2"><b>${q?'Tidak ditemukan':'Belum ada komunitas'}</b><p>${q?'Coba kata kunci lain.':'Buat komunitasmu sendiri atau lihat semua komunitas untuk bergabung.'}</p></div>`;
 return (own.length?`<h3 class="v8h">Utama</h3>${own.map(row).join('')}`:'')+(mem.length?`<h3 class="v8h">Komunitas Saya</h3>${mem.map(row).join('')}`:'')}
function commOv(){return `<div class="v8top"><button class="rb" data-a="ovb" aria-label="Kembali">${ico('back',28)}</button><h2>Komunitas</h2><button class="v8btn" style="background:none" data-a="ctab">${CT=='mine'?'Lihat Semua':'Komunitasku'}</button></div><div class="v8b">
 <input class="shin" id="v8cq" type="text" placeholder="${CT=='mine'?'Cari Komunitas Saya':'Cari semua komunitas'}" value="${esc(CQ)}" autocomplete="off" maxlength="50" style="padding:15px 16px">
 <button class="v8btn w" style="margin-top:12px" data-a="cnew">Buat Komunitas</button><div id="v8cl">${cmList()}</div></div>`}
function cviewOv(id){const c=CM().find(x=>x.id==id);if(!c)return emptyPage('Komunitas tidak ditemukan.');const s=cmSt(c),ow=users[c.owner],mem=Object.keys(c.mem);
 const act1=s=='own'?`<button class="v8btn dg w" data-a="cdel" data-v="${esc(id)}">${ico('trash',20)} Hapus Komunitas</button>`:s=='mem'?`<button class="v8btn w" data-a="cleave" data-v="${esc(id)}">Keluar dari Komunitas</button>`:s=='pen'?`<button class="v8btn w" data-a="ccancel" data-v="${esc(id)}">Permintaan terkirim · Batalkan</button>`:`<button class="v8btn bl w" data-a="cjoin" data-v="${esc(id)}">${c.mode=='open'?'Bergabung':'Minta Bergabung'}</button>`;
 return `<div class="v8top" style="position:absolute;left:0;right:0;background:none"><button class="rb" data-a="ovb" aria-label="Kembali" style="background:#0007">${ico('back',28)}</button></div><div class="v8cv" style="${okImg(c.cover)?`background-image:url(${c.cover})`:''}"></div><div class="v8b" style="padding-top:0">
 <div class="v8row" style="margin-top:-30px">${cmIc(c,76)}<span class="tx"><b style="font-size:22px;white-space:normal">${esc(c.name)}</b><small>${nf(cmCnt(c))} anggota · oleh ${esc(c.owner)}${ow?vb(ow):''}</small></span></div>
 ${c.desc?`<p class="v8p" style="font-size:16px;color:#f1e4e5;white-space:pre-wrap">${esc(c.desc)}</p>`:''}${act1}
 ${s=='own'&&(c.pend||[]).length?`<h3 class="v8h">Permintaan bergabung</h3>${c.pend.map(n=>`<div class="v8row"><span class="tx"><b>${esc(n)}</b></span><button class="v8btn bl" data-a="cok" data-v="${esc(id)}|${esc(n)}">Terima</button><button class="v8btn" data-a="cno" data-v="${esc(id)}|${esc(n)}">Tolak</button></div>`).join('')}`:''}
 <h3 class="v8h">Anggota</h3>${mem.map(n=>`<div class="v8row"><button class="v8lnk v8row" style="padding:0;flex:1" data-a="prof" data-v="${esc(n)}"><span class="ic2" style="border-radius:50%;background:none;width:44px;height:44px">${circ(pinfo(n)?pinfo(n).av:undefined,44)}</span><span class="tx"><b>${esc(n)}${users[n]?vb(users[n]):''}</b><small>${c.mem[n]=='owner'?'Pemilik':'Member'}</small></span></button>${s=='own'&&c.mem[n]!='owner'?`<button class="v8btn dg" data-a="ckick" data-v="${esc(id)}|${esc(n)}">Keluarkan</button>`:''}</div>`).join('')}</div>`}
function cnewOv(){if(!CD)cdNew();const pv=(k,w,h)=>CD[k]?`<span class="pv" style="width:${w}px;height:${h}px;background-image:url(${CD[k]})"></span>`:`<span class="pv" style="width:${w}px;height:${h}px">${ico('img',34)}</span>`;
 return `<div class="v8top"><button class="rb" data-a="cback" aria-label="Tutup">${ico('x',30)}</button><h2>Buat Komunitas</h2></div><div class="v8b">
 <label>Nama*</label><input class="shin" id="v8cn" type="text" maxlength="50" autocomplete="off" value="${esc(CD.name)}"><div class="v8cnt"><span id="v8k1">${CD.name.length}</span> / 50</div>
 <label>Deskripsi</label><textarea class="shin" id="v8cd" maxlength="1000">${esc(CD.desc)}</textarea><div class="v8cnt"><span id="v8k2">${CD.desc.length}</span> / 1000</div>
 <label>Lambang*</label><button class="v8dz" data-a="cpick" data-v="icon">${pv('icon',110,110)}<span class="t">Pilih gambar dari perangkat kamu</span></button>
 <label>Foto Sampul</label><p class="v8p" style="margin:0 0 8px">Gambar akan dipotong ke 720x228.</p><button class="v8dz" data-a="cpick" data-v="cover">${pv('cover',240,76)}<span class="t">Pilih gambar dari perangkat kamu</span></button>
 <label>Pengaturan</label><div class="v8box" style="padding:0;background:#4a1519"><button class="v8rd ${CD.mode=='open'?'on':''}" data-a="cmode" data-v="open"><i></i>Siapa Pun Dapat Bergabung</button><button class="v8rd ${CD.mode=='manual'?'on':''}" data-a="cmode" data-v="manual"><i></i>Persetujuan Manual</button></div>
 <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px"><button class="v8btn" data-a="cback">Batalkan</button><button class="v8btn bl" data-a="cmake">${ico('hex',20)} ${CCOST}</button></div></div>`}
Object.assign(act,{
 comm(){CT='mine';CQ='';ovOpen('comm')},
 ctab(){CT=CT=='mine'?'all':'mine';CQ='';ovRender(1)},
 cview(id){ovOpen('cview',id)},
 cnew(){cdNew();ovOpen('cnew')},
 cback(){CD=null;OVS.pop();ovRender()},
 cmode(v){CD.mode=v;ovRender()},
 cpick(k){window.V8K=k;$('#v8fi').click()},
 cmake(){if(!CD)return;CD.name=CD.name.trim();if(CD.name.length<3)return toast('Nama komunitas minimal 3 huruf');if(!CD.icon)return toast('Pilih lambang komunitas dulu');if(me.bux<CCOST)return toast('PickBux tidak cukup (butuh '+CCOST+')');
  const id=Math.random().toString(36).slice(2,9),a=CM();addBux(-CCOST);const m={};m[me.name]='owner';a.push({id,name:CD.name,desc:CD.desc.trim(),icon:CD.icon,cover:CD.cover,owner:me.name,mode:CD.mode,mem:m,pend:[],t:Date.now()});CMs(a);notify('Komunitas "'+CD.name+'" dibuat (-'+CCOST+' PickBux)');CD=null;OVS.pop();ovOpen('cview',id);toast('Komunitas berhasil dibuat')},
 cjoin(id){const c=CM().find(x=>x.id==id);if(!c)return;if(c.mode=='open'){CMmod(id,x=>x.mem[me.name]='member');toast('Kamu bergabung ke '+c.name)}else{CMmod(id,x=>{x.pend=x.pend||[];if(!x.pend.includes(me.name))x.pend.push(me.name)});if(users[c.owner])pushNote(users[c.owner],me.name+' ingin bergabung ke "'+c.name+'"');toast('Permintaan dikirim')}ovRender()},
 ccancel(id){CMmod(id,x=>x.pend=(x.pend||[]).filter(n=>n!=me.name));toast('Permintaan dibatalkan');ovRender()},
 cleave(id){CMmod(id,x=>{delete x.mem[me.name]});toast('Kamu keluar dari komunitas');ovRender()},
 cok(v){const i=v.indexOf('|'),id=v.slice(0,i),n=v.slice(i+1);CMmod(id,x=>{x.pend=(x.pend||[]).filter(p=>p!=n);x.mem[n]='member'});if(users[n])pushNote(users[n],'Permintaanmu bergabung ke komunitas diterima');ovRender()},
 cno(v){const i=v.indexOf('|'),id=v.slice(0,i),n=v.slice(i+1);CMmod(id,x=>x.pend=(x.pend||[]).filter(p=>p!=n));ovRender()},
 ckick(v){const i=v.indexOf('|'),id=v.slice(0,i),n=v.slice(i+1);CMmod(id,x=>{delete x.mem[n]});toast(n+' dikeluarkan');ovRender()},
 cdel(id){const c=CM().find(x=>x.id==id);if(!c)return;shOpen(`<div class="shn" style="margin-top:6px">Hapus "${esc(c.name)}"?</div><p class="v8p" style="text-align:center">Komunitas dan semua anggotanya akan dihapus. Biaya pembuatan tidak dikembalikan.</p><button class="sb" style="color:#ff9aa0" data-a="cdel2" data-v="${esc(id)}">Hapus Komunitas</button><button class="sb ln" data-a="shx">Batal</button>`)},
 cdel2(id){CMs(CM().filter(x=>x.id!=id));shClose();OVS.pop();ovRender();toast('Komunitas dihapus')}
});
document.body.insertAdjacentHTML('beforeend','<input type="file" id="v8fi" accept="image/*" hidden>');
function v8img(f,W,H,cb){const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d'),s=Math.max(W/im.width,H/im.height);x.drawImage(im,(W-im.width*s)/2,(H-im.height*s)/2,im.width*s,im.height*s);cb(c.toDataURL('image/jpeg',.82))};im.onerror=()=>toast('Gambar tidak valid');im.src=fr.result};fr.readAsDataURL(f)}
$('#v8fi').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f||!CD)return;if(!/^image\//.test(f.type))return toast('File harus gambar');
 const k=window.V8K;v8img(f,k=='icon'?128:720,k=='icon'?128:228,d=>{CD[k]=d;ovRender()})});
document.addEventListener('input',e=>{const t=e.target;
 if(t.id=='v8cq'){CQ=t.value;const l=$('#v8cl');if(l)l.innerHTML=cmList()}
 if(t.id=='v8cn'&&CD){CD.name=t.value;const k=$('#v8k1');if(k)k.textContent=t.value.length}
 if(t.id=='v8cd'&&CD){CD.desc=t.value;const k=$('#v8k2');if(k)k.textContent=t.value.length}
 if(t.id=='v8aq'){const l=$('#v8al');if(l)l.innerHTML=addList(t.dataset.id,t.value)}});

/* ================= RENDER OVERLAY & MASUK ================= */
const V8={srv:srvOv,psc:pscOv,shop:shopOv,comm:commOv,cview:cviewOv,cnew:cnewOv,tsec:tsecOv};
const _ovr8=ovRender;
ovRender=function(fresh){const tp=OVS[OVS.length-1];if(!tp||!V8[tp.t])return _ovr8.apply(this,arguments);const o=$('#ov'),y=fresh?0:o.scrollTop;o.innerHTML=V8[tp.t](tp.a);o.classList.add('on');o.scrollTop=y};
const _en8=enter;
enter=function(){_en8.apply(this,arguments);setTimeout(hashPS,400)};
if(me&&$('#app').classList.contains('on')){buildChrome();render();hashPS()}
})();
