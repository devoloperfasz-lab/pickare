const $=s=>document.querySelector(s);
const mem={};
const ls={get(k,d){try{const v=localStorage.getItem(k);if(v)return JSON.parse(v)}catch(e){}return k in mem?mem[k]:d},set(k,v){mem[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let users=ls.get('sp_users',null);
if(!users){users=ls.get('bv_users',{});Object.keys(users).forEach(k=>{users[k].bux=users[k].bux||users[k].coins||0})}
let me=null,S=ls.get('sp_set',{sens:5,cam:'third',hq:true}),mode='login',page='home',roomCode=ls.get('sp_room','publik');
const save=()=>{ls.set('sp_users',users);ls.set('sp_set',S);ls.set('sp_room',roomCode)};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const banOf=u=>{const b=u&&u.ban;if(!b)return null;if(b.perm)return b;return b.until&&b.until>Date.now()?b:null};
function toast(t){const e=$('#toast');e.style.display='none';void e.offsetWidth;e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',2400)}
function show(id){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('on'));$('#'+id).classList.add('on')}
function notify(t){me.notes.unshift({t,new:1});save();navRender()}
window.ACC_FEE=1000;
window.accFeeDue=function(d){return d&&d.feePaid?0:window.ACC_FEE};
window.accFeeErr=function(d){const f=window.accFeeDue(d);return f&&(me.bux||0)<f?'Butuh '+f.toLocaleString('id-ID')+' PickBux untuk publish aksesoris (saldomu '+(me.bux||0).toLocaleString('id-ID')+')':''};
window.accFeePay=function(d){const f=window.accFeeDue(d);if(!f)return;addBux(-f);d.feePaid=true;try{notify('Biaya publish "'+d.name+'" -'+f.toLocaleString('id-ID')+' PickBux')}catch(e){}};
function addBux(n){me.bux+=n;save();const p=$('#buxp');p.classList.remove('bump');void p.offsetWidth;p.classList.add('bump');navRender()}

const SKIN=['#ffd7b5','#f1c27d','#c68642','#8d5524','#7df9ff','#b6f25a'],SHIRT=['#ff90e8','#ffde59','#7df9ff','#b6f25a','#ff5a5a','#ffffff','#333333'],PANTS=['#2b4acb','#222222','#ff9f43','#7a3cff','#3a9d4a','#ffffff'];
const BASE=[];
const TESTMAP={id:'_test',name:'Uji Aksesori',emoji:'',col:'#b6f25a',sky:'#7df9ff',seed:3,n:6};
const allGames=()=>pubGames().concat((me.games||[]).filter(g=>g.pub===false));
const RPUB=[];
window.tkKey=(k,by,id)=>k+'|'+String(by).toLowerCase()+'|'+id;
window.tkBlk=(k,by,id)=>{try{const t=ls.get('sp_tkd',{})[window.tkKey(k,by,id)];return !!(t&&(t.s=='off'||t.s=='banned'||t.s=='del'))}catch(e){return false}};
const pubGames=()=>{const loc=BASE.concat(Object.values(users).filter(u=>!banOf(u)).flatMap(u=>(u.games||[]).filter(g=>g.pub!==false&&!(g.rv&&g.rv.s&&g.rv.s!=='approved')))),ids=new Set(loc.map(g=>g.id));return loc.concat(RPUB.filter(g=>!ids.has(g.id)&&!(g.rv&&g.rv.s&&g.rv.s!=='approved')&&!banOf(users[g.by]))).filter(g=>!(g.by&&window.tkBlk('map',g.by,g.id)))};
function avHTML(a,u=10){return `<div class="av" style="--u:${u}px;--skin:${a.skin};--shirt:${a.shirt};--pants:${a.pants}"><div class="h"><div class="hat ${a.hat}"></div></div><div class="m"><div class="a"></div><div class="t"></div><div class="a"></div></div><div class="l"><i></i><i></i></div></div>`}

document.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(t&&act[t.dataset.a])act[t.dataset.a](t.dataset.v,t)});
const act={
 tab(v,t){mode=v;document.querySelectorAll('.tabs .btn').forEach(b=>b.classList.toggle('act',b===t));$('#go').textContent=v=='login'?'Masuk':'Buat Akun';$('#err').textContent=''},
 auth(){const u=$('#u').value.trim(),p=$('#pw').value,bad=m=>{$('#err').textContent=m;const c=$('#acard');c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')};
  if(mode=='reg'){if(u.length<3)return bad('Username min. 3 karakter');if(p.length<4)return bad('Password min. 4 karakter');if(users[u])return bad('Username sudah dipakai');
   users[u]={pass:p,bux:100,daily:'',av:{skin:SKIN[0],shirt:SHIRT[0],pants:PANTS[0],hat:'none'},games:[],notes:[{t:'Selamat datang di Pickare! Hadiah awal 100 PickBux',new:1}]};save()}
  else if(!users[u]||users[u].pass!==p)return bad('Username atau password salah');
  me=users[u];me.name=u;me.notes=me.notes||[];me.games=me.games||[];ls.set('sp_sess',u);enter()},
 go(v){page=v;thread=null;render()},
 play(v){startGame(allGames().find(g=>g.id===v))},
 av(v,t){me.av[t.dataset.k]=v;save();render()},
 daily(){const d=new Date().toDateString();if(me.daily===d)return toast('Bonus hari ini sudah diambil!');me.daily=d;addBux(50);notify('Bonus harian +50 PickBux');toast('+50 PickBux!');render()},
 rnd(){roomCode=Math.random().toString(36).slice(2,6);save();render()},
 create(){const n=$('#gn').value.trim();if(!n)return toast('Isi nama game dulu!');
  const g={id:'c'+Date.now(),name:n,emoji:$('#ge').value,col:window._cc||'#b6f25a',sky:'#7df9ff',seed:Math.floor(Math.random()*99),n:+$('#gd').value||22,pl:1,lk:0,mine:1};
  me.games.push(g);notify('Game "'+n+'" berhasil dibuat');addBux(10);toast('Game dibuat! +10 PickBux');page='home';render()},
 col(v,t){window._cc=v;document.querySelectorAll('#cols .sw').forEach(s=>s.classList.toggle('sel',s===t))},
 open(v){thread=v;render()},
 say(){const i=$('#mi');if(!i.value.trim())return;(th[thread]=th[thread]||[]).push({me:1,t:i.value});const f=thread;i.value='';render();setTimeout(()=>{(th[f]=th[f]||[]).push({t:['Haha keren!','Ayo mabar','Aku di Obby Neon nih','Oke siap!'][Math.random()*4|0]});if(page=='msg'&&thread==f)render()},900)},
 back(){thread=null;render()},
 clr(){me.notes.forEach(n=>n.new=0);save();render()},
 cams(v){S.cam=v;save();render()},
 sens(v,t){S.sens=+t.value;save()},
 hq(){S.hq=!S.hq;save();render()},
 out(){ls.set('sp_sess','');me=null;show('auth')},
 pause(){paused=true;$('#pause').style.display='flex';plist()},
 resume(){paused=false;$('#pause').style.display='none'},
 cam(){camMode=camMode=='third'?'first':'third';$('#camb').textContent='Cam';toast(camMode=='third'?'Kamera orang ketiga':'Kamera orang pertama')},
 chat(){const b=$('#chatbox');b.style.display=b.style.display=='flex'?'none':'flex';if(b.style.display=='flex')$('#ci').focus()},
 send(){const i=$('#ci'),t=i.value.trim();if(t){addChat(me.name,t);if(RM)RM.presence({c:t,ct:Date.now()}).catch(()=>{})}i.value='';$('#chatbox').style.display='none';i.blur()},
 respawn(){P.x=SP.x;P.y=SP.y;P.z=SP.z;P.vy=0;act.resume()},
 leave(){stopGame()}
};
$('#pw').addEventListener('keydown',e=>{if(e.key=='Enter')act.auth()});
function enter(){$('#err').textContent='';show('app');
 $('#nav').innerHTML=[['home','','Home'],['top','','Top'],['create','','Studio'],['avatar','','Avatar'],['msg','','Pesan'],['notif','','Notif'],['set','','Atur']].map(x=>`<button data-a="go" data-v="${x[0]}" id="n_${x[0]}"><span>${x[1]}</span>${x[2]}</button>`).join('');
 page='home';render()}
function navRender(){if(!me)return;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('act',b.id=='n_'+page));
 document.querySelectorAll('.badge').forEach(b=>b.remove());const c=me.notes.filter(n=>n.new).length;if(c)$('#n_notif').insertAdjacentHTML('beforeend','<i class="badge">'+c+'</i>');$('#buxp').textContent=''+me.bux+' PickBux'}
let thread=null;const th={};
const FR=[];
function render(){const m=$('#main');let h='';
 if(page=='home'){h=`<div class="card hero"><div class="big"></div><h1>Halo, ${esc(me.name)}!</h1><p>Pilih dunia, ajak teman, lalu main bareng.</p><button class="btn g" data-a="daily">Bonus Harian</button></div>
  <div class="tick"><div>★ PICKARE ★ MAIN BARENG TEMAN ★ BUAT GAME KAMU SENDIRI ★ PICKARE ★</div></div>
  <div class="card row" style="background:var(--c);flex-wrap:wrap"><div style="flex:1;min-width:150px"><label>Kode Room Mabar</label><input type="text" id="rc" value="${esc(roomCode)}" maxlength="16" style="margin:6px 0 0" oninput="roomCode=this.value.toLowerCase().replace(/[^a-z0-9]/g,'')||'publik';save()"></div><button class="btn p" data-a="rnd">Acak</button></div>
  <h3>Game Populer</h3><div class="grid">`+[].map((g,i)=>`<div class="card gcard" style="animation-delay:${i*60}ms"><div class="th" style="background-color:${g.col};${g.thumb?'background-image:url('+g.thumb+');background-size:cover;background-position:center':''}">${g.mine?'<span class="tag">BARU</span>':''}${g.thumb?'':'<span>'+g.emoji+'</span>'}</div><div class="in"><b>${g.icon?'<img src="'+g.icon+'" width="20" height="20" style="vertical-align:middle;border:2px solid #000;border-radius:4px;margin-right:5px">':''}${esc(g.name)}</b><small>${g.pl} · ${g.lk}%</small><button class="btn w g" data-a="play" data-v="${g.id}">▶ Main</button></div></div>`).join('')+'</div>'}
 if(page=='top'){const pl=[['Kakashi_X',9800],['PixelQueen',8420],['NoobMaster',7100],[me.name,me.bux*10],['Si_Kotak',3300]].sort((a,b)=>b[1]-a[1]);
  h='<h2>Pemain Teratas</h2>'+pl.map((p,i)=>`<div class="card row" style="animation:pop .4s ${i*70}ms both"><div class="rank" style="background:${['var(--y)','var(--c)','var(--p)'][i]||'var(--g)'}">${i+1}</div><b style="flex:1">${esc(p[0])}${p[0]==me.name?' (kamu)':''}</b><span>${p[1]} XP</span></div>`).join('')+'<h2 style="margin-top:20px">Game Teratas</h2>'+pubGames().slice().sort((a,b)=>b.pl-a.pl).map((g,i)=>`<div class="card row"><div class="rank">${i+1}</div><b style="flex:1">${g.emoji} ${esc(g.name)}</b><button class="btn g" data-a="play" data-v="${g.id}">Main</button></div>`).join('')}
 if(page=='create'){h=`<h2> Buat Game</h2><div class="card"><label>Nama Game</label><input type="text" id="gn" maxlength="20"><label>Ikon</label><select id="ge"><option></option><option></option><option></option><option></option><option></option></select><label>Warna Dunia</label><div id="cols">${['#b6f25a','#ff90e8','#7df9ff','#ff9f43','#ffde59'].map(c=>`<span class="sw" style="background:${c}" data-a="col" data-v="${c}"></span>`).join('')}</div><label style="display:block;margin-top:10px">Jumlah Platform</label><select id="gd"><option value="14">Mudah (14)</option><option value="22" selected>Sedang (22)</option><option value="32">Sulit (32)</option></select><button class="btn w g" data-a="create">Buat &amp; Publikasikan</button></div>`}
 if(page=='create')h=dash();
 if(page=='avatar'){const sw=(k,arr)=>arr.map(c=>`<span class="sw ${me.av[k]==c?'sel':''}" style="background:${c}" data-a="av" data-k="${k}" data-v="${c}"></span>`).join('');
  h=`<h2> Editor Avatar</h2><div class="card" style="display:flex;justify-content:center;background:var(--c);padding:26px 20px 20px">${avHTML(me.av,12)}</div><div class="card" style="margin-top:16px"><label>Kulit</label><br>${sw('skin',SKIN)}<br><label>Baju</label><br>${sw('shirt',SHIRT)}<br><label>Celana</label><br>${sw('pants',PANTS)}<br><label>Topi</label><br>${['none','cap','crown'].map(x=>`<button class="btn ${me.av.hat==x?'g':''}" style="margin:6px 8px 4px 0" data-a="av" data-k="hat" data-v="${x}">${{none:'Polos',cap:'Topi',crown:'Mahkota'}[x]}</button>`).join('')}</div>${accHTML()}`}
 if(page=='msg'){if(thread){h=`<button class="btn" data-a="back">← Kembali</button><h2 style="margin-top:14px">${thread}</h2><div class="card" style="min-height:200px">${(th[thread]||[{t:'Hai! Ayo main bareng?'}]).map(b=>`<div class="bubble ${b.me?'me':''}">${esc(b.t)}</div>`).join('')}</div><div class="row" style="margin-top:14px"><input type="text" id="mi" style="margin:0" placeholder="Tulis pesan"><button class="btn g" data-a="say">Kirim</button></div>`}
  else h='<h2>Pesan</h2>'+FR.map((f,i)=>`<div class="card row" data-a="open" data-v="${f}" style="cursor:pointer;animation:pop .4s ${i*70}ms both">${avHTML({skin:SKIN[i],shirt:SHIRT[i+1],pants:PANTS[1],hat:'none'},3)}<b style="flex:1">${f}</b><span class="pill" style="font-size:12px">Online</span></div>`).join('')}
 if(page=='notif'){h='<h2>Notifikasi</h2><button class="btn p" data-a="clr" style="margin-bottom:14px">Tandai dibaca</button>'+(me.notes.map(n=>`<div class="note ${n.new?'new':''}">${esc(n.t)}</div>`).join('')||'Kosong')}
 if(page=='set'){h=`<h2>Pengaturan</h2><div class="card"><label>Sensitivitas Kamera</label><input type="range" min="1" max="10" value="${S.sens}" oninput="act.sens(0,this)" style="width:100%;margin:8px 0 14px"><label>Kamera Awal</label><br><button class="btn ${S.cam=='third'?'g':''}" style="margin:8px 8px 14px 0" data-a="cams" data-v="third">Orang Ketiga</button><button class="btn ${S.cam=='first'?'g':''}" data-a="cams" data-v="first">Orang Pertama</button><br><label>Grafis HD</label><br><button class="btn ${S.hq?'g':'o'}" style="margin-top:8px" data-a="hq">${S.hq?'AKTIF':'MATI'}</button></div><button class="btn w p" style="margin-top:18px" data-a="out">Keluar Akun</button>`}
 m.innerHTML='<div class="page">'+h+'</div>';m.scrollTop=0;navRender()}

/* ===== GAME ===== */
let R,scene,cam3,boxes,coins,plr,P,run=false,paused=false,camMode='third',yaw=0,pitch=.35,last=0,raf,keys={},joy={x:0,y:0},jumpHeld=false,curG,got=0,fin=false,chatT,pts=[],sq=0,wasGround=true,fov=70;
let RM=null,rmOff=null,remote={},lastPS=0,lastSent='',roomName='',peerCount=1,seenCt={};
let testing=false,forceAcc=null,SP={x:0,y:2,z:0},baseOn=true,lavas=[];
const cv=$('#cv'),PG=new THREE.BoxGeometry(.18,.18,.18);
function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const mat=c=>new THREE.MeshLambertMaterial({color:c});
const EL=new THREE.LineBasicMaterial({color:0});
function part(w,h,d,c,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c));m.position.set(x,y,z);m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),EL));return m}
function mkAvatar(a,accs){const G=new THREE.Group(),piv=(y,x)=>{const p=new THREE.Group();p.position.set(x,y,0);G.add(p);return p};
 const lL=piv(.9,-.25),lR=piv(.9,.25),aL=piv(1.85,-.75),aR=piv(1.85,.75);
 lL.add(part(.5,.9,.5,a.pants,0,-.45,0));lR.add(part(.5,.9,.5,a.pants,0,-.45,0));
 aL.add(part(.5,1,.5,a.skin,0,-.45,0));aR.add(part(.5,1,.5,a.skin,0,-.45,0));
 G.add(part(1,1,.6,a.shirt,0,1.4,0));const h=part(.8,.8,.8,a.skin,0,2.3,0);G.add(h);
 h.add(part(.12,.2,.05,'#000000',-.17,.05,.41),part(.12,.2,.05,'#000000',.17,.05,.41));
 if(a.hat=='cap')h.add(part(.9,.2,.9,'#ff3b3b',0,.5,0));if(a.hat=='crown')h.add(part(.9,.3,.9,'#ffc400',0,.55,0));
 G.l=[lL,lR];G.a=[aL,aR];(accs||[]).forEach(id=>{const it=(me.items||[]).find(i=>i.id==id);if(it)it.objs.forEach(o=>{if(o.t!='coin')G.add(mkObj(o))})});return G}
function tagSprite(name){const c=document.createElement('canvas');c.width=256;c.height=64;const x=c.getContext('2d');x.fillStyle='#ffde59';x.fillRect(0,0,256,64);x.strokeStyle='#000';x.lineWidth=8;x.strokeRect(0,0,256,64);x.fillStyle='#000';x.font='bold 30px Arial';x.textAlign='center';x.textBaseline='middle';x.fillText(String(name).slice(0,14),128,34);
 const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false}));s.scale.set(2.4,.6,1);s.position.y=3.6;s.renderOrder=9;return s}
function mkCoin(x,y,z){const c=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.14,6),mat('#00d4ff'));c.rotation.x=Math.PI/2;c.position.set(x,y,z);c.add(new THREE.LineSegments(new THREE.EdgesGeometry(c.geometry),EL));c.userData.y=y;scene.add(c);coins.push(c)}
function burst(x,y,z,col,n){for(let i=0;i<n;i++){const m=new THREE.Mesh(PG,mat(col));m.position.set(x,y,z);m.userData={v:new THREE.Vector3((Math.random()-.5)*5,Math.random()*5+1,(Math.random()-.5)*5),life:.7};scene.add(m);pts.push(m)}}
function build(g){scene=new THREE.Scene();scene.background=new THREE.Color(g.sky);scene.fog=new THREE.Fog(g.sky,40,120);
 scene.add(new THREE.HemisphereLight(0xffffff,0x998877,1));const d=new THREE.DirectionalLight(0xffffff,.5);d.position.set(30,50,20);scene.add(d);
 const gr=new THREE.Mesh(new THREE.PlaneGeometry(100,100),mat(g.col));gr.rotation.x=-Math.PI/2;scene.add(gr);
 const gh=new THREE.GridHelper(100,50,0x000000,0x000000);gh.material.transparent=true;gh.material.opacity=.25;gh.position.y=.02;scene.add(gh);
 boxes=[];coins=[];pts=[];const r=rng(g.seed),pal=['#ff90e8','#ffde59','#7df9ff','#b6f25a','#ff9f43','#ffffff'];
 for(let i=0;i<g.n;i++){const a=i*.42,rad=Math.max(8,17-i*.2),top=.8*(i+1),x=Math.cos(a)*rad,z=Math.sin(a)*rad,fl=i==g.n-1,w=fl?6:4.2;
  const m=part(w,1,w,fl?'#ffc400':pal[Math.floor(r()*pal.length)],x,top-.5,z);scene.add(m);boxes.push({x,z,hw:w/2,hd:w/2,top,fl});
  if(!fl&&i%2==0)mkCoin(x,top+1.3,z)}
 for(let i=0;i<6;i++){const x=(r()-.5)*70,z=(r()-.5)*70,s=2+r()*3,h=1+r()*2;if(Math.hypot(x,z)<5)continue;scene.add(part(s,h,s,pal[i%6],x,h/2,z));boxes.push({x,z,hw:s/2,hd:s/2,top:h})}
 for(let i=0;i<4;i++)mkCoin(-6+i*4,1.3,-6)}
function setNet(on,n){const e=$('#net');e.textContent=on?'Online · '+n+' pemain':'Solo'}
function plist(){const l=$('#plist');let h='<b>Pemain:</b><br><span class="dot" style="background:var(--y)"></span>'+esc(me.name)+' (kamu · ID '+(me.uid||'-')+')';for(const k in remote)h+='<br><span class="dot" style="background:var(--p)"></span>'+esc(remote[k].name);if(!RM)h+='<br><i>Mode solo (koneksi ke server mabar gagal, coba lagi)</i>';l.innerHTML=h}
function leaveRoom(){try{if(rmOff)rmOff()}catch(e){}rmOff=null;try{if(RM)RM.leave()}catch(e){}RM=null;for(const k in remote){if(scene)scene.remove(remote[k].g)}remote={};seenCt={}}
async function joinRoom(name){setNet(0);
 try{if(!(window.claude&&claude.use))return;const room=await claude.use('room');if(!room)return;const r=await room.join(name);
  if(!run||roomName!==name){try{r.leave()}catch(e){}return}
  RM=r;lastSent='';rmOff=r.onPeers(ch=>syncPeers(ch.peers),()=>{RM=null;setNet(0)});syncPeers(r.peers())}catch(e){RM=null;setNet(0)}}
function syncPeers(peers){const seen={};let n=0;
 peers.forEach(p=>{n++;if(p.isMe||p.kind!=='viewer'||!p.presence||p.presence.n==null)return;const q=p.presence;seen[p.peer]=1;let o=remote[p.peer];
  if(!o){const g=mkAvatar({skin:q.sk||SKIN[0],shirt:q.sh||SHIRT[0],pants:q.pa||PANTS[0],hat:q.ht||'none'});g.add(tagSprite(q.n));g.position.set(q.x||0,q.y||0,q.z||0);scene.add(g);o=remote[p.peer]={g,name:String(q.n).slice(0,14),tx:q.x||0,ty:q.y||0,tz:q.z||0,tr:q.r||0,ph:0};burst(q.x||0,(q.y||0)+1,q.z||0,'#ffde59',10);addChat('Sistem',o.name+' bergabung');if(q.ct)seenCt[p.peer]=q.ct}
  o.tx=+q.x||0;o.ty=+q.y||0;o.tz=+q.z||0;o.tr=+q.r||0;try{window.spApplyAcc&&spApplyAcc(o,q.ac)}catch(e){}
  if(q.ct&&q.ct!==seenCt[p.peer]){seenCt[p.peer]=q.ct;if(Date.now()-q.ct<15000)addChat(o.name,String(q.c||'').slice(0,80))}});
 for(const k in remote)if(!seen[k]){addChat('Sistem',remote[k].name+' keluar');scene.remove(remote[k].g);delete remote[k]}
 peerCount=Math.max(1,n);setNet(1,peerCount);if($('#pause').style.display=='flex')plist()}
function pushPresence(t){if(!RM||t-lastPS<90)return;const o={n:me.name,x:+P.x.toFixed(2),y:+P.y.toFixed(2),z:+P.z.toFixed(2),r:+plr.rotation.y.toFixed(2),sk:me.av.skin,sh:me.av.shirt,pa:me.av.pants,ht:me.av.hat,ac:(window.spAcc?spAcc():[])},s=JSON.stringify(o);
 if(s===lastSent&&t-lastPS<1500)return;lastSent=s;lastPS=t;RM.presence(o).catch(()=>{})}
function startGame(g,test){testing=!!test;curG=g;got=0;fin=false;paused=false;$('#pause').style.display='none';show('game');
 try{if(!R){R=new THREE.WebGLRenderer({canvas:cv,antialias:true});cam3=new THREE.PerspectiveCamera(70,1,.1,300);cam3.rotation.order='YXZ'}}catch(e){show('app');return toast('Browser tidak mendukung WebGL')}
 R.setPixelRatio(S.hq?Math.min(window.devicePixelRatio||1,2):1);buildW(g);
 plr=mkAvatar(me.av,forceAcc||me.av.acc);scene.add(plr);P={x:SP.x,y:SP.y,z:SP.z,vy:0,ground:false,ry:0,t:0};camMode=S.cam;$('#camb').textContent='Cam';yaw=0;pitch=.35;sq=0;
 $('#chatlog').innerHTML='';addChat('Sistem','Selamat datang di '+g.name+'!');
 chatT=null;
 run=true;resize();last=performance.now();raf=requestAnimationFrame(loop);
 roomName=('sp-'+g.id+'-'+(roomCode||'publik')).slice(0,48);if(test)setNet(0);else{joinRoom(roomName);try{spShare(g)}catch(e){}}
 toast('Gerak: joystick/WASD · Lompat: tombol/Spasi · C: kamera')}
function stopGame(){run=false;cancelAnimationFrame(raf);clearInterval(chatT);leaveRoom();joy.x=joy.y=0;if(testing){testing=false;forceAcc=null;edBack();return}show('app');notify('Kamu main '+curG.name);render()}
function addChat(n,t){const l=$('#chatlog'),d=document.createElement('div');d.innerHTML='<b>'+esc(n)+':</b> '+esc(t);l.appendChild(d);while(l.children.length>6)l.firstChild.remove();setTimeout(()=>d.remove(),10000)}
function resize(){if(!R)return;const w=window.innerWidth,h=window.innerHeight;R.setSize(w,h,false);cam3.aspect=w/h;cam3.updateProjectionMatrix()}
window.addEventListener('resize',resize);window.addEventListener('orientationchange',()=>setTimeout(resize,250));
function inF(b,x,z,pad){if(b.sh){const dx=x-b.x,dz=z-b.z,u=dx*b.ca+dz*b.sa,v=-dx*b.sa+dz*b.ca,a=b.rx+pad,c=b.rz+pad;return u*u/(a*a)+v*v/(c*c)<1}return Math.abs(x-b.x)<b.hw+pad&&Math.abs(z-b.z)<b.hd+pad}
function topAt(b,x,z){if(b.sh==='ball'){const dx=x-b.x,dz=z-b.z,u=dx*b.ca+dz*b.sa,v=-dx*b.sa+dz*b.ca,q=u*u/(b.rx*b.rx)+v*v/(b.rz*b.rz);return b.cy+b.ry*Math.sqrt(Math.max(0,1-q))}return b.top}
function hit(x,z,y){for(const b of boxes)if(inF(b,x,z,.3)&&y<topAt(b,x,z)-.25&&y+2.7>b.bot)return true;return false}
function loop(t){if(!run)return;raf=requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1000);last=t;let moving=false,L=0;
 if(!paused){let ix=joy.x+(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),iy=joy.y+(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0);
  L=Math.hypot(ix,iy);if(L>1){ix/=L;iy/=L;L=1}
  const fx=-Math.sin(yaw),fz=-Math.cos(yaw),rx=Math.cos(yaw),rz=-Math.sin(yaw),vx=(fx*iy+rx*ix)*8,vz=(fz*iy+rz*ix)*8;
  const nx=P.x+vx*dt,nz=P.z+vz*dt;if(!hit(nx,P.z,P.y))P.x=Math.max(-48,Math.min(48,nx));if(!hit(P.x,nz,P.y))P.z=Math.max(-48,Math.min(48,nz));
  if((jumpHeld||keys[' '])&&P.ground){P.vy=12;P.ground=false;burst(P.x,P.y+.1,P.z,'#ffffff',5)}
  P.vy-=30*dt;let ny=P.y+P.vy*dt;P.ground=false;
  if(P.vy<=0){if(ny<=0&&baseOn){ny=0;P.vy=0;P.ground=true}
   for(const b of boxes){const tp=topAt(b,P.x,P.z);if(inF(b,P.x,P.z,.2)&&P.y>=tp-.1&&ny<=tp){ny=tp;P.vy=0;P.ground=true;
    if(b.fl&&!fin){fin=true;toast('SELESAI!');burst(P.x,P.y+1,P.z,'#ffc400',24);addChat('Sistem',me.name+' menyelesaikan '+curG.name+'!')}}}}
  else for(const b of boxes)if(inF(b,P.x,P.z,.2)&&P.y+2.7<=b.bot&&ny+2.7>b.bot){P.vy=-1;ny=P.y}
  P.y=ny;for(const b of lavas)if(Math.abs(P.x-b.x)<b.hw+.1&&Math.abs(P.z-b.z)<b.hd+.1&&P.y<b.top&&P.y+2>b.bot){toast('Kena lava!');act.respawn();break}if(P.y<-20)act.respawn();
  if(P.ground&&!wasGround){sq=1;burst(P.x,P.y+.1,P.z,'#ffffff',6)}wasGround=P.ground;
  moving=L>.1;if(moving){P.ry=Math.atan2(vx,vz);P.t+=dt*(8+L*4)}
  for(let i=coins.length-1;i>=0;i--){const c=coins[i];c.rotation.z+=dt*3.5;c.position.y=c.userData.y+Math.sin(t/300+i)*.15;
   if(Math.hypot(c.position.x-P.x,c.position.z-P.z)<1.3&&Math.abs(c.position.y-P.y-1)<1.7){burst(c.position.x,c.position.y,c.position.z,'#00d4ff',10);scene.remove(c);coins.splice(i,1);}}}
 plr.position.set(P.x,P.y,P.z);let dr=P.ry-plr.rotation.y;dr=Math.atan2(Math.sin(dr),Math.cos(dr));plr.rotation.y+=dr*Math.min(1,dt*14);
 const sw=moving?Math.sin(P.t)*.9:0,air=P.ground?0:1,br=Math.sin(t/400)*.05;
 plr.l[0].rotation.x=air?.5:sw;plr.l[1].rotation.x=air?-.4:-sw;plr.a[0].rotation.x=air?-2.6:-sw+br;plr.a[1].rotation.x=air?-2.6:sw-br;
 sq=Math.max(0,sq-dt*5);plr.scale.set(1+sq*.18,1-sq*.25,1+sq*.18);
 for(const k in remote){const o=remote[k],g=o.g,dx=o.tx-g.position.x,dz=o.tz-g.position.z,sp=Math.hypot(dx,dz);const f=Math.min(1,dt*10);g.position.x+=dx*f;g.position.z+=dz*f;g.position.y+=(o.ty-g.position.y)*f;
  let d2=o.tr-g.rotation.y;d2=Math.atan2(Math.sin(d2),Math.cos(d2));g.rotation.y+=d2*f;if(sp>.05)o.ph+=dt*10;const s2=sp>.05?Math.sin(o.ph)*.9:0;g.l[0].rotation.x=s2;g.l[1].rotation.x=-s2;g.a[0].rotation.x=-s2;g.a[1].rotation.x=s2}
 for(let i=pts.length-1;i>=0;i--){const m=pts[i],u=m.userData;u.life-=dt;u.v.y-=14*dt;m.position.addScaledVector(u.v,dt);m.scale.setScalar(Math.max(.01,u.life*1.4));if(u.life<=0){scene.remove(m);pts.splice(i,1)}}
 pushPresence(t);
 const p=Math.max(-1.2,Math.min(1.4,pitch));plr.visible=camMode=='third';cam3.rotation.set(-p,yaw,0);
 const tf=70+(moving?7:0);fov+=(tf-fov)*Math.min(1,dt*6);if(Math.abs(cam3.fov-fov)>.05){cam3.fov=fov;cam3.updateProjectionMatrix()}
 if(camMode=='first')cam3.position.set(P.x,P.y+2.4,P.z);
 else{const D=7,cp=Math.cos(p),tx=P.x+Math.sin(yaw)*cp*D,ty=Math.max(.5,P.y+2.2+Math.sin(p)*D),tz=P.z+Math.cos(yaw)*cp*D,f=1-Math.exp(-dt*14);
  if(cam3.position.distanceTo(new THREE.Vector3(tx,ty,tz))>20)cam3.position.set(tx,ty,tz);else{cam3.position.x+=(tx-cam3.position.x)*f;cam3.position.y+=(ty-cam3.position.y)*f;cam3.position.z+=(tz-cam3.position.z)*f}}
 R.render(scene,cam3)}
/* input */
window.addEventListener('keydown',e=>{if(!run)return;if(document.activeElement&&document.activeElement.tagName=='INPUT'){if(e.key=='Enter')act.send();return}const k=e.key.toLowerCase();keys[k]=1;if(k=='c')act.cam();if(k=='enter')act.chat();if(k=='escape')paused?act.resume():act.pause();if(k==' ')e.preventDefault()});
window.addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=0});
window.addEventListener('blur',()=>{keys={}});
let lp=null;
function lookDown(e){if(lp)return;lp={id:e.pointerId,x:e.clientX,y:e.clientY};try{e.currentTarget.setPointerCapture(e.pointerId)}catch(x){}}
function lookMove(e){if(!lp||lp.id!==e.pointerId)return;const s=S.sens*.0016;yaw-=(e.clientX-lp.x)*s;pitch+=(e.clientY-lp.y)*s;lp.x=e.clientX;lp.y=e.clientY}
function lookUp(e){if(lp&&lp.id===e.pointerId)lp=null}
cv.addEventListener('pointerdown',lookDown);cv.addEventListener('pointermove',lookMove);cv.addEventListener('pointerup',lookUp);cv.addEventListener('pointercancel',lookUp);
const jz=$('#jzone'),jb=$('#joy'),kn=$('#knob');let jid=null,jc={x:0,y:0};
function jpos(x,y){jb.style.left=x-65+'px';jb.style.top=y-65+'px';jc={x,y}}
function jrest(){const r=jz.getBoundingClientRect();jpos(Math.max(80,r.width*.3),r.height-90)}
function jm(e){const r=jz.getBoundingClientRect(),dx=e.clientX-r.left-jc.x,dy=e.clientY-r.top-jc.y,l=Math.hypot(dx,dy),m=Math.min(l,48),a=Math.atan2(dy,dx),kx=Math.cos(a)*m,ky=Math.sin(a)*m;
 kn.style.transform='translate('+kx+'px,'+ky+'px)';joy.x=kx/48;joy.y=-ky/48}
function jreset(){jid=null;joy.x=joy.y=0;kn.style.transform='';jb.classList.remove('act');jrest()}
jz.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){lookDown(e);return}e.preventDefault();if(jid!==null)return;jid=e.pointerId;try{jz.setPointerCapture(jid)}catch(x){}const r=jz.getBoundingClientRect();jpos(e.clientX-r.left,e.clientY-r.top);jb.classList.add('act');jm(e)});
jz.addEventListener('pointermove',e=>{if(e.pointerType==='mouse'){lookMove(e);return}if(e.pointerId===jid){e.preventDefault();jm(e)}});
['pointerup','pointercancel'].forEach(v=>jz.addEventListener(v,e=>{if(e.pointerType==='mouse'){lookUp(e);return}if(e.pointerId===jid)jreset()}));
jz.addEventListener('contextmenu',e=>e.preventDefault());
const jbtn=$('#jump');
jbtn.addEventListener('pointerdown',e=>{e.preventDefault();jumpHeld=true;try{jbtn.setPointerCapture(e.pointerId)}catch(x){}});
['pointerup','pointercancel','pointerleave'].forEach(v=>jbtn.addEventListener(v,()=>jumpHeld=false));
new MutationObserver(jrest).observe($('#game'),{attributes:true,attributeFilter:['class']});
window.addEventListener('resize',jrest);
document.addEventListener('gesturestart',e=>e.preventDefault());
/* boot */
(function(){const s=ls.get('sp_sess','');if(s&&users[s]){me=users[s];me.name=s;me.notes=me.notes||[];me.games=me.games||[];me.bux=me.bux||0;enter()}})();
