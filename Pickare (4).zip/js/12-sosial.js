/* ===== SOSIAL: teman, profil, detail game, bergabung ===== */
Object.assign(IC,{x:'<path d="M6 6l12 12M18 6L6 18"/>',more:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="12" r=".6" fill="currentColor"/><circle cx="12" cy="12" r=".6" fill="currentColor"/><circle cx="16" cy="12" r=".6" fill="currentColor"/>',invite:'<rect x="4" y="3.5" width="6" height="6" rx="1"/><path d="M4 21v-6.5h6V21M13 8h6v7h-6zM13 18l7 3-7 3z" transform="translate(0 -3) scale(.95)"/>',play:'<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',star:'<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9-4.3-4.1 5.9-.8z"/>',thumbd:'<path d="M8 13V4H4v9zM8 13l4 7c1.6 0 2.6-1.3 2.2-2.8L13.5 14H19a1.5 1.5 0 0 0 1.4-1.9L18.6 5.5A2 2 0 0 0 16.7 4H8"/>',bellx:'<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 21h4"/>'});
const BN=[],BOTS={};
BN.forEach((n,i)=>BOTS[n]={n,gi:i,av:{skin:SKIN[i%SKIN.length],shirt:SHIRT[(i+1)%SHIRT.length],pants:PANTS[1],hat:['none','cap','crown','none'][i]},fr:12+i*7,fl:30+i*11,fg:20+i*3});
const isBot=n=>!!BOTS[n]&&!users[n];
function FRD(u){u.fr=u.fr||{};['f','i','o','fo'].forEach(k=>{if(!Array.isArray(u.fr[k]))u.fr[k]=[]});return u.fr}
function pinfo(n){if(users[n])return{n,av:users[n].av,u:users[n]};if(BOTS[n])return{n,av:BOTS[n].av,bot:1};return null}
function rel(n){const f=FRD(me);return f.f.includes(n)?'friend':f.o.includes(n)?'sent':f.i.includes(n)?'recv':'none'}
function presOf(n){if(isBot(n)){const g=BASE[BOTS[n].gi%BASE.length];return{g:g.id,room:'bot-'+n.toLowerCase()}}const u=users[n],p=u&&u.pres;return p&&p.g?p:null}
function pushNote(u,t){u.notes=u.notes||[];u.notes.unshift({t,new:1});save();if(u===me)navRender()}
const fmtN=n=>n>=1e6?(n/1e6).toFixed(1).replace('.',',')+' jt':n>=1e3?(n/1e3).toFixed(1).replace('.',',')+' rb':String(n);
function counts(n){if(isBot(n)){const b=BOTS[n],f=FRD(me);return{fr:b.fr+(rel(n)=='friend'?1:0),fl:b.fl+(f.fo.includes(n)?1:0),fg:b.fg}}
 const u=users[n];return{fr:FRD(u).f.length,fl:Object.keys(users).filter(k=>FRD(users[k]).fo.includes(n)).length,fg:FRD(u).fo.length}}
function friends(){return FRD(me).f.filter(n=>pinfo(n)).map(n=>{const p=pinfo(n),ps=presOf(n),g=ps&&allGames().find(x=>x.id==ps.g);return{n,a:p.av,g:g?g.name:'Offline',pl:!!g}})}
const playingFriends=gid=>FRD(me).f.filter(n=>{const p=presOf(n);return p&&p.g==gid});
const lastMsg=n=>{const c=(me.chat||{})[n]||[];return c[c.length-1]};

/* ---- aksi pertemanan ---- */
function botAcc(n){if(!me||!FRD(me).o.includes(n))return;const f=FRD(me);f.o=f.o.filter(x=>x!=n);if(!f.f.includes(n))f.f.push(n);pushNote(me,''+n+' menerima permintaan pertemananmu');toast(n+' menerima permintaanmu');refreshUI()}
function refreshUI(){if(!me||!$('#app').classList.contains('on'))return;if(OVS.length)ovRender();if(page=='home'||page=='msg'||page=='fav')render();else navRender()}
Object.assign(act,{
 freq(n){if(rel(n)!='none'||!pinfo(n))return;FRD(me).o.push(n);if(isBot(n))setTimeout(()=>botAcc(n),1800);else{FRD(users[n]).i.push(me.name);pushNote(users[n],''+me.name+' mengirim permintaan pertemanan')}save();toast('Permintaan dikirim ke '+n);refreshUI()},
 facc(n){const f=FRD(me);if(!f.i.includes(n))return;f.i=f.i.filter(x=>x!=n);if(!f.f.includes(n))f.f.push(n);if(users[n]){const g=FRD(users[n]);g.o=g.o.filter(x=>x!=me.name);if(!g.f.includes(me.name))g.f.push(me.name);pushNote(users[n],''+me.name+' menerima permintaan pertemananmu')}save();toast('Sekarang berteman dengan '+n);refreshUI()},
 fdec(n){const f=FRD(me);f.i=f.i.filter(x=>x!=n);if(users[n]){const g=FRD(users[n]);g.o=g.o.filter(x=>x!=me.name)}save();refreshUI()},
 fcan(n){const f=FRD(me);f.o=f.o.filter(x=>x!=n);if(users[n]){const g=FRD(users[n]);g.i=g.i.filter(x=>x!=me.name)}save();toast('Permintaan dibatalkan');refreshUI()},
 funf(n){const f=FRD(me);f.f=f.f.filter(x=>x!=n);if(users[n]){const g=FRD(users[n]);g.f=g.f.filter(x=>x!=me.name)}if(thread==n)thread=null;save();shClose();toast('Berteman dengan '+n+' diakhiri');refreshUI()},
 ffol(n){const f=FRD(me),i=f.fo.indexOf(n);i<0?f.fo.push(n):f.fo.splice(i,1);save();toast(i<0?'Kamu mengikuti '+n:'Berhenti mengikuti '+n);refreshUI()}});

/* ---- sheet bawah & overlay ---- */
const OVS=[];let PQ='',ptab='add',gcache=0;
function shOpen(h){$('#shp').innerHTML=h;$('#sh').classList.add('on')}
function shClose(){$('#sh').classList.remove('on')}
function ovOpen(t,a){shClose();OVS.push({t,a});ovRender(1)}
function ovRender(fresh){const o=$('#ov'),tp=OVS[OVS.length-1];if(!tp){o.classList.remove('on');o.innerHTML='';return}
 const y=fresh?0:o.scrollTop;o.innerHTML=({game:gameOv,prof:profOv,ppl:pplOv})[tp.t](tp.a);o.classList.add('on');o.scrollTop=y}
function ovClear(){OVS.length=0;shClose();ovRender()}
Object.assign(act,{ovb(){shClose();OVS.pop();ovRender()},shx(){shClose()},
 gopen(id){ovOpen('game',id)},prof(n){if(pinfo(n)||n==me.name)ovOpen('prof',n)},
 ptab(v){ptab=v;PQ='';ovRender()},
 fr(n){const p=pinfo(n);if(!p)return;const ps=presOf(n),g=ps&&allGames().find(x=>x.id==ps.g),t=g?okImg(g.thumb):'';
  shOpen(`<div class="sht" style="${g?`background:${t?`url(${t}) center/cover`:`linear-gradient(135deg,${hexc(g.col,'#b6f25a')},${hexc(g.sky,'#7df9ff')})`}`:''}">${g?(t?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())):circ(p.av,150)}</div><div class="shn">${g?esc(g.name):esc(n)+' · Offline'}</div>${g?`<button class="sb pr" data-a="join" data-v="${esc(n)}">Bergabung</button>`:''}<button class="sb" data-a="chatw" data-v="${esc(n)}">Chat dengan ${esc(n)}</button><button class="sb ln" data-a="prof" data-v="${esc(n)}">Lihat profil</button>`)},
 join(n){if(rel(n)!='friend')return toast('Kamu harus berteman dulu untuk bergabung');const ps=presOf(n),g=ps&&allGames().find(x=>x.id==ps.g);if(!g)return toast(n+' sedang tidak bermain');roomCode=String(ps.room||'publik').toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,16)||'publik';save();ovClear();startGame(g)},
 chatw(n){if(rel(n)!='friend')return toast('Terima pertemanan dulu untuk chat');ovClear();page='msg';thread=n;render()},
 glike(id){const l=me.lk=me.lk||{};l[id]=l[id]==1?0:1;save();ovRender()},gdis(id){const l=me.lk=me.lk||{};l[id]=l[id]==-1?0:-1;save();ovRender()},
 gfav(id){const a=me.favs=me.favs||[],i=a.indexOf(id);i<0?a.push(id):a.splice(i,1);save();toast(i<0?'Ditambahkan ke Favorit':'Dihapus dari Favorit');ovRender()},
 gnot(id){const n=me.nots=me.nots||{};n[id]=!n[id];save();toast(n[id]?'Notifikasi game aktif':'Notifikasi game mati');ovRender()},
 gfrp(id){const l=playingFriends(id);if(!l.length)return;shOpen('<div class="shn" style="margin-top:6px">Teman yang sedang bermain</div>'+l.map(n=>`<div class="ur"><button class="ura" data-a="prof" data-v="${esc(n)}">${circ(pinfo(n).av,48)}<span><b>${esc(n)}</b></span></button><button class="ub bl" data-a="join" data-v="${esc(n)}">Bergabung</button></div>`).join(''))},
 gmenu(){shOpen(`<div class="shn" style="margin-top:6px">Kode room</div><input class="shin" type="text" id="rc2" maxlength="16" value="${esc(roomCode)}" oninput="roomCode=this.value.toLowerCase().replace(/[^a-z0-9-]/g,'')||'publik';save()"><button class="sb" data-a="rcrnd">Acak kode</button><button class="sb" data-a="rccopy">Salin kode</button><button class="sb ln" data-a="shx">Tutup</button>`)},
 rcrnd(){roomCode=Math.random().toString(36).slice(2,6);save();const i=$('#rc2');if(i)i.value=roomCode;toast('Kode room: '+roomCode)},
 rccopy(){try{navigator.clipboard.writeText(roomCode)}catch(e){}toast('Kode room "'+roomCode+'" — bagikan ke temanmu')},
 ginv(){act.gmenu()}});

/* ---- tampilan: detail game ---- */
function gameOv(id){const g=allGames().find(x=>x.id==id);if(!g)return'<div class="otop"><button class="rb" data-a="ovb">'+ico('x',28)+'</button></div><div class="empty">Game tidak ditemukan.</div>';
 const t=okImg(g.thumb),ic=okImg(g.icon),c1=hexc(g.col,'#b6f25a'),c2=hexc(g.sky,'#7df9ff'),bg=t?`url(${t}) center/cover`:`linear-gradient(135deg,${c1},${c2})`,lk=(me.lk||{})[g.id]||0,fav=(me.favs||[]).includes(g.id),nt=(me.nots||{})[g.id],pf=playingFriends(g.id),by=g.by||'Pickare',bu=users[by],vis=(ls.get('sp_vis',{})[g.id]||0)+(g.pl||1)*1300,
  others=pubGames().filter(x=>x.id!=g.id),dt=new Date().toLocaleDateString('id-ID');
 return `<div class="otop"><button class="rb" data-a="ovb" aria-label="Tutup">${ico('x',30)}</button></div><div class="gsheet">
 <div class="ghead"><span class="gico" style="background:${ic?`url(${ic}) center/cover`:bg}">${ic?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())}</span><div><h1>${esc(g.name)}</h1><p>oleh ${esc(by)}${bu?vb(bu):''}</p><small>Kedewasaan: Minimal</small></div></div>
 <div class="gshot" style="background:${bg}">${t?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())}</div>
 <div class="gchips"><span class="gch"><button class="${lk==1?'on':''}" data-a="glike" data-v="${esc(g.id)}">${ico('thumb',22)} ${g.lk>0?(+g.lk)+'%':'Baru'}</button><hr><button class="${lk==-1?'on':''}" data-a="gdis" data-v="${esc(g.id)}">${ico('thumbd',22)}</button></span><span class="gch">${ico('friends',22)} ${fmtN((g.pl||1)+pf.length)} aktif</span><button class="gch ${nt?'on':''}" data-a="gnot" data-v="${esc(g.id)}">${ico('bell',22)} Notifikasi</button><button class="gch ${fav?'on':''}" data-a="gfav" data-v="${esc(g.id)}">${ico('star',22)} Favorit</button></div>
 <button class="gplay" ${pf.length?`data-a="gfrp" data-v="${esc(g.id)}"`:''}>${pf.length?`<span class="stk">${pf.slice(0,3).map(n=>circ(pinfo(n).av,34)).join('')}</span><span>Dimainkan oleh <b>${esc(pf[0])}</b>${pf.length>1?' dan <b>'+(pf.length-1)+' teman lainnya</b>':''} — ketuk untuk bergabung</span>`:'<span>Belum ada temanmu yang sedang bermain ini.</span>'}</button>
 <h3>Deskripsi</h3><p class="ds">${esc(g.desc||'Selamat datang di '+g.name+'! Lompati platform dan capai garis finish bersama teman.')}</p>
 <h3>Informasi</h3>
 <div class="irow"><span>Kunjungan</span><b>${fmtN(vis)}</b></div><div class="irow"><span>Kedewasaan Konten</span><b>Minimal</b></div><div class="irow"><span>Pengembang</span><b>${bu?`<a data-a="prof" data-v="${esc(by)}" style="cursor:pointer">${esc(by)}</a>`:esc(by)}${bu?vb(bu):(window.spVb?spVb(by):'')}</b></div><div class="irow"><span>Ukuran Server</span><b>8</b></div><div class="irow"><span>Genre</span><b>${g.mine?'Buatan Pemain':'Obby'}</b></div><div class="irow"><span>Di-update</span><b>${dt}</b></div><div class="irow"><span>Kode room</span><b>${esc(roomCode)}</b></div>
 ${others.length?`<h3>Pengguna lain juga ikut</h3><div class="hs" style="margin:0 -16px;padding:0 16px">${others.map(gcard).join('')}</div>`:''}
 </div><div class="gbar"><button class="gb" data-a="gmenu" aria-label="Opsi">${ico('more',34)}</button><button class="gb" data-a="gmenu" aria-label="Undang">${ico('invite',34)}</button><button class="gplayb" data-a="play" data-v="${esc(g.id)}" aria-label="Main">${ico('play',34)}</button></div>`}

/* ---- tampilan: cari orang / teman ---- */
function uact(n){const r=rel(n);return r=='friend'?'<span class="tg2">Teman</span>':r=='sent'?`<button class="ub" data-a="fcan" data-v="${esc(n)}">Batalkan</button>`:r=='recv'?`<button class="ub bl" data-a="facc" data-v="${esc(n)}">Terima</button><button class="ub" data-a="fdec" data-v="${esc(n)}">Tolak</button>`:`<button class="ub bl" data-a="freq" data-v="${esc(n)}">Tambah</button>`}
function urow(n,sub,act2){const p=pinfo(n);if(!p)return'';return `<div class="ur"><button class="ura" data-a="prof" data-v="${esc(n)}">${circ(p.av,52)}<span><b>${esc(n)}${p.u?vb(p.u):''}</b><small>${sub}</small></span></button>${act2||uact(n)}</div>`}
const allPeople=()=>Object.keys(users).filter(k=>k!==me.name&&!users[k].role&&!banOf(users[k])).concat(BN.filter(n=>!users[n]));
const subOf=n=>'@'+esc(String(n).toLowerCase());
function pplList(){const q=PQ.trim().toLowerCase(),f=FRD(me);
 if(q){const r=allPeople().filter(n=>n.toLowerCase().includes(q));return `<div class="ps">Hasil pencarian</div>`+(r.length?r.map(n=>urow(n,subOf(n))).join(''):'<div class="empty">Tidak ada pengguna dengan nama itu.</div>')}
 if(ptab=='fr'){const fl=friends();return fl.length?fl.map(x=>urow(x.n,x.pl?'Bermain: '+esc(x.g):'Offline',`<button class="ub" data-a="chatw" data-v="${esc(x.n)}">Chat</button>${x.pl?`<button class="ub bl" data-a="join" data-v="${esc(x.n)}">Gabung</button>`:''}`)).join(''):'<div class="empty">Belum ada teman.<br>Cari orang di tab "Tambah teman".</div>'}
 let h='';if(f.i.length)h+=`<div class="ps">Permintaan masuk (${f.i.length})</div>`+f.i.map(n=>urow(n,'Ingin berteman denganmu')).join('');
 if(f.o.length)h+=`<div class="ps">Permintaan terkirim</div>`+f.o.map(n=>urow(n,'Menunggu persetujuan')).join('');
 const sg=allPeople().filter(n=>rel(n)=='none');h+=`<div class="ps">Orang yang mungkin kamu kenal</div>`+(sg.length?sg.map(n=>urow(n,subOf(n))).join(''):'<div class="empty">Tidak ada saran lagi.</div>');return h}
function pplOv(){const bi=FRD(me).i.length;return `<div class="pph"><button class="rb" data-a="ovb" aria-label="Kembali">${ico('back',28)}</button><input type="text" id="pq" placeholder="Cari orang" value="${esc(PQ)}" autocomplete="off" maxlength="20"></div><div class="ptabs"><button class="${ptab=='add'?'on':''}" data-a="ptab" data-v="add">Tambah teman${bi?' ('+bi+')':''}</button><button class="${ptab=='fr'?'on':''}" data-a="ptab" data-v="fr">Teman</button></div><div class="pbody" id="pl">${pplList()}</div>`}
document.addEventListener('input',e=>{if(e.target.id=='pq'){PQ=e.target.value;const l=$('#pl');if(l)l.innerHTML=pplList()}});

/* ---- tampilan: profil ---- */
function wearTiles(u){const a=u.av||{},t=(l,c)=>`<div class="wt"><i style="background:${hexc(c,'#888')}"></i>${l}<small>Tidak Dijual</small></div>`,
 acc=(a.acc||[]).map(id=>(u.items||[]).find(i=>i.id==id)).filter(Boolean).map(i=>`<div class="wt"><i style="background:#3b2023"></i>${esc(i.name)}<small>Aksesori</small></div>`).join('');
 return t('Kulit',a.skin)+t('Baju',a.shirt)+t('Celana',a.pants)+(a.hat&&a.hat!='none'?`<div class="wt"><i style="background:#3b2023"></i>${a.hat=='crown'?'Mahkota':'Topi'}<small>Tidak Dijual</small></div>`:'')+acc}
function profOv(n){const self=n==me.name,p=self?{n,av:me.av,u:me}:pinfo(n);if(!p)return'<div class="otop"><button class="rb" data-a="ovb">'+ico('back',28)+'</button></div><div class="empty">Pengguna tidak ditemukan.</div>';
 const r=self?'self':rel(n),c=self?{fr:FRD(me).f.length,fl:Object.keys(users).filter(k=>FRD(users[k]).fo.includes(n)).length,fg:FRD(me).fo.length}:counts(n),fo=FRD(me).fo.includes(n),ps=self?null:presOf(n),gm=ps&&allGames().find(x=>x.id==ps.g),
 mine=p.u?(p.u.games||[]).filter(g=>g.pub!==false&&!(g.rv&&g.rv.s&&g.rv.s!=='approved')):[];
 let b='';
 if(self)b=`<button class="bl" data-a="edav">Edit Avatar</button>`;
 else if(r=='none')b=`<button class="bl" data-a="freq" data-v="${esc(n)}">Tambahkan Teman</button><button data-a="ffol" data-v="${esc(n)}">${fo?'Mengikuti':'Ikuti'}</button>`;
 else if(r=='sent')b=`<button data-a="fcan" data-v="${esc(n)}">Permintaan terkirim · Batalkan</button><button data-a="ffol" data-v="${esc(n)}">${fo?'Mengikuti':'Ikuti'}</button>`;
 else if(r=='recv')b=`<button class="bl" data-a="facc" data-v="${esc(n)}">Terima</button><button data-a="fdec" data-v="${esc(n)}">Tolak</button>`;
 else b=`<button class="bl" data-a="chatw" data-v="${esc(n)}">Chat</button>${gm?`<button class="bl" data-a="join" data-v="${esc(n)}">Bergabung</button>`:''}<button data-a="ffol" data-v="${esc(n)}">${fo?'Mengikuti':'Ikuti'}</button>`;
 if(!self)b+=`<button class="sm" data-a="pmore" data-v="${esc(n)}" aria-label="Lainnya">${ico('more',26)}</button>`;
 return `<div class="otop" style="position:absolute;left:0;right:0;background:none"><button class="rb" data-a="ovb" aria-label="Tutup">${ico('x',30)}</button></div><div class="pst"><div id="pst3" data-n="${esc(n)}" style="width:100%;height:100%">${avHTML(p.av,12)}</div></div>
 <div class="pid">${circ(p.av,72)}<div><b>${esc(n)}${p.u?vb(p.u):''}</b><small>@${esc(String(n).toLowerCase())}</small></div></div>
 <div class="pch"><span>${c.fr} Teman</span><span class="dm">${c.fl} Pengikut</span><span class="dm">${c.fg} Mengikuti</span></div>
 ${gm&&r=='friend'?`<div class="pch" style="padding-top:0"><span style="background:#1f6b3f">● Bermain: ${esc(gm.name)}</span></div>`:''}
 <div class="pbt">${b}</div>
 <h3 class="sec" style="padding:0 16px">Saat ini Memakai</h3><div class="wr">${wearTiles(p)}</div>
 ${mine.length?`<h3 class="sec" style="padding:0 16px">Game buatan ${esc(n)}</h3><div class="hs">${mine.map(gcard).join('')}</div>`:''}<div style="height:40px"></div>`}
Object.assign(act,{edav(){ovClear();avt='cust';page='avatar';render()},
 pmore(n){shOpen(`<div class="shn" style="margin-top:6px">${esc(n)}</div>${rel(n)=='friend'?`<button class="sb" data-a="funf" data-v="${esc(n)}">Hapus teman</button>`:''}<button class="sb" data-a="cpn" data-v="${esc(n)}">Salin username</button><button class="sb ln" data-a="shx">Tutup</button>`)},
 cpn(n){try{navigator.clipboard.writeText(n)}catch(e){}shClose();toast('Username disalin')}});

/* ---- beranda: hanya teman yang sudah diterima ---- */
homeH=function(){const gs=pubGames(),rec=(me.recent||[]).map(id=>gs.find(g=>g.id==id)).filter(Boolean),bi=FRD(me).i.length;
 return `<div class="who" data-a="prof" data-v="${esc(me.name)}" style="cursor:pointer">${circ(me.av,46)}<span>${esc(me.name)}${vb(me)}</span></div>
 <div class="frs"><button class="fr add" data-a="ppl"><span class="circw"><span class="circ" style="--s:92px">${ico('adduser',40)}</span>${bi?`<i class="bdg">${bi}</i>`:''}</span><em>Tambah Teman</em></button>${friends().map(f=>`<button class="fr" data-a="fr" data-v="${esc(f.n)}"><span class="circw">${circ(f.a,92)}${f.pl||isBot(f.n)?'<i class="on"></i>':''}</span><em>${esc(f.n)}</em><small>${esc(f.pl?f.g:'Offline')}</small></button>`).join('')}</div>
 <h3 class="sec">Direkomendasikan untukmu</h3><div class="gg">${gs.map(gcard).join('')}</div>
 <h3 class="sec" id="cont">${rec.length?'Lanjutkan':'Populer'} ${ico('chev',20)}</h3><div class="hs">${(rec.length?rec:gs).map(gcard).join('')}</div>
 <h3 class="sec">Mabar bareng teman</h3><div class="card row" style="flex-wrap:wrap"><div style="flex:1;min-width:150px"><label>Kode room</label><input type="text" id="rc" value="${esc(roomCode)}" maxlength="16" style="margin:6px 0 0" oninput="roomCode=this.value.toLowerCase().replace(/[^a-z0-9-]/g,'')||'publik';save()"></div><button class="btn g" data-a="rnd">Acak</button></div>`};
act.ppl=function(){PQ='';ptab='add';ovOpen('ppl')};
const _dn6=act.dnav;act.dnav=function(v){if(v.startsWith('ppl:')){act.dclose();ptab=v.slice(4);PQ='';return ovOpen('ppl')}return _dn6(v)};

/* ---- chat: hanya teman ---- */
msgH=function(){const fl=friends();return '<h2>Chat</h2>'+(fl.length?fl.map(f=>{const m=lastMsg(f.n),un=((me.unr||{})[f.n]||0);return `<button class="crow" data-a="open" data-v="${esc(f.n)}">${circ(f.a,54)}<span><b>${esc(f.n)}${un?'<i class="dot2"></i>':''}</b><small class="lm">${m?esc((m.me?'Kamu: ':'')+m.t):(f.pl?'Bermain: '+esc(f.g):'Mulai ngobrol')}</small></span></button>`}).join(''):`<div class="empty">Kamu belum punya teman.<br>Tambahkan teman dulu untuk chat dan mabar.<br><br><button class="btn g" data-a="ppl">Cari Teman</button></div>`)};
function thrH(){const n=thread,p=pinfo(n),ok=rel(n)=='friend';if(!p)return '<div class="empty">Pengguna tidak ditemukan.</div><button class="btn" data-a="back">← Kembali</button>';
 if(me.unr)delete me.unr[n];const ps=ok?presOf(n):null,gm=ps&&allGames().find(x=>x.id==ps.g),ms=(me.chat||{})[n]||[];
 return `<div class="thh"><button class="rb" data-a="back" aria-label="Kembali">${ico('back',26)}</button>${circ(p.av,40)}<button class="nm" data-a="prof" data-v="${esc(n)}">${esc(n)}<small>${ok?(gm?'Bermain: '+esc(gm.name):'Offline'):'Bukan teman'}</small></button>${gm?`<button class="ub bl" data-a="join" data-v="${esc(n)}">Gabung</button>`:''}</div>
 <div class="thm">${ms.length?ms.map(b=>`<div class="bubble ${b.me?'me':''}">${esc(b.t)}</div>`).join(''):'<div class="empty">Belum ada pesan. Sapa '+esc(n)+'!</div>'}</div>
 ${ok?`<div class="thi"><input type="text" id="mi" placeholder="Tulis pesan" maxlength="200" autocomplete="off"><button class="btn g" data-a="say">Kirim</button></div>`:`<div class="empty">Kamu harus berteman dulu untuk chat.<br><br><button class="btn c" data-a="prof" data-v="${esc(n)}">Lihat profil</button></div>`}`}
act.say=function(){const i=$('#mi');if(!i||!thread)return;const t=i.value.trim(),n=thread;if(!t||rel(n)!='friend')return;
 (me.chat=me.chat||{})[n]=(me.chat[n]||[]).concat({me:1,t,ts:Date.now()}).slice(-80);
 if(users[n]){const u=users[n];(u.chat=u.chat||{})[me.name]=(u.chat[me.name]||[]).concat({me:0,t,ts:Date.now()}).slice(-80);(u.unr=u.unr||{})[me.name]=((u.unr||{})[me.name]||0)+1}
 else setTimeout(()=>{if(!me||rel(n)!='friend')return;const r=['Haha keren!','Ayo mabar ','Aku lagi di '+(allGames().find(x=>x.id==(presOf(n)||{}).g)||{name:'game'}).name,'Oke siap!','Gas!'][Math.random()*5|0];(me.chat[n]=me.chat[n]||[]).push({me:0,t:r,ts:Date.now()});save();if(page=='msg'&&thread==n)render()},900);
 save();render();const m=$('#mi');if(m)m.focus()};
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.id=='mi'){e.preventDefault();act.say()}});

/* ---- Favorit & Kustomisasi bertab ---- */
let ctab='av';act.ct=function(v){ctab=v;render()};
avP=function(){const own=it=>(me.items||[]).some(x=>x.src==it.key||'u_'+me.name+'_'+x.id==it.key);
 let h=`<div class="atop"><button class="rb" data-a="go" data-v="home" aria-label="Kembali">${ico('back',28)}</button><div class="seg"><button class="${avt=='mkt'?'on':''}" data-a="avt" data-v="mkt">Marketplace</button><button class="${avt!='mkt'?'on':''}" data-a="avt" data-v="cust">Kustomisasi</button></div><span class="bx">${ico('hex',20)} ${me.bux}</span></div><div class="stage">${avHTML(me.av,13)}</div><div class="sheet"><i class="grab"></i>`;
 if(avt=='mkt'){const all=mkItems(),f=all.filter(it=>mfil=='all'||(mfil=='off'?it.by=='Pickare':it.by!='Pickare'));
  h+=`<div class="ban">${ico('hex',20)}<span>Kamu punya <b>${me.bux}</b> PickBux. Item kreator muncul setelah dipublish.</span></div><div class="chips">${[['all','Semua'],['off','Resmi'],['cr','Kreator']].map(c=>`<button class="${mfil==c[0]?'on':''}" data-a="mf" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>`+
  (f.length?`<div class="ig">${f.map(it=>{const im=okImg(it.icon),o=own(it);return `<button class="it" data-a="buy" data-v="${esc(it.key)}"><span class="ith">${im?`<img src="${im}" alt="">`:esc(it.e||String(it.name||'?').charAt(0).toUpperCase())}</span><strong>${esc(it.name)}</strong><small>${esc(it.by)}${it.v?' ✔':''}</small><em>${o?'Dimiliki':ico('hex',15)+' '+(+it.price||0)}</em></button>`}).join('')}</div>`:'<div style="color:var(--mut);padding:20px 0;text-align:center">Belum ada item.</div>')}
 else{const sw=(k,arr)=>`<div class="sws">${arr.map(c=>`<span class="sw ${me.av[k]==c?'sel':''}" style="background:${c}" data-a="av" data-k="${k}" data-v="${c}"></span>`).join('')}</div>`;
  h+=`<div class="chips" style="margin-top:4px">${[['av','Avatar'],['body','Tubuh'],['cloth','Pakaian'],['acc','Aksesori']].map(c=>`<button class="${ctab==c[0]?'on':''}" data-a="ct" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>`;
  if(ctab=='av')h+=`<div class="sl" style="margin-top:0">Sedang dipakai</div><div class="wr" style="padding:0">${wearTiles(me)}</div><button class="sb" style="margin-top:18px;background:#4d2a2d;border:0;border-radius:12px;padding:15px;width:100%;font:700 16px Inter,sans-serif;color:#fff;cursor:pointer" data-a="avt" data-v="mkt">Buka Marketplace</button>`;
  if(ctab=='body')h+=`<div class="sl" style="margin-top:0">Warna kulit</div>${sw('skin',SKIN)}`;
  if(ctab=='cloth')h+=`<div class="sl" style="margin-top:0">Baju</div>${sw('shirt',SHIRT)}<div class="sl">Celana</div>${sw('pants',PANTS)}`;
  if(ctab=='acc'){const its=me.items||[];h+=`<div class="sl" style="margin-top:0">Topi</div>${[['none','Polos'],['cap','Topi'],['crown','Mahkota']].map(x=>`<button class="chip ${me.av.hat==x[0]?'on':''}" data-a="av" data-k="hat" data-v="${x[0]}">${x[1]}</button>`).join('')}<div class="sl">Aksesori 3D saya</div>`+(its.length?`<div class="ig">${its.map(i=>{const on=(me.av.acc||[]).includes(i.id),im=okImg(i.icon);return `<button class="it" data-a="acc" data-v="${esc(i.id)}"><span class="ith" style="${on?'outline:3px solid #fff':''}">${im?`<img src="${im}" alt="">`:''}</span><strong>${esc(i.name)}</strong><small>${on?'✓ Dipakai':esc(i.slot||'Kepala')}</small></button>`}).join('')}</div>`:'<div style="color:var(--mut);font-size:14px">Belum ada. Beli di Marketplace atau buat di Studio.</div>')}}
 return h+'</div>'};
const _r7=render;
render=function(){_r7();const m=$('#main');
 if(page=='fav'){const gs=pubGames().filter(g=>(me.favs||[]).includes(g.id));m.innerHTML='<div class="page"><h2>Favorit</h2>'+(gs.length?'<div class="gg">'+gs.map(gcard).join('')+'</div>':'<div class="empty">Belum ada favorit.<br>Buka sebuah game lalu ketuk ★ Favorit.</div>')+'</div>'}
 if(page=='msg'){m.innerHTML='<div class="page">'+(thread?thrH():msgH())+'</div>';if(thread){m.scrollTop=m.scrollHeight;const i=$('#mi');if(i&&!navigator.maxTouchPoints)i.focus()}}
 navRender()};

/* ---- presence, kunjungan, bot pending ---- */
const _sg7=startGame;
startGame=function(g,test){if(!test&&me&&g&&g.id){me.pres={g:g.id,room:roomCode,t:Date.now()};const v=ls.get('sp_vis',{});v[g.id]=(v[g.id]||0)+1;ls.set('sp_vis',v);save()}ovClear();return _sg7.apply(this,arguments)};
const _st7=stopGame;
stopGame=function(){if(me){me.pres=null;save()}return _st7.apply(this,arguments)};
const _out7=act.out;act.out=function(){if(me){me.pres=null;save()}ovClear();return _out7.apply(this,arguments)};
const _en7=enter;
enter=function(){_en7();FRD(me).o.filter(isBot).forEach((n,i)=>setTimeout(()=>botAcc(n),1200+i*600));if(!$('#ov')){$('#app').insertAdjacentHTML('beforeend','<div id="ov"></div><div id="sh"><div id="shs" data-a="shx"></div><div id="shp"></div></div>')}};
if(!$('#ov'))$('#app').insertAdjacentHTML('beforeend','<div id="ov"></div><div id="sh"><div id="shs" data-a="shx"></div><div id="shp"></div></div>');
if(me&&$('#app').classList.contains('on')){FRD(me).o.filter(isBot).forEach((n,i)=>setTimeout(()=>botAcc(n),1200+i*600));render()}

/* perbaikan: animasi saldo tidak lagi bergantung pada menu samping */
addBux=function(n){me.bux+=n;save();const p=document.querySelector('.hb[data-a=daily]');if(p){p.classList.remove('bump');void p.offsetWidth;p.classList.add('bump')}navRender()};
