/* ===== v12c: tombol ＋ di Part/Model/Folder/Script + efek sebagai anak objek ===== */
(function(){
const FXC=['Fire','Smoke','Sparkles','ParticleEmitter','Explosion','PointLight'];
const OBJC=['Script','ModuleScript','Folder'].concat(FXC);
const FXD={
 Fire:{Rate:28,Lifetime:.9,Speed:3,Size:.7,SpreadAngle:14,Acceleration:-4,Color:'#ff7300',Enabled:true},
 Smoke:{Rate:10,Lifetime:2.6,Speed:2,Size:.8,SpreadAngle:20,Acceleration:-1,Color:'#737373',Enabled:true},
 Sparkles:{Rate:24,Lifetime:.8,Speed:2.2,Size:.18,SpreadAngle:180,Acceleration:0,Color:'#ffe64d',Enabled:true},
 ParticleEmitter:{Rate:20,Lifetime:1.5,Speed:5,Size:.3,SpreadAngle:35,Acceleration:0,Color:'#ffffff',Enabled:true},
 Explosion:{BlastRadius:6,Color:'#ff8019'},
 PointLight:{Brightness:1,Range:16,Color:'#ffffff'}};
const FP={Fire:['Rate','Lifetime','Speed','Size','SpreadAngle','Acceleration'],Smoke:['Rate','Lifetime','Speed','Size','SpreadAngle','Acceleration'],Sparkles:['Rate','Lifetime','Speed','Size','SpreadAngle','Acceleration'],ParticleEmitter:['Rate','Lifetime','Speed','Size','SpreadAngle','Acceleration'],Explosion:['BlastRadius'],PointLight:['Brightness','Range']};
Object.assign(CL,{Fire:'',Smoke:'',Sparkles:'',ParticleEmitter:'',Explosion:'',PointLight:''});
Object.assign(CD,{Fire:'Api menyala di Part induknya',Smoke:'Asap yang naik dari Part',Sparkles:'Percikan warna-warni di Part',ParticleEmitter:'Pemancar partikel (atur Rate, Speed, Warna)',Explosion:'Ledakan sekali jalan di posisi Part',PointLight:'Cahaya titik yang menyala di Part'});
FXC.forEach(c=>{if(!PL.Workspace.includes(c))PL.Workspace.push(c)});
/* newI: isi nilai default efek */
const _ni=newI;newI=function(cls){const i=_ni.apply(this,arguments);if(FXD[cls]){i.fx=1;Object.assign(i,FXD[cls])}return i};
/* picker: Part/Model/objek 3D, Folder, Script */
const _pk2=pickL;pickL=function(t){let L=_pk2(t);
 try{const have=new Set(L.map(x=>x.id)),add=c=>{if(!have.has(c)){have.add(c);L.push({id:c,k:'inst',n:c,ic:CL[c],d:CD[c]})}};
  if(t==='@acc')OBJC.concat(['LocalScript','RemoteEvent','RemoteFunction','BindableEvent','Sound']).forEach(add);
  else if(ST&&ST.d&&(ST.d.objs||[]).some(o=>o.id==t))OBJC.concat(ST.kind==='a'?['LocalScript']:[]).forEach(add);
  else{const r=loc(t);if(r){const cl=r.i.cls;if(cl==='Folder'||/Script$/.test(cl)&&cl!=='LocalScript')OBJC.concat(ST.kind==='a'?['LocalScript']:[]).forEach(add)}}}catch(e){}
 return L};
/* properti efek */
const _ip=iProps;iProps=function(i){if(!i||!i.fx)return _ip.apply(this,arguments);
 const f=FP[i.cls]||[];let h='<h4>'+(CL[i.cls]||'')+' '+i.cls+'</h4><label>Nama</label><input type="text" data-q="n" value="'+esc(i.n)+'" maxlength="24">';
 f.forEach(k=>h+='<label>'+k+'</label><input type="number" step="any" data-q="'+k+'" value="'+(+i[k]||0)+'">');
 h+='<label>Color</label><input type="color" data-q="Color" value="'+(/^#[0-9a-f]{6}$/i.test(i.Color)?i.Color:'#ffffff')+'">';
 if(i.Enabled!==undefined)h+='<label class="ck"><input type="checkbox" data-q="Enabled" '+(i.Enabled!==false?'checked':'')+'> Enabled</label>';
 h+='<div style="font-size:11px;opacity:.7;margin-top:6px">Efek tampil di Part induknya saat game dimainkan (Test / Main).</div>';return h};
/* runtime */
const num=(v,d)=>{v=+v;return isFinite(v)?v:d};
function lc(h){const m=/^#([0-9a-f]{6})$/i.exec(h||'');if(!m)return new LC(1,1,1);const n=parseInt(m[1],16);return new LC((n>>16&255)/255,(n>>8&255)/255,(n&255)/255)}
function mkFx(n,par){const w=G.get('Instance').get('new')(n.cls);
 ['Rate','Lifetime','Speed','Size','SpreadAngle','Acceleration','Brightness','Range','BlastRadius'].forEach(k=>{if(n[k]!==undefined)w.$s(k,num(n[k],0))});
 if(n.Color)w.$s('Color',lc(n.Color));if(n.Enabled===false)w.$s('Enabled',false);w.$s('Name',n.n||n.cls);w.$s('Parent',(Array.isArray(n.pq)&&n.pq.length===4&&par===RT.root)?{$q:n.pq}:par);return w}
function walk(list,parW,posW,fxOnly,dep,acc){if(dep>12)return;(list||[]).forEach(n=>{if(!n)return;
 try{if(FXD[n.cls])mkFx(n,posW||RT.ws);
  else if((n.cls==='Script'||acc&&n.cls==='LocalScript')&&!fxOnly)runScript(n,parW);
  else if(n.cls==='Folder')walk(n.ch,iW(n),posW,fxOnly,dep+1,acc);
  if(/Script$/.test(n.cls)&&n.ch&&n.ch.length)walk(n.ch,parW,posW,fxOnly,dep+1,acc)}catch(e){OUT('err',(n.n||n.cls)+' → '+(e.message||e))}})}
const _rs=rtStart;rtStart=function(g){_rs.apply(this,arguments);
 try{if(!RT||!RT.alive||!g||!g.svc)return;
  (RT.parts||[]).forEach(w=>{if(w.o&&w.o.ch&&w.o.ch.length)walk(w.o.ch,w,w,false,0)});
  walk((g.svc.Workspace||[]).filter(x=>x.cls==='Folder'),RT.ws,null,true,0);
  {const tl=[],col=l=>(l||[]).forEach(i=>{if(i.cls==='Tool')tl.push(i);else if(i.cls==='Folder')col(i.ch)});col(g.svc.StarterPack);tl.forEach(t=>{if(t.ch&&t.ch.length){const w=iW(t);walk(t.ch,w,w,true,0)}})}
  {const ids=(forceAcc||(me.av&&me.av.acc)||[]).slice();if(me.av&&me.av.body&&!ids.includes(me.av.body))ids.push(me.av.body);
   const fm=o=>{let r=null;try{plr.traverse(c=>{if(!r&&c.userData&&c.userData.o===o)r=c})}catch(e){}return r};
   ids.forEach(id=>{const it=(me.items||[]).find(x=>x.id==id);if(!it)return;if(it.ch&&it.ch.length)walk(it.ch,RT.ch,RT.root,false,0,true);(it.objs||[]).forEach(o=>{if(o&&o.ch&&o.ch.length){const mm=fm(o);walk(o.ch,RT.ch,mm?{$am:mm}:RT.root,false,0,true)}})})}}catch(e){OUT('err',e.message||e)}};
})();
