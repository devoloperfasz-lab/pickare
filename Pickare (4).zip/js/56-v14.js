/* ===== v14: Daftar Admin — semua pemain bisa lihat siapa saja staf =====
   Owner menandatangani daftar staf (kunci owner) lalu mengirimnya ke broker; tiap perangkat memverifikasi dengan public key owner
   yang sudah disematkan (sp_ownpk) sebelum menampilkannya. Daftar lokal (akun yang punya role di perangkat ini) ikut digabung. */
(function(){
const OWN='pickare/v9/own/',ST=OWN+'staff',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const EC={name:'ECDSA',namedCurve:'P-256'},SG={name:'ECDSA',hash:'SHA-256'};
const te=s=>new TextEncoder().encode(s),mq=()=>window.__spMq;
const b64=u=>{let s='';u.forEach(c=>s+=String.fromCharCode(c));return btoa(s)},unb=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
const ready=async()=>!!(mq()&&(window.mqtt||await mq().lib()));
const OK={owner:3,coowner:2,admin:1},LBL={owner:'OWNER',coowner:'CO-ADMIN',admin:'ADMIN'};
const clean=n=>String(n||'').replace(/[\u0000-\u001f<>"&]/g,'').slice(0,20);
const msg=(l,t)=>'staff|'+t+'|'+JSON.stringify(l);
let busy=0,loadedAt=0;
function sub(url,topic,ms,cb){return new Promise(res=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}res()};
 try{m=mqtt.connect(url,{clientId:'sps_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){return res()}
 m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topic,{qos:0});setTimeout(end,ms)});
 m.on('message',(t,b)=>{try{const s=b.toString();if(s)cb(JSON.parse(s))}catch(e){}});setTimeout(end,ms+4000)})}
/* daftar dari akun lokal */
function localList(){const o=[];try{Object.keys(users).forEach(k=>{const u=users[k];if(u&&OK[u.role])o.push([k,u.role])})}catch(e){}return o}
/* OWNER: kirim daftar staf bertanda tangan */
async function publish(force){try{if(!me||me.role!=='owner'||!(await ready()))return;
 const l=localList().sort((a,b)=>OK[b[1]]-OK[a[1]]||a[0].localeCompare(b[0])),sg=JSON.stringify(l),S=ls.get('sp_stsig',{});
 if(!force&&S.s===sg&&Date.now()-S.t<216e5)return;
 const k=ls.get('sp_okey',null);if(!k||!k.priv)return;const ts=Date.now();
 const key=await crypto.subtle.importKey('jwk',k.priv,EC,false,['sign']),sig=b64(new Uint8Array(await crypto.subtle.sign(SG,key,te(msg(l,ts)))));
 if(await mq().pushAll([{t:ST,p:JSON.stringify({list:l,ts,sig})}]))ls.set('sp_stsig',{s:sg,t:Date.now()})}catch(e){}}
/* SEMUA: ambil daftar, verifikasi, simpan cache */
async function load(){if(busy)return;busy=1;try{if(!(await ready()))return;const pin=ls.get('sp_ownpk',null);if(!pin)return;let best=null;
 await Promise.all(BR.map(u=>sub(u,ST,2500,d=>{if(d&&d.sig&&Array.isArray(d.list)&&(!best||d.ts>best.ts))best=d})));
 if(!best)return;const c=ls.get('sp_staffc',{});if((c.ts||0)>=best.ts){loadedAt=Date.now();return}
 const key=await crypto.subtle.importKey('jwk',pin,EC,false,['verify']);
 if(!(await crypto.subtle.verify(SG,key,unb(best.sig),te(msg(best.list,best.ts)))))return;
 const l=best.list.filter(x=>Array.isArray(x)&&OK[x[1]]).slice(0,60).map(x=>[clean(x[0]),x[1]]);
 ls.set('sp_staffc',{list:l,ts:best.ts});loadedAt=Date.now()}catch(e){}finally{busy=0}}
/* gabungan: cache terverifikasi + lokal; role lokal menang (lebih baru di perangkat ini) */
function merged(){const m=new Map(),c=ls.get('sp_staffc',{});(c.list||[]).forEach(x=>m.set(x[0].toLowerCase(),x));
 localList().forEach(x=>m.set(x[0].toLowerCase(),x));
 try{if(me&&OK[me.role])m.set(me.name.toLowerCase(),[me.name,me.role]);else if(me)m.delete(me.name.toLowerCase())}catch(e){}
 return [...m.values()].sort((a,b)=>OK[b[1]]-OK[a[1]]||a[0].localeCompare(b[0]))}
function sheet(){const l=merged();
 const row=x=>{const n=x[0],a=(()=>{try{const k=Object.keys(users).find(y=>y.toLowerCase()===n.toLowerCase());return k&&users[k].av||(typeof avFor==='function'?avFor(n):null)}catch(e){return null}})();
  return `<div class="ur"><button class="ura" data-a="prof" data-v="${esc(n)}">${a?circ(a,48):''}<span><b>${esc(n)}</b><small style="display:block;opacity:.7">${LBL[x[1]]||''}</small></span></button></div>`};
 shOpen('<div class="shn" style="margin-top:6px">Daftar Admin</div>'+(l.length?l.map(row).join(''):'<div style="text-align:center;opacity:.7;padding:14px 6px">Belum ada admin yang terdata.</div>')+'<button class="sb ln" data-a="shx">Tutup</button>');
 if(Date.now()-loadedAt>15000)load().then(()=>{const sh=document.getElementById('sh');if(sh&&sh.classList.contains('on')&&document.querySelector('#shp .shn')&&/Daftar Admin/.test(document.querySelector('#shp .shn').textContent)){const b=JSON.stringify(l),n=JSON.stringify(merged());if(b!==n)sheet()}})}
act.admins=function(){sheet()};
/* tombol di menu samping + kartu kecil di Beranda tidak memberatkan render (hanya satu tombol) */
if(typeof drawerFill==='function'){const _d=drawerFill;drawerFill=function(){_d.apply(this,arguments);try{const d=$('#dpn');if(d&&!d.querySelector('[data-a="admins"]')){const sw=d.querySelector('[data-a="redeem"]')||d.querySelector('.mi');const h='<button class="mi" data-a="admins">'+(typeof ico==='function'&&typeof IC!=='undefined'&&IC.shield?ico('shield',27):'')+'<span>Daftar Admin</span></button>';if(sw)sw.insertAdjacentHTML('afterend',h);else d.insertAdjacentHTML('beforeend',h)}}catch(e){}}}
window.spStaffList=merged;window.spStaffLoad=()=>load();
window.addEventListener('load',()=>{
 const _g=act.grole;if(typeof _g==='function')act.grole=function(){const r=_g.apply(this,arguments);setTimeout(()=>publish(true),2500);return r};
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{publish();load()},4000);return r};
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden){publish();if(Date.now()-loadedAt>120000)load()}},60000);
 if(typeof me!=='undefined'&&me)setTimeout(()=>{publish();load()},6000)});
})();
