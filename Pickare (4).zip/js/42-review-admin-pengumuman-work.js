/* ===== REVIEW ADMIN + PENGUMUMAN + WORK ===== */
const RV=(()=>{const ID=i=>document.getElementById(i),Q='pickare/v9/rvq/',mq=()=>window.__spMq,ky=(k,by,id)=>(k+'_'+String(by).toLowerCase()+'_'+id).replace(/[^\w-]/g,'_').slice(0,60),
sm=u=>u&&u.length<6e4?u:'',rid=()=>Math.random().toString(36).slice(2,9)+Date.now().toString(36),rf=()=>{try{render()}catch(e){}try{hubRender()}catch(e){}};
const cat=(k,o)=>k=='map'?'Map':k=='mdl'?'Model':k=='snd'?'Suara':({Tubuh:'Tubuh',Avatar:'Avatar',Pakaian:'Pakaian',Sepatu:'Pakaian'})[o.slot]||'Aksesori';
const ent=(k,o,by)=>({key:ky(k,by,o.id),k,id:String(o.id),by,n:o.name||'',d:o.desc||'',p:+o.price||0,c:cat(k,o),t:(o.rv&&o.rv.t)||Date.now(),oc:(o.objs||(o.data&&o.data.objs)||[]).length,ic:sm(o.icon),th:sm(o.thumb),ag:o.age||''});
const push=(e,clr)=>{try{mq()&&mq().pushAll([{t:Q+e.key,p:clr?'':JSON.stringify(e)}])}catch(x){}};
const find=(k,id,by)=>{const u=users[by];if(k=='acc')return u&&(u.items||[]).find(i=>i.id==id);if(k=='map')return u&&(u.games||[]).find(g=>g.id==id);return ls.get('sp_models',[]).find(m=>m.id==id)};
let T={},C=ls.get('sp_rvq',{});
const R={
 pend:g=>!!(g&&g.rv&&g.rv.s=='pending'),
 submit(o,k){if(lv(me)>=3){o.pub=true;o.rv={s:'approved',t:Date.now()};save();notify('"'+o.name+'" dipublikasikan');return true}
  o.pub=false;o.rv={s:'pending',t:Date.now()};save();push(ent(k,o,me.name));notify('"'+o.name+'" dikirim ke admin untuk dicek');return false},
 stamp(r,k){if(lv(me)>=3){r.rv={s:'approved',t:Date.now()};return}r.rv={s:'pending',t:Date.now()};push(ent(k,r,me.name));notify('"'+r.name+'" dikirim ke admin untuk dicek')},
 cancel(o){const k=o.slot!==undefined||o.objs&&!o.age&&!o.col?'acc':'map';o.rv=null;o.pub=false;save();try{(me.items||[]).includes(o)&&push({key:ky('acc',me.name,o.id)},1);(me.games||[]).includes(o)&&push({key:ky('map',me.name,o.id)},1)}catch(e){}},
 cancelById(id){const o=(me.games||[]).concat(me.items||[]).find(x=>x.id==id);if(o){R.cancel(o);toast('Pengajuan dibatalkan');rf()}},
 note(g){const v=g.rv;if(v&&v.s=='pending')return '<div class="nt">⏳ Menunggu review admin. Setelah disetujui, otomatis tampil publik.</div><div class="row"><button class="ghost" data-a="rvcancel" data-v="'+esc(g.id)+'">Batalkan pengajuan</button></div>';
  if(v&&(v.s=='off'||v.s=='banned'))return '<div class="nt">⛔ '+(v.s=='off'?'Off sale':'Diblokir')+' oleh staf'+(v.note?': '+esc(v.note):'')+'. Tidak bisa dipublish ulang.</div>';if(v&&v.s=='rejected')return '<div class="nt">❌ Ditolak admin'+(v.note?': '+esc(v.note):'')+'. Perbaiki lalu ajukan lagi.</div>';return '<div class="nt">Item dicek admin dulu sebelum tampil di Marketplace/Beranda.</div>'},
 mut(k,id,by,fn){if(k=='mdl'||k=='snd'){const a=ls.get('sp_models',[]),o=a.find(m=>m.id==id);if(!o)return null;fn(o);ls.set('sp_models',a);return o}const o=find(k,id,by);if(!o)return null;fn(o);save();return o},
 blk:g=>!!(g&&g.rv&&(g.rv.s=='off'||g.rv.s=='banned')),
 apply(k,id,by,ok,note){note=String(note||'').slice(0,100);const o=R.mut(k,id,by,o=>{o.rv={s:ok?'approved':'rejected',t:Date.now(),note};if(k=='acc'||k=='map')o.pub=!!ok});if(!o)return;
  const u=users[by]||me;(u.notes=u.notes||[]).unshift({t:'"'+o.name+'" '+(ok?'disetujui admin ✓':'ditolak admin'+(note?': '+note:'')),new:1});save();rf()},
 setS(k,id,by,s,note){if(!/^(off|banned|ok)$/.test(s))return;note=String(note||'').slice(0,100);const on=s=='ok',o=R.mut(k,id,by,o=>{o.rv={s:on?'approved':s,t:Date.now(),note};if(k=='acc'||k=='map')o.pub=on});if(!o)return;
  const u=users[by]||me;(u.notes=u.notes||[]).unshift({t:'"'+o.name+'" '+(on?'diaktifkan kembali oleh staf':s=='off'?'di-off sale oleh staf':'diblokir oleh staf')+(note&&!on?': '+note:''),new:1});save();rf()},
 W:{},
 works(){const L={},add=(k,by,id,n,c,st,ic,note)=>{L[ky(k,by,id)]={key:ky(k,by,id),k,by,id,n,c,st,ic,note}},px=(i)=>'u_'+i.by+'_';
  mkItems().forEach(i=>{if(i.by&&i.by!='Pickare'&&String(i.key).startsWith(px(i))){add('acc',i.by,i.key.slice(px(i).length),i.name,cat('acc',i),'on',i.icon)}});
  pubGames().forEach(g=>{if(g.by&&g.by!='Pickare')add('map',g.by,g.id,g.name,'Map','on',g.icon)});
  ls.get('sp_models',[]).concat(window.spRMD||[]).forEach(m=>{if(m.by&&(!m.rv||m.rv.s=='approved'))add(m.kind=='sound'?'snd':'mdl',m.by,m.id,m.name,cat(m.kind=='sound'?'snd':'mdl',m),'on',m.thumb)});
  const bad=(k,o,by)=>{if(R.blk(o))add(k,by,o.id,o.name,cat(k,o),o.rv.s,o.icon||o.thumb,o.rv.note)};
  Object.keys(users).forEach(un=>{const u=users[un];if(!u||u.rm)return;(u.items||[]).forEach(i=>!i.src&&bad('acc',i,un));(u.games||[]).forEach(g=>bad('map',g,un))});
  ls.get('sp_models',[]).forEach(m=>bad(m.kind=='sound'?'snd':'mdl',m,m.by));
  Object.values(ls.get('sp_tkd',{})).forEach(t=>{if(t&&t.k&&(t.s=='off'||t.s=='banned')){const kk=ky(t.k,t.by,t.id);if(!L[kk])add(t.k,t.by,t.id,t.n||t.id,t.c||'',t.s,t.ic,t.note)}});
  R.W=L;return Object.values(L).sort((a,b)=>(a.st=='on')-(b.st=='on')).slice(0,80)},
 worksH(){const L=R.works();return L.length?L.map(w=>`<div class="card ur2"><div class="ur2h"><b>${esc(w.n)}</b><span class="pill" style="font-size:12px">${esc(w.c)} · ${w.st=='on'?'Aktif':w.st=='off'?'Off sale':'Diblokir'}</span></div><div style="display:flex;gap:8px;align-items:center;margin:4px 0">${w.ic?`<img src="${w.ic}" width="44" height="44" style="border-radius:8px;object-fit:cover">`:''}<div class="rby">oleh <b>${esc(w.by)}</b>${w.note?'<br>Alasan: '+esc(w.note):''}</div></div>${w.st=='on'?`<input type="text" id="wn_${w.key}" placeholder="Alasan (wajib)" maxlength="100"><div class="rac"><button class="btn sm c" data-a="wkdo" data-v="${w.key}|off">Off Sale</button><button class="btn sm o" data-a="wkdo" data-v="${w.key}|banned">Blokir</button><button class="btn sm o" data-a="wkdo" data-v="${w.key}|del">Hapus</button><button class="btn sm o" data-a="wkdo" data-v="${w.key}|banuser">Ban pembuat</button></div>`:`<input type="text" id="wn_${w.key}" placeholder="Alasan (untuk Hapus/Ban)" maxlength="100"><div class="rac"><button class="btn sm g" data-a="wkdo" data-v="${w.key}|ok">Aktifkan lagi</button><button class="btn sm o" data-a="wkdo" data-v="${w.key}|del">Hapus</button><button class="btn sm o" data-a="wkdo" data-v="${w.key}|banuser">Ban pembuat</button></div>`}</div>`).join(''):'<div class="empty2"><b>Belum ada karya</b><p style="margin:0">Karya kreator yang sudah tayang muncul di sini.</p></div>'},
 wkdo(v){const [key,st]=v.split('|'),w=R.W[key];if(!w)return;const note=((document.getElementById('wn_'+key)||{}).value||'').trim();if(st!='ok'&&note.length<3)return toast('Isi alasan dulu');
  if(st=='banuser'){if(!users[w.by])users[w.by]={rm:1,bux:0,av:null,games:[],notes:[]};if(typeof act.banu=='function')act.banu(w.by);else toast('Fitur ban tidak tersedia');return}
  if(w.by==(me&&me.name)&&lv(me)<3)return toast('Tidak boleh memproses punya sendiri');
  const it=w.k=='acc'?mkItems().find(i=>i.by==w.by&&i.key=='u_'+w.by+'_'+w.id):null;
  R.send(w.k,w.by,w.id,st,w.n,w.c,w.ic,note);
  toast(st=='ok'?'Diaktifkan lagi (global)':st=='off'?'Off sale — berlaku di semua perangkat':st=='del'?'Dihapus — berlaku di semua perangkat':'Diblokir — berlaku di semua perangkat');rf()},
 b(){T={}},got(t,d){if(d&&d.key&&d.n)T[d.key]=d},f(){C=T;ls.set('sp_rvq',C)},
 list(){const L={};Object.values(C).forEach(e=>L[e.key]=e);Object.keys(users).forEach(un=>{const u=users[un];if(!u||u.rm)return;(u.items||[]).forEach(i=>{if(R.pend(i)&&!i.src)L[ky('acc',un,i.id)]=ent('acc',i,un)});(u.games||[]).forEach(g=>{if(R.pend(g))L[ky('map',un,g.id)]=ent('map',g,un)})});
  ls.get('sp_models',[]).forEach(m=>{if(R.pend(m))L[ky(m.kind=='sound'?'snd':'mdl',m.by,m.id)]=ent(m.kind=='sound'?'snd':'mdl',m,m.by)});return Object.values(L).sort((a,b)=>a.t-b.t)},
 n(){return staff()?R.list().length:0},
 decide(key,ok){const e=R.list().find(x=>x.key==key);if(!e)return;if(e.by==me.name&&lv(me)<3)return toast('Tidak boleh menyetujui punya sendiri');const note=(ID('rn_'+key)||{}).value||'';if(!ok&&note.trim().length<3)return toast('Isi alasan penolakan');
  const u=users[e.by];if((e.k=='mdl'||e.k=='snd')?find(e.k,e.id,e.by):(u&&!u.rm&&find(e.k,e.id,e.by)))R.apply(e.k,e.id,e.by,ok,note);else if(window.spSendCmd)window.spSendCmd(e.by,'rv',{k:e.k,id:e.id,ok:ok?1:0,note},0);
  delete C[key];ls.set('sp_rvq',C);push({key},1);toast(ok?'Disetujui ✓':'Ditolak');rf()},
 put(c,a){const l=ls.get('sp_'+c,[]).filter(x=>x.id!=a.id);l.unshift(a);l.sort((x,y)=>y.ts-x.ts);ls.set('sp_'+c,l.slice(0,40))},
 tk(k,by,id,st,n,c,ic,note,fromRemote,ts){if(!/^(off|banned|del|ok)$/.test(st))return 0;ts=ts||Date.now();const T0=ls.get('sp_tkd',{}),kk=window.tkKey(k,by,id);if(T0[kk]&&T0[kk].ts>=ts&&fromRemote)return 0;
  if(st=='ok')delete T0[kk];else T0[kk]={s:st,n:String(n||'').slice(0,40),c:String(c||'').slice(0,20),ic:(ic&&String(ic).length<400)?ic:'',note:String(note||'').slice(0,100),ts,k,by,id};
  ls.set('sp_tkd',T0);
  if(me&&String(by).toLowerCase()==me.name.toLowerCase()){
   if(st=='del'){if(k=='acc'&&me.items)me.items=me.items.filter(i=>i.id!=id);else if(k=='map'&&me.games)me.games=me.games.filter(g=>g.id!=id);else if(k=='mdl'||k=='snd')ls.set('sp_models',ls.get('sp_models',[]).filter(m=>m.id!=id));(me.notes=me.notes||[]).unshift({t:'"'+(n||id)+'" dihapus oleh staf'+(note?': '+note:''),new:1});save()}
   else R.setS(k,id,me.name,st,note)}
  rf();return 1},
 send(k,by,id,st,n,c,ic,note){const ts=Date.now();R.tk(k,by,id,st,n,c,ic,note,0,ts);const to='_tk'+window.tkKey(k,by,id).replace(/[^\w-]/g,'_').slice(0,50);
  if(window.spSendCmd)window.spSendCmd(to,'tkd',{k,by:String(by).slice(0,20),id:String(id).slice(0,40),s:st,n:String(n||'').slice(0,40),c:String(c||'').slice(0,20),ic:(ic&&String(ic).length<400)?ic:'',note:String(note||'').slice(0,100)},1);
  else toast('Tersimpan di perangkat ini; perintah global belum bisa dikirim')},
 rcv(rec){const c=String(rec.cmd||'').replace(/x$/,''),a=rec.args||{};
  if(c=='tkd'){if(!a.k||!a.by||!a.id)return 0;return R.tk(a.k,a.by,a.id,a.s,a.n,a.c,a.ic,a.note,1,rec.ts)}
  if(c!='ann'&&c!='wrk')return 0;const id=String(a.id||rec.to.slice(1)).replace(/[^\w-]/g,'').slice(0,24),o=ls.get('sp_'+c,[]).find(x=>x.id==id);if(o&&o.ts>=rec.ts)return 0;
  if(!o&&!/x$/.test(rec.cmd)&&me&&String(rec.from).toLowerCase()!=me.name.toLowerCase()){(me.notes=me.notes||[]).unshift({t:(+a.r>0?'🎁 Event PickBux: ':'📢 ')+String(a.t||'').slice(0,60),new:1});save()}
  R.put(c,{id,t:String(a.t||'').slice(0,60),x:String(a.x||'').slice(0,400),r:Math.max(0,Math.min(9999,Math.floor(+a.r||0))),by:String(rec.from).slice(0,20),ts:rec.ts,dead:/x$/.test(rec.cmd)?1:0});rf();return 1},
 post(c){const t=ID(c+'_t').value.trim(),x=ID(c+'_x').value.trim();if(t.length<3||x.length<5)return toast('Judul min 3 & isi min 5 huruf');const id=rid(),r=c=='ann'?Math.max(0,Math.min(9999,Math.floor(+ID('ann_r').value||0))):0,a={id,t,x,r};
  R.put(c,Object.assign({by:me.name,ts:Date.now(),dead:0},a));window.spSendCmd&&window.spSendCmd('_'+id,c,a,1);toast('Terkirim ke semua perangkat');rf()},
 del(c,id){R.put(c,{id,ts:Date.now(),dead:1});window.spSendCmd&&window.spSendCmd('_'+id,c+'x',{id},1);rf()},
 tab(t){if(t=='wk')return R.worksH();if(t=='vl')return R.vlH();if(t=='rv'){const L=R.list();return L.length?L.map(e=>`<div class="card ur2"><div class="ur2h"><b>${esc(e.n)}</b><span class="pill" style="font-size:12px">${esc(e.c)}</span></div><div style="display:flex;gap:8px;margin:6px 0">${e.ic?`<img src="${e.ic}" width="56" height="56" style="border-radius:8px;object-fit:cover">`:''}${e.th?`<img src="${e.th}" height="56" style="border-radius:8px">`:''}</div><div class="rtx">${esc(e.d||'-')}</div><div class="rby">oleh <b>${esc(e.by)}</b> · ${e.p} PickBux · ${e.oc} objek${e.ag?' · '+esc(e.ag):''}</div><input type="text" id="rn_${e.key}" placeholder="Alasan (wajib jika ditolak)" maxlength="100"><div class="rac"><button class="btn sm g" data-a="rvok" data-v="${e.key}">Setujui</button><button class="btn sm o" data-a="rvno" data-v="${e.key}">Tolak</button></div></div>`).join(''):'<div class="empty2"><b>Antrean kosong</b><p style="margin:0">Aksesori, tubuh, avatar, model, suara, dan map baru muncul di sini sebelum tayang.</p></div>'}
  const l=ls.get('sp_'+t,[]).filter(x=>!x.dead);return `<div class="card"><label>Judul</label><input type="text" id="${t}_t" maxlength="60"><label>Isi</label><input type="text" id="${t}_x" maxlength="400">${t=='ann'?'<label>Hadiah PickBux (0 = pengumuman biasa, &gt;0 = event klaim)</label><input type="text" inputmode="numeric" id="ann_r" value="0">':''}<button class="btn w g" data-a="rvpost" data-v="${t}">Kirim ke semua pemain</button><button class="btn w" data-a="ntest" style="margin-top:8px">🔔 Tes notifikasi HP</button></div>`+l.map(x=>`<div class="card ur2"><div class="ur2h"><b>${esc(x.t)}</b>${x.r?`<span class="pill" style="font-size:12px">${x.r} SB</span>`:''}</div><div class="rtx">${esc(x.x)}</div><div class="rby">${esc(x.by)}</div><div class="rac"><button class="btn sm o" data-a="rvdel" data-v="${t}:${x.id}">Hapus</button></div></div>`).join('')},
 annH(){const A=ls.get('sp_ann',[]).filter(x=>!x.dead).slice(0,5),cl=(me&&me.claimed)||[];if(!A.length)return'';
  return '<div class="anl">'+A.map(x=>`<div class="anc${x.r?' rw':''}"><div class="ani">${x.r?'🎁':'📢'}</div><div class="anb"><div class="ant">${esc(x.t)}</div><div class="anx">${esc(x.x)}</div><div class="anm">${esc(x.by||'Admin')}${x.ts?' · '+new Date(x.ts).toLocaleDateString('id-ID',{day:'numeric',month:'short'}):''}</div>${x.r?`<button class="anbt${cl.includes(x.id)?' dn':''}" data-a="rvwk" data-v="${x.id}">${cl.includes(x.id)?'Sudah diklaim ✓':'Klaim '+x.r+' PickBux'}</button>`:''}</div></div>`).join('')+'</div>'}};
Object.assign(act,{wkdo(v){R.wkdo(v)},rvok(v){R.decide(v,1)},rvno(v){R.decide(v,0)},rvcancel(v){R.cancelById(v)},rvpost(v){R.post(v)},rvdel(v){const i=v.indexOf(':');R.del(v.slice(0,i),v.slice(i+1))},rvwk(v){const x=ls.get('sp_ann',[]).find(a=>a.id==v&&!a.dead);if(!x||!x.r)return;me.claimed=me.claimed||[];if(me.claimed.includes(v))return toast('Sudah kamu klaim');me.claimed.push(v);me.bux=(me.bux||0)+x.r;(me.notes=me.notes||[]).unshift({t:'Klaim event: +'+x.r+' PickBux',new:1});save();toast('+'+x.r+' PickBux diklaim 🎉');rf();try{refreshUI()}catch(e){}}});
const _hh=homeH;homeH=function(){return R.annH()+_hh.apply(this,arguments)};
return R})();
