/* ===== v11: Panel hanya untuk staf + gift/ban lewat username (juga untuk pemain di perangkat lain) ===== */
(function(){
const STAFF_ACTS=['pt','gbux','gver','grole','grolev','banu','banui','banperm','bango','unban','bandirect','unbandirect','rtake','rdone','vlgo','vlx','rvok','rvno','rvpost','rvdel','wkdo'];
const OWNER_ACTS=['prgo','prdel','cdgo','cddel','cdcopy'];
const TARGET={gbux:'pt_u',gver:'pt_u',grole:'pt_u',bandirect:'bu_u',unbandirect:'bu_u'};
const HIDE='#n_panel,#spPnl,.mi[data-v="panel"],[data-a="go"][data-v="panel"],[data-a="dnav"][data-v="panel"]';
const isStaff=()=>{try{return typeof me!=='undefined'&&!!me&&staff()}catch(e){return false}};
const isOwner=()=>{try{return isStaff()&&lv(me)>=3}catch(e){return false}};
const deny=m=>{try{toast(m||'Hanya staf yang bisa melakukan ini')}catch(e){}};
const localKey=r=>{r=String(r||'').trim().replace(/^@/,'').toLowerCase();return r?Object.keys(users).find(k=>k.toLowerCase()===r)||null:null};

/* 1. sembunyikan Panel dari semua yang bukan staf */
function sweep(){
 if(isStaff())return;
 document.querySelectorAll(HIDE).forEach(e=>e.remove());
 try{if(typeof page!=='undefined'&&page==='panel'){page='home';render()}}catch(e){}
}
setInterval(sweep,700);

function install(){
 /* 2. semua aksi panel ditolak bila bukan staf / bukan owner */
 STAFF_ACTS.forEach(n=>{const o=act[n];if(typeof o!=='function')return;act[n]=function(){if(!isStaff())return deny();return o.apply(this,arguments)}});
 OWNER_ACTS.forEach(n=>{const o=act[n];if(typeof o!=='function')return;act[n]=function(){if(!isOwner())return deny('Hanya Owner yang bisa melakukan ini');return o.apply(this,arguments)}});
 const go=act.go;act.go=function(v){if(v==='panel'&&!isStaff())v='home';return go.call(this,v)};
 const dn=act.dnav;if(typeof dn==='function')act.dnav=function(v){if(v==='panel'&&!isStaff()){try{act.dclose()}catch(e){}return}return dn.apply(this,arguments)};
 const out=act.out;if(typeof out==='function')act.out=function(){document.querySelectorAll(HIDE).forEach(e=>e.remove());return out.apply(this,arguments)};

 /* 3. gift/ban lewat username: kalau username belum ada di perangkat ini, cari di semua perangkat dulu */
 Object.keys(TARGET).forEach(n=>{const prev=act[n];if(typeof prev!=='function')return;
  act[n]=function(){const self=this,args=arguments;
   if(!isStaff())return deny();
   const inp=document.getElementById(TARGET[n]),raw=String(inp&&inp.value||'').trim().replace(/^@/,'');
   if(!raw||localKey(raw)||typeof window.spLookupName!=='function')return prev.apply(self,args);
   if(raw.toLowerCase()===String(me.name).toLowerCase())return prev.apply(self,args);
   deny('Mencari @'+raw+' ...');
   window.spLookupName(raw).then(real=>{
    if(real===false)return deny('Tidak ada koneksi, username di perangkat lain belum bisa dicari');
    if(!real)return deny('Username "'+raw+'" tidak ditemukan');
    if(!localKey(real)){users[real]={rm:1,bux:0,av:{skin:SKIN[0],shirt:SHIRT[1],pants:PANTS[1]},games:[],notes:[]};save()}
    if(inp)inp.value=localKey(real);
    prev.apply(self,args)}).catch(()=>deny('Gagal mencari username'))}});
}
if(document.readyState==='complete')install();else window.addEventListener('load',install);
})();
