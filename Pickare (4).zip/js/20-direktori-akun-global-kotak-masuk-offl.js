/* ===== DIREKTORI AKUN GLOBAL + KOTAK MASUK OFFLINE =====
   - Profil (username + avatar, tanpa password) dipublish ke broker MQTT publik agar akun dari HP lain muncul di "Cari orang".
   - Permintaan teman & chat disimpan di broker (retained) sampai penerima online, lalu diproses dan dihapus. */
(function(){
const USR='pickare/v9/usr/',INB='pickare/v9/inb/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)};
const lw=n=>hs(String(n).toLowerCase());
const hx=(c,f)=>/^#[0-9a-f]{6}$/i.test(c||'')?c:f;
const safeAv=a=>{a=a||{};return{skin:hx(a.skin,'#ffd7b5'),shirt:hx(a.shirt,'#ffde59'),pants:hx(a.pants,'#222222'),hat:String(a.hat||'none').replace(/[^\w-]/g,'').slice(0,14)||'none',acc:Array.isArray(a.acc)?a.acc.filter(x=>typeof x==='string'||typeof x==='number').slice(0,5).map(x=>String(x).slice(0,24)):[]}};
const mq=()=>window.__spMq;
window.spInboxPut=ev=>{try{if(!ev||!ev.to||!ev.id||!mq())return Promise.resolve(0);return mq().pushAll([{t:INB+lw(ev.to)+'/'+ev.id,p:JSON.stringify(ev)}])}catch(e){return Promise.resolve(0)}};
let putting=0;
async function putMe(){if(putting||!me||me.role==='owner'||!mq())return;putting=1;
 try{const av=safeAv(me.av),sg=hs(me.name+JSON.stringify(av)),S=ls.get('sp_usrsig',{}),e=S[me.name];if(e&&e.s===sg&&Date.now()-e.t<216e5)return;
  const ok=await mq().pushAll([{t:USR+lw(me.name),p:JSON.stringify({n:me.name,av,ts:Date.now()})}]);if(ok){S[me.name]={s:sg,t:Date.now()};ls.set('sp_usrsig',S)}}
 catch(e){}finally{putting=0}}
function collect(){return new Promise(async res=>{if(!me||!mq()||!(window.mqtt||await mq().lib()))return res(null);
 const mine=INB+lw(me.name)+'/',D={},I={};let pend=BR.length,fin=0;const out=()=>{if(!fin){fin=1;res({D,I})}};
 BR.forEach(url=>{let done=0,m;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}if(--pend===0)out()};
  try{m=mqtt.connect(url,{clientId:'spd_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)out();return}
  m.on('error',end);m.on('close',end);
  m.on('connect',()=>{m.subscribe([USR+'+',mine+'+'],{qos:0});setTimeout(end,3500)});
  m.on('message',(t,b)=>{try{const s=b.toString();if(!s)return;const d=JSON.parse(s);if(t.startsWith(USR))D[t]=d;else I[t]=d}catch(e){}});
  setTimeout(end,8000)});setTimeout(out,10000)})}
let polling=0;
async function poll(){if(polling||!me)return;polling=1;
 try{const r=await collect();if(!r)return;let ch=0;
  for(const t in r.D){const d=r.D[t],n=String((d&&d.n)||'').replace(/[\u0000-\u001f<>"&]/g,'').slice(0,20);
   if(!n||n===me.name||/^(owner|admin|coowner|co-owner)$/i.test(n))continue;let u=users[n];if(u&&!u.rm)continue;
   if(!u){users[n]={rm:1,bux:0,av:safeAv(d.av),games:[],notes:[]};ch=1}else{const a=safeAv(d.av);if(JSON.stringify(a)!==JSON.stringify(u.av)){u.av=a;ch=1}}}
  const clr=[];
  for(const t in r.I){const p=r.I[t];if(!p||p.to!==me.name||!p.from||!p.ts||Date.now()-p.ts>6048e5){clr.push({t,p:''});continue}
   try{if(window.__spOnEv)window.__spOnEv(p);ch=1;clr.push({t,p:''})}catch(e){}}
  if(ch){save();try{refreshUI()}catch(e){}}
  if(clr.length&&mq())mq().pushAll(clr)}
 catch(e){}finally{polling=0}}
window.spDirSync=()=>{putMe();poll()};
window.addEventListener('load',()=>{
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{putMe();poll()},900);return r};
 setInterval(()=>{if(typeof me!=='undefined'&&me)putMe()},10000);
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)poll()},30000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&me)spDirSync()});
 if(typeof me!=='undefined'&&me)setTimeout(spDirSync,900)});
})();
