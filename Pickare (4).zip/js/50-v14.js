/* ===== v14: Teman / Pengikut / Mengikuti terlihat oleh semua pemain di profil (lintas perangkat) ===== */
(function(){
const SOC='pickare/v9/soc/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)};
const lw=n=>hs(String(n).toLowerCase()),low=n=>String(n||'').toLowerCase();
const clean=a=>(Array.isArray(a)?a:[]).filter(x=>typeof x==='string'&&x.length>0&&x.length<=20).map(x=>x.replace(/[\u0000-\u001f<>"&]/g,'')).slice(0,300);
const cleanB=t=>String(t||'').replace(/[\u0000-\u001f<>"&]/g,' ').replace(/\s+/g,' ').trim().slice(0,150);
const cache=()=>{const c=ls.get('sp_soc',{});return c&&typeof c==='object'&&!Array.isArray(c)?c:{}};
const mq=()=>window.__spMq;

/* 1. publikasikan daftar teman & yang diikuti milik sendiri */
let lastSig='',lastT=0;
async function publish(){try{if(typeof me==='undefined'||!me||!mq())return;const f=FRD(me),rec={n:me.name,f:clean(f.f),fo:clean(f.fo),ts:Date.now(),b:cleanB(me.bio),j:+me.joined||0},sg=hs(me.name+JSON.stringify([rec.f,rec.fo,rec.b,rec.j]));
 if(sg===lastSig&&Date.now()-lastT<216e5)return;
 if(await mq().pushAll([{t:SOC+lw(me.name),p:JSON.stringify(rec)}])){lastSig=sg;lastT=Date.now()}}catch(e){}}

/* 2. ambil data sosial semua pemain */
let pulling=0,lastPull=0;
async function pull(){if(pulling)return;pulling=1;lastPull=Date.now();try{if(typeof me==='undefined'||!me||!mq()||!(window.mqtt||await mq().lib()))return;const got={};
 await Promise.all(BR.map(url=>new Promise(res=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}res()};
  try{m=mqtt.connect(url,{clientId:'sps_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){return res()}
  m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(SOC+'+',{qos:0});setTimeout(end,2500)});
  m.on('message',(t,b)=>{try{const s=b.toString();if(!s)return;const d=JSON.parse(s);if(!d||typeof d.n!=='string'||d.n.length>20||t!==SOC+lw(d.n))return;const k=low(d.n);if(!got[k]||d.ts>got[k].ts)got[k]={n:d.n.replace(/[\u0000-\u001f<>"&]/g,''),f:clean(d.f),fo:clean(d.fo),ts:+d.ts||0,b:cleanB(d.b),j:(+d.j>9e11&&+d.j<4e12)?+d.j:0}}catch(e){}});
  setTimeout(end,6500)})));
 const c=cache();let ch=0;for(const k in got){if(!c[k]||got[k].ts>=c[k].ts){c[k]=got[k];ch=1}}if(ch)ls.set('sp_soc',c);deco()}catch(e){}finally{pulling=0}}

/* 3. hitung angka + daftar nama untuk satu pemain */
function soc(n){const c=cache(),me0=me.name,k=low(n),S={fr:new Map(),fo:new Map(),fl:new Map()};
 const add=(M,x)=>{if(x)M.set(low(x),x)};
 const u=users[n]||users[Object.keys(users).find(x=>low(x)===k)];
 if(n===me0){FRD(me).f.forEach(x=>add(S.fr,x));FRD(me).fo.forEach(x=>add(S.fo,x))}
 else{const r=c[k];if(r){r.f.forEach(x=>add(S.fr,x));r.fo.forEach(x=>add(S.fo,x))}if(u&&!u.rm){FRD(u).f.forEach(x=>add(S.fr,x));FRD(u).fo.forEach(x=>add(S.fo,x))}}
 for(const kk in c)if(c[kk].fo.some(x=>low(x)===k))add(S.fl,c[kk].n);
 for(const kk in users){if(users[kk]===me)continue;if(!users[kk].rm&&FRD(users[kk]).fo.some(x=>low(x)===k))add(S.fl,kk)}
 if(n!==me0&&FRD(me).fo.some(x=>low(x)===k))add(S.fl,me0);
 return{fr:[...S.fr.values()],fo:[...S.fo.values()],fl:[...S.fl.values()]}}
window.spSoc=soc;

/* 4. tampilkan di halaman profil + bisa diketuk untuk melihat daftarnya */
function decorate(){try{const pc=document.querySelector('#ov .pch'),st=document.getElementById('pst3');if(!pc||!st||typeof me==='undefined'||!me)return;
 const n=st.dataset.n;if(!n||(typeof isBot==='function'&&isBot(n)))return;const S=soc(n),sp=pc.querySelectorAll(':scope > span');if(sp.length<3)return;
 [['fr','Teman'],['fl','Pengikut'],['fo','Mengikuti']].forEach(([k,l],i)=>{sp[i].textContent=S[k].length+' '+l;sp[i].dataset.a='soclist';sp[i].dataset.v=k+'|'+n;sp[i].style.cursor='pointer'});
 /* bio + bergabung sejak */
 const k=low(n),r=cache()[k],u=users[n]||users[Object.keys(users).find(x=>low(x)===k)],mine=n===me.name;
 const bio=mine?me.bio:((r&&r.b)||(u&&u.bio)),jn=mine?me.joined:((r&&r.j)||(u&&u.joined));
 const old=document.getElementById('pbio');if(old)old.remove();
 let h='<div id="pbio" style="margin:8px 0 10px;text-align:center">';
 h+='<div style="font-size:14px;line-height:1.4;'+(bio?'':'opacity:.6;')+'">'+(bio?esc(bio):(mine?'Belum ada bio':''))+'</div>';
 if(jn)h+='<div style="font-size:12px;opacity:.75;margin-top:4px">Bergabung sejak '+new Date(jn).getFullYear()+'</div>';
 if(mine)h+='<button class="btn sm g" data-a="bioedit" style="margin-top:8px">Edit Bio</button>';
 pc.insertAdjacentHTML('beforebegin',h+'</div>')}catch(e){}}
let ob=null,ovEl=null;
function deco(){if(ob)ob.disconnect();try{decorate()}finally{if(ob&&ovEl)ob.observe(ovEl,{childList:true})}}
function watch(){const o=document.getElementById('ov');if(!o)return setTimeout(watch,1000);
 ovEl=o;ob=new MutationObserver(()=>{deco();if(document.querySelector('#ov .pch')&&Date.now()-lastPull>20000)setTimeout(pull,300)});ob.observe(o,{childList:true})}
watch();

/* 5. daftar nama (sheet bawah) */
const T={fr:'Teman',fl:'Pengikut',fo:'Mengikuti'};
Object.assign(act,{
 soclist(v){const i=String(v).indexOf('|'),k=v.slice(0,i),n=v.slice(i+1);if(!T[k])return;const L=soc(n)[k].slice().sort((a,b)=>low(a)<low(b)?-1:1);
  const row=x=>{const a=(window.spUI&&spUI.avFor&&spUI.avFor(x))||(users[x]&&users[x].av)||null,u=users[x];
   return '<button data-a="soclistgo" data-v="'+esc(x)+'" style="display:flex;align-items:center;gap:12px;width:100%;background:none;border:0;border-bottom:1px solid rgba(255,255,255,.08);padding:10px 4px;color:inherit;font:inherit;text-align:left;cursor:pointer">'+circ(a,44)+'<b>'+esc(x)+'</b>'+(u&&u.verified||(window.spVerified&&spVerified(x))?'<span class="vb">✔</span>':'')+'</button>'};
  shOpen('<div class="shn" style="margin:6px 0 10px">'+T[k]+' · '+esc(n)+' ('+L.length+')</div><div style="max-height:52vh;overflow:auto">'+(L.length?L.map(row).join(''):'<div style="opacity:.7;padding:14px 4px">Belum ada.</div>')+'</div>')},
 bioedit(){const ov='<div class="shn" style="margin:6px 0 10px">Edit Bio</div><textarea id="bioin" maxlength="150" rows="4" placeholder="Ceritakan tentang dirimu (maks 150 huruf)" style="width:100%;box-sizing:border-box;padding:10px;border:3px solid #000;border-radius:10px;font:inherit;resize:none">'+esc(me.bio||'')+'</textarea><button class="btn w" data-a="biosave" style="margin-top:10px">Simpan</button>';shOpen(ov)},
 biosave(){const el=document.getElementById('bioin');if(!el)return;me.bio=cleanB(el.value);save();shClose();window.spSocPublish();toast('Bio disimpan');deco()},
 soclistgo(x){if(!users[x])users[x]={rm:1,bux:0,av:{skin:SKIN[0],shirt:SHIRT[1],pants:PANTS[1]},games:[],notes:[]};shClose();act.prof(x)}});

window.spSocPublish=()=>{lastSig='';publish()};
/* jadwal */
setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)publish()},6000);
setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden)pull()},40000);
const _en=enter;enter=function(){const r=_en.apply(this,arguments);try{if(me&&!me.joined){me.joined=Date.now();save()}}catch(e){}setTimeout(()=>{publish();pull()},2000);return r};
})();
