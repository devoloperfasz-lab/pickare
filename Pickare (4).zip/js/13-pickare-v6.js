/* ===== PICKARE v6: redeem code, report, ban, promosi, beranda tanpa demo ===== */
(function(){
const NOW=()=>Date.now();
const fmtDT=t=>new Date(t).toLocaleString('id-ID',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
const ago=t=>{const s=Math.max(1,(NOW()-t)/1000|0);if(s<60)return s+' dtk lalu';const m=s/60|0;if(m<60)return m+' mnt lalu';const h=m/60|0;if(h<24)return h+' jam lalu';return (h/24|0)+' hari lalu'};
const normCode=v=>String(v||'').toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,24);
const codes=()=>{const c=ls.get('sp_codes',{});return c&&typeof c=='object'&&!Array.isArray(c)?c:{}},setCodes=c=>ls.set('sp_codes',c);
const promos=()=>{const p=ls.get('sp_promo',[]);return(Array.isArray(p)?p:[]).filter(x=>!x.until||x.until>NOW())},setPromos=p=>ls.set('sp_promo',p);
const userKey=n=>{n=String(n||'').trim().toLowerCase();return n?Object.keys(users).find(k=>k.toLowerCase()==n)||null:null};
const creatorOf=gid=>Object.keys(users).find(k=>(users[k].games||[]).some(g=>g.id==gid))||null;
const DUR={'1h':36e5,'1d':864e5,'3d':3*864e5,'7d':7*864e5,'30d':30*864e5};
const DURL={'1h':'1 jam','1d':'1 hari','3d':'3 hari','7d':'7 hari','30d':'30 hari','perm':'Permanen'};
const REASONS=['Spam','Kata kasar / pelecehan','Curang / cheat','Penipuan','Username tidak pantas','Lainnya'];
let _bt=null,_rt=null,_rr=0;
pt='rep';

/* ---------- laporan ---------- */
function repAll(){let r=ls.get('sp_rep',[]);if(!Array.isArray(r))r=[];let ch=0;r.forEach((x,i)=>{if(!x.id){x.id='r'+(x.t||0)+'_'+i;ch=1}if(!x.st){x.st='open';ch=1}});if(ch)ls.set('sp_rep',r);return r}
const repOpen=()=>repAll().filter(r=>r.st=='open');
function addReport(o){const r=repAll();
 if(r.some(x=>x.st=='open'&&x.by==me.name&&x.type==o.type&&String(x.tg||'').toLowerCase()==String(o.tg||'').toLowerCase()))return false;
 r.unshift(Object.assign({id:'r'+NOW().toString(36)+Math.random().toString(36).slice(2,5),t:NOW(),st:'open',by:me.name},o));
 ls.set('sp_rep',r.slice(0,200));
 Object.keys(users).forEach(k=>{if(lv(users[k])>0&&users[k]!==me)pushNote(users[k],'Report baru: '+me.name+(o.tg?' melaporkan '+o.tg:' mengirim laporan'))});
 return true}

/* ---------- ban ---------- */
const banTxt=b=>b.perm?'permanen':'sampai '+fmtDT(b.until);
const canBan=k=>{const u=users[k];return !!u&&staff()&&u!==me&&u.role!=='owner'&&okT(u)};
function applyBan(k,key,why){
 if(!canBan(k)){toast('Tidak diizinkan');return false}
 if(!DURL[key])return false;
 if(key=='perm'&&lv(me)<3){toast('Ban permanen hanya untuk Owner');return false}
 const u=users[k];
 u.ban={perm:key=='perm',until:key=='perm'?0:NOW()+DUR[key],reason:(why||'Pelanggaran aturan').slice(0,120),by:me.name,t:NOW()};
 u.pres=null;
 const r=repAll();r.forEach(x=>{if(x.st=='open'&&(userKey(x.tg)==k||(x.gid&&creatorOf(x.gid)==k))){x.st='done';x.res='Ban '+DURL[key].toLowerCase()+' oleh '+me.name;x.rt=NOW()}});
 ls.set('sp_rep',r);save();return true}
function banDlg(k,rid,preset){
 if(!canBan(k))return toast('Tidak diizinkan');
 _bt={k,rid};
 const opts=Object.keys(DURL).filter(x=>x!='perm'||lv(me)>=3);
 shOpen(`<div class="shn" style="margin-top:6px">Ban ${esc(k)}</div><label class="dl">Durasi</label><select id="bn_d" class="shin">${opts.map(x=>`<option value="${x}" ${x==preset?'selected':''}>${DURL[x]}</option>`).join('')}</select><label class="dl">Alasan (ditampilkan ke pemain)</label><input class="shin" type="text" id="bn_r" maxlength="120" placeholder="Contoh: kata kasar di chat"><button class="sb pr" data-a="bango">Terapkan ban</button><button class="sb ln" data-a="shx">Batal</button>`)}
function showBan(b){const e=$('#err'),c=$('#acard');e.textContent='Akun ini diblokir '+banTxt(b)+'.\nAlasan: '+(b.reason||'-');e.classList.add('banmsg');c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')}

/* ---------- panel ---------- */
function repCard(x){const mk=x.gid?creatorOf(x.gid):null,k=userKey(x.tg)||mk,u=k&&users[k],bn=u&&banOf(u),own=lv(me)>=3;
 const cls=x.type=='Akun'?'a':x.type=='Map'?'m':'b';
 return `<div class="rc"><div class="rh2"><span class="rtag ${cls}">${esc(x.type)}</span><b>${esc(x.tg||'-')}</b><small>${ago(x.t)}</small></div>
 <div class="rby">Dilaporkan oleh <b>${esc(x.by)}</b></div>${x.why?`<div class="rwhy">${esc(x.why)}</div>`:''}<div class="rtx">${esc(x.txt||'')}</div>
 ${x.gn?`<small class="rg">Map: ${esc(x.gn)}${mk?' · pembuat '+esc(mk):''}</small>`:''}
 <div class="rac">${bn?`<span class="rban">Sudah diblokir (${banTxt(bn)})</span>`:(k&&canBan(k)?`<button class="btn sm o" data-a="banui" data-v="${esc(x.id)}">Ban</button>${own?`<button class="btn sm p" data-a="banperm" data-v="${esc(x.id)}">Ban permanen</button>`:''}`:'')}
 ${x.gid?`<button class="btn sm" data-a="rtake" data-v="${esc(x.id)}">Turunkan map</button>`:''}<button class="btn sm" data-a="rdone" data-v="${esc(x.id)}">Abaikan</button></div></div>`}
function giftH(){const ro=[['admin','Admin',2],['coowner','Co-Admin',3]].filter(r=>lv(me)>=r[2]);
 return `<div class="card"><label>Username pemain</label><input type="text" id="pt_u" list="pt_dl" placeholder="Ketik username" autocomplete="off" autocapitalize="none"><datalist id="pt_dl">${usersOpt()}</datalist>
 <label>Jumlah PickBux${lv(me)<3?' (maks. 500)':''}</label><input type="text" inputmode="numeric" id="pt_n" value="100"><button class="btn w g" data-a="gbux">Kirim PickBux</button>
 <label style="margin-top:14px;display:block">Centang biru</label><div style="display:flex;gap:8px;margin-top:6px"><button class="btn w c" data-a="gver" data-v="1">Beri centang</button><button class="btn w o" data-a="gver" data-v="0">Cabut centang</button></div>`
 +(ro.length?`<label style="margin-top:14px;display:block">Akses panel</label><select id="pt_r" hidden>${ro.map(r=>`<option value="${r[0]}">${r[1]}</option>`).join('')}<option value="none">Cabut</option></select><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">${ro.map(r=>`<button class="btn v" style="flex:1 1 45%" data-a="grolev" data-v="${r[0]}">Beri ${r[1]}</button>`).join('')}<button class="btn w o" data-a="grolev" data-v="none">Cabut akses</button></div>`:'')+'</div>'}
function userRow(k){const u=users[k],b=banOf(u);
 return `<div class="card ur2"><div class="ur2h"><b>${esc(k)}${vb(u)}</b><span class="pill" style="font-size:12px">${RN[u.role]||'User'}</span><span class="pill" style="font-size:12px">${u.bux||0} PickBux</span></div>${b?`<div class="rban">Diblokir ${banTxt(b)} · ${esc(b.reason||'-')}</div>`:''}
 <div class="rac">${b?(canBan(k)?`<button class="btn sm g" data-a="unban" data-v="${esc(k)}">Cabut ban</button>`:''):(canBan(k)?`<button class="btn sm o" data-a="banu" data-v="${esc(k)}">Ban</button>`:'')}</div></div>`}
function promoTab(){const gs=pubGames(),ps=promos();
 let h=`<div class="card"><label>Pilih map</label><select id="pr_g">${gs.length?gs.map(g=>`<option value="${esc(g.id)}">${esc(g.name)} · ${esc(g.by||'Pickare')}</option>`).join(''):'<option value="">Belum ada map dipublish</option>'}</select>
 <label>Teks promosi (opsional)</label><input type="text" id="pr_t" maxlength="50" placeholder="Contoh: Event akhir pekan">
 <label>Durasi</label><select id="pr_d"><option value="1">1 hari</option><option value="3">3 hari</option><option value="7" selected>7 hari</option><option value="30">30 hari</option><option value="0">Tanpa batas</option></select>
 <button class="btn w g" data-a="prgo">Pasang di bagian atas Beranda</button></div><div class="ps2">Promosi aktif (${ps.length}/6)</div>`;
 h+=ps.length?ps.map(p=>{const g=gs.find(x=>x.id==p.gid);return `<div class="card ur2"><div class="ur2h"><b>${esc(g?g.name:'Map tidak tersedia')}</b><small style="color:var(--mut)">${p.until?'sampai '+fmtDT(p.until):'tanpa batas'}</small></div>${p.title?`<div class="rtx">${esc(p.title)}</div>`:''}<div class="rac"><button class="btn sm o" data-a="prdel" data-v="${esc(p.id)}">Hapus</button></div></div>`}).join(''):'<div class="empty2"><p style="margin:0">Belum ada promosi.</p></div>';
 return h}
function codeTab(){const c=codes(),ks=Object.keys(c).sort((a,b)=>(c[b].t||0)-(c[a].t||0));
 let h=`<div class="card"><label>Kode (kosongkan untuk acak)</label><input type="text" id="cd_k" maxlength="24" autocomplete="off" autocapitalize="characters" placeholder="Contoh: PICKARE100" style="text-transform:uppercase">
 <label>Jumlah PickBux</label><input type="text" inputmode="numeric" id="cd_a" value="100">
 <label>Batas pemakaian (0 = tanpa batas)</label><input type="text" inputmode="numeric" id="cd_m" value="0">
 <label>Masa berlaku dalam hari (0 = tanpa batas)</label><input type="text" inputmode="numeric" id="cd_e" value="0">
 <button class="btn w g" data-a="cdgo">Buat kode</button></div><div class="ps2">Kode aktif (${ks.length})</div>`;
 h+=ks.length?ks.map(k=>{const d=c[k],n=(d.used||[]).length,ex=d.exp&&d.exp<NOW();return `<div class="card ur2"><div class="ur2h"><span class="cdk">${esc(k)}</span><span class="pill" style="font-size:12px">${d.amt} PickBux</span></div><div class="rby">Dipakai <b>${n}${d.max?' / '+d.max:''}</b> kali · ${d.exp?(ex?'sudah kedaluwarsa':'berlaku sampai '+fmtDT(d.exp)):'tanpa masa berlaku'}</div><div class="rac"><button class="btn sm c" data-a="cdcopy" data-v="${esc(k)}">Salin</button><button class="btn sm o" data-a="cddel" data-v="${esc(k)}">Hapus</button></div></div>`}).join(''):'<div class="empty2"><p style="margin:0">Belum ada kode. Buat kode pertama di atas.</p></div>';
 return h}
panH=function(){if(!staff())return'';
 const own=lv(me)>=3,no=repOpen().length,nb=Object.keys(users).filter(k=>banOf(users[k])).length;
 const T=[['rv','Review',RV.n()],['ann','Pengumuman',0],['wk','Works',0],['vl','Pelanggaran',0],['rep','Report',no],['user','Pengguna',0],['ban','Diblokir',nb],['gift','Gift',0]].concat(own?[['promo','Promosi',0],['code','Kode',0]]:[]);
 if(!T.some(x=>x[0]==pt))pt='rep';
 let h='<h2>Panel '+(RN[me.role]||'')+'</h2><div class="ptabs2">'+T.map(x=>`<button class="ptb ${pt==x[0]?'on':''}" data-a="pt" data-v="${x[0]}">${x[1]}${x[2]?'<i>'+x[2]+'</i>':''}</button>`).join('')+'</div>';
 if(pt=='rep'){const r=repAll(),op=r.filter(x=>x.st=='open'),dn=r.filter(x=>x.st!='open').slice(0,8);
  h+=op.length?op.map(repCard).join(''):'<div class="empty2"><b>Tidak ada report baru</b><p style="margin:0">Laporan dari pemain akan muncul di sini.</p></div>';
  if(dn.length)h+='<div class="ps2">Selesai</div>'+dn.map(x=>`<div class="rc done"><div class="rh2"><span class="rtag ${x.type=='Akun'?'a':x.type=='Map'?'m':'b'}">${esc(x.type)}</span><b>${esc(x.tg||'-')}</b><small>${ago(x.rt||x.t)}</small></div><div class="rby">${esc(x.res||'Selesai')}</div></div>`).join('')}
 if(pt=='user')h+=Object.keys(users).length?Object.keys(users).map(userRow).join(''):'<div class="empty2"><p style="margin:0">Belum ada pengguna.</p></div>';
 if(pt=='ban'){const l=Object.keys(users).filter(k=>banOf(users[k]));h+=l.length?l.map(userRow).join(''):'<div class="empty2"><p style="margin:0">Tidak ada akun yang sedang diblokir.</p></div>'}
 if(pt=='gift')h+=giftH();
 if(pt=='promo'&&own)h+=promoTab();
 if(pt=='code'&&own)h+=codeTab();
 if(pt=='rv'||pt=='ann'||pt=='wk'||pt=='vl')h+=RV.tab(pt);
 return h};

function rand(n){const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';const a=new Uint8Array(n);try{crypto.getRandomValues(a)}catch(e){for(let i=0;i<n;i++)a[i]=Math.random()*256|0}for(let i=0;i<n;i++)s+=A[a[i]%A.length];return s}
const num=id=>{const e=$('#'+id);return e?Math.max(0,Math.floor(+String(e.value).replace(/[^0-9]/g,'')||0)):0};

Object.assign(act,{
 rdone(v){if(!staff())return;const r=repAll(),x=r.find(y=>y.id==v);if(!x)return;x.st='done';x.res='Diabaikan oleh '+me.name;x.rt=NOW();ls.set('sp_rep',r);render()},
 rtake(v){if(!staff())return;const r=repAll(),x=r.find(y=>y.id==v);if(!x||!x.gid)return;Object.values(users).forEach(u=>(u.games||[]).forEach(g=>{if(g.id==x.gid)g.pub=false}));x.st='done';x.res='Map diturunkan oleh '+me.name;x.rt=NOW();ls.set('sp_rep',r);save();toast('Map diturunkan jadi draft');render()},
 banui(v){const x=repAll().find(y=>y.id==v);if(!x)return;const k=userKey(x.tg)||(x.gid&&creatorOf(x.gid));if(!k)return toast('Akun tidak ditemukan');banDlg(k,v,'1d')},
 banperm(v){const x=repAll().find(y=>y.id==v);if(!x)return;const k=userKey(x.tg)||(x.gid&&creatorOf(x.gid));if(!k)return toast('Akun tidak ditemukan');banDlg(k,v,'perm')},
 banu(n){banDlg(n,null,'1d')},
 bango(){if(!_bt)return;const d=$('#bn_d'),r=$('#bn_r');if(!d)return;const k=_bt.k;if(applyBan(k,d.value,(r.value||'').trim())){shClose();toast(k+' diblokir ('+DURL[d.value].toLowerCase()+')');pushNote(me,'Kamu memblokir '+k+' ('+DURL[d.value].toLowerCase()+')');render()}},
 unban(n){const u=users[n];if(!staff()||!u||!okT(u))return toast('Tidak diizinkan');delete u.ban;pushNote(u,'Blokir pada akunmu telah dicabut');save();toast('Ban '+n+' dicabut');render()},
 prgo(){if(lv(me)<3)return;const g=$('#pr_g').value;if(!g)return toast('Pilih map dulu');const ps=promos();if(ps.some(p=>p.gid==g))return toast('Map ini sudah dipromosikan');if(ps.length>=6)return toast('Maksimal 6 promosi aktif');
  const dy=+$('#pr_d').value||0;ps.push({id:'p'+NOW().toString(36),gid:g,title:($('#pr_t').value||'').trim().slice(0,50),until:dy?NOW()+dy*864e5:0,t:NOW()});setPromos(ps);toast('Promosi dipasang');render()},
 prdel(v){if(lv(me)<3)return;setPromos(promos().filter(p=>p.id!=v));toast('Promosi dihapus');render()},
 cdgo(){if(lv(me)<3)return;let k=normCode($('#cd_k').value);const amt=num('cd_a'),mx=num('cd_m'),ex=num('cd_e'),c=codes();
  if(!k){do{k='SHIN-'+rand(4)+'-'+rand(4)}while(c[k])}
  if(k.length<4)return toast('Kode minimal 4 karakter');if(c[k])return toast('Kode sudah ada');if(!(amt>=1&&amt<=1000000))return toast('Jumlah PickBux 1 sampai 1.000.000');
  c[k]={amt,max:mx,exp:ex?NOW()+ex*864e5:0,used:[],by:me.name,t:NOW()};setCodes(c);toast('Kode '+k+' dibuat');render()},
 cddel(v){if(lv(me)<3)return;const c=codes();delete c[v];setCodes(c);toast('Kode dihapus');render()},
 cdcopy(v){try{navigator.clipboard.writeText(v)}catch(e){}toast('Kode '+v+' disalin')},
 /* redeem */
 redeem(){act.dclose();shOpen(`<div class="shn" style="margin-top:6px">Redeem Kode</div><p class="sub2">Masukkan kode untuk mendapatkan PickBux.</p><input class="shin" type="text" id="rd_k" maxlength="24" autocomplete="off" autocapitalize="characters" placeholder="Masukkan kode" style="text-transform:uppercase"><div class="err2" id="rd_e"></div><button class="sb pr" data-a="rdgo">Tukar kode</button><button class="sb ln" data-a="shx">Tutup</button>`);setTimeout(()=>{const i=$('#rd_k');if(i)i.focus()},320)},
 rdgo(){const e=$('#rd_e');if(!e)return;const bad=m=>{e.textContent=m},now=NOW();me.rdf=(me.rdf||[]).filter(t=>now-t<60000);
  if(me.rdf.length>=5)return bad('Terlalu banyak percobaan. Coba lagi sebentar.');
  const k=normCode($('#rd_k').value);if(!k)return bad('Masukkan kodenya dulu');
  const c=codes(),d=c[k];
  if(!d){me.rdf.push(now);save();return bad('Kode tidak valid')}
  if(d.exp&&d.exp<now)return bad('Kode sudah kedaluwarsa');
  d.used=d.used||[];if(d.used.includes(me.name))return bad('Kamu sudah memakai kode ini');
  if(d.max&&d.used.length>=d.max)return bad('Kode sudah habis dipakai');
  d.used.push(me.name);setCodes(c);addBux(d.amt);notify('Redeem kode '+k+': +'+d.amt+' PickBux');shClose();toast('+'+d.amt+' PickBux berhasil ditambahkan');render()},
 /* report dari pemain */
 pmore(n){shOpen(`<div class="shn" style="margin-top:6px">${esc(n)}</div>${rel(n)=='friend'?`<button class="sb" data-a="funf" data-v="${esc(n)}">Hapus teman</button>`:''}<button class="sb" data-a="cpn" data-v="${esc(n)}">Salin username</button><button class="sb dg" data-a="rptu" data-v="${esc(n)}">Laporkan akun</button><button class="sb ln" data-a="shx">Tutup</button>`)},
 rptu(n){const k=userKey(n);if(!k||k==me.name)return toast('Akun tidak bisa dilaporkan');_rt=k;_rr=0;
  shOpen(`<div class="shn" style="margin-top:6px">Laporkan ${esc(k)}</div><label class="dl">Alasan</label><div class="chips2" id="rp_c">${REASONS.map((r,i)=>`<button class="chip ${i==0?'on':''}" data-a="rpr" data-v="${i}">${r}</button>`).join('')}</div><input class="shin" type="text" id="rp_d" maxlength="120" placeholder="Detail tambahan (opsional)"><div class="err2" id="rp_e"></div><button class="sb pr" data-a="rpgo">Kirim laporan</button><button class="sb ln" data-a="shx">Batal</button>`)},
 rpr(v){_rr=+v||0;document.querySelectorAll('#rp_c .chip').forEach((b,i)=>b.classList.toggle('on',i==_rr))},
 rpgo(){if(!_rt||!users[_rt])return;const d=($('#rp_d').value||'').trim();
  if(!addReport({type:'Akun',tg:_rt,why:REASONS[_rr],txt:d||REASONS[_rr]})){$('#rp_e').textContent='Kamu sudah melaporkan akun ini dan masih ditinjau.';return}
  shClose();toast('Laporan terkirim ke admin')},
 /* report dari dalam game */
 rsend(){const t=($('#rp_x').value||'').trim(),ty=$('#rp_t').value;let tg=($('#rp_g').value||'').trim();
  if(t.length<5)return toast('Tulis alasan (min. 5 huruf)');
  const o={txt:t,why:''};
  if(ty=='Pemain'){const k=userKey(tg);if(!k)return toast('Nama pemain tidak ditemukan');if(k==me.name)return toast('Tidak bisa melaporkan diri sendiri');o.type='Akun';o.tg=k}
  else if(ty=='Map'){o.type='Map';o.tg=tg||(curG&&curG.name)||'';o.gid=curG&&curG.id;o.gn=curG&&curG.name}
  else{o.type='Bug';o.tg=tg}
  if(!addReport(o))return toast('Laporan serupa masih ditinjau');
  $('#rp_x').value='';toast('Laporan terkirim')},
 play(v){const g=allGames().find(x=>x.id===v);if(!g)return toast('Game tidak tersedia');startGame(g)}
});
act.pt=function(v){pt=v;render()};

/* ---------- beranda & teratas ---------- */
function promoH(){const gs=pubGames(),it=promos().map(p=>({p,g:gs.find(g=>g.id==p.gid)})).filter(x=>x.g);if(!it.length)return'';
 return `<div class="promo">${it.map(({p,g})=>{const t=okImg(g.thumb),bg=t?`url(${t}) center/cover`:`linear-gradient(135deg,${hexc(g.col,'#b6f25a')},${hexc(g.sky,'#7df9ff')})`;
  return `<button class="pcard" data-a="gopen" data-v="${esc(g.id)}" style="background:${bg}"><span class="pshade"></span><span class="ptag">Promosi</span><span class="pinfo"><b>${esc(g.name)}</b><small>${esc(p.title||('oleh '+(g.by||'Pickare')))}</small></span><span class="pplay">Main</span></button>`}).join('')}</div>`}
let HOME_N=24;act.homemore=function(){const m=$('#main'),t=m?m.scrollTop:0;HOME_N+=24;render();if(m)m.scrollTop=t};
homeH=function(){const gs=pubGames(),vis=ls.get('sp_vis',{}),rec=(me.recent||[]).map(id=>gs.find(g=>g.id==id)).filter(Boolean),bi=FRD(me).i.length;
 const pop=gs.slice().sort((a,b)=>((vis[b.id]||0)+(b.pl||0))-((vis[a.id]||0)+(a.pl||0)));
 const games=gs.length?`<h3 class="sec">Direkomendasikan untukmu</h3><div class="gg">${gs.slice(0,HOME_N).map(gcard).join('')}</div>${gs.length>HOME_N?`<button class="btn w" data-a="homemore" style="margin-top:12px">Lihat lebih banyak (${gs.length-HOME_N} lagi)</button>`:''}<h3 class="sec" id="cont">${rec.length?'Lanjutkan':'Populer'} ${ico('chev',20)}</h3><div class="hs">${(rec.length?rec:pop).slice(0,12).map(gcard).join('')}</div>`
  :`<div class="empty2"><b>Belum ada game</b><p>Belum ada map yang dipublish. Buat map pertamamu di Studio lalu publish agar muncul di sini.</p><button class="btn g" data-a="go" data-v="create">Buka Studio</button></div>`;
 return promoH()+`<div class="who" data-a="prof" data-v="${esc(me.name)}" style="cursor:pointer">${circ(me.av,46)}<span>${esc(me.name)}${vb(me)}</span></div>
 <div class="frs"><button class="fr add" data-a="ppl"><span class="circw"><span class="circ" style="--s:92px">${ico('adduser',40)}</span>${bi?`<i class="bdg">${bi}</i>`:''}</span><em>Tambah Teman</em></button>${friends().map(f=>`<button class="fr" data-a="fr" data-v="${esc(f.n)}"><span class="circw">${circ(f.a,92)}${f.pl?'<i class="on"></i>':''}</span><em>${esc(f.n)}</em><small>${esc(f.pl?f.g:'Offline')}</small></button>`).join('')}</div>`
 +games+`<h3 class="sec">Mabar bareng teman</h3><div class="card row" style="flex-wrap:wrap"><div style="flex:1;min-width:150px"><label>Kode room</label><input type="text" id="rc" value="${esc(roomCode)}" maxlength="16" style="margin:6px 0 0" oninput="roomCode=this.value.toLowerCase().replace(/[^a-z0-9-]/g,'')||'publik';save()"></div><button class="btn g" data-a="rnd">Acak</button></div>
 <div class="card row" style="margin-top:12px"><div style="flex:1"><b>Punya kode redeem?</b><br><small style="color:var(--mut)">Tukarkan dengan PickBux</small></div><button class="btn c" data-a="redeem">Tukar</button></div>`};
function topH(){const us=Object.keys(users).filter(k=>!users[k].role&&!banOf(users[k])).sort((a,b)=>(users[b].bux||0)-(users[a].bux||0)).slice(0,10);
 const gs=pubGames(),vis=ls.get('sp_vis',{}),sc=g=>(vis[g.id]||0)+(g.pl||0),gl=gs.slice().sort((a,b)=>sc(b)-sc(a)).slice(0,10);
 return '<h2>Teratas</h2><h3 class="sec" style="margin-top:6px">Pemain</h3>'+(us.length?us.map((k,i)=>`<div class="lbr ${i==0?'t1':''}" data-a="prof" data-v="${esc(k)}" style="cursor:pointer"><div class="rank">${i+1}</div>${circ(users[k].av,36)}<b>${esc(k)}${vb(users[k])}${k==me.name?' (kamu)':''}</b><span class="v">${users[k].bux||0} PickBux</span></div>`).join(''):'<div class="empty2"><p style="margin:0">Belum ada pemain.</p></div>')
 +'<h3 class="sec">Game</h3>'+(gl.length?gl.map((g,i)=>`<div class="lbr ${i==0?'t1':''}" data-a="gopen" data-v="${esc(g.id)}" style="cursor:pointer"><div class="rank">${i+1}</div><b>${esc(g.name)}</b><span class="v">${fmtN(sc(g))} kunjungan</span></div>`).join(''):'<div class="empty2"><p style="margin:0">Belum ada game dipublish.</p></div>')}
const _r8=render;
render=function(){_r8();const m=$('#main');if(page=='top'){m.innerHTML='<div class="page">'+topH()+'</div>';navRender()}};

/* ---------- drawer, badge, ban saat login ---------- */
const _df=drawerFill;
drawerFill=function(){_df();const d=$('#dpn'),sw=d.querySelector('.mi[data-v="avatar:mkt"]');
 if(sw)sw.insertAdjacentHTML('afterend',`<button class="mi" data-a="redeem">${ico('gift',27)}<span>Redeem Kode</span></button>`);
 const pn=d.querySelector('.mi[data-v="panel"]');if(pn){const sp=pn.querySelector('span');if(sp)sp.textContent='Panel Admin';const n=repOpen().length;if(n)pn.insertAdjacentHTML('beforeend',`<i class="bd rd">${n} Report</i>`)}};
const _nr=navRender;
navRender=function(){_nr();if(me&&staff()){const md=$('#mdot');if(md&&repOpen().length)md.style.display='block'}};
const _en9=enter;
enter=function(){const b=me&&banOf(me);
 if(b){me=null;ls.set('sp_sess','');show('auth');showBan(b);return}
 if(me&&me.ban){delete me.ban;save()}
 _en9()};
const _a9=act.auth;
act.auth=function(){const e=$('#err');if(e)e.classList.remove('banmsg');return _a9.apply(this,arguments)};
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.id=='rd_k'){e.preventDefault();act.rdgo()}});
})();
