/* MULTIPLAYER via FIREBASE Realtime Database. Jalan lintas HP/browser/akun/WiFi.
   Antarmuka room tetap sama (claude.use('room').join(kode)) jadi game tidak perlu diubah. */
(function(){
if(window.claude&&claude.use)return;
const FBV='10.12.2',STALE=9000;
const hs=t=>{let h=2166136261,g=5381;for(let i=0;i<t.length;i++){h=Math.imul(h^t.charCodeAt(i),16777619);g=(g*33)^t.charCodeAt(i)}return(h>>>0).toString(36)+(g>>>0).toString(36)};
const say=m=>{try{toast(m)}catch(e){}};
/* --- key room (tetap kompatibel dengan API key mabar lama) --- */
const ki=()=>{let key=(localStorage.getItem('sp_rkey')||'').replace(/["\s]/g,''),rw=1;const mm=/^spm_([rw])([0-9a-z]{8})([0-9a-f]{12})$/.exec(key);if(mm){if(mm[2]!=='00000000'&&parseInt(mm[2],36)*6e4<Date.now()){say('API key mabar kadaluarsa');throw new Error('expired')}rw=mm[1]==='w';key=mm[3]}return{key,rw}};
const kn=()=>{let k=(localStorage.getItem('sp_rkey')||'').replace(/["\s]/g,'');const m=/^spm_[rw][0-9a-z]{8}([0-9a-f]{12})$/.exec(k);return m?m[1]:k};
/* --- konfigurasi: dari file (FIREBASE_CONFIG) atau dari kotak tempel di Studio --- */
const okCfg=c=>c&&c.apiKey&&c.databaseURL&&!/ISI_/.test(c.apiKey+c.databaseURL);
const cfg=()=>{if(okCfg(window.FIREBASE_CONFIG))return window.FIREBASE_CONFIG;try{const c=JSON.parse(localStorage.getItem('sp_fbcfg')||'null');if(okCfg(c))return c}catch(e){}return null};
const parseCfg=t=>{const o={};['apiKey','authDomain','databaseURL','projectId','storageBucket','messagingSenderId','appId'].forEach(k=>{const m=new RegExp(k+'\\s*[:=]\\s*["\']([^"\']+)["\']').exec(t);if(m)o[k]=m[1]});return o};
const addScript=src=>new Promise(ok=>{const e=document.createElement('script');e.src=src;e.onload=()=>ok(1);e.onerror=()=>ok(0);document.head.appendChild(e)});
const fbLib=async()=>{if(window.firebase&&firebase.database)return 1;const b='https://www.gstatic.com/firebasejs/'+FBV+'/';return (await addScript(b+'firebase-app-compat.js'))&&(await addScript(b+'firebase-database-compat.js'))&&window.firebase&&firebase.database?1:0};
const fbdb=async()=>{if(window.__fbdb)return window.__fbdb;const c=cfg();if(!c)throw new Error('nocfg');if(!(await fbLib()))throw new Error('fblib');const app=firebase.apps.length?firebase.app():firebase.initializeApp(c);return window.__fbdb=firebase.database(app)};
window.spFB=fbdb;window.spParseCfg=parseCfg;
/* diagnosis: cek apakah alamat database terjangkau lewat HTTPS biasa */
const probe=async()=>{const c=cfg();if(!c)return 'konfigurasi Firebase belum diisi';
 try{const r=await timeout(fetch(c.databaseURL.replace(/\/$/,'')+'/.json?shallow=true',{cache:'no-store'}),8000);
  if(r.status===404)return 'databaseURL salah (404). Cek alamat database di file';
  if(r.status===401||r.status===403||r.ok)return 'server Firebase terjangkau, tapi koneksi realtime diblokir. Buka game lewat Chrome (bukan dari TikTok/aplikasi lain) lalu coba lagi';
  return 'Firebase membalas status '+r.status}
 catch(e){return 'server Firebase tidak terjangkau dari jaringan ini. Cek internet/VPN/DNS'}};
window.spProbe=probe;
const TS=()=>firebase.database.ServerValue.TIMESTAMP;
const timeout=(p,ms,msg)=>Promise.race([p,new Promise((_,r)=>setTimeout(()=>r(new Error(msg||'timeout')),ms))]);
/* --- room: semua pemain menulis ke rooms/<hash>/<id>, semua membaca seluruh room --- */
async function join(name,idp){
 let db;
 try{db=await fbdb()}catch(e){
  if(e.message==='expired')throw e;
  say(e.message==='nocfg'?'Firebase belum diatur. Isi konfigurasi dulu (lihat tutorial)':'Gagal memuat Firebase. Cek internet lalu coba lagi');
  throw new Error('none')}
 const {key,rw}=ki(),base=hs(name+'|'+key),id=idp||Math.random().toString(36).slice(2,10);
 const rr=db.ref('rooms/'+base),mine=rr.child(id),con=db.ref('.info/connected');
 const P={},subs=[];let alive=1,me={};
 const list=()=>{const t=Date.now(),a=[{peer:id,isMe:true,kind:'viewer',presence:me}];for(const k in P){if(t-P[k].t>STALE){delete P[k];continue}a.push({peer:k,isMe:false,kind:'viewer',presence:P[k].p,t:P[k].t})}return a};
 const fire=()=>{const l=list();subs.forEach(f=>{try{f({peers:l})}catch(e){}})};
 const onRoom=snap=>{if(!alive)return;const v=snap.val()||{};
  for(const k in v){if(k===id)continue;const s=JSON.stringify(v[k]),o=P[k];if(!o||o.s!==s)P[k]={p:v[k].d||{},t:Date.now(),s}}
  for(const k in P)if(!(k in v))delete P[k];
  fire()};
 const pub=()=>{if(!rw||!alive)return;try{mine.set({d:me,t:TS()})}catch(e){}};
 /* tunggu terhubung ke server Firebase */
 try{await timeout(new Promise(res=>{let done=0;const f=v=>{if(v.val()===true&&!done){done=1;res();setTimeout(()=>{try{con.off('value',f)}catch(e){}},0)}};con.on('value',f)}),20000,'fbtimeout')}
 catch(e){const why=await probe();say('Mabar gagal: '+why);throw new Error('none')}
 rr.on('value',onRoom,()=>{say('Firebase menolak akses. Cek Rules di Realtime Database')});
 /* tiap (re)connect: pasang ulang auto-hapus saat putus & tulis ulang posisi */
 const onCon=con.on('value',s=>{if(s.val()===true&&alive){if(rw){try{mine.onDisconnect().remove()}catch(e){}}pub()}});
 const tm=setInterval(fire,2000),ka=setInterval(pub,2500);
 pub();
 return{peers:list,
  presence(o){if(!rw)return Promise.resolve();Object.assign(me,o);pub();return Promise.resolve()},
  onPeers(f,cl){subs.push(f);return()=>{const i=subs.indexOf(f);if(i>-1)subs.splice(i,1)}},
  leave(){alive=0;clearInterval(tm);clearInterval(ka);try{rr.off('value',onRoom);con.off('value',onCon)}catch(e){}
   try{if(rw){mine.onDisconnect().cancel();mine.remove()}}catch(e){}}}}
/* --- LOBI TEMAN (presence + event) di atas Firebase. Meniru channel Supabase supaya skrip teman tidak perlu diubah --- */
const enc=k=>encodeURIComponent(String(k)).replace(/\./g,'%2E'),dec=k=>{try{return decodeURIComponent(k)}catch(e){return k}};
const jclean=o=>JSON.parse(JSON.stringify(o===undefined?null:o));
function mkChannel(db,name,conf){
 const pk=(conf&&conf.config&&conf.config.presence&&conf.config.presence.key)||Math.random().toString(36).slice(2,10);
 const base='lobby/'+hs(name),pr=db.ref(base+'/p'),mine=pr.child(enc(pk)),inbox=db.ref(base+'/ev/'+enc(pk)),con=db.ref('.info/connected');
 const cbs={sync:[],ev:[]},P={},offs=[];let alive=1,ready=0,lastG='',last=null,tm=null,onP=null,onE=null;
 const state=()=>{const t=Date.now(),st={};for(const k in P){if(t-P[k].t>25000){delete P[k];continue}st[dec(k)]=[P[k].v]}return st};
 const fireSync=()=>{cbs.sync.forEach(f=>{try{f()}catch(e){}})};
 const doTrack=()=>{if(!ready||!alive||!last)return;let o;try{o=jclean(last)}catch(e){return}
  const game=o.game||null;delete o.game;const gs=game?JSON.stringify(game):'';const upd={d:o,t:TS()};if(gs!==lastG)upd.g=game;
  try{mine.update(upd);lastG=gs}catch(e){if('g' in upd){try{delete upd.g;mine.update(upd)}catch(x){}}}};
 const attach=()=>{
  onP=pr.on('value',snap=>{if(!alive)return;const v=snap.val()||{},now=Date.now(),me=enc(pk);
   for(const k in v){if(k===me)continue;const n=v[k]||{},sig=String(n.t);if(!P[k]||P[k].s!==sig){const val=Object.assign({},n.d||{});if(n.g)val.game=n.g;P[k]={v:val,t:now,s:sig}}}
   for(const k in P)if(!(k in v))delete P[k];
   fireSync()});
  onE=inbox.on('child_added',snap=>{if(!alive)return;const v=snap.val();try{snap.ref.remove()}catch(e){}if(!v||!v.p)return;cbs.ev.forEach(f=>{try{f({payload:v.p})}catch(e){}})});
  tm=setInterval(fireSync,5000)};
 const ch={
  on(type,flt,cb){if(type==='presence')cbs.sync.push(cb);else if(type==='broadcast')cbs.ev.push(cb);return ch},
  presenceState(){return state()},
  track(o){last=o;doTrack();return Promise.resolve('ok')},
  send(m){const p=m&&m.payload;if(!p||!p.to||!alive||!ready)return Promise.resolve('error');
   try{db.ref(base+'/ev/'+enc(p.to)+'/'+(p.t==='ack'?'a_':'e_')+String(p.id||Date.now()).replace(/[.#$\[\]\/]/g,'_')).set({p:jclean(p),t:TS()})}catch(e){}
   return Promise.resolve('ok')},
  subscribe(cb){
   const to=setTimeout(()=>{if(!ready&&alive){try{cb&&cb('TIMED_OUT')}catch(e){}}},9000);
   const h=con.on('value',s=>{if(s.val()!==true||!alive)return;try{mine.onDisconnect().remove()}catch(e){}lastG='';
    if(!ready){ready=1;clearTimeout(to);attach();try{cb&&cb('SUBSCRIBED')}catch(e){}}doTrack()});
   offs.push(()=>con.off('value',h));return ch},
  _close(){alive=0;clearInterval(tm);try{if(onP)pr.off('value',onP);if(onE)inbox.off('child_added',onE)}catch(e){}offs.forEach(f=>{try{f()}catch(e){}});try{mine.onDisconnect().cancel();mine.remove()}catch(e){}}};
 return ch}
window.spSB=async()=>{if(window.__sb)return window.__sb;const db=await fbdb();return window.__sb={channel:(n,c)=>mkChannel(db,n,c),removeChannel:ch=>{try{ch._close()}catch(e){}return Promise.resolve('ok')}}};
window.claude={use:async k=>k=='room'?{join}:null};
/* --- bagikan / ambil game lewat Firebase (untuk tombol Gabung Mabar) --- */
const cl=g=>{const d=Object.assign({},g);delete d.thumb;delete d.icon;delete d.by;delete d.mb;d.objs=d.objs||[];return d};
const gpath=()=>'games/'+hs('game|'+roomCode+'|'+kn());
window.spShare=async g=>{try{const db=await fbdb(),r=db.ref(gpath());await r.set({game:cl(g),t:TS()});r.onDisconnect().remove()}catch(e){}};
window.spFetch=async()=>{try{const db=await fbdb(),s=await timeout(db.ref(gpath()).once('value'),7000),v=s&&s.val();if(v&&v.game)return v.game}catch(e){}return null};
window.spJoin=async()=>{toast('Mencari game di room "'+roomCode+'"...');const d=await spFetch();if(!d||typeof d!=='object'||!d.id)return toast('Belum ada game di room ini. Minta temanmu tekan Main dulu dengan kode room yang sama');
 const id=String(d.id);let g=(me.games||[]).find(x=>x.id==id);if(g&&g.mb){me.games=me.games.filter(x=>x!==g);g=null}
 if(!g){const inp=document.getElementById('imp'),dt=new DataTransfer();dt.items.add(new File([JSON.stringify({shinpo:1,kind:'g',data:d})],'m.pickare.json'));inp.files=dt.files;inp.dispatchEvent(new Event('change'));
  for(let i=0;i<30&&!(g=(me.games||[]).find(x=>x.id==id));i++)await new Promise(r=>setTimeout(r,100));if(!g)return toast('Gagal memuat game temanmu');g.mb=1;save()}
 startGame(g)};
/* UI: Room Key (API key room privat) di Home */
const mk=()=>'rk_'+Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b=>b.toString(16).padStart(2,'0')).join('');
window.addEventListener('load',()=>{
 const R0=window.render;if(typeof R0!=='function')return;
 window.render=render=function(){R0.apply(this,arguments);try{if(page!=='home'||document.getElementById('rkc'))return;const rc=document.getElementById('rc');if(!rc)return;const card=rc.closest('.card');
  card.insertAdjacentHTML('afterend','<div class="card" id="rkc" style="margin-top:14px;background:var(--g)"><button class="btn g w" id="rkj" style="margin-bottom:12px"> Gabung Mabar (pakai kode room di atas)</button><label>API Key Room (opsional, untuk room privat)</label><input type="text" id="rk" placeholder="kosong = room publik" maxlength="40" autocomplete="off" value="'+esc(localStorage.getItem('sp_rkey')||'')+'" style="margin:6px 0 10px"><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm c" id="rkn">Buat Key</button><button class="btn sm" id="rkc2">Salin</button></div><p style="margin:8px 0 0;font-size:12px">Teman harus memasukkan <b>kode room</b> dan <b>API key</b> yang sama untuk berada di dunia yang sama.</p></div>');
  const i=document.getElementById('rk'),sv=()=>{try{localStorage.setItem('sp_rkey',i.value.replace(/\s/g,''))}catch(e){}};
  i.oninput=sv;document.getElementById('rkj').onclick=()=>window.spJoin();document.getElementById('rkn').onclick=()=>{i.value=mk();sv();toast('API key room dibuat')};
  document.getElementById('rkc2').onclick=()=>{i.select();try{document.execCommand('copy')}catch(e){}if(navigator.clipboard)navigator.clipboard.writeText(i.value).catch(()=>{});toast('API key room disalin')}}catch(e){}}});
})();
