/* ===== v12e: editor Aksesoris bisa diisi Script, Folder, efek, dll ===== */
(function(){
function row(i,dep){const on=SI===i.id,cont=pickL(i.id).length;
 let h='<div class="er '+(on?'on':'')+'" style="padding-left:'+(18+dep*12)+'px" data-a="isel" data-v="'+i.id+'"><span>'+(CL[i.cls]||'▫')+' '+esc(i.n)+'</span><span>'+(cont?'<b class="px" data-a="padd" data-v="'+i.id+'">＋</b>':'')+(on?'<b class="px dx" data-a="idel" data-v="'+i.id+'">✕</b>':'')+'</span></div>';
 (i.ch||[]).forEach(c=>h+=row(c,dep+1));return h}
const _e5=eRender;eRender=function(){_e5.apply(this,arguments);
 try{if(!ST||ST.kind!=='a')return;const d=ST.d;d.ch=d.ch||[];
  let h='<div class="er '+(SEL=='root'&&!SI?'on':'')+'" data-a="esel" data-v="root"><b>'+esc(d.name)+'</b></div><div class="er ind">Workspace ('+d.objs.length+')</div>';
  d.objs.forEach(o=>{h+='<div class="er ind2 '+(o.id==SEL?'on':'')+'" data-a="esel" data-v="'+o.id+'"><span>'+(TI[o.t]||'')+' '+esc(o.n)+'</span><span><b class="px" data-a="padd" data-v="'+o.id+'">＋</b>'+(o.id==SEL?'<i data-a="edel" data-v="'+o.id+'">✕</i>':'')+'</span></div>';(o.ch||[]).forEach(c=>h+=row(c,2))});
  h+='<div class="er sv" data-a="padd" data-v="@acc"><span>▾ Isi aksesoris (umum)</span><b class="px">＋</b></div>'+d.ch.map(c=>row(c,0)).join('');
  $('#expl').innerHTML=h}catch(e){}};
const _p5=pRender;pRender=function(){
 try{if(ST&&ST.kind==='a'&&SI){const r=loc(SI);if(r&&SEL==='root'){$('#props').innerHTML=iProps(r.i);return}SI=null}}catch(e){SI=null}
 return _p5.apply(this,arguments)};
})();
