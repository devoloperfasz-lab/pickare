/* ===== v20: TERRAIN VIA SCRIPT (semua material) + MATERIAL PART + KUAS EDITOR + ANIMASI POHON =====
   1. workspace.Terrain di Luau:
        Terrain:FillBlock(CFrame, Vector3, Enum.Material.X)
        Terrain:FillBall(Vector3, radius, Enum.Material.X)
        Terrain:FillCylinder(CFrame, height, radius, Enum.Material.X)
        Terrain:ReplaceMaterial(region, resolusi, dari, ke)   -- region diabaikan: ganti SEMUA terrain bermaterial "dari"
        Terrain:SetMaterialColor(Enum.Material.X, Color3) / :GetMaterialColor(Enum.Material.X)
        Terrain:Clear()
      Enum.Material.Air = hapus terrain (yang pusatnya berada di dalam kotak/bola/silinder).
      Material: Grass LeafyGrass Sand Sandstone Water Rock Slate Basalt Mud Ground Snow Ice Glacier Salt Limestone
                Pavement Asphalt Cobblestone Concrete Brick WoodPlanks CrackedLava Air
      Selain Water, semua terrain bisa diinjak (collision). Water tembus & bergelombang.
   2. Part.Material = Enum.Material.Water/Grass/Sand/... sekarang mengubah tampilan Part (tekstur/warna) juga.
   3. Terrain Editor (Studio) -> tab "Tipe Brush": semua material tersedia, bukan hanya 6.
   4. Toolbox: "Terrain Script (semua material)" dan "Pohon Bergoyang (animasi)". */
(function(){
const MAT={
 Grass:{c:'#5aa14a',tx:'grass'},LeafyGrass:{c:'#43a047',tx:'grass'},Sand:{c:'#e6cf8e',tx:'sand'},Sandstone:{c:'#d9a45f'},
 Water:{c:'#2f7fe0',tx:'water',a:.6,w:1},Rock:{c:'#8a8a8a',tx:'stone'},Slate:{c:'#5d6670',tx:'stone'},Basalt:{c:'#3a3a40'},
 Mud:{c:'#5b4330'},Ground:{c:'#7a5636'},Snow:{c:'#f4f8ff'},Ice:{c:'#aee3ff',a:.8},Glacier:{c:'#cfeeff',a:.9},Salt:{c:'#f0e9e0'},
 Limestone:{c:'#d8d0b8'},Pavement:{c:'#9a9a98'},Asphalt:{c:'#2c2c30'},Cobblestone:{c:'#8b8480',tx:'stone'},Concrete:{c:'#a9a9a9'},
 Brick:{c:'#a4523b',tx:'brick'},WoodPlanks:{c:'#9b7240',tx:'wood'},CrackedLava:{c:'#ff5a14',em:1}};
const ORDER=Object.keys(MAT);
const mdef=m=>MAT[String(m)]||{c:'#8a8a8a'};
const hex=c=>'#'+[c.r,c.g,c.b].map(v=>Math.round(Math.max(0,Math.min(1,+v||0))*255).toString(16).padStart(2,'0')).join('');
const nn=(v,d)=>{v=+v;return isFinite(v)?v:d};

/* ---------- enum: tambah material terrain yang belum ada ---------- */
function addEnum(){try{const M=G.get('Enum').get('Material');if(!M)return;['Water','Air','Sandstone','Glacier','CrackedLava'].concat(ORDER).forEach(n=>{if(M.get(n)===undefined)M.set(n,n)})}catch(e){}}
addEnum();

/* ---------- 1. workspace.Terrain ---------- */
class TerW{
 constructor(){this.pcs=[];this.col={};this.p={WaterColor:hexC('#2f7fe0'),WaterTransparency:.4,WaterWaveSize:.15,WaterWaveSpeed:10,WaterReflectance:1};this.t0=performance.now()}
 colOf(m){return this.col[m]||mdef(m).c}
 look(m,sx,sz){const d=mdef(m),mt=new THREE.MeshLambertMaterial({color:m==='Water'?hex(this.p.WaterColor):this.colOf(m)});
  if(d.tx&&typeof txGet==='function'){try{const t=txGet(d.tx).clone(),q=Math.max(1,Math.round((sx+sz)/8));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(q,q);t.needsUpdate=true;mt.map=t}catch(e){}}
  if(d.em){mt.emissive=new THREE.Color(d.c);mt.emissiveIntensity=.8}
  if(m==='Water'){mt.transparent=true;mt.opacity=Math.max(.1,1-this.p.WaterTransparency);mt.depthWrite=false}
  else if(d.a){mt.transparent=true;mt.opacity=d.a}
  return mt}
 add(m,mesh,bx){const p={m,mesh,bx};this.pcs.push(p);scene.add(mesh);if(!d0(m).w&&typeof boxes!=='undefined'&&boxes)bx.forEach(b=>boxes.push(b));return p}
 rm(p){try{scene.remove(p.mesh);p.mesh.geometry.dispose();if(p.mesh.material.map)p.mesh.material.map.dispose();p.mesh.material.dispose()}catch(e){}
  if(typeof boxes!=='undefined'&&boxes)p.bx.forEach(b=>{const i=boxes.indexOf(b);if(i>=0)boxes.splice(i,1)});const i=this.pcs.indexOf(p);if(i>=0)this.pcs.splice(i,1)}
 erase(ok){this.pcs.slice().forEach(p=>{if(ok(p.mesh.position))this.rm(p)})}
 block(cf,sz,m){if(!(cf&&cf.p&&cf.m)||!(sz instanceof LV))return;const c=cf.p,sx=Math.abs(sz.x),sy=Math.abs(sz.y),sw=Math.abs(sz.z);if(!(sx&&sy&&sw))return;
  if(m==='Air'){const ys=Math.atan2(cf.m[2],cf.m[0]),co=Math.cos(ys),si=Math.sin(ys);this.erase(q=>{const dx=q.x-c.x,dz=q.z-c.z,lx=dx*co-dz*si,lz=dx*si+dz*co;return Math.abs(lx)<=sx/2&&Math.abs(q.y-c.y)<=sy/2&&Math.abs(lz)<=sw/2});return}
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),this.look(m,sx,sw)),ry=Math.atan2(cf.m[2],cf.m[0]);
  mesh.scale.set(sx,sy,sw);mesh.position.set(c.x,c.y,c.z);mesh.rotation.y=ry;
  const co=Math.abs(Math.cos(ry)),si=Math.abs(Math.sin(ry));
  this.add(m,mesh,[{x:c.x,z:c.z,hw:(co*sx+si*sw)/2,hd:(si*sx+co*sw)/2,top:c.y+sy/2,bot:c.y-sy/2}])}
 ball(c,r,m){if(!(c instanceof LV)||!(r>0))return;
  if(m==='Air'){this.erase(q=>Math.hypot(q.x-c.x,q.y-c.y,q.z-c.z)<=r);return}
  const mesh=new THREE.Mesh(new THREE.SphereGeometry(1,24,16),this.look(m,r*2,r*2));mesh.scale.setScalar(r);mesh.position.set(c.x,c.y,c.z);
  const n=Math.max(3,Math.min(9,Math.round(r))),bx=[];
  for(let i=0;i<n;i++){const y0=-r+2*r*i/n,y1=-r+2*r*(i+1)/n,yc=(y0+y1)/2,h=Math.sqrt(Math.max(0,r*r-yc*yc))*.72;if(h>.2)bx.push({x:c.x,z:c.z,hw:h,hd:h,top:c.y+y1,bot:c.y+y0})}
  this.add(m,mesh,bx)}
 cyl(cf,h,r,m){if(!(cf&&cf.p&&cf.m)||!(h>0)||!(r>0))return;const c=cf.p;
  if(m==='Air'){this.erase(q=>Math.hypot(q.x-c.x,q.z-c.z)<=r&&Math.abs(q.y-c.y)<=h/2);return}
  const mesh=new THREE.Mesh(new THREE.CylinderGeometry(1,1,1,28),this.look(m,r*2,r*2));mesh.scale.set(r,h,r);mesh.position.set(c.x,c.y,c.z);mesh.rotation.y=Math.atan2(cf.m[2],cf.m[0]);
  this.add(m,mesh,[{x:c.x,z:c.z,hw:r*.85,hd:r*.85,top:c.y+h/2,bot:c.y-h/2}])}
 swap(a,b){if(b==='Air'){this.pcs.slice().forEach(p=>{if(p.m===a)this.rm(p)});return}
  this.pcs.slice().forEach(p=>{if(p.m!==a)return;const o=p.mesh,s=o.scale,old=o.material;o.material=this.look(b,s.x*(o.geometry.type==='BoxGeometry'?1:2),s.z*(o.geometry.type==='BoxGeometry'?1:2));try{old.map&&old.map.dispose();old.dispose()}catch(e){}
   const w0=!!mdef(a).w,w1=!!mdef(b).w;p.m=b;
   if(w0&&!w1&&typeof boxes!=='undefined'&&boxes)p.bx.forEach(x=>boxes.push(x));
   else if(!w0&&w1&&typeof boxes!=='undefined'&&boxes)p.bx.forEach(x=>{const i=boxes.indexOf(x);if(i>=0)boxes.splice(i,1)})})}
 recolor(m){this.pcs.forEach(p=>{if(p.m===m&&p.mesh.material.color)p.mesh.material.color.set(m==='Water'?hex(this.p.WaterColor):this.colOf(m))})}
 tick(){const t=(performance.now()-this.t0)/1000;this.pcs.forEach(p=>{if(p.m==='Water'&&p.mesh.material.map){const o=p.mesh.material.map.offset;o.x=(t*.02*(this.p.WaterWaveSpeed/10))%1;o.y=(Math.sin(t*.8)*.02)}})}
 $g(k){const T=this,M=v=>String(v==null?'Grass':v);
  switch(k){
   case'ClassName':return'Terrain';case'Name':return'Terrain';case'IsA':return(_,c)=>/^(Terrain|BasePart|Instance)$/.test(c);
   case'FillBlock':return(_,cf,sz,m)=>{T.block(cf,sz,M(m))};
   case'FillBall':return(_,c,r,m)=>{T.ball(c,nn(r,0),M(m))};
   case'FillCylinder':return(_,cf,h,r,m)=>{T.cyl(cf,nn(h,0),nn(r,0),M(m))};
   case'FillWedge':return(_,cf,sz,m)=>{T.block(cf,sz,M(m))};
   case'Clear':return()=>{T.pcs.slice().forEach(p=>T.rm(p))};
   case'ReplaceMaterial':return(_,a,b,c,d)=>{const arg=[a,b,c,d].filter(v=>typeof v==='string');if(arg.length>=2)T.swap(arg[arg.length-2],arg[arg.length-1])};
   case'SetMaterialColor':return(_,m,c)=>{if(c instanceof LC){T.col[M(m)]=hex(c);T.recolor(M(m))}};
   case'GetMaterialColor':return(_,m)=>hexC(T.colOf(M(m)));
   case'GetPieceCount':return()=>T.pcs.length;
   default:return T.p[k]}}
 $s(k,v){this.p[k]=v;if(k==='WaterColor'&&v instanceof LC)this.recolor('Water');
  if(k==='WaterTransparency'){const o=Math.max(.1,1-nn(v,.4));this.pcs.forEach(p=>{if(p.m==='Water')p.mesh.material.opacity=o})}}}
function d0(m){return mdef(m)}

/* pasang Terrain ke workspace setiap game dimulai */
const _rs=rtStart;
rtStart=function(g){const r=_rs.apply(this,arguments);
 try{if(RT&&RT.ws){const T=new TerW(),rt=RT,o=RT.ws.$g;RT.terr=T;
  RT.ws.$g=function(k){if(k==='Terrain')return T;if(k==='FindFirstChild'||k==='WaitForChild'||k==='FindFirstChildOfClass'||k==='FindFirstChildWhichIsA'){const f=o.apply(this,arguments);return(s,n,...q)=>(n==='Terrain'?T:(f&&f(s,n,...q)))}return o.apply(this,arguments)};
  (function lp(){if(RT!==rt||!rt.alive)return;try{T.tick()}catch(e){}requestAnimationFrame(lp)})()}}catch(e){}
 return r};

/* ---------- 2. Part.Material = Water / Grass / Sand ... mengubah tampilan Part ---------- */
function lookPart(w){const m=w.m&&w.m.material;if(!m)return;const k=String(w.mat||'Plastic'),d=MAT[k];
 if(w._om===undefined)w._om=m.map||null;
 if(d){
  if(d.tx&&typeof txGet==='function'){try{const t=txGet(d.tx).clone(),q=Math.max(1,Math.round(((w.m.scale.x||1)+(w.m.scale.z||1))/8));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(q,q);t.needsUpdate=true;m.map=t}catch(e){}}
  else m.map=null;
  if(!w.col&&d.c&&m.color)m.color.set(d.c);
  if(d.em&&m.emissive){m.emissive.set(d.c);m.emissiveIntensity=.8}
  if(w.trs===undefined){if(d.a){m.transparent=true;m.opacity=d.a}}
  w._tm=1;m.needsUpdate=true}
 else if(w._tm){m.map=w._om;w._tm=0;m.needsUpdate=true}}
if(typeof PtW!=='undefined'){const _ps=PtW.prototype.$s;PtW.prototype.$s=function(k,v){const r=_ps.apply(this,arguments);if(k==='Material'){try{lookPart(this)}catch(e){}}return r}}

/* ---------- 3. Terrain Editor: semua material di tab "Tipe Brush" ---------- */
function brushGrid(){const lc=document.getElementById('lcol');if(!lc)return false;const tgr=lc.querySelector('.tgr');if(!tgr)return false;
 const css=document.createElement('style');css.textContent='.tgx{display:grid;grid-template-columns:repeat(2,1fr);gap:4px;margin-top:6px;padding-top:6px;border-top:1px solid rgba(127,127,127,.35)}.tgx b{grid-column:1/-1;font-size:11px;opacity:.7}.tgx button{display:flex;align-items:center;gap:6px;font-size:11px;padding:5px 6px;border-radius:6px;border:1px solid rgba(127,127,127,.4);background:rgba(127,127,127,.12);color:inherit;cursor:pointer}.tgx i{width:12px;height:12px;border-radius:3px;border:1px solid rgba(0,0,0,.35);flex:0 0 12px}';document.head.appendChild(css);
 const draw=()=>{const on=lc.querySelector('.tt b.on');if(!on||on.dataset.v!=='tt:b'||tgr.querySelector('.tgx'))return;
  const d=document.createElement('div');d.className='tgx';d.innerHTML='<b>Semua material</b>'+ORDER.map(m=>'<button type="button" data-tm="'+m+'"><i style="background:'+MAT[m].c+'"></i>'+m+'</button>').join('');tgr.appendChild(d)};
 new MutationObserver(draw).observe(tgr,{childList:true});new MutationObserver(draw).observe(lc.querySelector('.tt'),{subtree:true,attributes:true,attributeFilter:['class']});
 tgr.addEventListener('click',e=>{const b=e.target.closest('[data-tm]');if(!b)return;e.stopPropagation();
  try{const d=MAT[b.dataset.tm],T=ST.d.objs.filter(o=>o.n=='Terrain');if(!T.length)return toast('Buat Terrain dulu (Generate)');
   pushUndo();T.forEach(o=>{o.c=d.c;o.tex=d.tx||''});sBuild();eRender();pRender();touch();slog('Terrain → '+b.dataset.tm)}catch(x){}});
 draw();return true}
{let n=0;const iv=setInterval(()=>{if(brushGrid()||++n>40)clearInterval(iv)},500)}

/* ---------- 4. template Toolbox ---------- */
const addT=(n,d,f)=>{if(!TB.some(x=>x.n===n))TB.push({n,ic:'',d,f})};
const TERSRC=`-- Membuat terrain dari script. Semua material bisa dipakai:
-- Grass LeafyGrass Sand Sandstone Water Rock Slate Basalt Mud Ground Snow Ice Glacier
-- Salt Limestone Pavement Asphalt Cobblestone Concrete Brick WoodPlanks CrackedLava
-- Air = menghapus terrain.
local terrain = workspace.Terrain
terrain:Clear()

-- bukit rumput + pantai pasir
terrain:FillBlock(CFrame.new(0, 1, 40), Vector3.new(40, 2, 30), Enum.Material.Grass)
terrain:FillBlock(CFrame.new(0, 0.5, 60), Vector3.new(40, 1, 10), Enum.Material.Sand)

-- kolam air (tembus, bisa dilewati)
terrain:FillCylinder(CFrame.new(32, 0.4, 40), 0.8, 9, Enum.Material.Water)

-- gunung batu + puncak salju
terrain:FillBall(Vector3.new(-30, 2, 40), 9, Enum.Material.Rock)
terrain:FillBall(Vector3.new(-30, 9, 40), 4, Enum.Material.Snow)

-- lava
terrain:FillBlock(CFrame.new(0, 0.3, 80), Vector3.new(14, 0.6, 14), Enum.Material.CrackedLava)

-- ganti material: rumput -> salju -> pasir -> rumput (tiap 3 detik)
local urutan = {Enum.Material.Snow, Enum.Material.Sand, Enum.Material.Mud, Enum.Material.Grass}
local sekarang = Enum.Material.Grass
local i = 1
while true do
	wait(3)
	terrain:ReplaceMaterial(nil, 4, sekarang, urutan[i])
	sekarang = urutan[i]
	i = i % #urutan + 1
end
`;
addT('Terrain Script (semua material)','Script: bikin terrain (FillBlock/FillBall/FillCylinder) dengan semua material + ReplaceMaterial',()=>sg('ServerScriptService','Script',TERSRC,'TerrainScript'));
const TREESRC=`-- Animasi pohon bergoyang tertiup angin.
-- Cara pakai untuk pohon buatanmu: namai part-nya  NamaPohon_Batang  dan  NamaPohon_Daun1, NamaPohon_Daun2, ...
-- (contoh: Pohon1_Batang, Pohon1_Daun1). Semua pohon dengan pola nama itu akan ikut bergoyang.
local RunService = game:GetService("RunService")

local KEKUATAN = 0.06   -- seberapa miring (radian). 0.03 = pelan, 0.12 = badai
local KECEPATAN = 1.4   -- seberapa cepat bergoyang

local pohon = {}
for _, p in pairs(workspace:GetChildren()) do
	local nama = p.Name
	if #nama > 7 and string.sub(nama, -7) == "_Batang" then
		local awalan = string.sub(nama, 1, #nama - 7)
		local alas = p.Position - Vector3.new(0, p.Size.Y / 2, 0)
		local data = {batang = p, tinggi = p.Size.Y, alas = alas, daun = {}, fase = #pohon * 1.7}
		for _, d in pairs(workspace:GetChildren()) do
			if string.sub(d.Name, 1, #awalan + 5) == awalan .. "_Daun" then
				table.insert(data.daun, {part = d, off = d.Position - alas})
			end
		end
		table.insert(pohon, data)
	end
end

RunService.Heartbeat:Connect(function()
	local t = tick()
	for _, h in pairs(pohon) do
		local angin = math.sin(t * KECEPATAN + h.fase) * KEKUATAN + math.sin(t * KECEPATAN * 2.3 + h.fase) * KEKUATAN * 0.3
		local cf = CFrame.new(h.alas) * CFrame.Angles(math.cos(t * KECEPATAN * 0.8 + h.fase) * KEKUATAN * 0.5, 0, angin)
		h.batang.CFrame = cf * CFrame.new(0, h.tinggi / 2, 0)
		for _, d in pairs(h.daun) do
			-- daun bergoyang sedikit lebih kuat daripada batang
			local ayun = CFrame.Angles(0, 0, math.sin(t * KECEPATAN * 2 + h.fase) * KEKUATAN * 0.4)
			d.part.CFrame = cf * CFrame.new(d.off) * ayun
		end
	end
end)
`;
addT('Pohon Bergoyang (animasi)','3 pohon + script animasi: batang & daun bergoyang tertiup angin',()=>{
 [[-12,12],[0,16],[12,12]].forEach((q,i)=>{const n='Pohon'+(i+1),x=q[0],z=q[1];
  const b=O('cyl',x,2,z,1.2,4,1.2,'#8d5524');b.n=n+'_Batang';ST.d.objs.push(b);
  const d1=O('ball',x,5.5,z,5,5,5,'#2e9e4f');d1.n=n+'_Daun1';ST.d.objs.push(d1);
  const d2=O('ball',x,8,z,3.2,3.2,3.2,'#43b85f');d2.n=n+'_Daun2';ST.d.objs.push(d2)});
 return sg('ServerScriptService','Script',TREESRC,'PohonBergoyang')});
addT('Animasi Pohon (untuk pohonmu)','Script saja: pohon bernama X_Batang + X_Daun1.. akan bergoyang',()=>sg('ServerScriptService','Script',TREESRC,'PohonBergoyang'));
})();
