(function(){
const G=$('#game');
/* ===== 1. Explorer ＋ : RemoteEvent dkk di Workspace dan service lain ===== */
const EV=['RemoteEvent','RemoteFunction','BindableEvent'],ad=(k,a)=>{PL[k]=PL[k]||[];a.forEach(x=>{if(!PL[k].includes(x))PL[k].push(x)})};
ad('Workspace',['Script','ModuleScript','Folder',...EV,'Sound']);
ad('ServerScriptService',['Script','ModuleScript','Folder',...EV,'Sound']);
ad('ServerStorage',['Script','ModuleScript','Folder',...EV,'Sound']);
ad('ReplicatedStorage',['ModuleScript','Folder',...EV,'Sound']);
ad('ReplicatedFirst',['LocalScript','ModuleScript',...EV]);
ad('StarterGui',['ScreenGui','LocalScript','Folder','ModuleScript',...EV,'Sound']);
ad('StarterPlayerScripts',['LocalScript','Folder','ModuleScript',...EV]);
ad('StarterPack',['LocalScript',...EV]);

/* ===== 2. Chat ala Roblox ===== */
$('#topl').innerHTML='<button class="rbx" data-a="pause" title="Menu">S</button><div class="rpill"><button data-a="pause">☰</button><button data-a="chat"></button><button data-a="cam"><i id="camb" style="display:none"></i></button></div>';
G.insertAdjacentHTML('beforeend','<div id="rchat"><div class="rtabs"><b data-a="rct" data-v="here" class="on">Di sini</b><b data-a="rct" data-v="all">Global</b><b data-a="rct" data-v="fr">Teman</b></div><div class="rlog"></div><div class="rin"></div></div><div class="hud" id="hpb"><i></i><b>100</b></div><div id="hurt"></div><div id="dead"> Kamu dimakan zombie!<small>Respawn sebentar lagi…</small></div>');
const RC=$('#rchat'),LG=RC.querySelector('.rlog'),CI=$('#ci');
CI.placeholder='Ketuk di sini untuk chat';RC.querySelector('.rin').appendChild(CI);
let CHM=[],CHT='here',opn=false;
const hue=n=>{let h=0;for(const c of String(n))h=(h*31+c.charCodeAt(0))%360;return h};
function draw(){const now=Date.now();let L=CHM.filter(m=>CHT=='all'?m.k!='s':CHT=='fr'?(m.me||(m.k=='u'&&rel(m.n)=='friend')):true);
 if(!opn)L=L.filter(m=>now-m.ts<12000);L=L.slice(-40);
 LG.innerHTML=L.length?L.map(m=>m.k=='u'?`<div class="rm"><b style="color:hsl(${hue(m.n)},80%,70%)">[${esc(m.n)}]:</b> ${esc(m.t)}</div>`:`<div class="rm ${m.k}"><span>${m.k=='s'?'':'['+esc(m.n)+'] '}${esc(m.t)}</span></div>`).join(''):(opn?'<div class="rm k"><span>Belum ada pesan.</span></div>':'');
 LG.scrollTop=LG.scrollHeight;RC.classList.toggle('op',opn);RC.querySelectorAll('.rtabs b').forEach(b=>b.classList.toggle('on',b.dataset.v==CHT))}
function bubble(g,t){if(!g||!window.THREE)return;if(g.userData.bub){g.remove(g.userData.bub);clearTimeout(g.userData.bubT)}
 const c=document.createElement('canvas');c.width=512;c.height=160;const x=c.getContext('2d');x.font='bold 30px Arial';
 const w=[],words=String(t).split(' ');let ln='';words.forEach(s=>{if(x.measureText(ln+' '+s).width>440&&ln){w.push(ln);ln=s}else ln=ln?ln+' '+s:s});w.push(ln);const ls=w.slice(0,3),h=ls.length*36+28;
 x.fillStyle='#fff';x.strokeStyle='#000';x.lineWidth=5;x.beginPath();x.roundRect?x.roundRect(8,8,496,h,22):x.rect(8,8,496,h);x.fill();x.stroke();
 x.fillStyle='#111';x.textAlign='center';x.textBaseline='middle';ls.forEach((s,i)=>x.fillText(s.slice(0,28),256,8+14+18+i*36));
 const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false,transparent:true}));sp.scale.set(4.2,1.3,1);sp.position.y=7.4;sp.renderOrder=9;g.add(sp);g.userData.bub=sp;
 g.userData.bubT=setTimeout(()=>{g.remove(sp);if(g.userData.bub===sp)g.userData.bub=null},7000)}
const _ac=addChat;
addChat=function(n,t){const sys=n=='Sistem',scr=n=='Script'||n=='Error'||n=='Peringatan',m={n,t:String(t),k:sys?'s':scr?'k':'u',ts:Date.now(),me:n==me.name};CHM.push(m);if(CHM.length>200)CHM.shift();draw();
 if(m.k=='u'){try{if(m.me)bubble(plr,t);else for(const k in remote)if(remote[k].name==n)bubble(remote[k].g,t)}catch(e){}}};
setInterval(()=>{if(run&&!opn)draw()},2000);
act.chat=function(){opn=!opn;draw();if(opn)setTimeout(()=>CI.focus(),30);else CI.blur()};
act.rct=function(v){CHT=v;draw()};
act.send=function(){const t=CI.value.trim();if(t){addChat(me.name,t);if(RM)RM.presence({c:t,ct:Date.now()}).catch(()=>{})}CI.value='';opn=false;CI.blur();draw()};

/* ===== 3. Health GUI, mati, respawn ===== */
const HB=$('#hpb'),HF=HB.querySelector('i'),HT=HB.querySelector('b'),HU=$('#hurt'),DD=$('#dead');let rvT=null,dPos=null,dT0=0,lastHurt=0;
function hud(){if(!RT)return;const h=Math.max(0,Math.ceil(RT.hp));HF.style.width=h+'%';HF.style.background=h>60?'#4cd964':h>30?'#ffcc00':'#ff3b30';HT.textContent=h}
function hurt(n){if(!RT||!RT.alive||RT.dead||!(n>0)||Date.now()<(RT.inv||0))return;RT.hp=Math.max(0,RT.hp-n);lastHurt=Date.now();hud();HU.style.opacity=1;setTimeout(()=>HU.style.opacity=0,160);try{burst(P.x,P.y+1.5,P.z,'#ff3b30',8)}catch(e){}if(RT.hp<=0)die()}
function die(){if(!RT||RT.dead)return;RT.dead=true;RT.hp=0;hud();dPos={x:P.x,z:P.z};dT0=performance.now();DD.style.display='flex';try{burst(P.x,P.y+1.5,P.z,'#ff3b30',30)}catch(e){}if(RT.died)RT.died.fire();
 rvT=setTimeout(()=>{if(!RT||!RT.alive)return;RT.dead=false;RT.hp=100;RT.inv=Date.now()+2500;DD.style.display='none';if(plr){plr.rotation.x=0}act.respawn();hud();if(RT.pl)try{RT.pl.x.CharacterAdded.fire(RT.ch)}catch(e){}toast('Respawn!')},1800)}
const _hg=HumW.prototype.$g,_hs=HumW.prototype.$s;
HumW.prototype.$g=function(k){if(k=='Health')return RT.hp;if(k=='TakeDamage')return(s,n)=>{hurt(+n);return[]};if(k=='Died')return RT.died;if(k=='MaxHealth')return 100;return _hg.call(this,k)};
HumW.prototype.$s=function(k,v){if(k=='Health'){v=+v;if(v<RT.hp)hurt(RT.hp-v);else if(!RT.dead){RT.hp=Math.min(100,v);hud()}}else _hs.call(this,k,v)};
const _rt=rtTick;rtTick=function(){_rt();if(!RT||!RT.alive||!P)return;
 if(RT.dead){P.x=dPos.x;P.z=dPos.z;P.vy=0;if(plr)plr.rotation.x=-Math.min(1.5,(performance.now()-dT0)/350)}
 else if(RT.hp<100&&Date.now()-lastHurt>4000){RT.hp=Math.min(100,RT.hp+.02*60*Math.min(.1,(performance.now()-(RT._lt2||performance.now()))/1000));hud()}
 RT._lt2=performance.now()};
const _sg=startGame;startGame=function(g,t){_sg(g,t);CHM=[];CHT='here';opn=false;try{if(RT){RT.dead=false;RT.hp=100;RT.inv=0;RT.died=new Sig()}}catch(e){}
 clearTimeout(rvT);DD.style.display='none';HU.style.opacity=0;HB.style.display='block';hud();CI.value='';draw();addChat('Sistem','Selamat datang di '+g.name+'!')};
const _sp=stopGame;stopGame=function(){clearTimeout(rvT);HB.style.display='none';DD.style.display='none';opn=false;_sp()};

/* ===== 4. Zombie: script yang mengejar & memakan pemain ===== */
const ZS=pre=>`-- ZombieAI: mengejar pemain, memakannya, lalu pemain respawn
local PREFIX = "${pre}"
local SPEED = 5      -- kecepatan jalan
local RANGE = 45     -- jarak mulai mengejar
local DAMAGE = 25    -- damage per gigitan
local player = game:GetService("Players").LocalPlayer
local parts, offs = {}, {}
local torso
for _, p in ipairs(workspace:GetChildren()) do
	if string.sub(p.Name, 1, #PREFIX) == PREFIX then
		table.insert(parts, p)
		if p.Name == PREFIX .. "Torso" then torso = p end
	end
end
if not torso then warn("ZombieAI: part tidak ditemukan") return end
local base = torso.Position
for i, p in ipairs(parts) do offs[i] = p.Position - base end
local home = base
local lastHit = 0
local function moveTo(target, dt)
	local cur = torso.Position
	local d = Vector3.new(target.X - cur.X, 0, target.Z - cur.Z)
	local dist = d.Magnitude
	if dist < 0.3 then return end
	local step = math.min(SPEED * dt, dist)
	local nxt = cur + d.Unit * step
	for i, p in ipairs(parts) do p.Position = nxt + offs[i] end
end
while true do
	local dt = wait(0.03)
	if dt > 0.1 then dt = 0.1 end
	local char = player.Character
	local root = char:FindFirstChild("HumanoidRootPart")
	local hum = char:FindFirstChild("Humanoid")
	local pos = root.Position
	local tp = torso.Position
	local flat = Vector3.new(pos.X - tp.X, 0, pos.Z - tp.Z).Magnitude
	local dy = math.abs(pos.Y - tp.Y)
	if hum.Health > 0 and flat < RANGE and dy < 8 then
		if flat > 2.2 then
			moveTo(pos, dt)
		elseif os.clock() - lastHit > 0.8 then
			lastHit = os.clock()
			hum:TakeDamage(DAMAGE)
		end
	else
		moveTo(home, dt)
	end
end
`;
const T=window.SPX.TBL.Rig,ix=T.findIndex(x=>x.n=='Zombie');
const zi={n:'Zombie',ic:'',d:'Zombie + script: mengejar & memakan pemain (HP berkurang, mati, respawn)',f(){
 const n=ST.d.objs.filter(o=>/^Zombie\d*_Torso$/.test(o.n)).length+1,pre='Zombie'+n+'_';
 const h=window.SPX.rig(pre,'#7ab648','#3a6b2a','#2d3a55',false);ST.d.objs.forEach(o=>{if(o.n.startsWith(pre))o.cc=false});
 window.SPX.sadd('ServerScriptService','Script','ZombieAI'+n,{src:ZS(pre)});return h}};
if(ix>=0)T[ix]=zi;else T.push(zi);
draw();
})();
