/* ===== KATALOG MAP GLOBAL: map yang dipublish tampil di semua HP/browser/akun =====
   Tiap map dipublish sebagai pesan "retained" di 3 broker MQTT publik (topik pickare/v9/cat/<id>).
   HP lain subscribe ke topik itu dan langsung menerima semua map yang pernah dipublish. */
(function(){
const BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const PFX='pickare/v9/cat/',MAXB=700000;
const lib=()=>new Promise(r=>{if(window.mqtt)return r(1);const e=document.createElement('script');e.src='https://cdn.jsdelivr.net/npm/mqtt@5.10.1/dist/mqtt.min.js';e.onload=()=>r(!!window.mqtt);e.onerror=()=>r(0);document.head.appendChild(e)});
const hsh=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)+t.length};
const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
const unb64=t=>{const s=atob(t),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u};
const pipe=async(data,S)=>{const st=new S('gzip'),w=st.writable.getWriter();w.write(data);w.close();return new Uint8Array(await new Response(st.readable).arrayBuffer())};
const enc=async o=>{const j=JSON.stringify(o);if(window.CompressionStream){try{return 'z1:'+b64(await pipe(new TextEncoder().encode(j),CompressionStream))}catch(e){}}return 'j1:'+j};
const dec=async s=>{try{if(s.startsWith('x1:'))return{dead:1,ts:+s.slice(3)||0};if(s.startsWith('j1:'))return JSON.parse(s.slice(3));if(s.startsWith('z1:'))return JSON.parse(new TextDecoder().decode(await pipe(unb64(s.slice(3)),DecompressionStream)))}catch(e){}return null};
const shrink=(src,w,h,q)=>new Promise(res=>{if(!src)return res('');const im=new Image();im.onload=()=>{try{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d'),r=Math.max(w/im.width,h/im.height),dw=im.width*r,dh=im.height*r;x.drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);res(c.toDataURL('image/jpeg',q))}catch(e){res('')}};im.onerror=()=>res('');im.src=src});
const sigOf=g=>{const d=Object.assign({},g);['pl','lk','mine','mb'].forEach(k=>delete d[k]);return hsh(JSON.stringify(d))};
const hx=(c,f)=>/^#[0-9a-f]{6}$/i.test(c||'')?c:f;
const okI=u=>/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(u||'')?u:'';
const cleanRemote=(g,id)=>{if(!g||typeof g!=='object'||!Array.isArray(g.objs))return null;const d=Object.assign({},g);d.id=id;d.name=String(d.name||'Map').slice(0,22);d.desc=String(d.desc||'').slice(0,140);d.emoji=String(d.emoji||'').slice(0,4);d.col=hx(d.col,'#b6f25a');d.sky=hx(d.sky,'#7df9ff');d.by=String(d.by||'Pickare').slice(0,20);d.thumb=okI(d.thumb);d.icon=okI(d.icon);if(d.rv&&d.rv.s&&d.rv.s!=='approved')return null;d.pub=true;d.rp=1;delete d.mb;delete d.mine;if(d.objs.length>4000)d.objs.length=4000;return d};

/* ---- kirim (publish / unpublish) ---- */
function pushAll(msgs){return new Promise(async res=>{if(!(window.mqtt||await lib()))return res(0);let ok=0,pend=BR.length;
 const fin=()=>{if(--pend===0)res(ok)};
 BR.forEach(url=>{let done=0,m;const end=g=>{if(done)return;done=1;if(g)ok++;try{m.end(true)}catch(e){}fin()};
  try{m=mqtt.connect(url,{clientId:'spc_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true});}catch(e){done=1;return fin()}
  m.on('error',()=>end(0));m.on('close',()=>end(0));
  m.on('connect',async()=>{try{for(const x of msgs)await new Promise(r=>m.publish(x.t,x.p,{qos:1,retain:true},()=>r()));end(1)}catch(e){end(0)}});
  setTimeout(()=>end(0),15000)})})}
let syncing=0;
async function sync(){if(syncing||typeof users==='undefined')return;syncing=1;
 try{const sigs=ls.get('sp_catsig',{}),cur={};
  Object.values(users).forEach(u=>{if(!u||u.rm||banOf(u))return;(u.games||[]).forEach(g=>{if(g&&g.pub===true&&!(g.rv&&g.rv.s&&g.rv.s!=='approved')&&!g.mb&&g.id&&g.icon&&g.thumb&&Array.isArray(g.objs))cur[g.id]=g})});
  const msgs=[],upd={};
  for(const id in cur){const sg=sigOf(cur[id]),e=sigs[id];if(e&&e.s===sg&&Date.now()-e.t<216e5)continue;
   const g=JSON.parse(JSON.stringify(cur[id]));['pl','lk','mine','mb'].forEach(k=>delete g[k]);
   g.icon=await shrink(g.icon,96,96,.75);g.thumb=await shrink(g.thumb,320,180,.65);
   const p=await enc({ts:Date.now(),g});if(p.length>MAXB){try{toast('Map "'+g.name+'" terlalu besar untuk dibagikan online')}catch(e){}continue}
   msgs.push({t:PFX+id,p});upd[id]={s:sg,t:Date.now()}}
  const gone=[];for(const id in sigs)if(!cur[id]){msgs.push({t:PFX+id,p:'x1:'+Date.now()});gone.push(id)}
  if(!msgs.length)return;
  const ok=await pushAll(msgs);
  if(ok){for(const id in upd)sigs[id]=upd[id];gone.forEach(id=>delete sigs[id]);ls.set('sp_catsig',sigs);
   if(Object.keys(upd).length)try{toast('Map dibagikan ke semua pemain ✓')}catch(e){}}
  else if(Object.keys(upd).length)try{toast('Gagal membagikan map, akan dicoba lagi')}catch(e){}
 }catch(e){}finally{syncing=0}}

/* ---- terima (katalog dari semua HP) ---- */
function fetchAll(){return new Promise(async res=>{if(!(window.mqtt||await lib()))return res(null);const got={};let pend=BR.length,fin=0;
 const out=()=>{if(fin)return;fin=1;res(got)};
 BR.forEach(url=>{let done=0,m;const ps=[];const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}Promise.all(ps).then(()=>{if(--pend===0)out()})};
  try{m=mqtt.connect(url,{clientId:'spc_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){done=1;if(--pend===0)out();return}
  m.on('error',end);m.on('close',end);
  m.on('connect',()=>{m.subscribe(PFX+'+',{qos:0});setTimeout(end,4000)});
  m.on('message',(t,b)=>{const id=t.slice(PFX.length).replace(/[^\w-]/g,'');if(!id)return;ps.push(dec(b.toString()).then(d=>{if(d&&d.ts&&(!got[id]||d.ts>got[id].ts))got[id]=d}))});
  setTimeout(end,9000)});
 setTimeout(out,11000)})}
let lastSig='',fetching=0;
async function pull(){if(fetching)return;fetching=1;
 try{const got=await fetchAll();if(!got||!Object.keys(got).length)return;
  const list=[];for(const id in got){const d=got[id];if(d.dead||!d.g)continue;const g=cleanRemote(d.g,id);if(g){g._ts=d.ts;list.push(g)}}
  list.sort((a,b)=>b._ts-a._ts);
  const sg=list.map(g=>g.id+':'+g._ts).join(',');if(sg===lastSig)return;lastSig=sg;
  RPUB.length=0;list.forEach(g=>RPUB.push(g));ls.set('sp_catcache',RPUB);
  const a=document.getElementById('app');if(a&&a.classList.contains('on')&&!document.getElementById('ov')?.classList.contains('on')){try{if(typeof refreshUI==='function')refreshUI();else render()}catch(e){}}
 }catch(e){}finally{fetching=0}}

/* cache terakhir langsung dipakai (tampil instan, sebelum koneksi selesai) */
try{const c=ls.get('sp_catcache',[]);if(Array.isArray(c))c.forEach(g=>{const x=cleanRemote(g,String(g.id||'').replace(/[^\w-]/g,''));if(x)RPUB.push(x)})}catch(e){}
window.__spMq={pushAll,lib};
window.spCatalogSync=()=>{sync();pull()};
window.addEventListener('load',()=>{
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{pull();sync()},600);return r};
 setInterval(()=>{if(typeof me!=='undefined'&&me)sync()},8000);
 setInterval(()=>{const a=document.getElementById('app');if(a&&a.classList.contains('on'))pull()},40000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){pull();sync()}});
 const a=document.getElementById('app');if(a&&a.classList.contains('on')){pull();sync()}});
})();
