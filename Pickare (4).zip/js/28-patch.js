(function(){
const G=$('#game'),E=d=>d*Math.PI/180,PRT=/^(Part|Cylinder|Ball)$/;
const NEWC={Tool:'🔧',Part:'🧱',Cylinder:'🛢',Ball:'🔴',WeldConstraint:'🔗',Motor6D:'⚙️'};
Object.assign(CL,NEWC);
Object.assign(CD,{Tool:'Alat yang bisa dipegang pemain (masuk Backpack)',Part:'Blok di dalam Tool',Cylinder:'Tabung di dalam Tool',Ball:'Bola di dalam Tool',WeldConstraint:'Menempelkan dua Part jadi satu',Motor6D:'Sendi: Part1 ikut Part0, bisa berputar'});
PL.StarterPack=['Tool','LocalScript'];PL.Workspace=['Script','Tool'];PL.ServerStorage=['Script','ModuleScript','Folder','Tool'];
const TD={Tool:{gx:0,gy:0,gz:0,gp:90,px:0,py:3,pz:8},Part:{ox:0,oy:0,oz:0,rx:0,ry:0,rz:0,sx:1,sy:1,sz:1,c:'#b0b0b0'},WeldConstraint:{w0:'',w1:''},Motor6D:{w0:'',w1:'',ax:'y',spd:0,a0:0,a1:0,a2:0,a3:0,a4:0,a5:0,b0:0,b1:0,b2:0,b3:0,b4:0,b5:0}};
TD.Cylinder=TD.Ball=TD.Part;
const _ni=newI;newI=function(c){const i=_ni(c);if(TD[c])Object.assign(i,JSON.parse(JSON.stringify(TD[c])));return i};
const mkL=a=>a.map(v=>({id:v,k:'inst',n:v,ic:CL[v],d:CD[v]}));
const _pk=pickL;pickL=function(t){if(!PL[t]){const r=loc(t);if(r){const c=r.i.cls;if(c=='Tool')return mkL(['Part','Cylinder','Ball','WeldConstraint','Motor6D','Script','LocalScript']);if(PRT.test(c))return mkL(['WeldConstraint','Motor6D'])}}return _pk(t)};
const par=i=>{for(const k in ST.d.svc){const p=findPar(ST.d.svc[k],i);if(p)return p}return null};
const toolOf=i=>{let p=par(i);while(p&&p.cls!='Tool')p=par(p);return p};
const parts=t=>{const o=[],w=a=>a.forEach(c=>{if(PRT.test(c.cls))o.push(c);w(c.ch)});w(t.ch);return o};
const _pn=act.pins;act.pins=function(v,t){const tg=($('#cpick')||{dataset:{}}).dataset.t;_pn(v,t);if(t.dataset.k!='inst')return;const r=SI&&loc(SI);if(!r)return;const i=r.i,tl=toolOf(i)||(i.cls=='Tool'?i:null),pa=tg&&(loc(tg)||{}).i;
 if(PRT.test(i.cls)&&tl){const ps=parts(tl);if(!ps.some(x=>x!==i&&x.n=='Handle')){i.n='Handle';i.sx=.6;i.sy=3;i.sz=.6;i.c='#8b5a2b'}else{i.oy=(ps.length-1)*1.1;i.c=['#ff5a5a','#5ab0ff','#ffd24d','#6edc7a'][ps.length%4]}}
 if((i.cls=='WeldConstraint'||i.cls=='Motor6D')&&tl){const ps=parts(tl);i.w0=pa&&PRT.test(pa.cls)?pa.id:(ps[0]&&ps[0].id)||'';const o=ps.find(x=>x.id!=i.w0);i.w1=o?o.id:''}
 eRender();pRender()};
const _ip=iProps;iProps=function(i){if(!NEWC[i.cls])return _ip(i);const tl=toolOf(i),
 v3=(l,ks)=>`<label>${l}</label><div class="g3">${ks.map(k=>`<input type="number" step=".1" data-q="${k}" value="${+i[k]||0}">`).join('')}</div>`,
 sel=(k,l)=>`<label>${l}</label><select data-q="${k}"><option value="">(kosong)</option>${(tl?parts(tl):[]).map(p=>`<option value="${p.id}" ${i[k]==p.id?'selected':''}>${esc(p.n)}</option>`).join('')}</select>`;
 let h=`<h4>${CL[i.cls]} ${i.cls}</h4><label>Nama</label><input type="text" data-q="n" value="${esc(i.n)}" maxlength="24">`;
 if(i.cls=='Tool')h+=v3('Grip offset (X, Y, Z)',['gx','gy','gz'])+`<label>Grip pitch (derajat, 90 = tegak)</label><input type="number" data-q="gp" value="${+i.gp}">`+v3('Posisi di dunia saat di Workspace (bisa dipungut)',['px','py','pz'])+'<div class="hint">Ketuk ＋ di Tool ini di Explorer untuk memasukkan Part, Weld, Motor6D, Script.</div>';
 if(PRT.test(i.cls))h+=v3('Posisi (X, Y, Z)',['ox','oy','oz'])+v3('Rotasi (derajat)',['rx','ry','rz'])+v3('Ukuran (X, Y, Z)',['sx','sy','sz'])+`<label>Warna</label><input type="color" data-q="c" value="${i.c||'#b0b0b0'}">`;
 if(i.cls=='WeldConstraint')h+=sel('w0','Part0')+sel('w1','Part1');
 if(i.cls=='Motor6D')h+=sel('w0','Part0')+sel('w1','Part1')+v3('C0 posisi',['a0','a1','a2'])+v3('C0 rotasi',['a3','a4','a5'])+v3('C1 posisi',['b0','b1','b2'])+v3('C1 rotasi',['b3','b4','b5'])+`<label>Sumbu putar</label><select data-q="ax">${['x','y','z'].map(a=>`<option ${i.ax==a?'selected':''}>${a}</option>`).join('')}</select><label>Kecepatan putar (derajat/detik)</label><input type="number" data-q="spd" value="${+i.spd||0}">`;
 return h+`<div style="display:flex;gap:6px;margin-top:8px"><button class="btn sm c" data-a="idup">⧉ Duplikat</button><button class="btn sm o" data-a="idel" data-v="${i.id}">Hapus</button></div>`};
/* ---- bangun model Tool (dipakai Studio & game) ---- */
function tbuild(tool){const root=new THREE.Group(),out=new THREE.Group(),map={},ps=parts(tool),mot=[];out.add(root);
 ps.forEach(p=>{const g=new THREE.Group();g.position.set(+p.ox||0,+p.oy||0,+p.oz||0);g.rotation.set(E(p.rx||0),E(p.ry||0),E(p.rz||0));
  const geo=p.cls=='Cylinder'?new THREE.CylinderGeometry(.5,.5,1,18):p.cls=='Ball'?new THREE.SphereGeometry(.5,14,10):new THREE.BoxGeometry(1,1,1),m=new THREE.Mesh(geo,mat(p.c||'#b0b0b0'));
  m.scale.set(+p.sx||1,+p.sy||1,+p.sz||1);if(p.cls!='Ball')m.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo),EL));g.add(m);root.add(g);map[p.id]=g});
 const h=ps.find(p=>p.n=='Handle')||ps[0];if(h)root.position.set(-(+h.ox||0),-(+h.oy||0),-(+h.oz||0));
 const cs=[],w=a=>a.forEach(c=>{if(c.cls=='WeldConstraint'||c.cls=='Motor6D')cs.push(c);w(c.ch)});w(tool.ch);
 cs.forEach(c=>{const a=map[c.w0],b=map[c.w1];if(!a||!b||a===b)return;for(let q=a;q;q=q.parent)if(q===b)return;
  if(c.cls=='WeldConstraint'){out.updateMatrixWorld(true);a.attach(b);return}
  const pv=new THREE.Group(),sp=new THREE.Group();pv.position.set(+c.a0||0,+c.a1||0,+c.a2||0);pv.rotation.set(E(c.a3||0),E(c.a4||0),E(c.a5||0));a.add(pv);pv.add(sp);
  const m1=new THREE.Matrix4().compose(new THREE.Vector3(+c.b0||0,+c.b1||0,+c.b2||0),new THREE.Quaternion().setFromEuler(new THREE.Euler(E(c.b3||0),E(c.b4||0),E(c.b5||0))),new THREE.Vector3(1,1,1)).invert();
  m1.decompose(b.position,b.quaternion,b.scale);sp.add(b);mot.push({s:sp,ax:c.ax||'y',spd:+c.spd||0})});
 return{g:out,mot}}
const tspin=(mot,dt)=>mot.forEach(m=>{m.s.rotation[m.ax]+=E(m.spd)*dt});
/* ---- pratinjau di viewport Studio ---- */
let TVG=null;function tvBuild(){try{if(TVG&&TVG.parent)TVG.parent.remove(TVG);TVG=null;if(!SS||!ST||ST.kind!='g'||!ST.d.svc)return;const g=new THREE.Group(),ws=ST.d.svc.Workspace||[],r=SI&&loc(SI),sel=r&&(r.i.cls=='Tool'?r.i:toolOf(r.i));
 ws.filter(x=>x.cls=='Tool').forEach(t=>{const b=tbuild(t);b.g.position.set(+t.px||0,+t.py||0,+t.pz||0);g.add(b.g)});
 if(sel&&!ws.includes(sel)){const b=tbuild(sel);b.g.position.set(0,3,0);g.add(b.g)}SS.add(g);TVG=g}catch(e){}}
const _er=eRender;eRender=function(){_er();tvBuild()};
const _sb=sBuild;sBuild=function(){_sb();tvBuild()};
/* ---- impor proyek: pertahankan properti Tool ---- */
const NK=['ox','oy','oz','rx','ry','rz','sx','sy','sz','gx','gy','gz','gp','px','py','pz','spd'].concat([0,1,2,3,4,5].map(n=>'a'+n),[0,1,2,3,4,5].map(n=>'b'+n));
const _cs=cleanSvc;cleanSvc=function(s){const o=_cs(s);try{const idm={},w=(a,b)=>{if(!Array.isArray(a)||!Array.isArray(b)||a.length!=b.length)return;a.forEach((x,j)=>{const y=b[j];if(!x||!y)return;idm[x.id]=y.id;if(NEWC[y.cls]){NK.forEach(k=>{if(x[k]!=null&&isFinite(+x[k]))y[k]=Math.max(-1e3,Math.min(1e3,+x[k]))});if(/^#[0-9a-f]{6}$/i.test(x.c))y.c=x.c;if(['x','y','z'].includes(x.ax))y.ax=x.ax;y.w0=x.w0;y.w1=x.w1}w(x.ch,y.ch)})};
 SKEYS.forEach(k=>w(s&&s[k],o[k]));const f=a=>a.forEach(y=>{if(NEWC[y.cls]){y.w0=idm[y.w0]||'';y.w1=idm[y.w1]||''}f(y.ch)});SKEYS.forEach(k=>f(o[k]))}catch(e){}return o};
/* ---- Luau: Tool.Activated / Equipped / Unequipped ---- */
const _iw=iW;iW=function(i){if(i.cls!='Tool')return _iw(i);if(RT.iw.has(i.id))return RT.iw.get(i.id);const w=new FW(i.n,()=>i.ch.map(iW),{Activated:new Sig(),Equipped:new Sig(),Unequipped:new Sig()});w.i=i;RT.iw.set(i.id,w);return w};
const _tx=tbxRender;tbxRender=function(){_tx();const e=$('#tbx');if(!e)return;const h=e.innerHTML,k=h.indexOf('<h4>Template');if(k<0)return;let t='';if(ST&&ST.kind=='g'){const T=window.SPX.TBL;t='<h4>Toolbox</h4>'+Object.keys(T).map(c=>`<div class="hint" style="margin:6px 0 2px">${c}</div>`+T[c].map(x=>`<button class="btn sm w" data-a="rb" data-v="tb:${c}:${esc(x.n)}">${x.ic||''} ${esc(x.n)}</button>`).join('')).join('')}e.innerHTML=h.slice(0,k)+t};
if(ST)tbxRender();
/* ---- game: hotbar, backpack, pegang Tool ---- */
G.insertAdjacentHTML('beforeend','<div id="hotbar"></div><div id="bpk"><div style="display:flex;justify-content:space-between;font:700 20px Arial"><span>Backpack</span><span data-a="bpx" style="cursor:pointer">✕</span></div><div class="gr"></div></div><button id="toolact" data-a="toolact">⚡</button><div id="fps"></div>');
window.__tbuild=tbuild;let TL=[],EQ=-1,held=null,hmot=[],SW0=-9e9,PK=[];const HB=$('#hotbar'),BP=$('#bpk');
function hbDraw(){const s=(t,n)=>`<div class="hb ${n==EQ?'eq':''}" data-a="tsel" data-v="${n}"><i>${n+1}</i>${esc(t.i.n)}</div>`;HB.innerHTML=TL.map(s).join('')+(TL.length?'<div class="hb" data-a="bpt">🎒</div>':'');HB.classList.toggle('on',TL.length>0);BP.querySelector('.gr').innerHTML=TL.map(s).join('')}
function unequip(){if(EQ>=0&&TL[EQ])try{TL[EQ].w.x.Unequipped.fire()}catch(e){}if(held&&held.parent)held.parent.remove(held);held=null;hmot=[];EQ=-1;window.__heldTool=null;window.__heldMesh=null;try{lastSent=''}catch(e){}$('#toolact').style.display='none'}
function equip(n){const same=EQ==n;unequip();if(!same&&TL[n]&&plr){const t=TL[n].i,b=tbuild(t);b.g.rotation.x=E(isFinite(+t.gp)?+t.gp:90);b.g.position.set(+t.gx||0,-.95+(+t.gy||0),+t.gz||0);plr.a[1].add(b.g);held=b.g;hmot=b.mot;EQ=n;window.__heldTool=String(t.id);window.__heldMesh=b.g;try{lastSent=''}catch(e){}$('#toolact').style.display=t.ch.some(c=>/Script$/.test(c.cls))?'grid':'none';try{TL[n].w.x.Equipped.fire()}catch(e){}}hbDraw()}
Object.assign(act,{tsel(v){equip(+v)},bpt(){BP.classList.toggle('on')},bpx(){BP.classList.remove('on')},toolact(){if(EQ<0)return;SW0=performance.now();try{TL[EQ].w.x.Activated.fire()}catch(e){}}});
const hasH=i=>parts(i).length>0;const _tsg=startGame;startGame=function(g,t){_tsg(g,t);unequip();TL=[];PK.forEach(p=>p.m.parent&&p.m.parent.remove(p.m));PK=[];BP.classList.remove('on');
 try{const sv=g.svc||{},add=i=>{if(i.cls!='Tool')return;if(!hasH(i))return;if(TL.some(x=>x.i.id===i.id))return;const w=iW(i);TL.push({i,w});i.ch.forEach(c=>{if(/Script$/.test(c.cls))runScript(c,w)})};
  (sv.StarterPack||[]).forEach(i=>{add(i);if(i.cls=='Folder')i.ch.forEach(add)});
  (sv.Workspace||[]).filter(i=>i.cls=='Tool').forEach(i=>{const b=tbuild(i);b.g.position.set(+i.px||0,+i.py||0,+i.pz||0);scene.add(b.g);PK.push({i,m:b.g,mot:b.mot})})}catch(e){OUT('err',e.message)}hbDraw()};
const _tst=stopGame;stopGame=function(){unequip();TL=[];PK=[];hbDraw();BP.classList.remove('on');_tst()};
let fc=0,ft=performance.now();const _trt=rtTick;rtTick=function(){_trt();if(!plr||!P)return;const now=performance.now(),dt=.016;
 if(held){const s=(now-SW0)/320;window.__armPose=-1.45+(s<1?-Math.sin(s*Math.PI)*.9:0);plr.a[1].rotation.x=window.__armPose;tspin(hmot,dt)}else window.__armPose=null;
 for(let k=PK.length-1;k>=0;k--){const p=PK[k];p.m.rotation.y+=.02;tspin(p.mot,dt);if(Math.hypot(P.x-p.m.position.x,P.z-p.m.position.z)<2.2&&Math.abs(P.y+1-p.m.position.y)<4){scene.remove(p.m);PK.splice(k,1);if(TL.some(x=>x.i.id===p.i.id)){toast('Sudah punya: '+p.i.n);continue}const w=iW(p.i);TL.push({i:p.i,w});p.i.ch.forEach(c=>{if(/Script$/.test(c.cls))runScript(c,w)});hbDraw();toast('Dipungut: '+p.i.n)}}
 fc++;if(now-ft>500){const e=$('#fps');if(e.style.display=='block')e.textContent=Math.round(fc*1000/(now-ft))+' FPS';fc=0;ft=now}};
window.addEventListener('keydown',e=>{if(!run||(document.activeElement&&document.activeElement.tagName=='INPUT'))return;if(/^[1-9]$/.test(e.key)&&TL[+e.key-1])equip(+e.key-1)});
/* ---- UI ala Roblox: tombol mic, menu pause, roda emote, papan peringkat ---- */
const mb=$('#topl .rpill button:last-child');if(mb){mb.dataset.a='mic';mb.innerHTML='<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/><path d="M4 4l16 16" stroke="#ff4040"/></svg><i id="camb" style="display:none"></i>'}
act.mic=()=>toast('Chat suara tidak tersedia');
G.insertAdjacentHTML('beforeend','<div id="pm"><div class="pmb"><div class="pmt"></div><div class="pmc"></div></div></div><div id="lbp"><div class="pmb"><div style="display:flex;justify-content:space-between;padding:14px 18px;font:700 20px Arial"><span data-a="lbx" style="cursor:pointer">✕</span><span>Papan Peringkat</span><span></span></div><div class="pmc"></div></div></div><div id="ew"><div id="ewc"><div id="ewm">Pilih Emote</div></div></div>');
const PM=$('#pm'),TABS=[['user','Pengguna'],['set','Pengaturan'],['gal','Galeri'],['rep','Laporkan'],['help','Bantuan']];let pmt='user',rpt='Pemain',rpOpen=0;
const row=(l,k,v)=>`<div class="pr"><span>${l}</span><div class="pa"><b data-a="pmset" data-v="${k}:-1">‹</b><span>${v}</span><b data-a="pmset" data-v="${k}:1">›</b></div></div>`,QL={'.6':'Rendah','1':'Sedang','2':'Tinggi'},SHL={normal:'Normal',bright:'Cerah',cine:'Sinematik',retro:'Retro',bw:'Hitam Putih'};
function pmDraw(){PM.querySelector('.pmt').innerHTML=TABS.map(t=>`<b class="${t[0]==pmt?'on':''}" data-a="pmtab" data-v="${t[0]}">${t[1]}</b>`).join('');const c=PM.querySelector('.pmc'),g=gf();let h='';
 if(pmt=='user'){const names=[me.name].concat(Object.values(remote).map(o=>o.name));h=`<div class="pbr"><button class="pbtn" data-a="leave">Keluar</button><button class="pbtn" data-a="respawn">Respawn</button><button class="pbtn bl" data-a="resume">Lanjutkan</button></div><div class="pbr"><button class="pbtn" data-a="pminv">Undang Teman</button><button class="pbtn" data-a="chl">${S.nochat?'Tampilkan':'Bunyikan'} Chat</button></div><div class="ph">Di server ini</div><div style="display:flex;gap:10px;flex-wrap:wrap">${names.map(n=>`<div style="background:#2a2c31;border-radius:8px;padding:10px;text-align:center;min-width:90px;font-size:12px">${n==me.name?circ(me.av,56):'<div style="height:56px;font-size:34px">🙂</div>'}<br>${esc(n)}</div>`).join('')}</div>`}
 if(pmt=='set')h=`<div class="ph">Tampilan &amp; Grafik</div>${row('Layar Penuh','fs',document.fullscreenElement?'Nyala':'Mati')}${row('Statistik Performa','fps',$('#fps').style.display=='block'?'Nyala':'Mati')}${row('Kualitas Grafik','q',QL[g.q]||'Tinggi')}${row('Shader','sh',SHL[g.sh]||'Normal')}${row('Kabut','fog',g.fog=='0'?'Mati':'Nyala')}<div class="ph">Tampilan &amp; Kendali</div>${row('Sensitivitas Kamera','sens',S.sens)}${row('Mode Kamera','cam',camMode=='first'?'Orang pertama':'Orang ketiga')}<div class="ph">Chat</div>${row('Log Chat','chl',S.nochat?'Sembunyi':'Tampil')}`;
 if(pmt=='gal')h='<div class="pbr"><button class="pbtn" data-a="pmshot">📷 Ambil Tangkapan Layar</button></div>';
 if(pmt=='rep')h=rpOpen?`<label>Jenis</label><select id="rp_t"><option ${rpt=='Pemain'?'selected':''}>Pemain</option><option ${rpt=='Map'?'selected':''}>Map</option><option>Bug</option></select><label>Nama pemain / map</label><input type="text" id="rp_g" maxlength="30"><label>Alasan</label><input type="text" id="rp_x" maxlength="120"><button class="pbtn bl" style="width:100%" data-a="rsend">Kirim Laporan</button>`:`<div class="ph">Apa yang ingin kamu laporkan?</div>${[['Chat suara','Pemain'],['Chat teks','Pemain'],['Seseorang sedang bermain','Pemain'],['Game atau pengalaman virtual','Map']].map(r=>`<div class="pr" style="cursor:pointer;font-size:16px" data-a="rpk" data-v="${r[1]}"><span>${r[0]}</span><span>›</span></div>`).join('')}`;
 if(pmt=='help')h='<b>Kontrol</b><br>WASD / joystick: gerak · Spasi / tombol panah: lompat<br>C: ganti kamera · Enter: chat · Esc: menu · 1-9: pilih Tool<br><br>Map: '+esc(curG?curG.name:'-');c.innerHTML=h}
act.pause=function(){paused=true;pmt='user';rpOpen=0;PM.classList.add('on');pmDraw()};
const _rs=act.resume;act.resume=function(){_rs();PM.classList.remove('on')};
Object.assign(act,{pmtab(v){pmt=v;rpOpen=0;pmDraw()},rpk(v){rpt=v;rpOpen=1;pmDraw()},pminv(){const u=location.href;try{navigator.clipboard.writeText(u);toast('Tautan disalin')}catch(e){toast(u)}},pmshot(){act.gma('media')},
 pmset(v){const[k,d]=v.split(':'),n=+d,g=gf(),sv=()=>{S.gfx=g;save();gfxApply()},cyc=(a,x)=>a[(a.indexOf(x)+n+a.length)%a.length];
  if(k=='fs'){try{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}catch(e){}setTimeout(pmDraw,250);return}
  if(k=='fps'){const e=$('#fps');e.style.display=e.style.display=='block'?'none':'block'}
  if(k=='q'){g.q=cyc(['.6','1','2'],g.q);sv()}if(k=='sh'){g.sh=cyc(Object.keys(SHL),g.sh);sv()}if(k=='fog'){g.fog=g.fog=='0'?'1':'0';sv()}
  if(k=='sens'){S.sens=Math.max(1,Math.min(10,(+S.sens||5)+n));save()}if(k=='cam')act.cam();if(k=='chl')act.chl();pmDraw()}});
const _chl=act.chl;act.chl=function(){_chl();if(PM.classList.contains('on'))pmDraw()};
const _mt=act.mt;act.mt=function(v){if(v=='rep'){pmt='rep';rpOpen=0;pmDraw()}else if(v=='play'){act.resume();const names=[[me.name,got]].concat(Object.values(remote).map(o=>[o.name,'-']));$('#lbp .pmc').innerHTML=`<div class="pr" style="color:#fff9"><span>Pengguna</span></div>${names.map(n=>`<div class="pr"><span>${esc(n[0])}</span></div>`).join('')}`;$('#lbp').classList.add('on')}else _mt(v)};
act.lbx=()=>$('#lbp').classList.remove('on');
const EW=$('#ew'),EMS=[['Lambai','wave'],['Dansa','dance'],['Loncat','jump']];
$('#ewc').insertAdjacentHTML('beforeend',[0,1,2,3,4,5,6,7].map(k=>{const a=E(-90+k*45),e=EMS[k];return`<div class="sl ${e?'e':''}" style="left:${50+39*Math.cos(a)}%;top:${50+39*Math.sin(a)}%" ${e?`data-a="ewp" data-v="${e[1]}"`:''}>${e?e[0]:k+1}</div>`}).join(''));
EW.addEventListener('pointerdown',e=>{if(e.target===EW)EW.classList.remove('on')});PM.addEventListener('pointerdown',e=>{if(e.target===PM)act.resume()});act.ewp=v=>{EW.classList.remove('on');act.gma(v)};
const _gm=act.gma;act.gma=function(v,t){if(v=='emote'){act.gmn();EW.classList.add('on');return}_gm(v,t)};
const _sg2=startGame;startGame=function(g,t){_sg2(g,t);PM.classList.remove('on');EW.classList.remove('on');$('#lbp').classList.remove('on')};
})();
