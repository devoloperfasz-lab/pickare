/* ===== v12: animasi terlihat di Avatar model + bagikan map ke teman ===== */
(function(){
const NOW=()=>performance.now();
const EMD={wave:2.5,dance:3.5,jump:1.2};
/* --- pemetaan anggota badan (nama + tebakan posisi) --- */
function limbName(n){n=String(n||'').toLowerCase().replace(/[_\s\-.]/g,'');if(!n)return null;const L=/(left|kiri)/.test(n),Rt=/(right|kanan)/.test(n);
 if(/(arm|lengan|hand|tangan|shoulder|bahu)/.test(n)){if(L)return'aL';if(Rt)return'aR'}
 if(/(leg|kaki|foot|shoe|sepatu|thigh|paha)/.test(n)){if(L)return'lL';if(Rt)return'lR'}return null}
function limbGuess(x,y){const ax=Math.abs(x);if(ax>=.55&&y>=.8&&y<=2.4)return x<0?'aL':'aR';if(y<1&&ax>=.05&&ax<=.6)return x<0?'lL':'lR';return null}
window.__limbName=limbName;
window.__limbPick=function(nm,ob,A,L,named){const k=named?limbName(nm):limbGuess(+(ob&&ob.x)||0,+(ob&&ob.y)||0);
 return k==='aL'?A[0]:k==='aR'?A[1]:k==='lL'?L[0]:k==='lR'?L[1]:null};
/* --- pose animasi (dipasang SEBELUM render, dikembalikan sesudahnya) --- */
function snap(g){return{y:g.position.y,ry:g.rotation.y,rz:g.rotation.z,l:g.l.map(x=>[x.rotation.x,x.rotation.z]),a:g.a.map(x=>[x.rotation.x,x.rotation.z])}}
function back(g,s){g.position.y=s.y;g.rotation.y=s.ry;g.rotation.z=s.rz;g.l.forEach((x,i)=>{x.rotation.x=s.l[i][0];x.rotation.z=s.l[i][1]});g.a.forEach((x,i)=>{x.rotation.x=s.a[i][0];x.rotation.z=s.a[i][1]})}
function pose(g,k,t){
 if(k==='wave'){g.a[1].rotation.x=-2.9+Math.sin(t*10)*.2;g.a[1].rotation.z=-.25+Math.sin(t*10)*.45;g.rotation.z=Math.sin(t*9)*.05}
 else if(k==='dance'){const s=Math.sin(t*8)*.9;g.rotation.y+=t*7;g.position.y+=Math.abs(Math.sin(t*8))*.35;g.a[0].rotation.x=-2.6+s*.3;g.a[1].rotation.x=-2.6-s*.3;g.l[0].rotation.x=s;g.l[1].rotation.x=-s}
 else if(k==='jump'){const u=Math.min(1,t/EMD.jump);g.position.y+=Math.sin(u*Math.PI)*1.3;g.a[0].rotation.x=g.a[1].rotation.x=-2.7;g.l[0].rotation.x=.4;g.l[1].rotation.x=-.4}}
let myE=null;
function moving(){try{if(Math.hypot(joy.x,joy.y)>.2)return true;return !!(keys.w||keys.a||keys.s||keys.d||keys.arrowup||keys.arrowdown||keys.arrowleft||keys.arrowright)}catch(e){return false}}
function hookPresence(){try{if(RM&&!RM.__emw){const f=RM.presence;RM.presence=function(o){if(o&&o.n!=null){if(myE)o.em=myE.k+':'+myE.id;if(window.__heldTool)o.tl=String(window.__heldTool).slice(0,24);try{const u=+me.uid;if(u>0)o.u=u}catch(e){}try{const fx=window.__ownFx&&window.__ownFx();if(fx&&fx.length)o.fx=fx}catch(e){}}return f.apply(this,arguments)};RM.__emw=1}}catch(e){}}
function startEmo(k){myE={k,t0:NOW(),id:Math.random().toString(36).slice(2,6)};try{lastSent=''}catch(e){}}
const _gm=act.gma;
act.gma=function(v,t){if(EMD[v]&&!moving())startEmo(v);return _gm.apply(this,arguments)};
function pre(){
 if(typeof scene==='undefined'||typeof plr==='undefined'||!plr||!plr.l||!plr.a)return null;
 const undo=[];hookPresence();
 const t=NOW();
 if(myE){const e=(t-myE.t0)/1000;if(e>EMD[myE.k]||moving()||(typeof RT!=='undefined'&&RT&&RT.dead)){myE=null;try{lastSent=''}catch(x){}}}
 try{const s=snap(plr);undo.push(()=>back(plr,s));
  if(myE)pose(plr,myE.k,(t-myE.t0)/1000);
  else if(typeof window.__armPose==='number')plr.a[1].rotation.x=window.__armPose}catch(e){}
 try{for(const k in remote){const o=remote[k],g=o.g;if(!g||!g.l||!g.a)continue;
  if(o.emo){const e=(t-o.emo.t0)/1000;if(e>EMD[o.emo.k])o.emo=null}
  if(o.emo||o.hg){const s=snap(g);undo.push(()=>back(g,s));if(o.hg)g.a[1].rotation.x=-1.45;if(o.emo)pose(g,o.emo.k,(t-o.emo.t0)/1000)}}}catch(e){}
 return()=>undo.forEach(f=>{try{f()}catch(e){}})}
function wrapR(){try{if(typeof R==='undefined'||!R||R.__w)return;const _r=R.render.bind(R);
 R.render=function(s,c){let post=null;if(s===scene){try{post=pre()}catch(e){}}const r=_r(s,c);if(post)try{post()}catch(e){}return r};R.__w=1}catch(e){}}
wrapR();
const _sg12=startGame;startGame=function(){const r=_sg12.apply(this,arguments);wrapR();return r};
/* --- emote pemain lain --- */
const _sp=syncPeers;
syncPeers=function(peers){_sp.apply(this,arguments);
 try{(peers||[]).forEach(p=>{const q=p&&p.presence;if(!q||p.isMe)return;const o=remote[p.peer];if(!o)return;const em=typeof q.em==='string'?q.em.slice(0,12):'';
  if(o.emS===undefined){o.emS=em;return}
  if(em!==o.emS){o.emS=em;const k=em.split(':')[0];if(em&&EMD[k])o.emo={k,t0:NOW()}}})}catch(e){}};

/* ===== Bagikan map ke teman ===== */
const esc2=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MAXB=240000;
function b64(u8){let s='';for(let i=0;i<u8.length;i+=8192)s+=String.fromCharCode.apply(null,u8.subarray(i,i+8192));return btoa(s)}
function unb64(s){const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
async function enc(o){const j=JSON.stringify(o);
 if(window.CompressionStream){try{const st=new Blob([j]).stream().pipeThrough(new CompressionStream('gzip'));return'z1:'+b64(new Uint8Array(await new Response(st).arrayBuffer()))}catch(e){}}
 return'j1:'+b64(new TextEncoder().encode(j))}
async function dec(s){s=String(s||'');if(s.length>MAXB*1.5)throw 0;const k=s.slice(0,3),u=unb64(s.slice(3));
 if(k==='z1:'){const st=new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'));const buf=await new Response(st).arrayBuffer();if(buf.byteLength>3e6)throw 0;return JSON.parse(new TextDecoder().decode(buf))}
 if(k==='j1:'){if(u.length>3e6)throw 0;return JSON.parse(new TextDecoder().decode(u))}
 throw 0}
const hx6=(c,f)=>/^#[0-9a-f]{6}$/i.test(c||'')?c:f;
function shClean(g,from,ts){if(!g||typeof g!=='object'||!Array.isArray(g.objs))return null;
 const d=JSON.parse(JSON.stringify(g));['thumb','icon','by','mb','mine','rp','sh','apiKey'].forEach(k=>delete d[k]);
 d.id='sh'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);d.name=String(d.name||'Map').slice(0,22);d.emoji=String(d.emoji||'').slice(0,4);d.desc=String(d.desc||'').slice(0,140);
 d.col=hx6(d.col,'#b6f25a');d.sky=hx6(d.sky,'#7df9ff');if(d.objs.length>4000)d.objs.length=4000;
 d.pub=false;d.mine=1;d.sh={f:String(from).slice(0,20),t:+ts||Date.now()};return d}
function friends(){try{return FRD(me).f.filter(n=>{try{return typeof isBot==='function'?!isBot(n):true}catch(e){return true}})}catch(e){return[]}}
let SM=null;
function ensureM(){if(SM)return SM;SM=document.createElement('div');SM.id='shm';SM.innerHTML='<div class="bx"><div class="hd"></div><div class="sb2"></div><div class="ls"></div><div class="ft"><button data-x="1">Tutup</button></div></div>';document.body.appendChild(SM);
 SM.addEventListener('click',e=>{if(e.target===SM||e.target.dataset.x)SM.classList.remove('on')});return SM}
function openShare(id){
 const g=(me.games||[]).find(x=>x.id==id);if(!g)return toast('Map tidak ditemukan');
 const m=ensureM(),fl=friends();m.querySelector('.hd').textContent='Bagikan "'+String(g.name||'Map').slice(0,22)+'"';
 m.querySelector('.sb2').textContent='Teman akan menerima salinan map sebagai draft (maks. ~30 detik).';
 const ls=m.querySelector('.ls');
 ls.innerHTML=fl.length?fl.map(n=>'<div class="fr"><b>'+esc2(n)+'</b><button data-n="'+esc2(n)+'">Kirim</button></div>').join(''):'<div class="em">Belum ada teman. Tambah teman dulu lewat menu Teman.</div>';
 ls.onclick=async e=>{const b=e.target.closest('button[data-n]');if(!b||b.disabled)return;b.disabled=true;b.textContent='...';
  try{const pk={n:g.name,g:g},z=await enc(pk);if(z.length>MAXB){b.textContent='Kirim';b.disabled=false;return toast('Map terlalu besar untuk dibagikan. Pakai Ekspor.')}
   const ev={id:Math.random().toString(36).slice(2,10),to:b.dataset.n,from:me.name,t:'share',x:z,av:me.av,ts:Date.now()};
   if(!window.spInboxPut)throw new Error('layanan kirim belum siap');
   const ok=await window.spInboxPut(ev);if(!ok)throw new Error('koneksi ke server pesan gagal, coba lagi');
   b.textContent='Terkirim ✓';toast('Map dikirim ke '+b.dataset.n)}
  catch(x){b.textContent='Kirim';b.disabled=false;toast('Gagal mengirim: '+String((x&&x.message)||x||'error').slice(0,80))}};
 m.classList.add('on')}
act.shshare=function(v){try{if(typeof me==='undefined'||!me)return;try{act.shx&&act.shx()}catch(e){}openShare(v)}catch(e){toast('Gagal membuka menu bagikan: '+String((e&&e.message)||e).slice(0,80))}};
/* terima */
const _oe=window.__spOnEv;
window.__spOnEv=function(p){
 if(p&&p.t==='share'&&typeof me!=='undefined'&&me&&p.to===me.name&&p.from){
  me.shd=me.shd||[];if(me.shd.includes(p.id))return;me.shd.push(p.id);if(me.shd.length>100)me.shd.shift();
  const from=String(p.from).slice(0,20);
  if(!FRD(me).f.includes(from)){return}
  if((me.games||[]).filter(g=>g.sh).length>=30){return}
  dec(p.x).then(pk=>{const d=shClean(pk&&pk.g,from,p.ts);if(!d)return;me.games.push(d);save();
   try{pushNote(me,from+' membagikan map "'+d.name+'"')}catch(e){}try{toast(from+' membagikan map "'+d.name+'"')}catch(e){}try{refreshUI()}catch(e){}try{navRender()}catch(e){}}).catch(()=>{});
  return}
 return _oe?_oe.apply(this,arguments):undefined};
/* Beranda */
const _hh=homeH;
homeH=function(){let h=_hh.apply(this,arguments);try{const L=(me.games||[]).filter(g=>g.sh);if(L.length)h+='<h3 class="sec">Dibagikan teman</h3><div class="hs">'+L.map(gcard).join('')+'</div>'}catch(e){}return h};
/* Studio: menu Bagikan */
let curEd=null;
const _eo=edOpen;edOpen=function(d,k){curEd=k=='g'?d:null;const r=_eo.apply(this,arguments);setTimeout(addMenu,50);return r};
function addMenu(){try{const rm=document.getElementById('rmenu');if(!rm||document.getElementById('shmn'))return;
 const d=document.createElement('div');d.className='mn';d.id='shmn';d.innerHTML='<b>Bagikan</b>';
 d.addEventListener('click',()=>{if(curEd&&(me.games||[]).includes(curEd))openShare(curEd.id);else toast('Hanya map yang bisa dibagikan')});rm.appendChild(d)}catch(e){}}
setTimeout(addMenu,1500);
})();
