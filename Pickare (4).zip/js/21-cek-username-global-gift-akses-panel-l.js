/* ===== CEK USERNAME GLOBAL + GIFT AKSES PANEL LINTAS PERANGKAT =====
   Owner menandatangani gift dengan kunci ECDSA di perangkatnya; perangkat lain memverifikasi dengan public key owner (disematkan saat pertama dilihat). */
(function(){
const USR='pickare/v9/usr/',OWN='pickare/v9/own/',BR=['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081'];
const hs=t=>{let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36)};
const lw=n=>hs(String(n).toLowerCase());
const mq=()=>window.__spMq,EC={name:'ECDSA',namedCurve:'P-256'},SG={name:'ECDSA',hash:'SHA-256'};
const b64=u=>{let s='';u.forEach(c=>s+=String.fromCharCode(c));return btoa(s)};
const unb=t=>Uint8Array.from(atob(t),c=>c.charCodeAt(0));
const te=s=>new TextEncoder().encode(s);
const msgOf=(n,r,t,k)=>String(n).toLowerCase()+'|'+r+'|'+t+'|'+(k?hs(JSON.stringify(k)):'');
const STUDIO=document.title==='Pickare Studio';
function sub(url,topics,ms,onMsg){return new Promise(res=>{let m,done=0;const end=()=>{if(done)return;done=1;try{m.end(true)}catch(e){}res()};
 try{m=mqtt.connect(url,{clientId:'spo_'+Math.random().toString(16).slice(2,12),connectTimeout:6000,reconnectPeriod:0,clean:true})}catch(e){return res()}
 m.on('error',end);m.on('close',end);m.on('connect',()=>{m.subscribe(topics,{qos:0});setTimeout(end,ms)});
 m.on('message',(t,b)=>{try{const s=b.toString();if(s&&onMsg(t,JSON.parse(s))===1)end()}catch(e){}});setTimeout(end,ms+4000)})}
async function ready(){return !!(mq()&&(window.mqtt||await mq().lib()))}
/* --- cek username --- */
async function checkName(n){if(!(await ready()))return null;let taken=0;
 await Promise.all(BR.map(u=>sub(u,[USR+lw(n)],2500,(t,d)=>{if(d&&String(d.n||'').toLowerCase()===n.toLowerCase()){taken=1;return 1}})));return taken}
/* v11: cari username di semua perangkat -> nama asli, null = tidak ada, false = tidak ada koneksi */
async function lookupName(n){if(!(await ready()))return false;let real=null;
 await Promise.all(BR.map(u=>sub(u,[USR+lw(n)],2500,(t,d)=>{if(d&&String(d.n||'').toLowerCase()===String(n).toLowerCase()){real=String(d.n).replace(/[\u0000-\u001f<>"&]/g,'').slice(0,20);return 1}})));
 return real&&!/^(owner|admin|coowner|co-owner)$/i.test(real)?real:null}
window.spLookupName=lookupName;
/* --- kunci owner --- */
async function ownerKey(){let k=ls.get('sp_okey',null);if(k&&k.priv&&k.pub)return k;
 const p=await crypto.subtle.generateKey(EC,true,['sign','verify']);k={priv:await crypto.subtle.exportKey('jwk',p.privateKey),pub:await crypto.subtle.exportKey('jwk',p.publicKey)};ls.set('sp_okey',k);ls.set('sp_ownpk',k.pub);return k}
async function pubPk(){if(!me||me.role!=='owner'||!mq())return;const k=await ownerKey(),sg=hs(JSON.stringify(k.pub)),S=ls.get('sp_pksig',{});if(S.s===sg&&Date.now()-S.t<216e5)return;
 if(await mq().pushAll([{t:OWN+'pk',p:JSON.stringify({pub:k.pub,ts:Date.now()})}]))ls.set('sp_pksig',{s:sg,t:Date.now()})}
async function grant(n,role){try{if(!(await ready())||me.role!=='owner')return;const k=await ownerKey(),ts=Date.now(),key=await crypto.subtle.importKey('jwk',k.priv,EC,false,['sign']);let UK=null;
 if(role!=='none')await Promise.all(BR.map(u=>sub(u,[OWN+'uk/'+lw(n)],2500,(t,d)=>{if(d&&d.pub&&(!UK||d.ts>UK.ts))UK=d})));const pk=UK?UK.pub:null;
 {const P=ls.get('sp_gpend',{})||{},kk=String(n).toLowerCase();if(role!=='none'&&!pk)P[kk]={n,role};else delete P[kk];ls.set('sp_gpend',P)}
 if(role!=='none'&&!pk&&!grant._auto)toast(n+' belum membuka versi terbaru; panel jalan di HP-nya, tapi aksi lintas HP butuh gift ulang setelah dia login');
 const sig=b64(new Uint8Array(await crypto.subtle.sign(SG,key,te(msgOf(n,role,ts,pk)))));
 const ok=await mq().pushAll([{t:OWN+'pk',p:JSON.stringify({pub:k.pub,ts})},{t:OWN+'g/'+lw(n),p:JSON.stringify({n,role,ts,pk,sig})}]);
 if(!grant._auto)toast(ok?'Akses '+n+' dikirim ke semua perangkat ✓':'Gagal mengirim akses ke server, coba lagi')}catch(e){if(!grant._auto)toast('Gagal menandatangani akses')}}
/* --- terima gift --- */
async function restoreRole(){try{if(!me||me.role||!me.grec||!me.grec.sig)return;const pin=ls.get('sp_ownpk',null);if(!pin)return;const G=me.grec;
 if(String(G.n||'').toLowerCase()!==me.name.toLowerCase()||!['admin','coowner'].includes(G.role))return;
 const key=await crypto.subtle.importKey('jwk',pin,EC,false,['verify']);if(!(await crypto.subtle.verify(SG,key,unb(G.sig),te(msgOf(G.n,G.role,G.ts,G.pk)))))return;
 me.role=G.role;save();try{rolePill();if(!document.getElementById('n_panel')&&document.getElementById('nav'))document.getElementById('nav').insertAdjacentHTML('beforeend','<button data-a="go" data-v="panel" id="n_panel"><span></span>Panel</button>');render()}catch(e){}}catch(e){}}
async function pullGrant(){if(!me||me.role==='owner')return;await restoreRole();if(!me||!(await ready()))return;let PK=null,G=null;
 await Promise.all(BR.map(u=>sub(u,[OWN+'pk',OWN+'g/'+lw(me.name)],3000,(t,d)=>{if(t===OWN+'pk'){if(d&&d.pub&&(!PK||d.ts>PK.ts))PK=d}else if(d&&d.sig&&(!G||d.ts>G.ts))G=d})));
 let pin=ls.get('sp_ownpk',null);if(!pin&&PK){pin=PK.pub;ls.set('sp_ownpk',pin)}if(!pin||!G)return;
 const _g0=me.gts||0,_fresh=G.ts>_g0,_stale=G.ts===_g0&&(G.role==='none'?!!(me.role&&me.role!=='owner'):me.role!==G.role);
 if(String(G.n||'').toLowerCase()!==me.name.toLowerCase()||!(_fresh||_stale)||!['admin','coowner','none'].includes(G.role))return;
 try{const key=await crypto.subtle.importKey('jwk',pin,EC,false,['verify']);if(!(await crypto.subtle.verify(SG,key,unb(G.sig),te(msgOf(G.n,G.role,G.ts,G.pk)))))return}catch(e){return}
 const _old=me.role;me.gts=G.ts;me.grec=G.role==='none'?null:G;if(G.role==='none'){if(me.role&&me.role!=='owner'){delete me.role;toast('Akses panel dicabut')}}else{me.role=G.role;if(_old!==G.role){toast('Kamu mendapat akses '+G.role.toUpperCase()+' ');(me.notes=me.notes||[]).unshift({t:'Kamu mendapat akses '+G.role.toUpperCase()+'. Buka menu → Panel.',new:1})}}
 save();try{rolePill();if(me.role&&!document.getElementById('n_panel')&&document.getElementById('nav'))document.getElementById('nav').insertAdjacentHTML('beforeend','<button data-a="go" data-v="panel" id="n_panel"><span></span>Panel</button>');render()}catch(e){}}
window.spPullGrant=pullGrant;window.spOwnerPub=()=>JSON.stringify((ls.get('sp_okey',{})||{}).pub||null);
window.addEventListener('load',()=>{
 /* username global saat daftar */
 const _a=act.auth;let okN=null;
 act.auth=function(){if(mode!=='reg')return _a.apply(this,arguments);const u=($('#u').value||'').trim();
  if(!u||u.includes('@')||okN===u.toLowerCase()){okN=null;return _a.apply(this,arguments)}
  const e=$('#err');e.textContent='Memeriksa username...';
  checkName(u).then(r=>{if(r===1){e.textContent='Username sudah dipakai oleh akun di perangkat lain';const c=$('#acard');if(c){c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')}}else{okN=u.toLowerCase();e.textContent='';act.auth()}});return};
 /* gift akses panel dari owner -> kirim ke perangkat target */
 const _g=act.grole;act.grole=function(){const i=$('#pt_u'),n=i?String(i.value||'').trim():'',b=n&&users[n]?users[n].role||'none':'none';const r=_g.apply(this,arguments);
  try{if(me&&me.role==='owner'&&n&&users[n]){const a=users[n].role||'none';if(a!==b)grant(n,a)}}catch(e){}return r};
 const _en=enter;enter=function(){const r=_en.apply(this,arguments);setTimeout(()=>{pubPk();pullGrant()},1200);return r};
 setInterval(()=>{if(typeof me!=='undefined'&&me&&!document.hidden){pubPk();pullGrant()}},30000);
 setTimeout(()=>{if(typeof me!=='undefined'&&me&&me.role!=='owner')pullGrant()},5000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&typeof me!=='undefined'&&me)pullGrant()});
 /* owner: kirim ulang gift akses yang belum punya kunci penerima */
 setInterval(async()=>{try{if(typeof me==='undefined'||!me||me.role!=='owner'||document.hidden)return;const P=ls.get('sp_gpend',{})||{};grant._auto=1;for(const k in P)await grant(P[k].n,P[k].role)}catch(e){}finally{grant._auto=0}},45000);
 /* tombol Panel untuk website Studio (tanpa nav bawah) */
 if(STUDIO)setInterval(()=>{let b=document.getElementById('spPnl');if(typeof me==='undefined'||!me||!staff()){if(b)b.remove();return}
  const a=document.getElementById('app');if(!a||!a.classList.contains('on')){if(b)b.style.display='none';return}
  if(!b){b=document.createElement('button');b.id='spPnl';b.className='btn sm v';b.style.cssText='position:fixed;right:10px;bottom:10px;z-index:9000';b.onclick=()=>act.go(page==='panel'?'create':'panel');document.body.appendChild(b)}
  b.style.display='';b.textContent=page==='panel'?'← Studio':' Panel'},1500)});
})();
