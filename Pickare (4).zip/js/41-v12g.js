/* ===== v12g: pratinjau efek (Kustomisasi/Marketplace/Profil) + Profil avatar 3D ===== */
(function(){
const FXC=['Fire','Smoke','Sparkles','ParticleEmitter','Explosion','PointLight'];
const DEF={Fire:{r:28,l:.9,s:3,z:.7,a:14,g:-4,k:'#ff7300',gr:-.6,add:1},Smoke:{r:10,l:2.6,s:2,z:.8,a:20,g:-1,k:'#737373',gr:1.4,add:0},Sparkles:{r:24,l:.8,s:2.2,z:.18,a:180,g:0,k:'#ffe64d',gr:-.5,add:1},ParticleEmitter:{r:20,l:1.5,s:5,z:.3,a:35,g:0,k:'#ffffff',gr:0,add:1},Explosion:{r:0,l:.8,s:18,z:.5,a:180,g:12,k:'#ff8019',gr:-.4,add:1},PointLight:{}};
const nv=(v,d,a,b)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):d};
/* deskriptor efek dari item (anak Part/Folder/Script) */
function fxOf(it){const out=[];const w=(l,q)=>(l||[]).forEach(n=>{if(!n)return;if(FXC.indexOf(n.cls)>=0&&out.length<6)out.push({q:q,c:n.cls,e:n.Enabled===false?0:1,r:n.Rate,l:n.Lifetime,s:n.Speed,z:n.Size,a:n.SpreadAngle,g:n.Acceleration,k:n.Color,b:n.BlastRadius||n.Brightness||0,n:n.Range||0});if(n.ch)w(n.ch,q)});
 if(it){w(it.ch);(it.objs||[]).forEach(o=>o&&w(o.ch,[o.x,o.y,o.z,(+o.sx+ +o.sy+ +o.sz)/3].map(v=>Math.round((+v||0)*100)/100)))}return out}
window.__fxOf=fxOf;
const qk=d=>Array.isArray(d.q)&&d.q.length===4?Math.max(.05,Math.min(20,+d.q[3]||1)):1;
/* pratinjau 3D */
window.__pvFxInit=function(rec,S,G,a,extra){
 let ds=[];try{ds=ds.concat(Array.isArray(a&&a.pvfx)?a.pvfx:[]);const its=(typeof me!=='undefined'&&me&&me.items)||[];((a&&a.acc)||[]).forEach(id=>{const it=its.find(x=>x.id==id);if(it)ds=ds.concat(fxOf(it))})}catch(e){}
 ds=ds.filter(d=>d&&DEF[d.c]).slice(0,6);if(!ds.length)return;
 const geo=new THREE.BoxGeometry(1,1,1),ps=[],em=ds.map(d=>({d,acc:0,t:0,fired:false}));let last=performance.now();
 const emit=(d,n)=>{const F=DEF[d.c],sp=nv(d.a,F.a,0,180)*Math.PI/180;
  for(let i=0;i<n&&ps.length<260;i++){const ang=Math.random()*6.283,t=Math.acos(1-Math.random()*(1-Math.cos(sp))),sx=Math.sin(t)*Math.cos(ang),sy=Math.cos(t),sz=Math.sin(t)*Math.sin(ang);
   const mt=new THREE.MeshBasicMaterial({color:/^#[0-9a-f]{6}$/i.test(d.k||'')?d.k:F.k,transparent:true,opacity:1,depthWrite:false});if(F.add)mt.blending=THREE.AdditiveBlending;if(d.c==='Sparkles')mt.color.setHSL(Math.random(),1,.65);
   const m=new THREE.Mesh(geo,mt),K=qk(d),z0=nv(d.z,F.z,.02,4)*(.6+Math.random()*.8)*K,v=nv(d.s,F.s,0,30)*(.5+Math.random()*.7)*(Array.isArray(d.q)?(.4+.6*K):1);
   if(Array.isArray(d.q)&&d.q.length===4){G.updateWorldMatrix(true,false);const c=G.localToWorld(new THREE.Vector3(+d.q[0]||0,+d.q[1]||0,+d.q[2]||0));m.position.set(c.x+(Math.random()-.5)*K,c.y+(Math.random()-.5)*K,c.z+(Math.random()-.5)*K)}
   else m.position.set((Math.random()-.5)*.6,1.5+(Math.random()-.5)*.3,(Math.random()-.5)*.6);m.scale.setScalar(z0);m.rotation.set(Math.random()*6,Math.random()*6,0);S.add(m);
   ps.push({m,mt,vx:sx*v,vy:sy*v,vz:sz*v,g:nv(d.g,F.g,-30,30),life:nv(d.l,F.l,.05,6)*(.7+Math.random()*.6),age:0,z0,gr:F.gr})}};
 rec.pv=function(){const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
  em.forEach(e=>{const d=e.d;e.t+=dt;
   if(d.c==='PointLight'){if(!e.l){e.l=new THREE.PointLight(/^#[0-9a-f]{6}$/i.test(d.k||'')?d.k:'#ffffff',nv(d.b,1,0,5),nv(d.n,16,1,40));e.l.position.set(0,1.8,3);S.add(e.l)}return}
   if(d.c==='Explosion'){if(!e.fired||e.t>2.6){e.fired=true;e.t=0;emit(d,60)}return}
   if(d.e===0)return;e.acc+=nv(d.r,DEF[d.c].r,0,60)*dt*(Array.isArray(d.q)?(.5+.8*qk(d)):1);const n=Math.floor(e.acc);if(n>0){e.acc-=n;emit(d,n)}});
  for(let i=ps.length-1;i>=0;i--){const q=ps[i];q.age+=dt;const u=q.age/q.life;if(u>=1){S.remove(q.m);q.mt.dispose();ps.splice(i,1);continue}
   q.vy-=q.g*dt;q.m.position.x+=q.vx*dt;q.m.position.y+=q.vy*dt;q.m.position.z+=q.vz*dt;q.m.scale.setScalar(Math.max(.01,q.z0*(1+q.gr*u)));q.mt.opacity=1-u*u;q.m.rotation.z+=dt*2}}};
/* beli: salin efek jadi isi aksesoris milik pembeli */
function fromDesc(d){const n=newI(d.c);const M={r:'Rate',l:'Lifetime',s:'Speed',z:'Size',a:'SpreadAngle',g:'Acceleration'};for(const k in M)if(d[k]!==undefined&&n[M[k]]!==undefined)n[M[k]]=+d[k];
 if(/^#[0-9a-f]{6}$/i.test(d.k||''))n.Color=d.k;if(d.c==='Explosion')n.BlastRadius=+d.b||6;if(d.c==='PointLight'){n.Brightness=+d.b||1;n.Range=+d.n||16}if(d.e===0&&n.Enabled!==undefined)n.Enabled=false;if(Array.isArray(d.q)&&d.q.length===4)n.pq=d.q.map(v=>+v||0);return n}
const _b3=act.buy2;act.buy2=function(k){const r=_b3.apply(this,arguments);
 try{const it=mkItems().find(x=>x.key===k),n=(me.items||[]).find(x=>x.src===k);if(it&&it.fx&&it.fx.length&&n&&!(n.ch&&n.ch.length)){n.ch=it.fx.map(fromDesc);save()}}catch(e){}return r};
/* Profil: avatar 3D mengikuti yang dipakai, bisa diputar */
function avOf(n){try{if(n===me.name)return{av:me.av,items:me.items||[]};const u=users[n];const pi=typeof pinfo==='function'?pinfo(n):null;const av=(pi&&pi.av)||(u&&u.av);return av?{av,items:(u&&u.items)||[]}:null}catch(e){return null}}
function sgOf(o){try{return JSON.stringify(o.av)+'|'+o.items.map(i=>i.id+':'+(i.objs||[]).length+':'+(i.ch||[]).length).join(',')}catch(e){return''}}
function mount(el){const n=el.dataset.n,o=avOf(n);if(!o||!window.THREE)return;el.dataset.sg=sgOf(o);
 setTimeout(()=>{if(!el.isConnected)return;const sv=me.items;try{me.items=o.items;(window.av3||function(){})(el,Object.assign({},o.av,{acc:(o.av.acc||[]).slice()}),[])}finally{me.items=sv}},30)}
const _ov12=ovRender;
ovRender=function(){const old=document.getElementById('pst3');const keep=old&&old.querySelector('canvas')?old:null;const r=_ov12.apply(this,arguments);
 try{const nw=document.getElementById('pst3');if(nw){const o=avOf(nw.dataset.n);if(keep&&o&&keep.dataset.n===nw.dataset.n&&keep.dataset.sg===sgOf(o))nw.replaceWith(keep);else mount(nw)}}catch(e){}return r};
})();
