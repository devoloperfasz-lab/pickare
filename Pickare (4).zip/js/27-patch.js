(function(){
const G=$('#game');
const ic=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
const I={
 menu:ic('<path d="M4 7h16M4 12h16M4 17h16"/>'),close:ic('<path d="M6 6l12 12M18 6L6 18"/>'),
 logo:'<svg viewBox="0 0 24 24" fill="#fff"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 8.5l3.5 2v3L12 15.5l-3.5-2v-3z" fill="#1b1d22"/></svg>',
 chat:ic('<path d="M4 5h16v11H10l-4 3v-3H4z" stroke="#fff" fill="none" stroke-width="1.8" stroke-linejoin="round"/><path d="M8 9h8M8 12h5" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>'),
 cam:ic('<rect x="3" y="7" width="18" height="13" rx="2" stroke="#fff" fill="none" stroke-width="1.8"/><circle cx="12" cy="13.5" r="3" stroke="#fff" fill="none" stroke-width="1.8"/><path d="M8 7l1.5-3h5L16 7" stroke="#fff" fill="none" stroke-width="1.8"/>'),
 friend:ic('<path d="M4 5h16v11H9l-4 3v-3H4z"/><path d="M8 9h8M8 12h5"/>'),shop:ic('<path d="M5 8h14l-1 12H6z"/><path d="M9 8a3 3 0 016 0"/>'),
 avatar:ic('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.5 18c1.5-3 9.5-3 11 0"/>'),
 music:ic('<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="16" r="2"/>'),
 media:ic('<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7l1.5-3h5L16 7"/><circle cx="12" cy="13.5" r="3"/>'),
 flag:ic('<path d="M5 21V4M5 5h13l-3 4 3 4H5"/>'),
 cup:ic('<path d="M8 4h8v6a4 4 0 01-8 0zM8 6H4v2a3 3 0 004 3M16 6h4v2a3 3 0 01-4 3M12 14v4M8 20h8"/>'),
 emote:ic('<circle cx="12" cy="12" r="9"/><path d="M8 14c2 3 6 3 8 0"/><circle cx="9" cy="10" r=".8"/><circle cx="15" cy="10" r=".8"/>'),
 bag:ic('<rect x="6" y="8" width="12" height="13" rx="3"/><path d="M9 8V6a3 3 0 016 0v2M9 14h6"/>'),
 resp:ic('<circle cx="9" cy="5" r="2"/><path d="M9 8v5l-3 4M9 13l3 4M14 17a4 4 0 106-3"/>'),
 up:'<svg viewBox="0 0 24 24"><path d="M12 3l9 10h-5v8H8v-8H3z"/></svg>'};
$('#topl').innerHTML=`<button class="rbx" data-a="pause" title="Menu">${I.logo}</button><div class="rpill"><button data-a="gmn" id="gmb">${I.menu}</button><button data-a="chat">${I.chat}</button><button data-a="cam">${I.cam}<i id="camb" style="display:none"></i></button></div>`;
$('#jump').innerHTML=I.up;
G.insertAdjacentHTML('beforeend','<div id="gmenu"></div><div id="stopb" data-a="stopt"><i></i>Stop</div>');
const M=$('#gmenu');
const LST=[['friend','Chat teman','friend'],['shop','Toko','shop'],['avatar','Beralih avatar','avatar'],['music','Musik','music'],['media','Media','media'],['flag','Laporkan','rep'],['cup','Papan Peringkat','lead'],['emote','Emote','emote'],['bag','Inventaris','inv'],['resp','Respawn','resp']];
const EMO=[['emote','Lambai','wave'],['emote','Dansa','dance'],['emote','Loncat','jump'],['friend','Kembali','back']];
function mdraw(l){M.innerHTML=l.map(x=>`<button data-a="gma" data-v="${x[2]}">${I[x[0]]}<span>${x[1]}</span></button>`).join('')}
function mopen(o){M.classList.toggle('on',o);$('#gmb').innerHTML=o?I.close:I.menu;$('#gmb').classList.toggle('on',o);if(o)mdraw(LST)}
let mus=null,emo=null;
function musik(){if(mus){clearInterval(mus.t);try{mus.c.close()}catch(e){}mus=null;toast('Musik mati');return}
 try{const c=new(window.AudioContext||window.webkitAudioContext)(),sc=[0,2,4,7,9,12,9,7,4,2],base=261.63;let i=0;
  const t=setInterval(()=>{const o=c.createOscillator(),g=c.createGain();o.type='triangle';o.frequency.value=base*Math.pow(2,sc[i++%sc.length]/12);g.gain.value=.05;g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.4);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.4)},420);mus={c,t};toast('Musik nyala')}catch(e){toast('Musik tidak didukung')}}
act.gmn=function(){mopen(!M.classList.contains('on'))};
act.gma=function(v){
 if(v=='emote'){mdraw(EMO);return}if(v=='back'){mdraw(LST);return}
 if(v=='wave'||v=='dance'||v=='jump'){emo={k:v,t0:performance.now()};if(v=='jump')act.jump&&0;mopen(false);return}
 mopen(false);
 if(v=='friend'){act.rct('fr');if(!document.querySelector('#rchat.op'))act.chat()}
 else if(v=='shop'||v=='avatar'){if(testing)return toast('Tidak tersedia saat Test');act.leave();setTimeout(()=>act.go('avatar'),60)}
 else if(v=='music')musik();
 else if(v=='media'){try{R.render(scene,cam3);const a=document.createElement('a');a.href=cv.toDataURL('image/png');a.download='pickare.png';a.click();toast('Tangkapan layar disimpan')}catch(e){toast('Gagal menyimpan gambar')}}
 else if(v=='rep'){act.pause();act.mt('rep')}
 else if(v=='lead'){act.pause();act.mt('play')}
 else if(v=='inv')toast('PickBux tidak bisa didapat di dalam game')
 else if(v=='resp')act.respawn()};
act.stopt=function(){if(testing)stopGame()};
document.addEventListener('click',e=>{if(!e.target.isConnected)return;if(M.classList.contains('on')&&!e.target.closest('#gmenu,#gmb'))mopen(false)});
const _rt=rtTick;rtTick=function(){_rt();if(!emo||!plr||(RT&&RT.dead))return;const t=(performance.now()-emo.t0)/1000;
 if(t>2.5||Math.hypot(joy.x,joy.y)>.2){emo=null;plr.rotation.z=0;return}
 if(emo.k=='wave')plr.rotation.z=Math.sin(t*9)*.22;else if(emo.k=='dance'){plr.rotation.y=t*7;plr.position.y+=Math.abs(Math.sin(t*8))*.35}else plr.position.y+=Math.abs(Math.sin(t*5))*1.1};
const _sg=startGame;startGame=function(g,t){_sg(g,t);mopen(false);emo=null;$('#stopb').style.display=t?'block':'none'};
const _sp=stopGame;stopGame=function(){mopen(false);$('#stopb').style.display='none';if(mus){clearInterval(mus.t);try{mus.c.close()}catch(e){}mus=null}_sp()};
})();
