/* ===== AUTH v3: username + email + password ===== */
(function(){
const card=$('#acard');
card.innerHTML=`<div class="logo">PICKARE</div><p id="sub" style="margin:-4px 0 12px;font-size:13px">Masuk untuk lanjut bermain</p>
<div class="tabs"><button class="btn act" data-a="tab" data-v="login">Masuk</button><button class="btn" data-a="tab" data-v="reg">Daftar</button></div>
<div id="fu" style="display:none"><label>Username</label><input type="text" id="u" maxlength="14" autocomplete="off" autocapitalize="off" placeholder="min. 3 karakter"></div>
<label>Email</label><input type="text" id="em" inputmode="email" autocomplete="off" autocapitalize="off" placeholder="nama@email.com">
<label>Password</label><div style="display:flex;gap:8px;align-items:flex-start"><input type="password" id="pw" autocomplete="off" placeholder="min. 4 karakter"><button class="btn" style="margin:6px 0 12px;padding:9px 12px;font-size:13px" data-a="eye">Lihat</button></div>
<div class="err" id="err"></div><button class="btn w g" id="go" data-a="auth">Masuk</button><div class="afoot">Dengan masuk, kamu setuju mengikuti aturan komunitas Pickare.<br>Akun yang melanggar aturan dapat diblokir.</div>`;
const isO=v=>{const h=sha(SALT+v.trim().toLowerCase());return h===OH||h===OU};
$('#em').addEventListener('input',e=>{e.target.type=isO(e.target.value)||e.target.value.toLowerCase().includes('owner')?'password':'text';$('#err').textContent=''});
$('#pw').addEventListener('keydown',e=>{if(e.key=='Enter')act.auth()});
mode='login';
Object.assign(act,{
 eye(){const p=$('#pw');p.type=p.type=='password'?'text':'password'},
 tab(v,t){mode=v;document.querySelectorAll('.tabs .btn').forEach(b=>b.classList.toggle('act',b===t));$('#go').textContent=v=='login'?'Masuk':'Buat Akun';$('#fu').style.display=v=='reg'?'':'none';$('#sub').textContent=v=='login'?'Masuk untuk lanjut bermain':'Buat akun baru, dapat 100 PickBux gratis!';$('#err').textContent=''},
 out(){ls.set('sp_sess','');me=null;['u','em','pw'].forEach(i=>$('#'+i).value='');$('#em').type='text';show('auth')},
 auth(){const u=$('#u').value.trim(),em=$('#em').value.trim().toLowerCase(),p=$('#pw').value,
  bad=m=>{$('#err').textContent=m;card.classList.remove('shake');void card.offsetWidth;card.classList.add('shake')},
  done=(k,o)=>{me=o;me.name=k;me.notes=me.notes||[];me.games=me.games||[];me.bux=me.bux||0;ls.set('sp_sess',k);$('#pw').value='';$('#em').value='';$('#em').type='text';enter()};
  if(!em)return bad('Isi email dulu');if(!p)return bad('Isi password dulu');
  if(mode=='reg'){
   if(u.length<3)return bad('Username min. 3 karakter');if(u.length>14)return bad('Username maks. 14 karakter');
   if(/^(owner|admin|coowner|co-owner|pickare)$/i.test(u)||users[u])return bad('Username sudah dipakai');
   if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em))return bad('Format email tidak valid');
   if(isO(em)||Object.values(users).some(x=>x.email===em))return bad('Email sudah terdaftar');
   if(p.length<4)return bad('Password min. 4 karakter');
   users[u]={pass:p,email:em,bux:100,daily:'',av:{skin:SKIN[0],shirt:SHIRT[0],pants:PANTS[0],hat:'none'},games:[],items:[],notes:[{t:'Selamat datang di Pickare! Hadiah awal 100 PickBux',new:1}]};save();return done(u,users[u])}
  if(isO(em)){if(p.length<6)return bad('Password min. 6 karakter');const ph=sha(SALT+'pw:'+p);if(ph!==OPH)return bad('Email atau password salah');let o=users.Owner;
   if(!o)o=users.Owner={pass:'',ph,bux:99999,daily:'',av:{skin:SKIN[0],shirt:SHIRT[1],pants:PANTS[1],hat:'crown'},games:[],items:[],notes:[{t:'Akun Owner aktif ',new:1}],role:'owner',verified:true};
   else o.ph=OPH;
   save();return done('Owner',o)}
  let k=Object.keys(users).find(x=>users[x].email===em);if(!k&&!em.includes('@')&&users[em])k=em;
  if(!k||users[k].role==='owner'||users[k].pass!==p)return bad('Email atau password salah');
  done(k,users[k])}});
if(me)show('app');
})();
