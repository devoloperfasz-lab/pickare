/* ===== TEMA PICKARE: header, drawer, nav, Beranda, Avatar, Chat ===== */
const IC={
 menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
 search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
 hex:'<path d="M12 2.8l7.8 4.5v9.4L12 21.2l-7.8-4.5V7.3z"/><path d="M12 8.2l3.4 2v3.6l-3.4 2-3.4-2v-3.6z"/>',
 bell:'<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 21h4"/>',
 bookmark:'<path d="M7 3.5h10v17l-5-4-5 4z"/>',
 history:'<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 4v4.5H8M12 7.5V12l3 2"/>',
 friends:'<circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.4 2.7-5.5 6-5.5s6 2.1 6 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.6 0 4.5 1.7 4.5 4.5"/>',
 comm:'<circle cx="12" cy="7" r="2.5"/><circle cx="6" cy="10" r="2"/><circle cx="18" cy="10" r="2"/><path d="M8 18c0-2.5 1.8-4 4-4s4 1.5 4 4M2.5 17c0-2 1.5-3.2 3.5-3.2M21.5 17c0-2-1.5-3.2-3.5-3.2"/>',
 pack:'<path d="M7 9a5 5 0 0 1 10 0v11H7z"/><path d="M9.5 5V3.5h5V5M7 14h10"/>',
 swap:'<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
 mail:'<rect x="3.5" y="5.5" width="17" height="13" rx="1.5"/><path d="M4 7l8 6 8-6"/>',
 plus:'<path d="M12 2.8l7.8 4.5v9.4L12 21.2l-7.8-4.5V7.3z"/><path d="M10 16v-7h3a2 2 0 0 1 0 4h-3"/>',
 gift:'<rect x="3.5" y="9" width="17" height="11" rx="1.5"/><path d="M3.5 13h17M12 9v11M12 9c-3-.5-4.5-1.5-4.5-3a2 2 0 0 1 4 0c0 1.5.5 2 .5 3zM12 9c3-.5 4.5-1.5 4.5-3a2 2 0 0 0-4 0"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
 shield:'<path d="M12 3l7 3v5.5c0 4.2-2.8 7.4-7 9.5-4.2-2.1-7-5.3-7-9.5V6z"/><rect x="9.5" y="10.5" width="5" height="4" rx=".8"/>',
 learn:'<circle cx="12" cy="8" r="3.5"/><path d="M6 20c0-3.5 2.7-5.5 6-5.5s6 2 6 5.5z"/>',
 create:'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>',
 home:'<path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/>',
 top:'<rect x="4" y="11" width="4" height="9" rx=".8"/><rect x="10" y="4" width="4" height="16" rx=".8"/><rect x="16" y="8" width="4" height="12" rx=".8"/>',
 chat:'<path d="M4 5h16v11H11l-4 4v-4H4z"/><path d="M8 9h8M8 12h5"/>',
 back:'<path d="M15 5l-7 7 7 7"/>',
 chev:'<path d="M9 5l7 7-7 7"/>',
 thumb:'<path d="M8 11v9H4v-9zM8 11l4-7c1.6 0 2.6 1.3 2.2 2.8L13.5 10H19a1.5 1.5 0 0 1 1.4 1.9l-1.8 6.6A2 2 0 0 1 16.7 20H8"/>',
 adduser:'<circle cx="10" cy="8" r="3.5"/><path d="M3.5 20c0-3.6 2.8-6 6.5-6"/><path d="M17 12v6M14 15h6"/>'
};
const ico=(k,s=24)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${IC[k]}</svg>`;
const hexc=(c,d)=>/^#[0-9a-f]{6}$/i.test(c||'')?c:d;
const okImg=u=>/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(u||'')?u:'';
/* foto profil: render 3D bagian atas avatar yang sedang dipakai (aksesori, baju, model tubuh ikut) */
let PFR=null;const PFC={};
function avItems(a){try{if(me&&a===me.av)return me.items||[];for(const k in users)if(users[k]&&users[k].av===a)return users[k].items||[]}catch(e){}return[]}
function avShot(a){if(!window.THREE||!a||typeof mkAvatar!=='function')return'';
 const items=avItems(a),ids=(a.acc||[]).slice();if(a.body&&!ids.includes(a.body))ids.push(a.body);
 let sg;try{sg=JSON.stringify([a.skin,a.shirt,a.pants,a.hat,a.body||0,a.hideBody||0,a.bodyObjs||0,ids.map(id=>{const i=items.find(x=>x.id==id);return i?[i.slot,i.objs]:0})])}catch(e){return''}
 if(PFC[sg]!==undefined)return PFC[sg];
 let url='';const sv=me.items;
 try{me.items=items;const N=320;
  if(!PFR){PFR=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});PFR.setPixelRatio(1)}
  PFR.setSize(N,N,false);PFR.setClearColor(0x000000,0);
  const S=new THREE.Scene(),C=new THREE.PerspectiveCamera(30,1,.1,60);S.add(new THREE.AmbientLight(0xffffff,.85));const L=new THREE.DirectionalLight(0xffffff,.6);L.position.set(4,8,7);S.add(L);
  const G=mkAvatar(a,a.acc||[]);G.rotation.y=-.4;S.add(G);C.position.set(0,2.15,6.2);C.lookAt(0,2.15,0);
  PFR.render(S,C);url=PFR.domElement.toDataURL('image/png');
  S.traverse(o=>{if(o.geometry)o.geometry.dispose()})
 }catch(e){url=''}finally{me.items=sv}
 if(Object.keys(PFC).length>120)for(const k in PFC)delete PFC[k];
 PFC[sg]=url;return url}
function circ(a,sz){a=a||{skin:SKIN[0],shirt:SHIRT[0],pants:PANTS[0],hat:'none'};const im=typeof avShot==='function'?avShot(a):'';return `<span class="circ" style="--s:${sz}px">${im?`<img src="${im}" alt="" draggable="false">`:avHTML(a,sz/10)}</span>`}
document.title='Pickare';
let mfil='all';

function buildChrome(){
 const lg=document.querySelector('#auth .logo');if(lg)lg.innerHTML='PICK<b>ARE</b>';
 $('#app header').innerHTML=`<button class="hb" data-a="drawer" aria-label="Menu">${ico('menu',30)}<i id="mdot"></i></button><div class="wm">PICK<b>ARE</b></div><span class="sp"></span><button class="hb" data-a="srch" aria-label="Cari">${ico('search',27)}</button><button class="hb" data-a="daily" aria-label="Bonus harian">${ico('hex',28)}</button><button class="hb" data-a="go" data-v="notif" aria-label="Notifikasi">${ico('bell',28)}<i id="bcnt" class="cnt"></i></button>`;
 if(!$('#sbar'))$('#app header').insertAdjacentHTML('afterend','<div id="sbar"><input type="text" id="qin" placeholder="Cari game..." autocomplete="off" maxlength="30"><div id="sres"></div></div>');
 $('#nav').innerHTML=[['home','home','Beranda'],['top','top','Teratas'],['avatar','','Avatar'],['msg','chat','Chat']].map(x=>`<button data-a="go" data-v="${x[0]}" id="n_${x[0]}">${x[1]?ico(x[1],28):'<span id="navav"></span>'}<em>${x[2]}</em></button>`).join('');
 if(!$('#drawer'))$('#app').insertAdjacentHTML('beforeend','<div id="drawer"><div id="dsc" data-a="dclose"></div><aside id="dpn"></aside></div>');
 const q=$('#qin');if(q&&!q.dataset.b){q.dataset.b=1;q.addEventListener('input',()=>srchGo(q.value))}
}
function friends(){const dflt=i=>({skin:SKIN[i%SKIN.length],shirt:SHIRT[(i+1)%SHIRT.length],pants:PANTS[1],hat:'none'});
 const real=Object.keys(users).filter(k=>k!==me.name&&!users[k].role).map(k=>({n:k,a:users[k].av||dflt(0)}));
 const fake=FR.filter(n=>!real.some(r=>r.n==n)).map((n,i)=>({n,a:dflt(i)}));
 const gs=pubGames();return real.concat(fake).slice(0,10).map((f,i)=>Object.assign(f,{g:(gs[i%gs.length]||{}).name||''}))}
const TH_C=new Map();
function thumbU(d){if(!d)return'';let v=TH_C.get(d);if(v!==undefined)return v;v='';
 try{const k=okImg(d);if(k){const m=/^data:(image\/[a-z0-9.+-]+);base64,(.*)$/i.exec(k);if(m){const b=atob(m[2]),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);v=URL.createObjectURL(new Blob([u],{type:m[1]}))}}}catch(e){v=''}
 if(TH_C.size>300){TH_C.forEach(x=>{try{x&&URL.revokeObjectURL(x)}catch(e){}});TH_C.clear()}TH_C.set(d,v);return v}
function gcard(g,i){const t=thumbU(g.thumb),c1=hexc(g.col,'#b6f25a'),c2=hexc(g.sky,'#7df9ff');
 const sub=g.by?`<span class="mini">${esc(String(g.by).charAt(0).toUpperCase())}</span>${esc(g.by)}`:`${ico('thumb',16)} ${g.lk>0?'Rating '+(+g.lk)+'%':'Baru'}`;
 return `<button class="gc" data-a="gopen" data-v="${esc(g.id)}" style="animation-delay:${Math.min(i,12)*40}ms"><span class="gt" style="background:${t?`url(${t}) center/cover`:`linear-gradient(135deg,${c1},${c2})`}">${t?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())}</span><strong>${esc(g.name)}</strong><small>${sub}</small></button>`}
function homeH(){const gs=pubGames(),rec=(me.recent||[]).map(id=>gs.find(g=>g.id==id)).filter(Boolean);
 return `<div class="who">${circ(me.av,46)}<span>${esc(me.name)}${vb(me)}</span></div>
 <div class="frs"><button class="fr add" data-a="soon" data-v="Tambah teman"><span class="circw"><span class="circ" style="--s:92px">${ico('adduser',40)}</span></span><em>Tambah Teman</em></button>${friends().map(f=>`<button class="fr" data-a="fr" data-v="${esc(f.n)}"><span class="circw">${circ(f.a,92)}<i class="on"></i></span><em>${esc(f.n)}</em><small>${esc(f.g)}</small></button>`).join('')}</div>
 <h3 class="sec">Direkomendasikan untukmu</h3><div class="gg">${gs.map(gcard).join('')}</div>
 <h3 class="sec" id="cont">${rec.length?'Lanjutkan':'Populer'} ${ico('chev',20)}</h3><div class="hs">${(rec.length?rec:gs).map(gcard).join('')}</div>
 <h3 class="sec">Mabar bareng teman</h3><div class="card row" style="flex-wrap:wrap"><div style="flex:1;min-width:150px"><label>Kode room</label><input type="text" id="rc" value="${esc(roomCode)}" maxlength="16" style="margin:6px 0 0" oninput="roomCode=this.value.toLowerCase().replace(/[^a-z0-9]/g,'')||'publik';save()"></div><button class="btn g" data-a="rnd">Acak</button></div>`}
function msgH(){return '<h2>Chat</h2>'+friends().map(f=>`<button class="crow" data-a="open" data-v="${esc(f.n)}">${circ(f.a,54)}<span><b>${esc(f.n)}</b><small>Online · ${esc(f.g)}</small></span></button>`).join('')}
function avP(){const own=it=>(me.items||[]).some(x=>x.src==it.key||'u_'+me.name+'_'+x.id==it.key);
 let h=`<div class="atop"><button class="rb" data-a="go" data-v="home" aria-label="Kembali">${ico('back',28)}</button><div class="seg"><button class="${avt=='mkt'?'on':''}" data-a="avt" data-v="mkt">Marketplace</button><button class="${avt!='mkt'?'on':''}" data-a="avt" data-v="cust">Kustomisasi</button></div><span class="bx">${ico('hex',20)} ${me.bux}</span></div><div class="stage">${avHTML(me.av,13)}</div><div class="sheet"><i class="grab"></i>`;
 if(avt=='mkt'){const all=mkItems(),f=all.filter(it=>mfil=='all'||(mfil=='off'?it.by=='Pickare':it.by!='Pickare'));
  h+=`<div class="ban">${ico('hex',20)}<span>Kamu punya <b>${me.bux}</b> PickBux. Item kreator muncul setelah dipublish.</span></div><div class="chips">${[['all','Semua'],['off','Resmi'],['cr','Kreator']].map(c=>`<button class="${mfil==c[0]?'on':''}" data-a="mf" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>`+
  (f.length?`<div class="ig">${f.map(it=>{const im=okImg(it.icon),o=own(it);return `<button class="it" data-a="buy" data-v="${esc(it.key)}"><span class="ith">${im?`<img src="${im}" alt="">`:esc(it.e||String(it.name||'?').charAt(0).toUpperCase())}</span><strong>${esc(it.name)}</strong><small>${esc(it.by)}${it.v?' ✔':''}</small><em>${o?'Dimiliki':ico('hex',15)+' '+(+it.price||0)}</em></button>`}).join('')}</div>`:'<div style="color:var(--mut);padding:20px 0;text-align:center">Belum ada item.</div>')}
 else{const sw=(k,arr)=>`<div class="sws">${arr.map(c=>`<span class="sw ${me.av[k]==c?'sel':''}" style="background:${c}" data-a="av" data-k="${k}" data-v="${c}"></span>`).join('')}</div>`;
  h+=`<div class="sl">Kulit</div>${sw('skin',SKIN)}<div class="sl">Baju</div>${sw('shirt',SHIRT)}<div class="sl">Celana</div>${sw('pants',PANTS)}<div class="sl">Topi</div>${[['none','Polos'],['cap','Topi'],['crown','Mahkota']].map(x=>`<button class="chip ${me.av.hat==x[0]?'on':''}" data-a="av" data-k="hat" data-v="${x[0]}">${x[1]}</button>`).join('')}<div class="sl">Aksesoris saya</div>`+((me.items||[]).length?(me.items||[]).map(i=>{const on=(me.av.acc||[]).includes(i.id);return `<button class="chip ${on?'on':''}" data-a="acc" data-v="${esc(i.id)}">${on?'✓ ':''}${esc(i.name)}</button>`}).join(''):'<div style="color:var(--mut);font-size:14px">Belum ada. Buat di Studio (menu ☰ → Buat) atau beli di Marketplace.</div>')}
 return h+'</div>'}
function drawerFill(){const nn=me.notes.filter(n=>n.new).length,rl=(RN[me.role]||'')+(me.verified?' ✔':'');
 const it=(ic,t,v,b)=>`<button class="mi" data-a="dnav" data-v="${v}">${ico(ic,27)}<span>${t}</span>${b?`<i class="bd">${b}</i>`:''}</button>`;
 $('#dpn').innerHTML=`<div class="pf">${circ(me.av,70)}<div><b>${esc(me.name)}${vb(me)}</b><small>@${esc(me.name.toLowerCase())}</small><span id="rolep">${esc(rl)}</span></div></div>
 <div class="cur"><div class="cr">${ico('hex',27)}<b id="buxp">${me.bux}</b><button class="pb" data-a="daily">Bonus Harian</button></div><button class="plus" data-a="soon" data-v="Pickare Plus">${ico('plus',27)}<span>Lebih seru, lebih hemat PickBux. Subscribe Pickare Plus.</span>${ico('chev',20)}</button></div>
 ${it('bookmark','Favorit','fav')}${it('history','Lanjutkan Bermain','cont')}${it('friends','Teman','ppl:fr',FRD(me).i.length||'')}${it('comm','Komunitas','soon:Komunitas')}${it('pack','Inventaris','avatar:cust')}${it('swap','Penukaran','avatar:mkt')}${it('mail','Pesan','msg')}${it('bell','Notifikasi','notif',nn?(nn>99?'99+':nn):'')}${it('plus','Pickare Plus','soon:Pickare Plus')}${it('gift','Beli Gift Card','soon:Gift Card')}${it('gear','Pengaturan','set')}${it('shield','Bantuan &amp; Keamanan','soon:Bantuan')}${staff()?it('shield','Panel '+esc(RN[me.role]||''),'panel'):''}
 <div class="dv"></div>${it('learn','Pelajari','soon:Pelajari')}${it('create','Buat','create')}
 <button class="dbtn" data-a="out">Beralih Akun</button><button class="dbtn" data-a="soon" data-v="Log In Cepat">Log In Cepat</button>`}
function srchGo(q){q=q.trim().toLowerCase();const r=$('#sres');if(!q){r.innerHTML='';return}
 const f=pubGames().filter(g=>g.name.toLowerCase().includes(q));
 r.innerHTML=f.length?f.map(g=>{const t=okImg(g.thumb);return `<button class="sr" data-a="gopen" data-v="${esc(g.id)}"><span class="gt" style="background:${t?`url(${t}) center/cover`:`linear-gradient(135deg,${hexc(g.col,'#b6f25a')},${hexc(g.sky,'#7df9ff')})`}">${t?'':esc(g.emoji||String(g.name||'?').charAt(0).toUpperCase())}</span><b>${esc(g.name)}</b>${ico('chev',20)}</button>`}).join(''):'<div style="color:var(--mut);padding:12px 0">Game tidak ditemukan.</div>'}

Object.assign(act,{
 drawer(){drawerFill();$('#drawer').classList.add('on')},
 dclose(){$('#drawer').classList.remove('on')},
 dnav(v){act.dclose();if(v.startsWith('soon:'))return toast(v.slice(5)+' segera hadir');
  if(v=='cont'){page='home';thread=null;render();const e=$('#cont');if(e)e.scrollIntoView({block:'start'});return}
  if(v.startsWith('avatar:')){avt=v.slice(7);v='avatar'}act.go(v)},
 soon(v){toast((v||'Fitur')+' segera hadir')},
 srch(){const b=$('#sbar');b.classList.toggle('on');if(b.classList.contains('on'))$('#qin').focus();else{$('#qin').value='';$('#sres').innerHTML=''}},
 fr(n){page='msg';thread=n;render()},
 mf(v){mfil=v;render()}});
document.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(t&&(t.dataset.a=='gopen'||t.dataset.a=='play')&&$('#sbar')){$('#sbar').classList.remove('on');$('#qin').value='';$('#sres').innerHTML=''}},true);

navRender=function(){if(!me)return;const app=$('#app');app.dataset.p=page;
 document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('act',b.dataset.v==page));
 const c=me.notes.filter(n=>n.new).length,bc=$('#bcnt'),md=$('#mdot');
 if(bc){bc.textContent=c>99?'99+':c;bc.style.display=c?'block':'none'}if(md)md.style.display=c?'block':'none';
 const bp=$('#buxp');if(bp)bp.textContent=me.bux;const na=$('#navav');if(na)na.innerHTML=circ(me.av,30)};
rolePill=function(){if(!me)return;const e=$('#rolep');if(e)e.textContent=(RN[me.role]||'')+(me.verified?' ✔':'')};
const _r5=render;
render=function(){const m=$('#main'),keep=(page=='avatar'&&m.dataset.pg=='avatar')?m.scrollTop:0;_r5();
 if(page=='home')m.innerHTML='<div class="page">'+homeH()+'</div>';
 if(page=='avatar'){m.innerHTML='<div class="page">'+avP()+'</div>';m.scrollTop=keep}
 if(page=='msg'&&!thread)m.innerHTML='<div class="page">'+msgH()+'</div>';
 m.dataset.pg=page;navRender()};
const _sg5=startGame;
startGame=function(g,test){if(!test&&me&&g&&g.id){me.recent=[g.id].concat((me.recent||[]).filter(x=>x!=g.id)).slice(0,10);save()}return _sg5.apply(this,arguments)};
const _en5=enter;
enter=function(){_en5();buildChrome();page='home';render()};
if(me&&$('#app').classList.contains('on')){buildChrome();render()}else buildChrome();
