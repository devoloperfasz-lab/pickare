/* ===== v10: map hanya baseplate kosong, slot aksesori, model Tubuh, part bulat ===== */
(function(){
const P=(n,t,x,y,z,sx,sy,sz,c)=>{const o=O(t,x,y,z,sx,sy,sz,c);o.n=n;return o};
const SKN='#ffd7b5';
const TPL={
 pakaian:{n:'Pakaian',e:'',slot:'Pakaian',f:()=>[P('Baju','part',0,1.4,0,1.14,1.06,.72,'#ff5a5a'),P('LenganKiri','part',-.75,1.62,0,.58,.6,.58,'#ff5a5a'),P('LenganKanan','part',.75,1.62,0,.58,.6,.58,'#ff5a5a')]},
 sepatu:{n:'Sepatu',e:'',slot:'Sepatu',f:()=>[P('SepatuKiri','part',-.25,.12,.05,.56,.26,.66,'#2b2b33'),P('SepatuKanan','part',.25,.12,.05,.56,.26,.66,'#2b2b33')]},
 bahu:{n:'Aksesoris Bahu',e:'',slot:'Bahu',f:()=>[P('BahuKiri','ball',-.78,1.95,0,.62,.4,.62,'#c9ccd6'),P('BahuKanan','ball',.78,1.95,0,.62,.4,.62,'#c9ccd6')]},
 kepala:{n:'Aksesoris Kepala',e:'',slot:'Kepala',f:()=>[P('TopiBrim','cyl',0,2.78,0,1.15,.1,1.15,'#3b82f6'),P('TopiAtas','cyl',0,2.95,0,.85,.3,.85,'#3b82f6')]},
 alat:{n:'Aksesoris Perlengkapan (pegang)',e:'',slot:'Alat',f:()=>[P('Gagang','cyl',.75,.85,.2,.14,.5,.14,'#6b4423'),P('Pelindung','part',.75,1.12,.2,.5,.1,.14,'#ffc400'),P('Bilah','part',.75,1.95,.2,.14,1.6,.06,'#d7dbe2')]},
 pinggang:{n:'Aksesoris Pinggang',e:'',slot:'Pinggang',f:()=>[P('Sabuk','part',0,.98,0,1.12,.2,.72,'#6b4423'),P('Gesper','part',0,.98,.37,.28,.22,.06,'#ffc400')]},
 belakang:{n:'Aksesoris Belakang',e:'',slot:'Belakang',f:()=>[P('Tas','part',0,1.4,-.5,.8,.95,.35,'#3b82f6'),P('Kantong','part',0,1.05,-.7,.5,.4,.12,'#2563eb')]},
 depan:{n:'Aksesoris Depan',e:'',slot:'Depan',f:()=>[P('Perisai','part',0,1.4,.45,.7,.7,.12,'#a855f7')]},
 tubuh:{n:'Model Tubuh',e:'',slot:'Tubuh',f:()=>[P('Head','ball',0,2.3,0,.9,.9,.9,SKN),P('Torso','part',0,1.4,0,1,1,.6,'#3b82f6'),P('LeftArm','cyl',-.75,1.4,0,.5,1,.5,SKN),P('RightArm','cyl',.75,1.4,0,.5,1,.5,SKN),P('LeftLeg','cyl',-.25,.45,0,.5,.9,.5,'#2b4acb'),P('RightLeg','cyl',.25,.45,0,.5,.9,.5,'#2b4acb'),P('MataKiri','part',-.17,2.35,.43,.12,.2,.05,'#000000'),P('MataKanan','part',.17,2.35,.43,.12,.2,.05,'#000000')]}};
TPL.avatar=Object.assign({},TPL.tubuh,{n:'Avatar (karakter lengkap)',slot:'Avatar'});
Object.keys(TPL).forEach(k=>AT[k]=TPL[k]);
['obby','menara','kota','arena'].forEach(k=>delete GT[k]);
const _na=act.newa;act.newa=function(k){_na.apply(this,arguments);if(ST&&ST.kind=='a'){ST.d.slot=AT[k]&&AT[k].slot||'Kepala';save();pRender()}};
AT.mahkota.slot='Kepala';AT.kerucut.slot='Kepala';AT.sayap.slot='Belakang';AT.kacamata.slot='Wajah';AT.jubah.slot='Belakang';

/* menu "Buat baru": map = baseplate kosong saja, aksesori dipilih per slot */
act.hnew=function(){
 const A=['avatar','pakaian','sepatu','kepala','bahu','alat','pinggang','belakang','depan','tubuh'];
 shOpen(`<div class="shn" style="margin-top:6px">Buat baru</div><div style="padding:0 4px 4px;opacity:.7">Map</div><button class="sb" data-a="hnewg" data-v="kosong">Baseplate Kosong</button><div style="padding:14px 4px 0;opacity:.7">Aksesori &amp; Tubuh</div>${A.map(k=>`<button class="sb" data-a="hnewa" data-v="${k}">${AT[k].n}</button>`).join('')}<button class="sb ln" data-a="shx">Tutup</button>`)};
const _tp=act.tpl;
act.tpl=function(v){_tp.apply(this,arguments);if(ST&&ST.kind=='a'&&AT[v]&&AT[v].slot){ST.d.slot=AT[v].slot;sBuild();eRender();pRender();touch()}};
const _pr=pRender;
pRender=function(){_pr();try{if(ST&&ST.kind=='a'&&!SI&&!cur()&&(ST.d.slot==='Tubuh'||ST.d.slot==='Avatar'))$('#props').insertAdjacentHTML('beforeend','<div style="font-size:11px;margin-top:8px;line-height:1.45">Model Tubuh menggantikan badan bawaan. Beri nama <b>LeftArm</b>, <b>RightArm</b>, <b>LeftLeg</b>, <b>RightLeg</b> agar anggota badan ikut bergerak. Bentuk bisa Part, Cylinder, atau Ball.</div>')}catch(e){}};

/* pakai model Tubuh */

/* avatar: model Tubuh menggantikan badan, Perlengkapan menempel di tangan kanan */
mkAvatar=function(a,accs){
 const G=new THREE.Group(),piv=(y,x)=>{const p=new THREE.Group();p.position.set(x,y,0);G.add(p);return p};
 const items=(typeof me!=='undefined'&&me&&me.items)||[];
 const ids=(accs||[]).slice();if(a.body&&!ids.includes(a.body))ids.push(a.body);
 const bItem=ids.map(id=>items.find(i=>i.id==id)).find(i=>i&&(i.slot==='Tubuh'||i.slot==='Avatar'));
 const bObjs=a.bodyObjs||(bItem&&bItem.objs)||null,hb=!!bObjs||!!a.hideBody;
 const lL=piv(.9,-.25),lR=piv(.9,.25),aL=piv(1.85,-.75),aR=piv(1.85,.75);let h;
 if(!hb){
  lL.add(part(.5,.9,.5,a.pants,0,-.45,0));lR.add(part(.5,.9,.5,a.pants,0,-.45,0));
  aL.add(part(.5,1,.5,a.skin,0,-.45,0));aR.add(part(.5,1,.5,a.skin,0,-.45,0));
  G.add(part(1,1,.6,a.shirt,0,1.4,0));h=part(.8,.8,.8,a.skin,0,2.3,0);G.add(h);
  h.add(part(.12,.2,.05,'#000000',-.17,.05,.41),part(.12,.2,.05,'#000000',.17,.05,.41))}
 else{h=new THREE.Group();h.position.set(0,2.3,0);G.add(h)}
 if(a.hat=='cap')h.add(part(.9,.2,.9,'#ff3b3b',0,.5,0));if(a.hat=='crown')h.add(part(.9,.3,.9,'#ffc400',0,.55,0));
 const named=!!bObjs&&bObjs.some(o=>o&&window.__limbName&&window.__limbName(o.n));
 if(bObjs)bObjs.forEach(o=>{if(!o||o.t==='coin')return;const m=mkObj(o),n=String(o.n||'').toLowerCase();let p=null;
  p=window.__limbPick?window.__limbPick(n,o,[aL,aR],[lL,lR],named):null;
  if(p){m.position.x-=p.position.x;m.position.y-=p.position.y;m.position.z-=p.position.z;p.add(m)}else G.add(m)});
 G.l=[lL,lR];G.a=[aL,aR];
 ids.forEach(id=>{const it=items.find(i=>i.id==id);if(!it||it===bItem||it.slot==='Tubuh'||it.slot==='Avatar')return;const hand=/^(Alat|Perlengkapan)$/.test(it.slot||'');
  (it.objs||[]).forEach(o=>{if(!o||o.t==='coin')return;const m=mkObj(o);if(hand){m.position.x-=aR.position.x;m.position.y-=aR.position.y;m.position.z-=aR.position.z;aR.add(m)}else G.add(m)})});
 return G};

/* seleksi bulat di Studio (tanpa kotak) */
selHelper=function(){
 if(helper){SS.remove(helper);helper=null}
 const m=meshes[SEL];
 if(m){const o=m.userData&&m.userData.o;
  if(o&&(o.t=='ball'||o.t=='cyl')){
   const g=new THREE.Group(),M=new THREE.LineBasicMaterial({color:0xff0066,depthTest:false,transparent:true});
   const ring=(rx,rz,yy)=>{const pts=[];for(let i=0;i<=48;i++){const t=i/48*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(t)*.5,0,Math.sin(t)*.5))}const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),M);l.rotation.set(rx||0,0,rz||0);l.position.y=yy||0;l.renderOrder=98;return l};
   if(o.t=='ball'){g.add(ring(0,0,0),ring(Math.PI/2,0,0),ring(0,Math.PI/2,0))}
   else{g.add(ring(0,0,.5),ring(0,0,-.5));[[.5,0],[-.5,0],[0,.5],[0,-.5]].forEach(p=>{const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(p[0],-.5,p[1]),new THREE.Vector3(p[0],.5,p[1])]),M);l.renderOrder=98;g.add(l)})}
   g.update=()=>{g.position.copy(m.position);g.rotation.copy(m.rotation);g.scale.copy(m.scale).multiplyScalar(1.01)};g.update();helper=g;SS.add(g)}
  else{helper=new THREE.BoxHelper(m,0xff0066);SS.add(helper)}}
 gzBuild()};
if(ST&&SS)selHelper();
})();
