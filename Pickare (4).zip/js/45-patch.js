(()=>{const nm=()=>{const i=document.getElementById('pt_u'),r=String(i&&i.value||'').trim().replace(/^@/,'').toLowerCase();return Object.keys(users).find(k=>k.toLowerCase()==r)||''},
lb=u=>RN[u&&u.role]||'User',
why=(role)=>{const k=nm();if(!k)return'';const u=users[k];if(u===me)return'';if(!staff())return 'akunmu ('+lb(me)+') bukan staf';
 if(!okT(u))return 'levelmu ('+lb(me)+') harus lebih tinggi dari '+k+' ('+lb(u)+')';
 if(role&&role!='none'&&lv({role})>=lv(me))return 'kamu ('+lb(me)+') hanya bisa memberi akses di bawah levelmu';return ''};
const gv=act.gver,gr=act.grole;
act.gver=function(){const w=why();if(w)return toast('Tidak diizinkan: '+w);return gv.apply(this,arguments)};
act.grole=function(){const r=document.getElementById('pt_r'),w=why(r&&r.value);if(w)return toast('Tidak diizinkan: '+w);return gr.apply(this,arguments)};
})();
