/* API Key Mabar di halaman Buat (Studio) */
window.addEventListener('load',()=>{
 const R1=window.render;if(typeof R1!=='function')return;
 const mk=()=>'rk_'+Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b=>b.toString(16).padStart(2,'0')).join('');
 const get=()=>{let k='';try{k=localStorage.getItem('sp_rkey')||''}catch(e){}return k},set=k=>{try{localStorage.setItem('sp_rkey',k)}catch(e){}};
 window.render=render=function(){R1.apply(this,arguments);try{if(page!=='create'||document.getElementById('rkS'))return;const pg=document.querySelector('#main .page');if(!pg)return;
  if(!get())set(mk());
  pg.insertAdjacentHTML('beforeend','<div class="card" id="rkS" style="margin-top:18px;background:var(--g)"><h3>API Key Mabar</h3><p style="margin:0 0 8px;font-size:13px">Key ini membuat room privat. Kirim <b>key</b> + <b>kode room</b> (di Home) ke temanmu, lalu mereka isi di Home &rarr; API Key Room. Beda HP, browser, akun, atau WiFi tetap bisa mabar.</p><input type="text" id="rkSi" value="'+esc(get())+'" maxlength="40" autocomplete="off"><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm" id="rkSn">Buat Key Baru</button><button class="btn sm c" id="rkSc">Salin</button><button class="btn sm p" id="rkSt">Tes Koneksi</button></div><div id="rkSs" style="margin-top:10px;font-size:13px"></div></div>');
  const i=document.getElementById('rkSi'),st=document.getElementById('rkSs');
  i.oninput=()=>set(i.value.replace(/\s/g,''));
  document.getElementById('rkSn').onclick=()=>{i.value=mk();set(i.value);toast('API key mabar baru dibuat')};
  document.getElementById('rkSc').onclick=()=>{i.select();try{document.execCommand('copy')}catch(e){}if(navigator.clipboard)navigator.clipboard.writeText(i.value).catch(()=>{});toast('API key disalin')};
  document.getElementById('rkSt').onclick=async()=>{st.textContent='Menghubungkan...';try{const rm=await claude.use('room'),a=await rm.join('tes-'+get());a.leave();st.textContent='\u2705 Terhubung ke server mabar. Key siap dipakai.'}catch(e){st.textContent='\u274c Gagal terhubung. Cek internet lalu coba lagi.'}}}catch(e){}}});
