/* ===== v13: foto profil semua pemain di menu (Keluar/Respawn/Lanjutkan) + bubble chat tepat di atas kepala ===== */
(function(){
const U=()=>window.spUI||{};
/* menu pengguna: ganti emoji 🙂 jadi foto profil + centang untuk tiap pemain */
function decPM(){try{document.querySelectorAll('#pm .pmc div[style*="min-width:90px"]:not([data-d])').forEach(c=>{c.dataset.d='1';
  const n=String(c.lastChild&&c.lastChild.textContent||'').trim();if(!n)return;
  const a=U().avFor&&U().avFor(n),f=c.firstElementChild;
  if(a&&f&&!f.classList.contains('circ'))f.outerHTML='<div style="height:56px;display:flex;justify-content:center">'+circ(a,56)+'</div>';
  if(U().vf&&U().vf(n))c.insertAdjacentHTML('beforeend','<span class="vb">✔</span>')})}catch(e){}}
function watchPM(){const c=document.querySelector('#pm .pmc');if(!c)return setTimeout(watchPM,1000);new MutationObserver(decPM).observe(c,{childList:true});decPM()}
watchPM();
/* kalau ada pemain masuk/keluar saat menu terbuka, gambar ulang daftarnya */
let pmKey='';
const _sp3=syncPeers;
syncPeers=function(){const r=_sp3.apply(this,arguments);
 try{const k=Object.values(remote).map(o=>o.name).sort().join('|'),pm=document.getElementById('pm'),t=pm&&pm.querySelector('.pmt b.on');
  if(k!==pmKey){pmKey=k;if(pm&&pm.classList.contains('on')&&t&&t.dataset.v==='user')act.pmtab('user')}}catch(e){}
 return r};

/* bubble chat: tepat di atas nametag (bukan jauh di atas), ukuran mengikuti isi pesan */
function fixBub(){try{const L=[];if(typeof plr!=='undefined'&&plr)L.push([plr,3.5]);for(const k in remote)L.push([remote[k].g,4.05]);
 L.forEach(([g,y])=>{const sp=g&&g.userData&&g.userData.bub;if(!sp||sp.userData.fx)return;sp.userData.fx=1;
  const m=sp.material.map,c=m.image,d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let last=0;
  for(let r=c.height-1;r>=0&&!last;r--)for(let q=0;q<c.width;q+=4)if(d[(r*c.width+q)*4+3]>10){last=r+1;break}
  const fr=Math.min(1,(last+4)/c.height);m.repeat.set(1,fr);m.offset.set(0,1-fr);sp.scale.set(4.2,1.3*fr,1);sp.center.set(.5,0);sp.position.y=y})}catch(e){}}
const _ac3=addChat;
addChat=function(){const r=_ac3.apply(this,arguments);setTimeout(fixBub,0);return r};
})();
