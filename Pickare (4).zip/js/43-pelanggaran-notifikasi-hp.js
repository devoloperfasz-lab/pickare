/* ===== PELANGGARAN + NOTIFIKASI HP ===== */
(()=>{const ID=i=>document.getElementById(i),rf=()=>{try{render()}catch(e){}},act_=u=>(u.viol||[]).filter(v=>!v.done),rd=()=>Math.random().toString(36).slice(2,9);
RV.viol=(u,id,reason,by)=>{u.viol=u.viol||[];id=String(id||rd()).slice(0,24);if(u.viol.some(v=>v.id==id))return;const n=act_(u).length+1,e={id,r:String(reason||'').slice(0,120),by:String(by||'staf').slice(0,20),t:Date.now(),n:Math.min(n,2),ack:0};u.viol.push(e);
 if(n>=2){e.ban=1;u.ban={perm:false,until:Date.now()+3*864e5,reason:'Pelanggaran 2/2: '+e.r,by:e.by,t:Date.now()}}
 (u.notes=u.notes||[]).unshift({t:'⚠️ Pelanggaran '+e.n+'/2: '+e.r,new:1});save();setTimeout(RV.vchk,300)};
RV.violx=u=>{const a=act_(u),l=a[a.length-1];if(!l)return;l.done=1;if(l.ban&&u.ban&&/^Pelanggaran 2\/2/.test(u.ban.reason))delete u.ban;save();rf()};
RV.vchk=()=>{if(typeof me==='undefined'||!me)return;const v=(me.viol||[]).find(x=>!x.ack&&!x.done);let o=ID('rvVio');if(!v){if(o)o.remove();return}
 if(v.ban&&!banOf(me)){me.viol.forEach(x=>x.done=1);save();if(o)o.remove();return}if(o&&o.dataset.id==v.id)return;if(o)o.remove();
 const d=document.createElement('div');d.id='rvVio';d.dataset.id=v.id;d.className='vov';
 const dt=new Date(v.t||Date.now()).toLocaleString('id-ID',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
 d.innerHTML=`<div class="vbx${v.ban?' vban':''}"><div class="vic">${v.ban?'⛔':'⚠️'}</div><div class="vkk">${v.ban?'Akun diblokir':'Peringatan resmi'}</div><h2>Pelanggaran ${v.n}/2</h2><div class="vpp"><i class="on"></i><i class="${v.n>=2?'on':''}"></i></div><div class="vrs"></div><div class="vby"></div><p class="vtx">${v.ban?'Ini pelanggaran ke-2, jadi akunmu <b>diblokir 3 hari</b>. Tekan tombol di bawah untuk keluar dari akun.':'Kamu hanya boleh melakukan <b>2 pelanggaran</b>. Pelanggaran ke-2 akan memblokir akunmu selama <b>3 hari</b>. Tekan tombol di bawah untuk melanjutkan ke akunmu.'}</p><button id="rvVioB" disabled>Terima</button></div>`;
 d.querySelector('.vrs').textContent=v.r||'Kamu melanggar aturan Pickare.';d.querySelector('.vby').textContent='Diberikan oleh '+(v.by||'staf')+' · '+dt;
 document.body.appendChild(d);const bt=ID('rvVioB'),lbl=v.ban?'Terima & keluar':'Terima & lanjutkan';let c=3;bt.textContent=lbl+' ('+c+')';
 const iv=setInterval(()=>{if(!document.body.contains(d)){clearInterval(iv);return}c--;if(c<=0){clearInterval(iv);bt.disabled=false;bt.textContent=lbl}else bt.textContent=lbl+' ('+c+')'},1000);
 bt.onclick=()=>{if(bt.disabled||!me)return;v.ack=1;const nm=me.name,bb=v.ban&&banOf(me);if(v.ban)me.viol.forEach(x=>x.done=1);save();d.remove();if(bb&&window.spDevBan)window.spDevBan(nm,bb);if(v.ban){try{act.out()}catch(e){}try{window.spBanCheck&&window.spBanCheck()}catch(e){}}else rf()}};
RV.vlH=()=>{const L=Object.keys(users).filter(k=>{const u=users[k];return u&&!u.rm&&act_(u).length}).map(k=>{const a=act_(users[k]);return `<div class="card ur2"><div class="ur2h"><b>${esc(k)}</b><span class="pill" style="font-size:12px">${a.length}/2</span></div><div class="rby">${esc(a[a.length-1].r)}</div><div class="rac"><button class="btn sm o" data-a="vlx" data-v="${esc(k)}">Hapus 1 pelanggaran</button></div></div>`}).join('');
 return `<div class="card"><label>Username pemain</label><input type="text" id="vl_u" maxlength="20" autocomplete="off" autocapitalize="off"><label>Alasan pelanggaran</label><input type="text" id="vl_r" maxlength="120"><div style="font-size:12px;margin:-6px 0 8px">Maks 2 pelanggaran. Ke-2 = akun otomatis diblokir 3 hari.</div><button class="btn w o" data-a="vlgo">Beri pelanggaran</button></div>`+(L||'<div class="empty2"><p style="margin:0">Belum ada pelanggaran aktif di perangkat ini.</p></div>')};
const find=n=>Object.keys(users).find(k=>k.toLowerCase()==String(n).toLowerCase())||n;
/* notifikasi native */
const NT=(()=>{const C=()=>window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications,K=()=>window.cordova&&cordova.plugins&&cordova.plugins.notification&&cordova.plugins.notification.local,B=()=>{const a=window.Android||window.AndroidBridge||window.ShinpoAndroid;return a&&(a.showNotification||a.notify)?a:null};let n=Math.floor(Math.random()*1e5);
 const ask=async()=>{try{if(C())await C().requestPermissions();else if(K()&&K().requestPermission)K().requestPermission(()=>{});else if(window.Notification&&Notification.permission==='default')await Notification.requestPermission()}catch(e){}};
 const show=async(t,b)=>{t=String(t).slice(0,60);b=String(b||'').slice(0,160);const id=(++n)%2147483647;
  try{if(C()){await C().schedule({notifications:[{id,title:t,body:b,schedule:{at:new Date(Date.now()+400)}}]});return 'capacitor'}}catch(e){}
  try{if(K()){K().schedule({id,title:t,text:b,foreground:true});return 'cordova'}}catch(e){}
  try{const a=B();if(a){(a.showNotification||a.notify).call(a,t,b);return 'bridge'}}catch(e){}
  try{if(window.Notification&&Notification.permission==='granted'){try{const r=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();if(r){await r.showNotification(t,{body:b});return 'sw'}}catch(e){}new Notification(t,{body:b});return 'web'}}catch(e){}
  try{navigator.vibrate&&navigator.vibrate(120)}catch(e){}return 'none'};
 return{ask,show}})();
let prev=null,who='';
setInterval(()=>{if(typeof me==='undefined'||!me){who='';prev=null;return}const cur={};(me.notes||[]).slice(0,20).forEach(x=>{if(x&&x.new)cur[x.t]=(cur[x.t]||0)+1});
 if(who!==me.name||!prev){who=me.name;prev=cur;return}for(const t in cur)if(cur[t]>(prev[t]||0))NT.show('Pickare',t);prev=cur},2000);
document.addEventListener('pointerdown',()=>NT.ask(),{once:true});
setInterval(RV.vchk,3000);
const _e=enter;enter=function(){const r=_e.apply(this,arguments);setTimeout(()=>{RV.vchk();NT.ask()},1200);return r};
Object.assign(act,{
 vlgo(){if(!staff())return;const nm=ID('vl_u').value.trim(),r=ID('vl_r').value.trim();if(!nm||r.length<3)return toast('Isi username & alasan (min 3 huruf)');const k=find(nm),u=users[k];
  if(/^(owner|admin|coowner|co-owner)$/i.test(k)||k.toLowerCase()==me.name.toLowerCase())return toast('Tidak bisa untuk akun ini');if(u&&!okT(u))return toast('Tidak diizinkan');
  if(u&&!u.rm){RV.viol(u,rd(),r,me.name);toast('Pelanggaran diberikan ke '+k)}else if(window.spSendCmd)window.spSendCmd(k,'viol',{id:rd(),reason:r},0);else return toast('Perintah belum bisa dikirim');rf()},
 vlx(v){const u=users[v];if(!staff()||!u)return;if(u.rm&&window.spSendCmd)window.spSendCmd(v,'violx',{},0);else RV.violx(u);rf()},
 ntest(){NT.ask();NT.show('Pickare','Tes notifikasi 🔔').then(m=>toast(m=='none'?'Notifikasi native belum terhubung ke APK':'Terkirim via: '+m))}});
})();
